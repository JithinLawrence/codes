/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Question;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author Libeesh
 */
public class QuestionListView {

    private final Integer questionId;
    private final String title;
    private final String description;
    private final String imageUrl;
    private final Integer mark;
    private final String category;
    private final String group;
    private final String level;
    private final byte status;
    @Json.DateTimeFormat
    private final Date createDate;
    @Json.DateTimeFormat
    private final Date updateDate;
    private final Long createdBy;
    private final String createdUser;

    public QuestionListView(Question question) {
        this.questionId = question.getQuestionId();
        this.title = question.getTitle();
        this.description = question.getDescription();
        this.imageUrl = question.getImageUrl();
        this.mark = question.getMark();
        this.category = null != question.getCategory() ? question.getCategory().getName() : null;
//        this.group = null != question.getGrade()? question.getGrade().getName() : null;
        this.group = "";
        this.level = null != question.getQuestionLevel()? question.getQuestionLevel().getName() : null;
        this.status = question.getStatus();
        this.createDate = question.getCreateDate();
        this.updateDate = question.getUpdateDate();
        this.createdBy = question.getUser().getUserId();
        this.createdUser = (question.getUser().getFirstName()+" "+ question.getUser().getLastName());
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Integer getMark() {
        return mark;
    }

    public String getCategory() {
        return category;
    }

    public String getGroup() {
        return group;
    }

    public String getLevel() {
        return level;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public String getCreatedUser() {
        return createdUser;
    }
}
