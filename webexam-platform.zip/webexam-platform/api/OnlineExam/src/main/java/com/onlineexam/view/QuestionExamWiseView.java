/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.Question;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class QuestionExamWiseView {
    private final Integer examQuestionId;
    private final boolean checkedStatus;
    private final Integer questionId;
    private final String title;
    private final String description;
    private final String imageUrl;
    private final Long questionBankId;
    private final String questionBank;
    private final Long gradeId;
    private final String grade;
    private final Long categoryId;
    private final String category;
    private final Long questionTypeId;
    private final String questionType;
    private final Long questionLevelId;
    private final String questionLevel;
    private final Long createdBy;
    private final Integer mark;
    private final String answer;
    private final String options;
    private final byte status;
    @Json.DateTimeFormat
    private final Date createDate;
    @Json.DateTimeFormat
    private final Date updateDate;

    public QuestionExamWiseView(Question question, ExamQuestion examQuestion) {
        this.examQuestionId = examQuestion == null ? null : examQuestion.getExamQuestionId();
        this.checkedStatus = examQuestion != null;
        this.questionId = question.getQuestionId();
        this.title = question.getTitle();
        this.description = question.getDescription();
        this.imageUrl = question.getImageUrl();
//        this.questionBankId = question.getQuestionBank().getQuestionBankId();
//        this.questionBank = question.getQuestionBank().getTitle();
//        this.gradeId = question.getGrade().getGradeId();
//        this.grade = question.getGrade().getName();
        this.questionBankId = 0L;
        this.questionBank = "";
        this.gradeId = 0L;
        this.grade = "";
        this.categoryId = question.getCategory().getCategoryId();
        this.category = question.getCategory().getName();
        this.questionTypeId = question.getQuestionType().getQuestionTypeId();
        this.questionType = question.getQuestionType().getName();
        this.questionLevelId = question.getQuestionLevel().getQuestionLevelId();
        this.questionLevel = question.getQuestionLevel().getName();
        this.createdBy = question.getUser().getUserId();
        this.mark = question.getMark();
        this.answer = question.getAnswer();
        this.options = question.getOptions();
        this.status = question.getStatus();
        this.createDate = question.getCreateDate();
        this.updateDate = question.getUpdateDate();
    }

    public Integer getExamQuestionId() {
        return examQuestionId;
    }

    public boolean isCheckedStatus() {
        return checkedStatus;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Long getQuestionBankId() {
        return questionBankId;
    }

    public String getQuestionBank() {
        return questionBank;
    }

    public Long getGradeId() {
        return gradeId;
    }

    public String getGrade() {
        return grade;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public String getCategory() {
        return category;
    }

    public Long getQuestionTypeId() {
        return questionTypeId;
    }

    public String getQuestionType() {
        return questionType;
    }

    public Long getQuestionLevelId() {
        return questionLevelId;
    }

    public String getQuestionLevel() {
        return questionLevel;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public Integer getMark() {
        return mark;
    }

    public String getAnswer() {
        return answer;
    }

    public String getOptions() {
        return options;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    
    
    
}
