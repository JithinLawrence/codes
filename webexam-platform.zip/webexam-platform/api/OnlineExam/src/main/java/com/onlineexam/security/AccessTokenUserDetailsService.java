/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.security;

import com.onlineexam.entity.User;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.security.util.InvalidTokenException;
import com.onlineexam.security.util.TokenExpiredException;
import com.onlineexam.security.util.TokenGenerator;
import com.onlineexam.security.util.TokenGenerator.Status;
import com.onlineexam.util.LanguageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

/**
 *
 * @author nirmal
 */
public class AccessTokenUserDetailsService implements AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> {

    public static final String PURPOSE_ACCESS_TOKEN = "ACCESS_TOKEN";

    @Autowired
    private TokenGenerator tokenGenerator;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LanguageUtil languageUtil;

    @Override
    public UserDetails loadUserDetails(PreAuthenticatedAuthenticationToken token) throws UsernameNotFoundException {
        if (!PURPOSE_ACCESS_TOKEN.equals(token.getCredentials())) {
            throw new UsernameNotFoundException(languageUtil.getTranslatedText("invalid.credantials", null, "en"));
        }

        final Status status;
        try {
            status = tokenGenerator.verify(PURPOSE_ACCESS_TOKEN, token.getPrincipal().toString());
        } catch (InvalidTokenException e) {
            throw new UsernameNotFoundException(languageUtil.getTranslatedText("access.token.expired", null, "en"), e);
        } catch (TokenExpiredException e) {
            throw new UsernameNotFoundException(languageUtil.getTranslatedText("access.token.expired", null, "en"), e);
        }

        long userId = Long.parseLong(status.data);
        User user = userRepository.findByUserId(userId).orElse(null);
        if (User.Status.ACTIVE.value != user.getStatus()) {
            throw new UsernameNotFoundException(languageUtil.getTranslatedText("access.token.expired", null, "en"));
        }

        return new AccessTokenUserDetails(userId, user.getRole(), null, null);
    }
}
