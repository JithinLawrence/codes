/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.entity.ExamResult;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.ImageAnswerForm;
import com.onlineexam.form.ImageUploadForm;
import com.onlineexam.form.MultipleAnswerForm;
import com.onlineexam.form.MultipleImageUploadForm;
import com.onlineexam.form.SingleAnswerForm;
import com.onlineexam.form.TextAnswerForm;
import com.onlineexam.service.ExamResultService;
import com.onlineexam.service.ExamService;
import com.onlineexam.service.QuestionService;
import com.onlineexam.service.UserService;
import com.onlineexam.view.CategoryDashboardListView;
import com.onlineexam.view.ExamQuestionAnswerView;
import com.onlineexam.view.ExamQuestionView;
import com.onlineexam.view.ExamResultsListView;
import com.onlineexam.view.FileUploadView;
import com.onlineexam.view.MultipleFileUploadView;
import com.onlineexam.view.QuestionAnswerView;
import java.util.Date;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author simon
 */
@RestController
@RequestMapping("/admin/preview_exam_answer")
public class PreviewExamAnswerController {

    @Autowired
    private UserService userService;

    @Autowired
    private ExamResultService examResultService;

    @Autowired
    ExamService examService;
    
    @Autowired
    QuestionService questionService;

    @GetMapping("/status/{examId}/{scheduleId}")
    public byte status(@PathVariable("examId") long examId, @PathVariable("scheduleId") long scheduleId) {

        return examService.getAnswerStatus(examId, userService.currentUser().getUserId(), scheduleId);
    }

    @GetMapping("/get_agreement/{examId}")
    public String getAgreement(@PathVariable("examId") long examId) {

        return examService.getAgreement(examId);
    }

    @GetMapping("/get_name/{examId}")
    public String getNmae(@PathVariable("examId") long examId) {

        return examService.getName(examId);
    }

    @GetMapping("/start_exam/{examId}/{scheduleId}")
    public Long startExam(@PathVariable("examId") long examId, @PathVariable("scheduleId") long scheduleId) {
        return examResultService.startExam(examId, userService.currentUser().getUserId(), scheduleId).getExamResultId();
    }
    
    @GetMapping("/submit_exam/{examId}/{scheduleId}")
    public Long submitExam(@PathVariable("examId") long examId, @PathVariable("scheduleId") long scheduleId) {
        return examResultService.submitExam(examId, userService.currentUser().getUserId(), scheduleId).getExamResultId();
    }

    @GetMapping("/get_categories/{examId}")
    public List<CategoryDashboardListView> getCatagories(
            @PathVariable("examId") long examId,
            @RequestParam(value = "type", required = false) String type
    ) {
        if(type == null || type.trim().isEmpty()){
            type = "list";
        }
        return examService.getExamCatagoryList(examId, type);
    }

    @GetMapping("/get_exam_question/{questionId}")
    public ExamQuestionAnswerView getExamQuestion(
            @PathVariable("questionId") Integer questionId,
            @RequestParam(value = "type", required = false) String type
    ) {
        if(type == null || type.trim().isEmpty()){
            type = "list";
            return examService.getExamQuestion(questionId);
        } else {
            return examService.getExamQuestion(questionId, type);
        }
    }

    @GetMapping("/get_question/{questionId}")
    public QuestionAnswerView getQuestion(@PathVariable("questionId") Integer questionId) {
        return examService.getQuestion(questionId);
    }
    
    @GetMapping("/get_start_time/{examId}/{scheduleId}")
    public Date getStartTime(@PathVariable("examId") Integer examId,@PathVariable("scheduleId") Integer scheduleId) {
        return examResultService.getStartTime(examId,userService.currentUser().getUserId(), scheduleId);
    }
    
    @GetMapping("/get_duration/{examId}")
    public int getDuration(@PathVariable("examId") Integer examId) {
        return examService.getDuration(examId);
    }
    
    @PostMapping("/single_answer")
    public boolean addSingleAnswer(@Valid @RequestBody SingleAnswerForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.addSingleAnswer(form);
    }
    
    @PostMapping("/multiple_answer")
    public boolean addMultipleAnswer(@Valid @RequestBody MultipleAnswerForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.addMultipleAnswer(form);
    }
    
    @PostMapping("/text_answer")
    public boolean addTextAnswer(@Valid @RequestBody TextAnswerForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.addTextAnswer(form);
    }
    
    @PostMapping("/imageupload")
    public MultipleFileUploadView imageUpload(
            @Valid MultipleImageUploadForm uploadForm, BindingResult bindingResult){
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return questionService.imageUpload(uploadForm, 2);
    }
    
    @PostMapping("/image_answer")
    public boolean addImageAnswer(@Valid @RequestBody ImageAnswerForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.addImageAnswer(form);
    }
    
    
    


}
