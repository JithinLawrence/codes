/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.ExamQuestionResultText;
import com.onlineexam.entity.ExamResult;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import javax.transaction.Transactional;

/**
 *
 * @author jinu
 */
public interface ExamResultTextRepository extends Repository<ExamQuestionResultText, Integer>{
    
    ExamQuestionResultText save(ExamQuestionResultText exqr);
    
    Integer countByExamResultAndIsCorrect(ExamResult examResult, byte isCorrect);
    
    ExamQuestionResultText findByExamResultAndQuestion(ExamResult examResult, ExamQuestion question);

    @Transactional
    @Modifying
    @Query(value = "update exam_question_result_text set is_correct = ?1, mark = ?2 where exam_question_id = ?3", nativeQuery = true)
    void updateExamQuestionResultTextBoxItems(Integer is_correct, Integer mark, Integer examQuestionId);


}
