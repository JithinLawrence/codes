package com.onlineexam.service.impl;

import com.onlineexam.entity.*;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.exception.UnauthorizedException;
import com.onlineexam.form.ExamEvaluateForm;
import com.onlineexam.form.ExamQuestionUpdateForm;
import com.onlineexam.form.ExamScheduleForm;
import com.onlineexam.repository.*;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.service.ExamEvaluationService;
import com.onlineexam.view.ExamEvaluationView;
import com.onlineexam.view.ExamResultView;
import com.onlineexam.view.ExamScheduleView;
import com.onlineexam.view.JsonObjectView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ExamEvaluationServiceImpl  implements ExamEvaluationService {

    @Autowired
    ExamResultRepository examResultRepository;

    @Autowired
    ExamRepository examRepository;

    @Autowired
    ExamScheduleRepository examScheduleRepository;

    @Autowired
    ExamScheduleRepository scheduleRepository;

    @Autowired
    ExamQuestionRepository examQuestionRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ExamResultTextRepository examResultTextRepository;

    @Autowired
    ExamResultRadioRepository examResultRadioRepository;

    @Autowired
    ExamResultImageRepository examResultImageRepository;

    @Autowired
    ExamResultCheckboxRepository examResultCheckboxRepository;

    @Autowired
    QuestionRepository questionRepository;


    @Override
    public HashMap<String, String> getExamResult(Long examId, Long userId, Long scheduleId) {
        Optional<User> user = userRepository.findByUserIdAndStatus(userId, User.Status.ACTIVE.value);
        Optional<Exam> exam = examRepository.findByExamId(examId);
        Exam examEntity = exam.get();
        int hour = 0, answeredCorrect = 0;
        String[] times = null;
        HashMap<String, String> examResult = new HashMap<String, String>();
        examResult.put("examName", examEntity.getName());
        String examSchedule = examScheduleRepository.findByExamAndStatus(examEntity, Schedule.Status.ACTIVE.value, scheduleId);
        examResult.put("examDate", examSchedule);
        Integer min = examResultRepository.findExamSchedule(examId);
        if (min != 0 && min > 60) {
            while (min > 60) {
                hour = hour + min / 60;
                min = min % 60;
            }
            examResult.put("durationHour", Integer.toString(hour));
            examResult.put("durationMin", Integer.toString(min));
        } else {
            examResult.put("durationHour", "0");
            examResult.put("durationMin", Integer.toString(min));
        }
        examResult.put("durationHour", Integer.toString(hour));
        examResult.put("durationMin", Integer.toString(min));

        examResult.put("questions", examQuestionRepository.countByStatusAndEditingStatusAndExam(ExamQuestion.Status.ACTIVE.value, ExamQuestion.EditingStatus.SAVED.value, examEntity).toString());
        examResult.put("marks", examEntity.getTotalMark().toString());

        ExamResult examRslt = examResultRepository.findByExamAndUser(examEntity, user.get());

        Integer textCount = examResultTextRepository.countByExamResultAndIsCorrect(examRslt, ExamQuestionResultText.IsCorrect.CORRECT.value);
        Integer radioCount = examResultRadioRepository.countByExamResultAndIsCorrect(examRslt, ExamQuestionResultText.IsCorrect.CORRECT.value);
        Integer imageCount = examResultImageRepository.countByExamResultAndIsCorrect(examRslt,ExamQuestionResultText.IsCorrect.CORRECT.value);
        Integer checkboxCount = examResultCheckboxRepository.countByExamResultId(examRslt.getExamResultId());

        if (textCount != null) {
            answeredCorrect = answeredCorrect + textCount;
        }
        if (radioCount != null) {
            answeredCorrect = answeredCorrect + radioCount;
        }
        if (imageCount != null) {
            answeredCorrect = answeredCorrect + imageCount;
        }
        if (checkboxCount != null) {
            answeredCorrect = answeredCorrect + checkboxCount;
        }

        examResult.put("answeredCorrect", Integer.toString(answeredCorrect));
        examResult.put("scoredMark", Integer.toString(examRslt.getMark()));

        return examResult;
    }

    @Override
    public List<ExamEvaluationView> getExamQuestionEvaluation(Long examId, Long userId) {
        Optional<User> user = userRepository.findByUserIdAndStatus(userId, User.Status.ACTIVE.value);
        Optional<Exam> exam = examRepository.findByExamId(examId);
        Exam examEntity = exam.get();
        ExamResult examRslt = examResultRepository.findByExamAndUser(examEntity, user.get());
        List<ExamEvaluationView> examEvaluationViewList = new ArrayList<ExamEvaluationView>();
        List<ExamQuestion> examQuestions = examQuestionRepository.findByExamOrderByQuestionOrder(examEntity);
        for (ExamQuestion question : examQuestions) {
            Optional<Question> qstn = questionRepository.findByQuestionId(question.getQuestion().getQuestionId());
            if (question.getQuestionType().getQuestionTypeId() == 1 || question.getQuestionType().getQuestionTypeId() == 3) {
                JSONArray arr = null;
                List<JsonObjectView> jsonList = new ArrayList<JsonObjectView>();
                ExamQuestionResultRadio examQuestionResultRadio = examResultRadioRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    if(question.getQuestionType().getQuestionTypeId() == 1){
                        JSONObject locs = new JSONObject(question.getOptions());
                        arr = locs.getJSONArray("options");

                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject jsonDrink = arr.getJSONObject(i);
                            Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                            Integer id = jsonDrink.getInt("id");
                            String value = jsonDrink.getString("value");
                            JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                            jsonList.add(jsonObjectView);
                        }
                    }else if(question.getQuestionType().getQuestionTypeId() == 3){
                        JSONObject locs = new JSONObject(question.getOptions());
                        arr = locs.getJSONArray("options");

                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject jsonDrink = arr.getJSONObject(i);
                            Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                            Integer id = jsonDrink.getInt("id");
                            String value = jsonDrink.getString("src");
                            JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                            jsonList.add(jsonObjectView);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (examQuestionResultRadio != null) {
                    examEvaluationViewList.add(new ExamEvaluationView(examQuestionResultRadio.getExamResult().getExamResultId(),
                            examQuestionResultRadio.getQuestion().getQuestion().getQuestionId(),
                            question.getQuestionType().getQuestionTypeId(),
                            examQuestionResultRadio.getAnswer().toString(),
                            examQuestionResultRadio.getCorrectAnswer().toString(),
                            examQuestionResultRadio.getMark(),
                            jsonList,
                            question.getTitle(),0));
                }

            } else if (question.getQuestionType().getQuestionTypeId() == 2 || question.getQuestionType().getQuestionTypeId() == 4) {
                JSONArray arr = null;
                List<JsonObjectView> jsonList = new ArrayList<JsonObjectView>();
                ExamQuestionResultCheckbox examQuestionResultChk = examResultCheckboxRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    if(question.getQuestionType().getQuestionTypeId() == 2){
                        JSONObject locs = new JSONObject(question.getOptions());
                        arr = locs.getJSONArray("options");

                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject jsonDrink = arr.getJSONObject(i);
                            Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                            Integer id = jsonDrink.getInt("id");
                            String value = jsonDrink.getString("value");
                            JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                            jsonList.add(jsonObjectView);
                        }
                    }else if(question.getQuestionType().getQuestionTypeId() == 4){
                        JSONObject locs = new JSONObject(question.getOptions());
                        arr = locs.getJSONArray("options");

                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject jsonDrink = arr.getJSONObject(i);
                            Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                            Integer id = jsonDrink.getInt("id");
                            String value = jsonDrink.getString("src");
                            JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                            jsonList.add(jsonObjectView);
                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (examQuestionResultChk != null) {
                    examEvaluationViewList.add(new ExamEvaluationView(examQuestionResultChk.getExamResult().getExamResultId(),
                            examQuestionResultChk.getQuestion().getQuestion().getQuestionId(),
                            question.getQuestionType().getQuestionTypeId(),
                            examQuestionResultChk.getAnswer().toString(),
                            examQuestionResultChk.getCorrectAnswer().toString(),
                            examQuestionResultChk.getMark(),
                            jsonList,
                            question.getTitle(),0));
                }
            }else if(question.getQuestionType().getQuestionTypeId() == 5) {
                JSONArray arr = null;
                List<JsonObjectView> jsonList = new ArrayList<JsonObjectView>();
                ExamQuestionResultText examQuestionResultTxt = examResultTextRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    JSONObject locs = new JSONObject(question.getOptions());
                    arr = locs.getJSONArray("options");

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject jsonDrink = arr.getJSONObject(i);
                        Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                        Integer id = jsonDrink.getInt("id");
                        String value = jsonDrink.getString("value");
                        JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                        jsonList.add(jsonObjectView);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (examQuestionResultTxt != null) {
                    examEvaluationViewList.add(new ExamEvaluationView(examQuestionResultTxt.getExamResult().getExamResultId(),
                            examQuestionResultTxt.getQuestion().getQuestion().getQuestionId(),
                            question.getQuestionType().getQuestionTypeId(),
                            examQuestionResultTxt.getAnswer().toString(),
                            examQuestionResultTxt.getCorrectAnswer().toString(),
                            examQuestionResultTxt.getMark(),
                            jsonList,
                            question.getTitle(),0));
                }
            } else if (question.getQuestionType().getQuestionTypeId() == 6) {
                JSONArray arr = null;
                List<JsonObjectView> jsonList = new ArrayList<JsonObjectView>();
                ExamQuestionResultImage examQuestionResultImg = examResultImageRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    JSONObject locs = new JSONObject(question.getOptions());
                    arr = locs.getJSONArray("options");

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject jsonDrink = arr.getJSONObject(i);
                        Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                        Integer id = jsonDrink.getInt("id");
                        String value = jsonDrink.getString("src");
                        JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                        jsonList.add(jsonObjectView);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (examQuestionResultImg != null) {
                    examEvaluationViewList.add(new ExamEvaluationView(examQuestionResultImg.getExamResult().getExamResultId(),
                            examQuestionResultImg.getQuestion().getQuestion().getQuestionId(),
                            question.getQuestionType().getQuestionTypeId(),
                            examQuestionResultImg.getAnswer().toString(),
                            examQuestionResultImg.getCorrectAnswer().toString(),
                            examQuestionResultImg.getMark(),
                            jsonList,
                            question.getTitle(),0));
                }
            }

        }
        return examEvaluationViewList;
    }


    @Override
    public ExamResultView edit(ExamEvaluateForm form, Long examId, Long userId) {

        System.out.println("userId"+userId);
        System.out.println("examId"+examId);

        System.out.println("totalmarks"+form.getTotalMarks());
       // System.out.println("marks"+form.getMarks());
       // form.getMarks().removeIf(Objects::isNull);
//        List<ExamEvaluateForm.ExamEvaluationInnerForm> listEvaluateInner= form.getExamEvaluationInnerForm();
//        listEvaluateInner.forEach(str-> System.out.println("id:"+str.getId()+" value:"+str.getValue()+" typeid:"+str.getTypeId()));
//        for (ExamEvaluateForm.ExamEvaluationInnerForm examEvaluateForm : form.getExamEvaluationInnerForm()) {
//
//
//        }


//        for (Map.Entry<String,String> entry : map.entrySet()) {
//            System.out.println(entry.getKey() + ":" + entry.getValue());
//        }

        //System.out.println("marks"+form.getMarks());
        Optional<Exam> exam = examRepository.findByExamId(examId);
        Optional<User> user = userRepository.findByUserIdAndStatus(userId, User.Status.ACTIVE.value);
        Exam examEntity = exam.get();
        ExamResult examRslt = examResultRepository.findByExamAndUser(examEntity, user.get());

        List<ExamQuestion> examQuestions = examQuestionRepository.findByExamOrderByQuestionOrder(examEntity);
        examResultRepository.updateExamStatus(examId, userId, examRslt.getSchedule().getScheduleId(),examRslt.getStatus(),form.getTotalMarks());

        for (ExamQuestion question : examQuestions) {
            System.out.println("qqq"+question.getExamQuestionId());
            if (question.getQuestionType().getQuestionTypeId() == 1 || question.getQuestionType().getQuestionTypeId() == 3){
                ExamQuestionResultRadio examQuestionResultRadio = examResultRadioRepository.findByExamResultAndQuestion(examRslt, question);
                try{
                if(question.getQuestionType().getQuestionTypeId() == 1){

                    System.out.println("RadioQ2"+examQuestionResultRadio.getExamQuestionResultRadioId());

                    for (ExamEvaluateForm.ExamEvaluationInnerForm examEvaluateForm : form.getExamEvaluationInnerForm()) {

                     if(examEvaluateForm.getTypeId()==1){

                         System.out.println("id:"+examEvaluateForm.getId()+" value:"+examEvaluateForm.getValue()+" typeid:"+examEvaluateForm.getTypeId());
                         examResultRadioRepository.updateExamQuestionResultRadioItems(0,examEvaluateForm.getValue(),examQuestionResultRadio.getQuestion().getExamQuestionId());
                      }

                    }

                }else if(question.getQuestionType().getQuestionTypeId() == 3){

                    System.out.println("RadioQ4"+examQuestionResultRadio.getExamQuestionResultRadioId());

                    for (ExamEvaluateForm.ExamEvaluationInnerForm examEvaluateForm : form.getExamEvaluationInnerForm()) {

                        if(examEvaluateForm.getTypeId()==3){

                            examResultRadioRepository.updateExamQuestionResultRadioItems(0,examEvaluateForm.getValue(),examQuestionResultRadio.getQuestion().getExamQuestionId());
                        }

                    }


                }}catch(Exception e){
                    e.printStackTrace();
                }

            } else if (question.getQuestionType().getQuestionTypeId() == 2 || question.getQuestionType().getQuestionTypeId() == 4) {
                ExamQuestionResultCheckbox examQuestionResultChk = examResultCheckboxRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    if (question.getQuestionType().getQuestionTypeId() == 2) {
                        System.out.println("CheckQ2"+examQuestionResultChk.getExamQuestionResultCheckboxId());
                        for (ExamEvaluateForm.ExamEvaluationInnerForm examEvaluateForm : form.getExamEvaluationInnerForm()) {

                            if(examEvaluateForm.getTypeId()==2){

                                examResultCheckboxRepository.updateExamQuestionResultCheckboxItems(0,examEvaluateForm.getValue(),examQuestionResultChk.getQuestion().getExamQuestionId());
                            }

                        }


                    } else if (question.getQuestionType().getQuestionTypeId() == 4) {
                        System.out.println("CheckQ4"+examQuestionResultChk.getExamQuestionResultCheckboxId());
                        for (ExamEvaluateForm.ExamEvaluationInnerForm examEvaluateForm : form.getExamEvaluationInnerForm()) {

                            if(examEvaluateForm.getTypeId()==4){

                                examResultCheckboxRepository.updateExamQuestionResultCheckboxItems(0,examEvaluateForm.getValue(),examQuestionResultChk.getQuestion().getExamQuestionId());
                            }

                        }



                    }
                }catch(Exception e){
                    e.printStackTrace();
                }

            }else if (question.getQuestionType().getQuestionTypeId() == 5) {
                ExamQuestionResultText examQuestionResultTxt = examResultTextRepository.findByExamResultAndQuestion(examRslt, question);
                System.out.println("TextQ1"+examQuestionResultTxt.getQuestion().getExamQuestionId());
                System.out.println("TextQ2"+examQuestionResultTxt.getExamQuestionResultTextId());

                for (ExamEvaluateForm.ExamEvaluationInnerForm examEvaluateForm : form.getExamEvaluationInnerForm()) {

                    if(examEvaluateForm.getTypeId()==5){

                        examResultTextRepository.updateExamQuestionResultTextBoxItems(0,examEvaluateForm.getValue(),examQuestionResultTxt.getQuestion().getExamQuestionId());
                    }

                }



            }else if (question.getQuestionType().getQuestionTypeId() == 6) {
                ExamQuestionResultImage examQuestionResultImg = examResultImageRepository.findByExamResultAndQuestion(examRslt, question);
                System.out.println("ImageQ2"+examQuestionResultImg.getExamQuestionResultImageId());
                for (ExamEvaluateForm.ExamEvaluationInnerForm examEvaluateForm : form.getExamEvaluationInnerForm()) {

                    if(examEvaluateForm.getTypeId()==6){

                        examResultImageRepository.updateExamQuestionResultImageRepoItems(0,examEvaluateForm.getValue(),examQuestionResultImg.getQuestion().getExamQuestionId());
                    }

                }


            }








        }



        return null;
    }

}
