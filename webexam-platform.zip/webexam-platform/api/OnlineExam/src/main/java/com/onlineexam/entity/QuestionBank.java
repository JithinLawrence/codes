/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import com.onlineexam.form.QuestionBankForm;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author sanal
 */
@Entity
public class QuestionBank {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }
    
    public static enum EditingStatus {
        TEMP_SAVE((byte) 0),
        SAVED((byte) 1);

        public final byte value;

        private EditingStatus(byte value) {
            this.value = value;
        }
    }
    
    public static enum SharedStatus {
        UNSHARED((byte) 0),
        SHARED((byte) 1);

        public final byte value;

        private SharedStatus(byte value) {
            this.value = value;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long questionBankId;
    private String title;
    private String description;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    private Organization organization;
    private byte editingStatus;
    private byte status;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User user;
    private byte sharedStatus;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shared_by")
    private User sharedUser;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    
    public QuestionBank() {
    }

    public QuestionBank(String title, String description, User user, byte editingStatus, Organization organization) {
        this.title = title;
        this.description = description;
        this.user = user;
        this.organization = organization;
        this.status = Status.ACTIVE.value;
        this.editingStatus = editingStatus;
        this.sharedStatus = QuestionBank.SharedStatus.UNSHARED.value;
        this.sharedUser = null;
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }
    
    public QuestionBank update(QuestionBankForm form){
        this.title = form.getTitle();
        this.description = form.getDescription();
        this.updateDate = new Date();
        return this;
    }
    
    public QuestionBank delete(QuestionBank questionBank){
        questionBank.setStatus(Status.INACTIVE.value);
        questionBank.setUpdateDate(new Date());
        return this;
    }

    public Long getQuestionBankId() {
        return questionBankId;
    }

    public void setQuestionBankId(Long questionBankId) {
        this.questionBankId = questionBankId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public byte getStatus() {
        return status;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public byte getEditingStatus() {
        return editingStatus;
    }

    public void setEditingStatus(byte editingStatus) {
        this.editingStatus = editingStatus;
    }

    public byte getSharedStatus() {
        return sharedStatus;
    }

    public User getSharedUser() {
        return sharedUser;
    }

    public void setSharedStatus(byte sharedStatus) {
        this.sharedStatus = sharedStatus;
    }

    public void setSharedUser(User sharedUser) {
        this.sharedUser = sharedUser;
    }
}
