/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

/**
 *
 * @author simon
 */
public class OrganizationListView {
    private long organizationId;
    private String organizationName; 

    public long getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(long organizationId) {
        this.organizationId = organizationId;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public OrganizationListView(long organizationId, String organizationName) {
        this.organizationId = organizationId;
        this.organizationName = organizationName;
    }    

}
