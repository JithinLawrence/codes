/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Exam;
import com.onlineexam.entity.Schedule;
import com.onlineexam.entity.ScheduleAssignCandidate;
import com.onlineexam.entity.User;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author jinu
 */
public interface ScheduleAssignCandidateRepository extends Repository<ScheduleAssignCandidate, Long>{

    @Query(value = "SELECT sc.* FROM schedule_assign_candidate as sc WHERE sc.status in ?1 AND sc.user_id=?2 ", nativeQuery = true)
    List<ScheduleAssignCandidate> getExamListByUser(byte[] status, Long user);

    Long countByExamAndRegisterStatusAndStatus(Exam e, byte registerStatus, byte status);

//    List<ScheduleAssignCandidate> save(ScheduleAssignCandidate candidate);

    List<ScheduleAssignCandidate> save(List<ScheduleAssignCandidate> candidates);
    
    ScheduleAssignCandidate save(ScheduleAssignCandidate scheduleAssignCandidate);
    
     @Query(value = "SELECT sc FROM ScheduleAssignCandidate as sc\n" +
                    " INNER JOIN Exam er on sc.exam.examId = er.examId\n" +
                    " WHERE er.status=?1 AND sc.status=?1 AND (er.name like %?2% OR er.description like %?2%) AND sc.user.userId=?3 ")
    Page<ScheduleAssignCandidate> getCandidateExamList(byte status, String search, Long user, Pageable page);
    
    ScheduleAssignCandidate findByScheduleAndExamAndUserAndStatus(Schedule schedule, Exam exam, User user, byte status);
    
    List<ScheduleAssignCandidate> findAllBySchedule(Schedule schedule);
    
    @Transactional
    @Modifying
    @Query(value = "UPDATE schedule_assign_candidate set status=0, register_status=0 WHERE schedule_id = ?1", nativeQuery = true)
    void deleteByScheduleId(Long scheduleId);
    
    @Transactional
    @Modifying
    @Query(value = "UPDATE schedule_assign_candidate set status=0, register_status=0 WHERE schedule_id = ?1 AND user_id=?2", nativeQuery = true)
    void deleteByScheduleIdAndUserId(Long scheduleId, Long userId);
}