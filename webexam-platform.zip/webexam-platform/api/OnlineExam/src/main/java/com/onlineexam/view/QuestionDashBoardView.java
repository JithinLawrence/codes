/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Category;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class QuestionDashBoardView {

    private Integer questionId;
    private Boolean IsAnswered;

    public QuestionDashBoardView(Integer questionId, Boolean IsAnswered) {
        this.questionId = questionId;
        this.IsAnswered = IsAnswered;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public Boolean getIsAnswered() {
        return IsAnswered;
    }

    public void setIsAnswered(Boolean IsAnswered) {
        this.IsAnswered = IsAnswered;
    }
    

}
