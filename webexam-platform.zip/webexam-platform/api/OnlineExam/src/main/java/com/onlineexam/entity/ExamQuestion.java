/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author sanal
 */
@Entity
public class ExamQuestion {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }

    public static enum EditingStatus {
        SAVED((byte) 1),
        TEMP_SAVE((byte) 2),
        TEMP_UPDATE((byte) 3),
        TEMP_DELETE((byte) 4);

        public final byte value;

        private EditingStatus(byte value) {
            this.value = value;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer examQuestionId;
    private String title;
    private String description;
    private String imageUrl;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_id")
    private Exam exam;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_id")
    private Question question;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_type_id")
    private QuestionType questionType;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_level_id")
    private QuestionLevel questionLevel;
    private String answer;
    private String options;
    private Integer categoryOrder;
    private Integer questionOrder;
    private Integer mark;
    private byte status;
    private byte editingStatus;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    public ExamQuestion() {
    }

    public ExamQuestion(String title, String description, String imageUrl, 
            Exam exam, Question question, Category category, QuestionType questionType, QuestionLevel questionLevel, 
            String answer, String options, Integer categoryOrder, Integer questionOrder, Integer mark, byte status, byte editingStatus) {
        this.title = title;
        this.description = description;
        this.imageUrl = imageUrl;
        this.exam = exam;
        this.question = question;
        this.category = category;
        this.questionType = questionType;
        this.questionLevel = questionLevel;
        this.answer = answer;
        this.options = options;
        this.categoryOrder = categoryOrder;
        this.questionOrder = questionOrder;
        this.mark = mark;
        this.status = status;
        this.editingStatus = editingStatus;
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }
    
    public ExamQuestion update(Integer categoryOrder, Integer questionOrder, Integer mark){
        this.categoryOrder = categoryOrder;
        this.questionOrder = questionOrder;
        this.mark = mark;
        this.updateDate = new Date();
        return this;
    }
    
    public ExamQuestion savePermanent(ExamQuestion examQuestion){
        this.status = Status.ACTIVE.value;
        this.editingStatus = EditingStatus.SAVED.value;
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
        return this;
    }
    
    public ExamQuestion delete(ExamQuestion examQuestion){
        this.status = Status.INACTIVE.value;
        this.updateDate = new Date();
        return this;
    }
    
    public ExamQuestion tempDelete(ExamQuestion examQuestion){
        this.editingStatus = EditingStatus.TEMP_DELETE.value;
        return this;
    }

    public Integer getExamQuestionId() {
        return examQuestionId;
    }

    public void setExamQuestionId(Integer examQuestionId) {
        this.examQuestionId = examQuestionId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Exam getExam() {
        return exam;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }

    public Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public QuestionType getQuestionType() {
        return questionType;
    }

    public void setQuestionType(QuestionType questionType) {
        this.questionType = questionType;
    }

    public QuestionLevel getQuestionLevel() {
        return questionLevel;
    }

    public void setQuestionLevel(QuestionLevel questionLevel) {
        this.questionLevel = questionLevel;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getOptions() {
        return options;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    public Integer getCategoryOrder() {
        return categoryOrder;
    }

    public void setCategoryOrder(Integer categoryOrder) {
        this.categoryOrder = categoryOrder;
    }

    public Integer getQuestionOrder() {
        return questionOrder;
    }

    public void setQuestionOrder(Integer questionOrder) {
        this.questionOrder = questionOrder;
    }

    public Integer getMark() {
        return mark;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public byte getEditingStatus() {
        return editingStatus;
    }

    public void setEditingStatus(byte editingStatus) {
        this.editingStatus = editingStatus;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
    
    
}
