/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service;

import com.onlineexam.form.QuestionBankForm;
import com.onlineexam.util.Pager;
import com.onlineexam.view.QuestionBankListView;
import com.onlineexam.view.QuestionBankView;
import com.onlineexam.view.QuestionsQBWiseView;
import java.util.List;

/**
 *
 * @author sanal
 */
public interface QuestionBankService {
    void add(QuestionBankForm form, Long questionBankId);
    
    QuestionBankView edit(QuestionBankForm form, Long questionBankId);
    
    QuestionBankView delete(Long questionBankId);
    
    Pager<QuestionBankView> listQuestionBanks(String search, Integer limit, String sort, boolean type, Integer page);
    
    List<QuestionBankListView> listQuestionBanks();
    
    Pager<QuestionsQBWiseView> listQuestionsForQB(Long questionBankId, String search, Integer limit, String sort, 
            boolean type, Integer page, Integer categoryId, Integer groupId, Integer levelId);
    
    QuestionBankView initEdit(Long questionBankId);
}
