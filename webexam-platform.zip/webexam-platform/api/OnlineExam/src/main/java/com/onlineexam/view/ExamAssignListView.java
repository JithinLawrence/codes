/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.ScheduleAssignCandidate;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author simon
 */
public class ExamAssignListView {
    private long scheduleAssignId;
    private long examId;
    private long scheduleId;
    private String name;
    private String description;
    private Integer duration;
    private byte registerStatus;
    @Json.DateTimeFormat
    private Date startTime;
    

    
    public ExamAssignListView(long scheduleAssignId, long examId, long scheduleId, String name, String description, Integer duration, Date startTime,byte registerStatus) {
        this.scheduleAssignId = scheduleAssignId;
        this.examId = examId;
        this.scheduleId = scheduleId;
        this.name = name;
        this.description = description;
        this.duration = duration;
        this.startTime = startTime;
        this.registerStatus = registerStatus;
    }

    public ExamAssignListView(ScheduleAssignCandidate exam) {
        this.scheduleAssignId = exam.getScheduleAssignId();
        this.examId = exam.getExam().getExamId();
        this.scheduleId = exam.getSchedule().getScheduleId();
        this.name = exam.getExam().getName();
        this.description = exam.getExam().getDescription();
        this.duration = exam.getExam().getDuration();
        this.startTime = exam.getSchedule().getStartTime();
        this.registerStatus=exam.getRegisterStatus();
    }

    public byte getRegisterStatus() {
        return registerStatus;
    }

    public void setRegisterStatus(byte registerStatus) {
        this.registerStatus = registerStatus;
    }

    public long getScheduleAssignId() {
        return scheduleAssignId;
    }

    public void setScheduleAssignId(long scheduleAssignId) {
        this.scheduleAssignId = scheduleAssignId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public long getExamId() {
        return examId;
    }

    public void setExamId(long examId) {
        this.examId = examId;
    }

    public long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(long scheduleId) {
        this.scheduleId = scheduleId;
    }
    

}
