/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service;

import com.onlineexam.entity.ExamResult;
import com.onlineexam.util.Pager;
import com.onlineexam.view.ExamResultView;
import com.onlineexam.view.ExamResultsListView;
import java.util.HashMap;
import java.util.List;
import java.util.Date;

/**
 *
 * @author simon
 */
public interface ExamResultService {
    Pager<ExamResultsListView> getResultsList(String search, Integer limit, String sort, boolean type, Integer page, long userId);
    
    HashMap<String, String> getExamResult(Long examId, Long userId, Long scheduleId);
        
    List<ExamResultView> getExamQuestionResult(Long examId, Long userId);
        
    ExamResult startExam(long examId,long userId,long scheduleId);
    
    Date getStartTime(long examId,long userId,long scheduleId);

    ExamResult submitExam(long examId, long userId, long scheduleId);
    
}
