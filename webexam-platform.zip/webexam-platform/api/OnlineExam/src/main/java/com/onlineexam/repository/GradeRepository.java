/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Grade;
import com.onlineexam.entity.Organization;
import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 *
 * @author Libeesh
 */
public interface GradeRepository extends Repository<Grade, Long> {

    Optional<Grade> findByGradeId(long gradeId);

    @Query(value = "SELECT * FROM grade as g WHERE g.status=?1 AND g.organization_id=?2" , nativeQuery=true)
    Optional<Grade> findAllByStatusAndOrganizationId(byte status, Long org);
    
    Optional<Grade> findByGradeIdAndStatus(Long gradeId, byte status);

    List<Grade> findAllByStatusAndOrganization(byte status , Organization org);
        
    List<Grade> findAll() ;
    
    Grade save(Grade grade);
    
    @Query(value = "SELECT COUNT(*) FROM grade as g WHERE g.status = ?1 AND ( g.name like %?2% OR g.description like %?2% ) AND g.organization_id=?3" , nativeQuery=true)
    Long countGradeList(byte status, String search, Long orgId);
    
    @Query(value = "SELECT * FROM grade as g WHERE g.status = ?1 AND (g.name like %?2% OR g.description like %?2% ) AND g.organization_id=?3", nativeQuery = true)
    Page<Grade> getGradeList(byte status, String search, Long orgId, Pageable page);
    
    Long countByGradeIdNotAndStatusAndName(Long examId, byte status, String name);
    
    Long countByStatusAndNameAndOrganization(byte status, String name, Organization org);
}
