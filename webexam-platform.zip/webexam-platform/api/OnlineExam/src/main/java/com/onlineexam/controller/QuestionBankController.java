/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.ExamQuestionForm;
import com.onlineexam.form.QuestionBankForm;
import com.onlineexam.service.QuestionBankQuestionService;
import com.onlineexam.service.QuestionBankService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.QuestionBankListView;
import com.onlineexam.view.QuestionBankView;
import com.onlineexam.view.QuestionListView;
import com.onlineexam.view.QuestionsQBWiseView;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author sanal
 */
@RestController
@RequestMapping("/admin/question_bank")
public class QuestionBankController {
    
    @Autowired
    QuestionBankService questionBankService;
    
    @Autowired
    QuestionBankQuestionService questionBankQuestionService;
    
    @PostMapping("/{questionBankId}")
    public void add(@Valid @RequestBody QuestionBankForm form, BindingResult bindingResult,
            @PathVariable(value = "questionBankId", required = false) Long questionBankId){
        if(bindingResult.hasErrors()){
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        questionBankService.add(form, questionBankId);
    }
    
    @PutMapping("/initEdit/{questionBankId}")
    public QuestionBankView initEdit(@PathVariable("questionBankId") Long questionBankId) {
        return questionBankService.initEdit(questionBankId);
    }
    
    @PutMapping("/{questionBankId}")
    public QuestionBankView edit(@Valid @RequestBody QuestionBankForm form, BindingResult bindingResult,
            @PathVariable("questionBankId") Long questionBankId){
        if(bindingResult.hasErrors()){
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return questionBankService.edit(form, questionBankId);
    }
    
    @DeleteMapping("/{questionBankId}")
    public QuestionBankView delete(@PathVariable("questionBankId") Long questionBankId){
        return questionBankService.delete(questionBankId);
    }

    @GetMapping("/list")
    public Pager<QuestionBankView> listQuestionBanks(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ) {
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        return questionBankService.listQuestionBanks(search, limit, sort, type, page);
    }

    @GetMapping("/list_question_bank")
    public List<QuestionBankListView> listQuestionBanks() {
        return questionBankService.listQuestionBanks();
    }
    
    @GetMapping("/listQuestionsForQB")
    public Pager<QuestionsQBWiseView> listQuestionsForQB( 
            @RequestParam(value = "questionBankId", required = false) Long questionBankId,
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type,
            @RequestParam(value = "cId", required = false) Integer categoryId,
            @RequestParam(value = "gId", required = false) Integer groupId,
            @RequestParam(value = "lId", required = false) Integer levelId
    ) {
//        if (limit == null) {
            limit = 1000;
//        }
        if (page == null) {
            page = 1;
        }
        if (null == categoryId) {
            categoryId = 0;
        }
        if (null == groupId) {
            groupId = 0;
        }
        if (null == levelId) {
            levelId = 0;
        }
        return questionBankService.listQuestionsForQB(questionBankId, search, limit, sort, type, page, 
                categoryId, groupId, levelId);
    }

    @PostMapping("/temporarySave/{questionBankId}")
    public QuestionBankView addTempQuestionBankQuestion(@Valid @RequestBody ExamQuestionForm form, BindingResult bindingResult,
            @PathVariable("questionBankId") Long questionBankId) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
       return questionBankQuestionService.addTempQuestionBankQuestion(form, questionBankId);
    }
    
    @GetMapping("/list_questions")
    public List<QuestionListView> listQuestions(@RequestParam(value = "questionBankId", required = false) Long questionBankId) {
        System.out.println("Questionbankid : "+questionBankId);
        return questionBankQuestionService.listQuestions(questionBankId);
    }
    
    @DeleteMapping("/{questionBankId}/{questionId}")
    public void delete(@PathVariable("questionBankId") Long questionBankId,
            @PathVariable("questionId") Integer questionId) {
        questionBankQuestionService.tempDeleteQuestionBankQuestions(questionBankId, questionId);
    }
}
