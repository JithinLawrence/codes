/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service.impl;

import com.onlineexam.entity.Exam;
import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.ExamQuestionResultCheckbox;
import com.onlineexam.entity.ExamQuestionResultImage;
import com.onlineexam.entity.ExamQuestionResultRadio;
import com.onlineexam.entity.ExamQuestionResultText;
import com.onlineexam.entity.ExamResult;
import com.onlineexam.entity.Question;
import com.onlineexam.entity.Schedule;
import com.onlineexam.entity.ScheduleAssignCandidate;
import com.onlineexam.entity.User;
import com.onlineexam.repository.ExamQuestionRepository;
import com.onlineexam.repository.ExamRepository;
import com.onlineexam.repository.ExamResultCheckboxRepository;
import com.onlineexam.repository.ExamResultImageRepository;
import com.onlineexam.repository.ExamResultRadioRepository;
import com.onlineexam.repository.ExamResultRepository;
import com.onlineexam.repository.ExamResultTextRepository;
import com.onlineexam.repository.ExamScheduleRepository;
import com.onlineexam.repository.QuestionRepository;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.service.ExamResultService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.ExamResultView;
import com.onlineexam.view.ExamResultsListView;
import com.onlineexam.view.JsonObjectView;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 *
 * @author simon
 */
@Service
public class ExamResultServiceImpl implements ExamResultService {

    @Autowired
    ExamResultRepository examResultRepository;

    @Autowired
    ExamRepository examRepository;

    @Autowired
    ExamScheduleRepository examScheduleRepository;

    @Autowired
    ExamScheduleRepository scheduleRepository;

    @Autowired
    ExamQuestionRepository examQuestionRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ExamResultTextRepository examResultTextRepository;

    @Autowired
    ExamResultRadioRepository examResultRadioRepository;

    @Autowired
    ExamResultImageRepository examResultImageRepository;

    @Autowired
    ExamResultCheckboxRepository examResultCheckboxRepository;

    @Autowired
    QuestionRepository questionRepository;

    private final byte[] activeStatus = {ScheduleAssignCandidate.Status.ACTIVE.value};

    @Override
    public Pager<ExamResultsListView> getResultsList(String search, Integer limit, String sort, boolean type, Integer page, long userId) {
        Pager<ExamResultsListView> examAssignPager = new Pager(0, 0, 0);
        Long queryCount;
        List<ExamResultsListView> examUpCommingList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        queryCount = examResultRepository.countExamResultList(activeStatus, search, userId);
        examUpCommingList = StreamSupport.stream(examResultRepository
                .getExamResultList(activeStatus, search, userId, PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(exam -> new ExamResultsListView(exam))
                .collect(Collectors.toList());
        examAssignPager = new Pager(limit, queryCount.intValue(), page);
        examAssignPager.setResult(examUpCommingList);
        return examAssignPager;
    }

    @Override
    public HashMap<String, String> getExamResult(Long examId, Long userId, Long scheduleId) {
        Optional<User> user = userRepository.findByUserIdAndStatus(userId, User.Status.ACTIVE.value);
        Optional<Exam> exam = examRepository.findByExamId(examId);
        Exam examEntity = exam.get();
        int hour = 0, answeredCorrect = 0;
        String[] times = null;
        HashMap<String, String> examResult = new HashMap<String, String>();
        examResult.put("examName", examEntity.getName());
        String examSchedule = examScheduleRepository.findByExamAndStatus(examEntity, Schedule.Status.ACTIVE.value, scheduleId);
        examResult.put("examDate", examSchedule);
        Integer min = examResultRepository.findExamSchedule(examId);
        if (min != 0 && min > 60) {
            while (min > 60) {
                hour = hour + min / 60;
                min = min % 60;
            }
            examResult.put("durationHour", Integer.toString(hour));
            examResult.put("durationMin", Integer.toString(min));
        } else {
            examResult.put("durationHour", "0");
            examResult.put("durationMin", Integer.toString(min));
        }
        examResult.put("durationHour", Integer.toString(hour));
        examResult.put("durationMin", Integer.toString(min));

        examResult.put("questions", examQuestionRepository.countByStatusAndEditingStatusAndExam(ExamQuestion.Status.ACTIVE.value, ExamQuestion.EditingStatus.SAVED.value, examEntity).toString());
        examResult.put("marks", examEntity.getTotalMark().toString());

        ExamResult examRslt = examResultRepository.findByExamAndUser(examEntity, user.get());

        Integer textCount = examResultTextRepository.countByExamResultAndIsCorrect(examRslt, ExamQuestionResultText.IsCorrect.CORRECT.value);
        Integer radioCount = examResultRadioRepository.countByExamResultAndIsCorrect(examRslt, ExamQuestionResultText.IsCorrect.CORRECT.value);
        Integer imageCount = examResultImageRepository.countByExamResultAndIsCorrect(examRslt,ExamQuestionResultText.IsCorrect.CORRECT.value);
        Integer checkboxCount = examResultCheckboxRepository.countByExamResultId(examRslt.getExamResultId());

        if (textCount != null) {
            answeredCorrect = answeredCorrect + textCount;
        }
        if (radioCount != null) {
            answeredCorrect = answeredCorrect + radioCount;
        }
        if (imageCount != null) {
            answeredCorrect = answeredCorrect + imageCount;
        }
        if (checkboxCount != null) {
            answeredCorrect = answeredCorrect + checkboxCount;
        }

        examResult.put("answeredCorrect", Integer.toString(answeredCorrect));
        examResult.put("scoredMark", Integer.toString(examRslt.getMark())); 

        return examResult;
    }
    
    @Override
    public List<ExamResultView> getExamQuestionResult(Long examId, Long userId) {
        Optional<User> user = userRepository.findByUserIdAndStatus(userId, User.Status.ACTIVE.value);
        Optional<Exam> exam = examRepository.findByExamId(examId);
        Exam examEntity = exam.get();
        ExamResult examRslt = examResultRepository.findByExamAndUser(examEntity, user.get());
        List<ExamResultView> examResultViewList = new ArrayList<ExamResultView>();
        List<ExamQuestion> examQuestions = examQuestionRepository.findByExamOrderByQuestionOrder(examEntity);
        for (ExamQuestion question : examQuestions) {
            Optional<Question> qstn = questionRepository.findByQuestionId(question.getQuestion().getQuestionId());
            if (question.getQuestionType().getQuestionTypeId() == 1 || question.getQuestionType().getQuestionTypeId() == 3) {
                JSONArray arr = null;
                List<JsonObjectView> jsonList = new ArrayList<JsonObjectView>();
                ExamQuestionResultRadio examQuestionResultRadio = examResultRadioRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    if(question.getQuestionType().getQuestionTypeId() == 1){
                    JSONObject locs = new JSONObject(question.getOptions());
                    arr = locs.getJSONArray("options");

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject jsonDrink = arr.getJSONObject(i);
                        Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                        Integer id = jsonDrink.getInt("id");
                        String value = jsonDrink.getString("value");
                        JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                        jsonList.add(jsonObjectView);
                    }  
                    }else if(question.getQuestionType().getQuestionTypeId() == 3){
                    JSONObject locs = new JSONObject(question.getOptions());
                    arr = locs.getJSONArray("options");

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject jsonDrink = arr.getJSONObject(i);
                        Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                        Integer id = jsonDrink.getInt("id");
                        String value = jsonDrink.getString("src");
                        JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                        jsonList.add(jsonObjectView);
                    }
                    }                  
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (examQuestionResultRadio != null) {
                    examResultViewList.add(new ExamResultView(examQuestionResultRadio.getExamResult().getExamResultId(),
                            examQuestionResultRadio.getQuestion().getQuestion().getQuestionId(),
                            question.getQuestionType().getQuestionTypeId(),
                            examQuestionResultRadio.getAnswer().toString(),
                            examQuestionResultRadio.getCorrectAnswer().toString(),
                            examQuestionResultRadio.getMark(),
                            jsonList,
                            question.getTitle()));
                }

            } else if (question.getQuestionType().getQuestionTypeId() == 2 || question.getQuestionType().getQuestionTypeId() == 4) {
                JSONArray arr = null;
                List<JsonObjectView> jsonList = new ArrayList<JsonObjectView>();
                ExamQuestionResultCheckbox examQuestionResultChk = examResultCheckboxRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    if(question.getQuestionType().getQuestionTypeId() == 2){
                      JSONObject locs = new JSONObject(question.getOptions());
                    arr = locs.getJSONArray("options");

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject jsonDrink = arr.getJSONObject(i);
                        Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                        Integer id = jsonDrink.getInt("id");
                        String value = jsonDrink.getString("value");
                        JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                        jsonList.add(jsonObjectView);
                    }  
                    }else if(question.getQuestionType().getQuestionTypeId() == 4){
                    JSONObject locs = new JSONObject(question.getOptions());
                    arr = locs.getJSONArray("options");

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject jsonDrink = arr.getJSONObject(i);
                        Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                        Integer id = jsonDrink.getInt("id");
                        String value = jsonDrink.getString("src");
                        JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                        jsonList.add(jsonObjectView);
                    }
                    }
                    

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (examQuestionResultChk != null) {
                    examResultViewList.add(new ExamResultView(examQuestionResultChk.getExamResult().getExamResultId(),
                            examQuestionResultChk.getQuestion().getQuestion().getQuestionId(),
                            question.getQuestionType().getQuestionTypeId(),
                            examQuestionResultChk.getAnswer().toString(),
                            examQuestionResultChk.getCorrectAnswer().toString(),
                            examQuestionResultChk.getMark(),
                            jsonList,
                            question.getTitle()));
                }
            }else if(question.getQuestionType().getQuestionTypeId() == 5) {
                JSONArray arr = null;
                List<JsonObjectView> jsonList = new ArrayList<JsonObjectView>();
                ExamQuestionResultText examQuestionResultTxt = examResultTextRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    JSONObject locs = new JSONObject(question.getOptions());
                    arr = locs.getJSONArray("options");

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject jsonDrink = arr.getJSONObject(i);
                        Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                        Integer id = jsonDrink.getInt("id");
                        String value = jsonDrink.getString("value");
                        JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                        jsonList.add(jsonObjectView);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (examQuestionResultTxt != null) {
                    examResultViewList.add(new ExamResultView(examQuestionResultTxt.getExamResult().getExamResultId(),
                            examQuestionResultTxt.getQuestion().getQuestion().getQuestionId(),
                            question.getQuestionType().getQuestionTypeId(),
                            examQuestionResultTxt.getAnswer().toString(),
                            examQuestionResultTxt.getCorrectAnswer().toString(),
                            examQuestionResultTxt.getMark(),
                            jsonList,
                            question.getTitle()));
                }
            } else if (question.getQuestionType().getQuestionTypeId() == 6) {
                JSONArray arr = null;
                List<JsonObjectView> jsonList = new ArrayList<JsonObjectView>();
                ExamQuestionResultImage examQuestionResultImg = examResultImageRepository.findByExamResultAndQuestion(examRslt, question);
                try {
                    JSONObject locs = new JSONObject(question.getOptions());
                    arr = locs.getJSONArray("options");

                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject jsonDrink = arr.getJSONObject(i);
                        Boolean isAnswer = jsonDrink.getBoolean("isAnswer");
                        Integer id = jsonDrink.getInt("id");
                        String value = jsonDrink.getString("src");
                        JsonObjectView jsonObjectView = new JsonObjectView(isAnswer, id, value);
                        jsonList.add(jsonObjectView);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (examQuestionResultImg != null) {
                    examResultViewList.add(new ExamResultView(examQuestionResultImg.getExamResult().getExamResultId(),
                            examQuestionResultImg.getQuestion().getQuestion().getQuestionId(),
                            question.getQuestionType().getQuestionTypeId(),
                            examQuestionResultImg.getAnswer().toString(),
                            examQuestionResultImg.getCorrectAnswer().toString(),
                            examQuestionResultImg.getMark(),
                            jsonList,
                            question.getTitle()));
                }
            } 
            
        }
        return examResultViewList;
    }

    @Override
    public ExamResult startExam(long examId, long userId, long scheduleId) {
        Date dt = new Date();

        return (examResultRepository.save(new ExamResult(
                scheduleRepository.findByScheduleId(scheduleId).get(),
                examRepository.findByExamId(examId).get(),
                userRepository.findByUserId(userId).get(),
                dt,
                dt,
                0,
                ExamResult.Status.INPROGRESS.value
        )));
    }

    @Override
    public Date getStartTime(long examId, long userId, long scheduleId) {
        return (examResultRepository.getStartTime(examId, userId, scheduleId));
    }

    @Override
    public ExamResult submitExam(long examId, long userId, long scheduleId) {
        Date dt = new Date();
        ExamResult exr = examResultRepository.findByExamIdAndUserIdAndScheduleId(examId, userId, scheduleId);
        int marks = completeExam(exr);
        examResultRepository.updateExamStatus(examId, userId, scheduleId, ExamResult.Status.COMPLETED.value,marks);
        
        return (exr);
    }

    public int completeExam(ExamResult exr) {
        List<ExamQuestion> eqList = examQuestionRepository.findByExamOrderByQuestionOrder(exr.getExam());
        int marks = 0;
        for (ExamQuestion eq : eqList) {
            if (eq.getQuestionType().getQuestionTypeId() == 1 || eq.getQuestionType().getQuestionTypeId() == 3) {
                ExamQuestionResultRadio questionResult = examResultRadioRepository.findByExamResultAndQuestion(exr, eq);
                if (questionResult == null) {
                    examResultRadioRepository.save(new ExamQuestionResultRadio(exr, eq, 0, 0, ExamQuestionResultRadio.IsCorrect.WRONG.value, 0));
                }else{
                    marks += questionResult.getMark();
                }
            } else if (eq.getQuestionType().getQuestionTypeId() == 2 || eq.getQuestionType().getQuestionTypeId() == 4) {
                ExamQuestionResultCheckbox questionResult = examResultCheckboxRepository.findByExamResultAndQuestion(exr, eq);
                if (questionResult == null) {
                    examResultCheckboxRepository.save(new ExamQuestionResultCheckbox(exr, eq, "0", "0", 0, 0, 0));
                }else{
                    marks += questionResult.getMark();
                }
            } else if (eq.getQuestionType().getQuestionTypeId() == 5) {
                ExamQuestionResultText questionResult = examResultTextRepository.findByExamResultAndQuestion(exr, eq);
                if (questionResult == null) {
                    examResultTextRepository.save(new ExamQuestionResultText(exr, eq, "0", "0", ExamQuestionResultText.IsCorrect.WRONG.value, 0));
                }else{
                    marks += questionResult.getMark();
                }

            } else if (eq.getQuestionType().getQuestionTypeId() == 6) {
                ExamQuestionResultImage questionResult = examResultImageRepository.findByExamResultAndQuestion(exr, eq);
                if (questionResult == null) {
                    examResultImageRepository.save(new ExamQuestionResultImage(exr, eq, "0", "0", ExamQuestionResultText.IsCorrect.WRONG.value, 0));
                }else{
                    marks += questionResult.getMark();
                }
            }
            
        }
        return marks;
    }
}
