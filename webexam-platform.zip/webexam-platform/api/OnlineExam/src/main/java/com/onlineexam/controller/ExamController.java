/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.ExamForm;
import com.onlineexam.form.ExamQuestionForm;
import com.onlineexam.form.ExamQuestionUpdateForm;
import com.onlineexam.form.ExamUpdateForm;
import com.onlineexam.service.ExamService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.BasicView;
import com.onlineexam.view.CandidateScheduleAssignView;
import com.onlineexam.view.ExamQuestionGroupedView;
import com.onlineexam.view.ExamQuestionView;
import com.onlineexam.view.ExamView;
import com.onlineexam.view.QuestionBankListView;
import com.onlineexam.view.QuestionExamWiseView;
import java.util.HashMap;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author sanal
 */
@RestController
@RequestMapping("/admin/exams")
public class ExamController {

    @Autowired
    ExamService examService;

    @PostMapping
    public ExamView add(@Valid @RequestBody ExamForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.add(form);
    }

    @PostMapping("/temporarySave/{examId}")
    public ExamQuestionGroupedView addTempExam(@Valid @RequestBody ExamQuestionForm form, BindingResult bindingResult,
            @PathVariable("examId") Long examId) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.addTempExam(form, examId);
    }

    @GetMapping("/verifyEdit/{examId}")
    public BasicView verifyEdit(@PathVariable("examId") Long examId) {
        return examService.verifyEdit(examId);
    }

    @PutMapping("/initEdit/{examId}")
    public ExamQuestionGroupedView initEdit(@PathVariable("examId") Long examId) {
        return examService.initEdit(examId);
    }

    @PostMapping("/initCopy/{examId}")
    public Long initCopy(@PathVariable("examId") Long examId) {
        return examService.initCopy(examId);
    }

    @GetMapping("/loadCopy/{examId}")
    public ExamQuestionGroupedView loadCopy(@PathVariable("examId") Long examId) {
        return examService.loadCopy(examId);
    }

    @PutMapping("/{examId}")
    public ExamView edit(@Valid @RequestBody ExamUpdateForm form, BindingResult bindingResult,
            @PathVariable("examId") Long examId) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.edit(form, examId);
    }

    @PutMapping("/saveCopy/{examId}")
    public ExamView saveCopy(@Valid @RequestBody ExamUpdateForm form, BindingResult bindingResult,
            @PathVariable("examId") Long examId) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.saveCopy(form, examId);
    }

//    @PutMapping("/temporaryUpdate/{examId}/{categoryId}")
    @PutMapping("/temporaryUpdate/{examId}")
    public ExamQuestionGroupedView editTempExam(@Valid @RequestBody ExamQuestionUpdateForm form, BindingResult bindingResult,
            @PathVariable("examId") Long examId
//            , @PathVariable("categoryId") Long categoryId
    ) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examService.editTempExam(form, examId);
    }

    @DeleteMapping("/{examId}")
    public ExamView delete(@PathVariable("examId") Long examId) {
        return examService.delete(examId);
    }

    @DeleteMapping("/{examId}/{categoryId}")
    public ExamQuestionGroupedView delete(@PathVariable("examId") Long examId,
            @PathVariable("categoryId") Long categoryId) {
        return examService.tempDeleteCategory(examId, categoryId);
    }

    @GetMapping("/list")
    public Pager<ExamView> listExams(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ) {
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        return examService.listExams(search, limit, sort, type, page);
    }

    @GetMapping("/listQuestionsForExam")
    public Pager<QuestionExamWiseView> listQuestionsForExam(
            @RequestParam(value = "examId", required = false) Long examId,
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type,
            @RequestParam(value = "cId", required = false) Integer categoryId,
            @RequestParam(value = "gId", required = false) Integer groupId,
            @RequestParam(value = "lId", required = false) Integer levelId
    ) {
//        if (limit == null) {
            limit = 1000;
//        }
        if (page == null) {
            page = 1;
        }
        if (null == categoryId) {
            categoryId = 0;
        }
        if (null == groupId) {
            groupId = 0;
        }
        if (null == levelId) {
            levelId = 0;
        }
        return examService.listQuestionsForExam(examId, search, limit, sort, type, page, 
                categoryId, groupId, levelId);
    }

    @GetMapping("/listExamQuestions")
    public List<ExamQuestionView> listExamQuestions(
            @RequestParam(value = "examId", required = false) Long examId,
            @RequestParam(value = "search", required = false) String search) {
        return examService.listExamQuestions(examId, search);
    }

    @GetMapping("/listExamQuestionsCategoryWise")
    public List<ExamQuestionView> listExamQuestionsCategoryWise(
            @RequestParam(value = "examId", required = false) Long examId,
            @RequestParam(value = "categoryId", required = false) Long categoryId,
            @RequestParam(value = "search", required = false) String search) {
        return examService.listExamQuestionsCategoryWise(examId, categoryId, search);
    }
    
     @GetMapping("/listCandidateExams")
    public Pager<CandidateScheduleAssignView> listCandidateExams(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type,
            @RequestParam(value = "user", required = false) Long user
    ) {
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        return examService.listCandidateExams(search, limit, sort, type, page, user);
    }
    
    @GetMapping("/listStatusCounts")
    public List listStatusCounts(@RequestParam(value = "user", required = true) Long user){
        
        return examService.listStatusCounts(user);
    }
    
    @GetMapping("/getExamReport")
    public HashMap<String , Long> getExamReport(@RequestParam(value = "examId", required = true) Long examId){
        return examService.getExamReport(examId);
    }
    
    @GetMapping("/listExams")
    public List<ExamView> listExams() {
        return examService.listExams();
    }
}
