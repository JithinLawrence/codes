/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service.impl;

import com.onlineexam.entity.Category;
import com.onlineexam.entity.Exam;
import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.ExamQuestionResultCheckbox;
import com.onlineexam.entity.ExamQuestionResultImage;
import com.onlineexam.entity.ExamQuestionResultRadio;
import com.onlineexam.entity.ExamQuestionResultText;
import com.onlineexam.entity.ExamResult;
import com.onlineexam.entity.Organization;
import com.onlineexam.entity.Question;
import com.onlineexam.entity.QuestionType;
import com.onlineexam.entity.Schedule;
import com.onlineexam.entity.ScheduleAssignCandidate;
import com.onlineexam.entity.User;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.exception.UnauthorizedException;
import com.onlineexam.form.ExamForm;
import com.onlineexam.form.ExamQuestionForm;
import com.onlineexam.form.ExamQuestionUpdateForm;
import com.onlineexam.form.ExamUpdateForm;
import com.onlineexam.form.ImageAnswerForm;
import com.onlineexam.form.MultipleAnswerForm;
import com.onlineexam.form.SingleAnswerForm;
import com.onlineexam.form.TextAnswerForm;
import com.onlineexam.repository.CategoryRepository;
import com.onlineexam.repository.ExamQuestionRepository;
import com.onlineexam.repository.ExamRepository;
import com.onlineexam.repository.ExamResultCheckboxRepository;
import com.onlineexam.repository.ExamResultImageRepository;
import com.onlineexam.repository.ExamResultRadioRepository;
import com.onlineexam.repository.ExamResultRepository;
import com.onlineexam.repository.ExamResultTextRepository;
import com.onlineexam.repository.ExamScheduleRepository;
import com.onlineexam.repository.QuestionRepository;
import com.onlineexam.repository.ScheduleAssignCandidateRepository;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.service.ExamService;
import com.onlineexam.util.LanguageUtil;
import com.onlineexam.util.Pager;
import com.onlineexam.view.BasicView;
import com.onlineexam.view.CandidateScheduleAssignView;
import com.onlineexam.view.CategoryDashboardListView;
import com.onlineexam.view.ExamQuestionAnswerView;
import com.onlineexam.view.ExamQuestionGroupedView;
import com.onlineexam.view.ExamQuestionView;
import com.onlineexam.view.ExamView;
import com.onlineexam.view.QuestionAnswerView;
import com.onlineexam.view.QuestionDashBoardView;
import com.onlineexam.view.QuestionExamWiseView;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 *
 * @author sanal
 */
@Service
public class ExamServiceImpl implements ExamService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    ExamRepository examRepository;

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    ExamQuestionRepository examQuestionRepository;

    @Autowired
    QuestionRepository questionRepository;

    @Autowired
    ScheduleAssignCandidateRepository scheduleAssignCandidateRepository;

    @Autowired
    ExamResultRepository examResultRepository;

    @Autowired
    ExamScheduleRepository scheduleRepository;

    @Autowired
    private LanguageUtil languageUtil;

    @Autowired
    ExamResultRadioRepository radioRepo;

    @Autowired
    ExamResultCheckboxRepository checkRepo;

    @Autowired
    ExamResultTextRepository textRepo;

    @Autowired
    ExamResultImageRepository imageRepo;

    private final byte[] examActiveStatus = {Exam.Status.ACTIVE.value};

    private final byte[] examInactiveStatus = {Exam.Status.INACTIVE.value};

    private final byte categoryActiveStatus = Category.Status.ACTIVE.value;

    private final byte[] questionActiveStatus = {Question.Status.ACTIVE.value};

//    private final byte[] examActiveAndTempSaveStatus = {Exam.Status.ACTIVE.value, Exam.Status.TEMP_SAVE.value};
//
    private final byte[] examQuestionStatusInactive = {ExamQuestion.Status.INACTIVE.value};
    private final byte[] examQuestionStatusSaved = {ExamQuestion.EditingStatus.SAVED.value};
    private final byte[] examQuestionStatusAll = {ExamQuestion.Status.ACTIVE.value, ExamQuestion.Status.INACTIVE.value};
    private final byte[] examQuestionEditingStatusNew = {ExamQuestion.EditingStatus.TEMP_SAVE.value};
    private final byte[] examQuestionEditingStatusOld = {ExamQuestion.EditingStatus.SAVED.value, ExamQuestion.EditingStatus.TEMP_SAVE.value, ExamQuestion.EditingStatus.TEMP_UPDATE.value};
    private final byte[] examQuestionEditingStatusCopy = {ExamQuestion.EditingStatus.SAVED.value, ExamQuestion.EditingStatus.TEMP_DELETE.value};
    private final byte[] examQuestionEditingStatusDelUpd = {ExamQuestion.EditingStatus.TEMP_DELETE.value, ExamQuestion.EditingStatus.TEMP_UPDATE.value};

    private final byte[] examEditingStatusNew = {Exam.EditingStatus.TEMP_SAVE.value};
    private final byte[] examEditingStatusOld = {Exam.EditingStatus.SAVED.value, Exam.EditingStatus.TEMP_UPDATE.value};

    private final byte scheduleRegisterStatus = ScheduleAssignCandidate.RegisterStatus.REGISTERED.value;
    private final byte scheduleActivestatus = ScheduleAssignCandidate.Status.ACTIVE.value;

    @Transactional
    @Override
    public ExamView add(ExamForm form) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Organization organization = currentUser.getOrganization();

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }

//        Long examNameCount = examRepository.countByStatusInAndName(examActiveStatus, form.getName());
//        if (examNameCount > 0) {
//            throw new BadRequestException(languageUtil.getTranslatedText("exam.name.exist", null, "en"));
//        }
        if (form.getPassMark() > form.getTotalMark()) {
            throw new BadRequestException(languageUtil.getTranslatedText("passmark.greater.than.totalmark", null, "en"));
        }
//        if (form.getExamId().equals(0L)) {
//            return new ExamView(examRepository.save(new Exam(
//                    form.getName(),
//                    form.getDescription(),
//                    form.getTermsAndConditions(),
//                    organization,
//                    form.getType(),
//                    form.getDuration(),
//                    form.getScheduleType(),
//                    form.getTotalMark(),
//                    form.getPassMark(),
//                    currentUser,
//                    Exam.Status.ACTIVE.value,
//                    Exam.EditingStatus.SAVED.value,
//                    form.getShowMark()
//            )), 0L);
//        } else {
            Exam exam = examRepository.findByExamIdAndStatusIn(form.getExamId(), examInactiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));

            List<ExamQuestion> examQuestions = examQuestionRepository.findByExamAndEditingStatusIn(exam, examQuestionEditingStatusNew);

            if(examQuestionRepository.countByExamAndEditingStatusIn(exam, examQuestionEditingStatusOld) > 0L){
                examQuestions.forEach((examQuestion) -> {
                    examQuestionRepository.save(examQuestion.savePermanent(examQuestion));
                });

                exam = examRepository.save(exam.activateExam(
                        form.getName(),
                        form.getDescription(),
                        form.getTermsAndConditions(),
                        form.getType(),
                        form.getDuration(),
                        form.getScheduleType(),
                        form.getTotalMark(),
                        form.getPassMark(),
                        currentUser,
                        Exam.Status.ACTIVE.value,
                        Exam.EditingStatus.SAVED.value,
                        form.getShowMark()
                ));

                return new ExamView(exam, Long.valueOf(examQuestions.size()));
            } else {
                throw new BadRequestException(languageUtil.getTranslatedText("cannot.save.exam.without.questions", null, "en"));
            }
//        }
    }

    @Transactional
    @Override
    public ExamQuestionGroupedView addTempExam(ExamQuestionForm form, Long examId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Organization organization = currentUser.getOrganization();
        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
//        Map<Long, Integer> categoryOrder = new LinkedHashMap<>();
        Map<Long, Integer> questionOrder = new LinkedHashMap<>();
        List<ExamQuestion> examQuestions = new ArrayList<>();
        Exam exam;
        if (examId.equals(0L)) {
            exam = examRepository.save(new Exam(
                    "",
                    "",
                    "",
                    organization,
                    (byte) -1,
                    -1,
                    (byte) -1,
                    -1,
                    -1,
                    currentUser,
                    Exam.Status.INACTIVE.value,
                    Exam.EditingStatus.TEMP_SAVE.value,
                    Exam.ShowMarks.SHOW_LATER.value
            ));
        } else {
            exam = examRepository.findByExamIdAndAllStatusAndAllEditingStatus(Exam.Status.ACTIVE.value, Exam.EditingStatus.TEMP_UPDATE.value,
                    Exam.EditingStatus.SAVED.value, Exam.Status.INACTIVE.value, Exam.EditingStatus.TEMP_SAVE.value, examId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));
//            exam = examRepository.findByExamIdAndStatusIn(examId, examActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));
            examQuestions = examQuestionRepository.findByExamAndEditingStatusIn(exam, examQuestionEditingStatusOld);
        }
        int order = examQuestions.stream().max(Comparator.comparing(ExamQuestion::getQuestionOrder))
                .map(c -> c.getQuestionOrder())
                .orElse(0);

        //check for null_____in form------_________--------------
        List<ExamQuestion> examQuestionsTemp = new ArrayList<>();
        for (Integer questionId : form.getQuestionId()) {
            Question question = questionRepository.findByQuestionIdAndStatusIn(questionId, questionActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en")));
            if (!examId.equals(0L) //                    && !categoryOrder.containsKey(question.getCategory().getCategoryId())
                    ) {
//                categoryOrder.put(
//                        question.getCategory().getCategoryId(),
//                        examQuestions.stream()
//                                .filter(a -> a.getCategory().getCategoryId().equals(question.getCategory().getCategoryId()))
//                                .map(b -> b.getCategoryOrder())
//                                .findFirst().orElse(
//                                        examQuestions.stream()
//                                                .max(Comparator.comparing(ExamQuestion::getCategoryOrder))
//                                                .map(c -> c.getCategoryOrder())
//                                                .orElse(0) + 1
//                                )
//                );
//                questionOrder.put(
//                        question.getCategory().getCategoryId(),
//                        examQuestions.stream()
//                                .filter(a -> a.getCategory().getCategoryId().equals(question.getCategory().getCategoryId()))
//                                .max(Comparator.comparing(ExamQuestion::getQuestionOrder))
//                                .map(b -> b.getQuestionOrder())
//                                .orElse(0) + 1
//                );
            } else {
//                categoryOrder.put(
//                        question.getCategory().getCategoryId(),
//                        categoryOrder.containsKey(question.getCategory().getCategoryId()) ? categoryOrder.get(question.getCategory().getCategoryId()) + 0 : categoryOrder.size() + 1
//                );
//                questionOrder.put(
//                        question.getCategory().getCategoryId(),
//                        questionOrder.containsKey(question.getCategory().getCategoryId()) ? questionOrder.get(question.getCategory().getCategoryId()) + 1 : 1
//                );
            }

            ExamQuestion examQuestion = new ExamQuestion(question.getTitle(), question.getDescription(),
                    //                    question.getImageUrl(), question.getQuestionBank(), question.getGrade(), exam, question,
                    question.getImageUrl(), exam, question,
                    question.getCategory(), question.getQuestionType(), question.getQuestionLevel(),
                    question.getAnswer(), question.getOptions(),
                    //                    categoryOrder.get(question.getCategory().getCategoryId()),
                    0,
                    ++order,
                    question.getMark(),
                    (ExamQuestion.Status.INACTIVE.value),
                    (ExamQuestion.EditingStatus.TEMP_SAVE.value)
            );
            examQuestionsTemp.add(examQuestion);
        }

        examQuestionsTemp = examQuestionsTemp.stream().sorted(
                Comparator
                        .comparing(ExamQuestion::getCategoryOrder)
                        .thenComparing(ExamQuestion::getQuestionOrder)
        ).collect(Collectors.toList());

        List<ExamQuestionView> examQuestionViews = new ArrayList<>();
        for (ExamQuestion examQuestion : examQuestionsTemp) {
            examQuestionViews.add(new ExamQuestionView(examQuestionRepository.save(examQuestion)));
        }

        examQuestionViews = examId.equals(0L) ? examQuestionViews : listExamQuestions(exam);
        return getExamQuestionGrouped(examQuestionViews, exam);
    }

    @Override
    public BasicView verifyEdit(Long examId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Exam exam = examRepository.findByExamIdAndStatusIn(examId, examActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (!Objects.equals(exam.getUser().getUserId(), currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        Long count = scheduleRepository.countByExamAndStatus(exam, Schedule.Status.ACTIVE.value);
        if (count > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("cannot.edit.exam.scheduled", null, "en"));
        }
        return new BasicView("OK");
    }

    @Transactional
    @Override
    public ExamQuestionGroupedView initEdit(Long examId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Exam exam = examRepository.findByExamIdAndStatusIn(examId, examActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (!Objects.equals(exam.getUser().getUserId(), currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        Long count = scheduleRepository.countByExamAndStatus(exam, Schedule.Status.ACTIVE.value);
        if (count > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("cannot.edit.exam.scheduled", null, "en"));
        }

        //deleteing temperory changes
        examQuestionRepository.deleteByExamIdAndExamQuestionInactiveStatus(examId, ExamQuestion.Status.INACTIVE.value, ExamQuestion.EditingStatus.TEMP_SAVE.value);
        examQuestionRepository.revertByExamId(ExamQuestion.EditingStatus.SAVED.value, examId, ExamQuestion.Status.ACTIVE.value, examQuestionEditingStatusDelUpd);

        List<ExamQuestionView> examQuestionViews = listExamQuestions(exam);
        return getExamQuestionGrouped(examQuestionViews, exam);
    }

    @Transactional
    @Override
    public Long initCopy(Long examId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Exam exam = examRepository.findByExamIdAndStatusIn(examId, examActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (!Objects.equals(exam.getUser().getUserId(), currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        
        Exam newExam = examRepository.save(new Exam(
                exam.getName(),
                exam.getDescription(),
                exam.getTermsAndConditions(),
                exam.getOrganization(),
                exam.getType(),
                exam.getDuration(),
                exam.getScheduleType(),
                exam.getTotalMark(),
                exam.getPassMark(),
                currentUser,
                Exam.Status.INACTIVE.value,
                Exam.EditingStatus.TEMP_SAVE.value,
                exam.getShowMark()
        ));
        
        List<ExamQuestion> examQuestions = examQuestionRepository.findByExamAndStatusAndEditingStatusIn(exam, ExamQuestion.Status.ACTIVE.value, examQuestionEditingStatusCopy);
        for (Iterator<ExamQuestion> iterator = examQuestions.iterator(); iterator.hasNext();) {
            ExamQuestion next = iterator.next();
            examQuestionRepository.save(new ExamQuestion(next.getTitle(), next.getDescription(),
                    //                    question.getImageUrl(), question.getQuestionBank(), question.getGrade(), exam, question,
                    next.getImageUrl(), newExam, next.getQuestion(),
                    next.getCategory(), next.getQuestionType(), next.getQuestionLevel(),
                    next.getAnswer(), next.getOptions(),
                    //                    categoryOrder.get(question.getCategory().getCategoryId()),
                    0,
                    next.getQuestionOrder(),
                    next.getMark(),
                    (ExamQuestion.Status.INACTIVE.value),
                    (ExamQuestion.EditingStatus.TEMP_SAVE.value))
            );
        }
        
        return newExam.getExamId();
    }

    @Override
    public ExamQuestionGroupedView loadCopy(Long examId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Exam newExam = examRepository.findByExamIdAndStatusIn(examId, examInactiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (!Objects.equals(newExam.getUser().getUserId(), currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        List<ExamQuestion> newExamQuestions = examQuestionRepository.findByExamAndStatusAndEditingStatusIn(newExam, ExamQuestion.Status.INACTIVE.value, examQuestionEditingStatusNew);
        
//        examQuestionRepository.deleteByExamIdAndExamQuestionInactiveStatus(examId, ExamQuestion.Status.INACTIVE.value, ExamQuestion.EditingStatus.TEMP_SAVE.value);
//        examQuestionRepository.revertByExamId(ExamQuestion.EditingStatus.SAVED.value, examId, ExamQuestion.Status.ACTIVE.value, examQuestionEditingStatusDelUpd);

        List<ExamQuestionView> examQuestionViews = listExamQuestionsCopy(newExam, newExamQuestions);
        return getExamQuestionGrouped(examQuestionViews, newExam);
    }

    @Transactional
    @Override
    public ExamView edit(ExamUpdateForm form, Long examId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Exam exam = examRepository.findByExamIdAndStatusIn(examId, examActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (!Objects.equals(exam.getUser().getUserId(), currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        if (form.getPassMark() > form.getTotalMark()) {
            throw new BadRequestException(languageUtil.getTranslatedText("passmark.greater.than.totalmark", null, "en"));
        }

        examQuestionRepository.deleteByExamIdAndExamQuestionActiveStatusAndEditingStatus(ExamQuestion.Status.INACTIVE.value, examId, ExamQuestion.Status.ACTIVE.value, ExamQuestion.EditingStatus.TEMP_DELETE.value);
        List<ExamQuestion> examQuestions = examQuestionRepository.findByExamAndEditingStatusIn(exam, examQuestionEditingStatusNew);
        
        if(examQuestionRepository.countByExamAndEditingStatusIn(exam, examQuestionEditingStatusOld) > 0L){
            examQuestions.forEach((examQuestion) -> {
                examQuestionRepository.save(examQuestion.savePermanent(examQuestion));
            });

            exam = examRepository.save(exam.update(form));

            return new ExamView(exam, Long.valueOf(examQuestions.size()));
        } else {
            throw new BadRequestException(languageUtil.getTranslatedText("cannot.update.exam.without.questions", null, "en"));
        }
    }

    @Transactional
    @Override
    public ExamView saveCopy(ExamUpdateForm form, Long examId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Exam exam = examRepository.findByExamIdAndStatusIn(examId, examInactiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (!Objects.equals(exam.getUser().getUserId(), currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        if (form.getPassMark() > form.getTotalMark()) {
            throw new BadRequestException(languageUtil.getTranslatedText("passmark.greater.than.totalmark", null, "en"));
        }

        examQuestionRepository.deleteByExamIdAndExamQuestionActiveStatusAndEditingStatus(ExamQuestion.Status.INACTIVE.value, examId, ExamQuestion.Status.ACTIVE.value, ExamQuestion.EditingStatus.TEMP_DELETE.value);
        List<ExamQuestion> examQuestions = examQuestionRepository.findByExamAndEditingStatusIn(exam, examQuestionEditingStatusNew);
        
        if(examQuestionRepository.countByExamAndEditingStatusIn(exam, examQuestionEditingStatusOld) > 0L){
            examQuestions.forEach((examQuestion) -> {
                examQuestionRepository.save(examQuestion.savePermanent(examQuestion));
            });

            exam = examRepository.save(exam.copy(form));

            return new ExamView(exam, Long.valueOf(examQuestions.size()));
        } else {
            throw new BadRequestException(languageUtil.getTranslatedText("cannot.update.exam.without.questions", null, "en"));
        }
    }

    @Transactional
    @Override
    public ExamQuestionGroupedView editTempExam(ExamQuestionUpdateForm form, Long examId
    //            , Long categoryId
    ) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        Exam exam = examRepository.findByExamIdAndAllStatusAndAllEditingStatus(Exam.Status.ACTIVE.value, Exam.EditingStatus.TEMP_UPDATE.value,
                Exam.EditingStatus.SAVED.value, Exam.Status.INACTIVE.value, Exam.EditingStatus.TEMP_SAVE.value, examId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));
//        Category category = categoryRepository.findByCategoryIdAndStatus(categoryId, categoryActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));

        //check for null_____in form------_________--------------
        for (ExamQuestionUpdateForm.ExamQuestionUpdateInnerForm examQuestionUpdateForm : form.getExamQuestionUpdateInnerForm()) {
            ExamQuestion examQuestion = examQuestionRepository.findByExamAndExamQuestionIdAndEditingStatusIn(exam, examQuestionUpdateForm.getExamQuestionId(), exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en")));
            examQuestionRepository.save(new ExamQuestion(examQuestion.getTitle(), examQuestion.getDescription(),
                    examQuestion.getImageUrl(), exam, examQuestion.getQuestion(),
                    examQuestion.getCategory(), examQuestion.getQuestionType(), examQuestion.getQuestionLevel(),
                    examQuestion.getAnswer(), examQuestion.getOptions(),
                    examQuestionUpdateForm.getCategoryOrder(),
                    examQuestionUpdateForm.getQuestionOrder(),
                    examQuestionUpdateForm.getMark(),
                    (ExamQuestion.Status.INACTIVE.value), (ExamQuestion.EditingStatus.TEMP_SAVE.value)
            ));
            if (examQuestion.getStatus() == ExamQuestion.Status.INACTIVE.value) {
                examQuestionRepository.deleteByExamQuestionIdAndExamId(examQuestion.getExamQuestionId(), examId);
            } else {
                examQuestionRepository.save(examQuestion.tempDelete(examQuestion));
            }
        }
        form.getDeletedData().forEach(examQuestionId -> {
            if (exam.getStatus() == Exam.Status.INACTIVE.value) {
                examQuestionRepository.deleteByExamQuestionIdAndExamId(examQuestionId, examId);
            } else if (exam.getStatus() == Exam.Status.ACTIVE.value) {
                ExamQuestion examQuestion = examQuestionRepository.findByExamQuestionId(examQuestionId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en")));
                if (examQuestion.getStatus() == ExamQuestion.Status.INACTIVE.value) {
                    examQuestionRepository.deleteByExamQuestionIdAndExamId(examQuestionId, examId);
                } else if (examQuestion.getStatus() == ExamQuestion.Status.ACTIVE.value) {
                    examQuestionRepository.save(examQuestion.tempDelete(examQuestion));
                }
            }
        });
        List<ExamQuestionView> examQuestionViews = listExamQuestions(exam);
        return getExamQuestionGrouped(examQuestionViews, exam);
    }

    @Transactional
    @Override
    public ExamView delete(Long examId) {
        Exam exam = examRepository.findByExamIdAndStatusIn(examId, examActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
            if (!exam.getUser().getUserId().equals(currentUser.getUserId())) {
//                if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
//                }
            }
        }
        Long count = scheduleRepository.countByExamAndStatus(exam, Schedule.Status.ACTIVE.value);
        if (count > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("cannot.delete.exam.scheduled", null, "en"));
        }
        if (!Objects.isNull(exam)) {
            exam = examRepository.save(exam.delete(exam));
        }
        return new ExamView(exam, 0L);
    }

    @Transactional
    @Override
    public ExamQuestionGroupedView tempDeleteCategory(Long examId, Long categoryId) {
        Exam exam = examRepository.findByExamIdAndAllStatusAndAllEditingStatus(Exam.Status.ACTIVE.value, Exam.EditingStatus.TEMP_UPDATE.value,
                Exam.EditingStatus.SAVED.value, Exam.Status.INACTIVE.value, Exam.EditingStatus.TEMP_SAVE.value, examId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));
        Category category = categoryRepository.findByCategoryIdAndStatus(categoryId, categoryActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));

        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
            if (!exam.getUser().getUserId().equals(currentUser.getUserId())) {
//                if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
//                }
            }
        }
        if (exam.getStatus() == Exam.Status.INACTIVE.value) {
            examQuestionRepository.deleteByExamIdAndCategoryId(examId, categoryId);
        } else if (exam.getStatus() == Exam.Status.ACTIVE.value) {
            List<ExamQuestion> examQuestions = examQuestionRepository.findByExamAndCategory(exam, category);
            examQuestions.forEach((examQuestion) -> {
                if (examQuestion.getStatus() == ExamQuestion.Status.INACTIVE.value) {
                    examQuestionRepository.deleteByExamQuestionIdAndExamIdAndCategoryId(examQuestion.getExamQuestionId(), examId, categoryId);
                } else if (examQuestion.getStatus() == ExamQuestion.Status.ACTIVE.value) {
                    examQuestionRepository.save(examQuestion.tempDelete(examQuestion));
                }

            });
        }

        List<ExamQuestionView> examQuestionViews = listExamQuestions(exam);
        return getExamQuestionGrouped(examQuestionViews, exam);
    }

    @Override
    public Pager<ExamView> listExams(String search, Integer limit, String sort, boolean type, Integer page) {
        Pager<ExamView> examPager = new Pager(0, 0, 0);
        Long queryCount;
        List<ExamView> examkList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
            queryCount = examRepository.countExamListByAdmin(examActiveStatus, currentUser.getOrganization().getOrganizationId(), search);
            examkList = StreamSupport.stream(examRepository
                    .getExamListByAdmin(examActiveStatus, currentUser.getOrganization().getOrganizationId(), search, PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                    .map(exam -> new ExamView(exam, examQuestionRepository.countByStatusAndExam(ExamQuestion.Status.ACTIVE.value, exam)))
                    .collect(Collectors.toList());
        } else {
            queryCount = examRepository.countExamListByUser(examActiveStatus, currentUser.getUserId(), search);
            examkList = StreamSupport.stream(examRepository
                    .getExamListByUser(examActiveStatus, currentUser.getUserId(), search, PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                    .map(exam -> new ExamView(exam, examQuestionRepository.countByStatusAndExam(ExamQuestion.Status.ACTIVE.value, exam)))
                    .collect(Collectors.toList());
        }

        examPager = new Pager(limit, queryCount.intValue(), page);
        examPager.setResult(examkList);
        return examPager;
    }

    @Override
    public Pager<QuestionExamWiseView> listQuestionsForExam(Long examId, String search, Integer limit, String sort,
            boolean type, Integer page, Integer categoryId, Integer groupId, Integer levelId) {
        Pager<QuestionExamWiseView> examPager;
        Long queryCount = 0L;
        List<QuestionExamWiseView> examList = new ArrayList<>();
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));

        if (examId == 0) {
            if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
                queryCount = questionRepository.countQuestionListByAdmin(questionActiveStatus, currentUser.getOrganization().getOrganizationId(), search,
                        categoryId, groupId, levelId);
                if (groupId == 0) {
                    examList = StreamSupport.stream(questionRepository
                            .getQuestionListWithOutGradeByAdmin(questionActiveStatus, currentUser.getOrganization().getOrganizationId(), search, categoryId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionExamWiseView(question, null))
                            .collect(Collectors.toList());
                } else {
                    examList = StreamSupport.stream(questionRepository
                            .getQuestionListWithGradeByAdmin(questionActiveStatus, currentUser.getOrganization().getOrganizationId(), search, categoryId, groupId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionExamWiseView(question, null))
                            .collect(Collectors.toList());
                }
            } else {
                queryCount = questionRepository.countQuestionListByUser(questionActiveStatus, currentUser.getUserId(), search,
                        categoryId, groupId, levelId);
                if (groupId == 0) {
                    examList = StreamSupport.stream(questionRepository
                            .getQuestionListWithOutGradeByUser(questionActiveStatus, currentUser.getUserId(), search, categoryId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionExamWiseView(question, null))
                            .collect(Collectors.toList());
                } else {
                    examList = StreamSupport.stream(questionRepository
                            .getQuestionListWithGradeByUser(questionActiveStatus, currentUser.getUserId(), search, categoryId, groupId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionExamWiseView(question, null))
                            .collect(Collectors.toList());
                }
            }

        } else {
            Exam exam = examRepository.findByExamId(examId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));
            if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
                examList = StreamSupport.stream(questionRepository
                        .getQuestionListNotInExamSelectWithSearchByAdmin(currentUser.getOrganization().getOrganizationId(), Question.Status.ACTIVE.value, search, categoryId, groupId, levelId,
                                exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionStatusInactive : examQuestionStatusAll,
                                exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld,
                                examId,
                                PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)
                        )
                        .spliterator(), false)
                        .map(question -> new QuestionExamWiseView(
                        question,
                        null
                ))
                        .collect(Collectors.toList());
                queryCount = Long.valueOf(examList.size());
            } else {
                examList = StreamSupport.stream(questionRepository
                        .getQuestionListNotInExamSelectWithSearchByUser(currentUser.getUserId(), Question.Status.ACTIVE.value, search, categoryId, groupId, levelId,
                                exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionStatusInactive : examQuestionStatusAll,
                                exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld,
                                examId,
                                PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)
                        )
                        .spliterator(), false)
                        .map(question -> new QuestionExamWiseView(
                        question,
                        null
                ))
                        .collect(Collectors.toList());
                queryCount = Long.valueOf(examList.size());
            }

        }
        examPager = new Pager(limit, queryCount.intValue(), page);
        examPager.setResult(examList);
        return examPager;
    }

    @Override
    public List<ExamQuestionView> listExamQuestions(Long examId, String search) {
        //findByExamIdAndAllStatusAndAllEditingStatus
        Exam exam = examRepository.findByExamId(examId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));
//        Category category = categoryRepository.findByCategoryIdAndStatus(categoryId, categoryActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));

        List<ExamQuestionView> examkList = examQuestionRepository.findByExamAndEditingStatusInAndTitleLike(exam,
                exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld, "%" + search + "%")
                .stream().map(question -> new ExamQuestionView(question))
                .collect(Collectors.toList());
        return examkList;
    }

    @Override
    public List<ExamQuestionView> listExamQuestionsCategoryWise(Long examId, Long categoryId, String search) {
        //findByExamIdAndAllStatusAndAllEditingStatus
        Exam exam = examRepository.findByExamId(examId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("exam.not.found", null, "en")));
        Category category = categoryRepository.findByCategoryIdAndStatus(categoryId, categoryActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));

        List<ExamQuestionView> examkList = examQuestionRepository.findByExamAndCategoryAndEditingStatusInAndTitleLike(exam, category,
                exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld, "%" + search + "%")
                .stream().map(question -> new ExamQuestionView(question))
                .collect(Collectors.toList());
        return examkList;
    }

    public List<ExamQuestionView> listExamQuestions(Exam exam) {
        //findByExamIdAndAllStatusAndAllEditingStatus

        List<ExamQuestionView> examkList = examQuestionRepository.findByExamAndEditingStatusInOrderByCategoryOrderAscQuestionOrderAsc(exam,
                exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld)
                .stream().map(question -> new ExamQuestionView(question))
                .collect(Collectors.toList());
        return examkList;
    }

    public List<ExamQuestionView> listExamQuestionsCopy(Exam newExam, List<ExamQuestion> newExamQuestions) {
        List<ExamQuestionView> examkList = newExamQuestions
                .stream().map(question -> new ExamQuestionView(question))
                .collect(Collectors.toList());
        return examkList;
    }

    public ExamQuestionGroupedView getExamQuestionGrouped(List<ExamQuestionView> examQuestionViews, Exam exam) {
        LinkedHashMap<Long, List<ExamQuestionView>> examQuestionGroup
                = examQuestionViews.stream().collect(Collectors.groupingBy(
                        question -> question.getCategoryId(),
                        LinkedHashMap::new,
                        Collectors.toList()
                ));
        List<Integer> questionIds = examQuestionViews.stream().map(a -> a.getQuestionId()).collect(Collectors.toList());
        List<Integer> examQuestionIds = examQuestionViews.stream().map(a -> a.getExamQuestionId()).collect(Collectors.toList());

        List<ExamQuestionGroupedView.TableData> tableData = new ArrayList<>();
        examQuestionGroup.entrySet().stream().map(entry -> {
            List<ExamQuestionView> val = entry.getValue();
            ExamQuestionGroupedView.TableData tableDatum = new ExamQuestionGroupedView.TableData(
                    entry.getKey(),
                    val.get(0).getCategory(),
                    val.stream().mapToInt(a -> a.getMark()).sum(),
                    val.get(0).getCategoryOrder(),//error
                    val.get(0).getQuestionOrder(),
                    val.stream().mapToInt(a -> a.getQuestionCount()).sum());
            return tableDatum;
        }).forEachOrdered(tableDatum -> {
            tableData.add(tableDatum);
        });

        return new ExamQuestionGroupedView(examQuestionGroup, questionIds, examQuestionIds, exam, tableData);
    }

    @Override
    public Pager<CandidateScheduleAssignView> listCandidateExams(String search, Integer limit, String sort, boolean type, Integer page, Long user) {
        Pager<CandidateScheduleAssignView> examPager = new Pager(0, 0, 0);
        Long queryCount;
        List<CandidateScheduleAssignView> examkList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        queryCount = examRepository.countCandidateExamList(user, search);
        examkList = StreamSupport.stream(scheduleAssignCandidateRepository
                .getCandidateExamList(ScheduleAssignCandidate.Status.ACTIVE.value, search, user, PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(scheduleCandidate -> new CandidateScheduleAssignView(scheduleCandidate.getExam().getExamId(), scheduleCandidate.getExam().getName(), scheduleCandidate.getExam().getDuration(), examQuestionRepository.countByStatusAndExam(ExamQuestion.Status.ACTIVE.value, scheduleCandidate.getExam()), examRepository.getExamStartDate(examActiveStatus, scheduleCandidate.getExam().getExamId(), scheduleCandidate.getSchedule().getScheduleId()), scheduleCandidate.getSchedule().getScheduleId(), examResultRepository.countByExamIdAndUserIdAndScheduleIdAndStatus(scheduleCandidate.getExam().getExamId(), user, scheduleCandidate.getSchedule().getScheduleId(), ExamResult.Status.COMPLETED.value)))
                .collect(Collectors.toList());

        examPager = new Pager(limit, queryCount.intValue(), page);
        examPager.setResult(examkList);
        return examPager;
    }

    @Override
    public List listStatusCounts(Long userId) {
        List statusCounts = new ArrayList<>();
        Long allCount, completedCount, upcomingCount, expiredCount;
        allCount = examRepository.countCandidateExamList(userId, "");
        statusCounts.add(allCount);
        completedCount = examRepository.completedExamsCount(userId, (byte) 1);
        statusCounts.add(completedCount);
        upcomingCount = examRepository.upcomingExamsCount(userId);
        statusCounts.add(upcomingCount);
        expiredCount = examRepository.expiredExamsCount(userId);
        statusCounts.add(expiredCount);
        return statusCounts;
    }

    @Override
    public HashMap<String, Long> getExamReport(Long examId) {
        Optional<Exam> exam = examRepository.findByExamId(examId);
        Exam examEntity = exam.get();
        float passCount, failCount, pass, fail, attendedCount;
        int hour = 0;
        String[] times = null;
        HashMap<String, Long> examReport = new HashMap<String, Long>();
        examReport.put("Assigned", scheduleAssignCandidateRepository.countByExamAndRegisterStatusAndStatus(examEntity, scheduleRegisterStatus, scheduleActivestatus));
        attendedCount = examResultRepository.countByExam(examEntity);
        examReport.put("Attended", (long) attendedCount);
        Integer min = examResultRepository.findExamSchedule(examId);
        System.out.println("Duration : " + min);
        if (min != 0 && min > 60) {
            while (min > 60) {
                hour = hour + min / 60;
                min = min % 60;
            }
            examReport.put("Hour", (long) hour);
            examReport.put("Minute", (long) (min));
        } else {
            examReport.put("Hour", 0L);
            examReport.put("Minute", (long) min);
        }
        System.out.println("Duration hour : " + hour);
        System.out.println("Duration minute: " + min);
        examReport.put("Question", examQuestionRepository.countByStatusAndExam(ExamQuestion.Status.ACTIVE.value, examEntity));
        examReport.put("MoreAvg", examResultRepository.findCountGTAvg(examId));
        examReport.put("LessAvg", examResultRepository.findCountLTAvg(examId));
        examReport.put("Incomplete", examResultRepository.countByExamAndStatus(examEntity, ExamResult.Status.INPROGRESS.value));
        examReport.put("Completed", examResultRepository.countByExamAndStatus(examEntity, ExamResult.Status.COMPLETED.value));
        examReport.put("Max", examResultRepository.findMaxScore(examId));
        examReport.put("Min", examResultRepository.findMinScore(examId));
        examReport.put("Avg", examResultRepository.findAvgScore(examId));
        if (attendedCount != 0) {
            pass = examResultRepository.findPassCount(examId);
            passCount = (pass / attendedCount) * 100;
            examReport.put("Pass", (long) passCount);
            fail = examResultRepository.findFailCount(examId);
            failCount = (fail / attendedCount) * 100;
            examReport.put("Fail", (long) failCount);
        } else {
            examReport.put("Pass", 0L);
            examReport.put("Fail", 0L);
        }
        return examReport;
    }

    @Override
    public byte getAnswerStatus(long examId, long userId, long scheduleId) {
        ExamResult examStatus = examResultRepository.findByExamIdAndUserIdAndScheduleId(examId, userId, scheduleId);
        if (examStatus != null) {
            return examStatus.getStatus();
        }

        return -1;
    }

    @Override
    public String getAgreement(long examId) {
        Exam exam = examRepository.findByExamId(examId).get();
        return exam.getTermsAndConditions();
    }

    @Override
    public String getName(long examId) {
        Exam exam = examRepository.findByExamId(examId).get();
        return exam.getName();
    }

    @Override
    public List<CategoryDashboardListView> getExamCatagoryList(long examId, String type) {
        //findByExamIdAndAllStatusAndAllEditingStatus
        Exam exam = examRepository.findByExamId(examId).get();
        List<CategoryDashboardListView> categoryList = new ArrayList<>();
        List<ExamQuestion> questions;
        if (type.equals("edit") || type.equals("save")) {
            questions
                    = examQuestionRepository
                            .findByExamAndEditingStatusInOrderByCategoryOrderAscQuestionOrderAsc(
                                    exam,
                                    exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld
                            );
        } else {
            questions
                    = examQuestionRepository
                            .findByExamAndStatusInAndEditingStatusInOrderByCategoryOrderAscQuestionOrderAsc(
                                    exam,
                                    examActiveStatus,
                                    examQuestionStatusSaved
                            );
        }
        List<Category> catList = questions
                .stream().map(question -> question.getCategory())
                .distinct()
                .collect(Collectors.toList());
        catList.forEach((category) -> {
            long qcount;
            Integer totalMarks;
            List<QuestionDashBoardView> qlist;
            if (type.equals("edit") || type.equals("save")) {
                qcount = examQuestionRepository.countByExamAndCategoryAndEditingStatusIn(
                        exam, category,
                        exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld);
                totalMarks = examQuestionRepository.totalMarksByExamIdAndCategoryIdAndEditingStatusIn(
                        examId, category.getCategoryId(),
                        Exam.EditingStatus.SAVED.value,
                        Exam.EditingStatus.TEMP_SAVE.value);
                qlist = examQuestionRepository.findByExamAndCategoryAndEditingStatusIn(
                        exam, category,
                        exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld)
                        .stream().map(question -> new QuestionDashBoardView(question.getExamQuestionId(), false))
                        .collect(Collectors.toList());
            } else {
                qcount = examQuestionRepository.countByExamAndCategoryAndEditingStatusIn(exam, category, exam.getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld);
                totalMarks = examQuestionRepository.totalMarksByExamIdAndCategoryId(examId, category.getCategoryId());
                qlist = examQuestionRepository.findByExamAndCategoryAndStatusInAndEditingStatusIn(exam, category, examActiveStatus, examQuestionStatusSaved)
                        .stream().map(question -> new QuestionDashBoardView(question.getExamQuestionId(), false))
                        .collect(Collectors.toList());
            }

            categoryList.add(new CategoryDashboardListView(category, totalMarks, qcount, qlist));
        });
        return categoryList;
    }

    @Override
    public List<CategoryDashboardListView> getExamCatagoryList(long examId, long scheduleId, long userId) {
        //findByExamIdAndAllStatusAndAllEditingStatus
        Exam exam = examRepository.findByExamId(examId).get();
        List<CategoryDashboardListView> categoryList = new ArrayList<>();
        List<ExamQuestion> questions = examQuestionRepository.findByExamAndStatusInAndEditingStatusInOrderByCategoryOrderAscQuestionOrderAsc(exam, examActiveStatus, examQuestionStatusSaved);
        List<Category> catList = questions
                .stream().map(question -> question.getCategory())
                .distinct()
                .collect(Collectors.toList());
        catList.forEach((category) -> {
            long qcount;
            Integer totalMarks;
            qcount = examQuestionRepository.countByExamAndCategoryAndStatusInAndEditingStatusIn(exam, category, examActiveStatus, examQuestionStatusSaved);
            totalMarks = examQuestionRepository.totalMarksByExamIdAndCategoryId(examId, category.getCategoryId());
            List<QuestionDashBoardView> qlist = examQuestionRepository.findByExamAndCategoryAndStatusInAndEditingStatusIn(exam, category, examActiveStatus, examQuestionStatusSaved)
                    .stream().map(question -> new QuestionDashBoardView(question.getExamQuestionId(), isAnswerd(question, examId, scheduleId, userId)))
                    .collect(Collectors.toList());
            categoryList.add(new CategoryDashboardListView(category, totalMarks, qcount, qlist));
        });
        return categoryList;
    }

    @Override
    public List<QuestionDashBoardView> getExamQuestionList(long examId, long scheduleId, long userId) {
        //findByExamIdAndAllStatusAndAllEditingStatus
        Exam exam = examRepository.findByExamId(examId).get();

        List<QuestionDashBoardView> qlist = examQuestionRepository.findByExamAndStatusInOrderByQuestionOrderAsc(exam, examActiveStatus)
                .stream().map(question -> new QuestionDashBoardView(question.getExamQuestionId(), isAnswerd(question, examId, scheduleId, userId)))
                .collect(Collectors.toList());

        return qlist;
    }

    public boolean isAnswerd(ExamQuestion question, long examId, long scheduleId, long userId) {
        ExamResult exr = examResultRepository.findByExamIdAndUserIdAndScheduleId(examId, userId, scheduleId);
        if (question.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.MULTIPLE_ANSWER.value || question.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.MULTIPLE_ANSWER_IMAGE.value) {
            return checkRepo.findByExamResultAndQuestion(exr, question) != null;
        } else if (question.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.SINGLE_ANSWER.value || question.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.SINGLE_ANSWER_IMAGE.value) {
            return radioRepo.findByExamResultAndQuestion(exr, question) != null;
        } else if (question.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.TEXT_INPUT.value) {
            return textRepo.findByExamResultAndQuestion(exr, question) != null;
        } else if (question.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.IMAGE_TYPE.value) {
            return imageRepo.findByExamResultAndQuestion(exr, question) != null;
        }
        return false;
    }

    @Override
    public ExamQuestionAnswerView getExamQuestion(Integer questionId) {
        ExamQuestion eq = examQuestionRepository.findByExamQuestionId(questionId).get();
        long qcount = examQuestionRepository.countByExam(eq.getExam());
        System.out.println(qcount);
        System.out.println("------------------------");
        int nextPos = eq.getQuestionOrder() + 1;
        int prePos = eq.getQuestionOrder() - 1;
        int nxId = -1;
        int prId = -1;
        Optional<ExamQuestion> nxeq = null;
        Optional<ExamQuestion> preq = null;
        while (nextPos <= qcount) {
            nxeq = examQuestionRepository.findByExamAndQuestionOrder(eq.getExam(), nextPos);
            if (nxeq.isPresent() && nxeq.get().getStatus() == ExamQuestion.Status.ACTIVE.value) {
                break;
            } else {
                nxeq = null;
                nextPos++;
            }

        }

        while (prePos > 0) {
            preq = examQuestionRepository.findByExamAndQuestionOrder(eq.getExam(), prePos);
            if (preq.isPresent() && preq.get().getStatus() == ExamQuestion.Status.ACTIVE.value) {
                break;
            } else {
                preq = null;
                prePos--;
            }

        }
        if (nxeq != null) {
            nxId = nxeq.get().getExamQuestionId();
        }
        if (preq != null) {
            prId = preq.get().getExamQuestionId();
        }
        return new ExamQuestionAnswerView(examQuestionRepository.findByExamQuestionId(questionId).get(), nxId, prId);
    }

    @Override
    public ExamQuestionAnswerView getExamQuestion(Integer questionId, long scheduleId, long userId) {
        System.out.println(questionId);
        ExamQuestion eq = examQuestionRepository.findByExamQuestionId(questionId).get();
        long qcount = examQuestionRepository.countByExam(eq.getExam());
        int nextPos = eq.getQuestionOrder() + 1;
        int prePos = eq.getQuestionOrder() - 1;
        System.out.println(nextPos);
        System.out.println("*************");
        int nxId = -1;
        int prId = -1;
        Optional<ExamQuestion> nxeq = null;
        Optional<ExamQuestion> preq = null;
        while (nextPos <= qcount) {
            nxeq = examQuestionRepository.findByExamAndQuestionOrder(eq.getExam(), nextPos);
            if (nxeq.isPresent() && nxeq.get().getStatus() == ExamQuestion.Status.ACTIVE.value ) {
                break;
            } else {
                nxeq = null;
                nextPos++;
            }

        }

        while (prePos > 0) {
            preq = examQuestionRepository.findByExamAndQuestionOrder(eq.getExam(), prePos);
            if (preq.isPresent() && preq.get().getStatus() == ExamQuestion.Status.ACTIVE.value) {
                break;
            } else {
                preq = null;
                prePos--;
            }

        }
        if (nxeq != null) {
            nxId = nxeq.get().getExamQuestionId();
        }
        if (preq != null) {
            prId = preq.get().getExamQuestionId();
        }
        ExamQuestion examQuestion = examQuestionRepository.findByExamQuestionId(questionId).get();
        int answerRadio = 0;
        String answer = new String("");
        ExamResult exr = examResultRepository.findByExamIdAndUserIdAndScheduleId(examQuestion.getExam().getExamId(), userId, scheduleId);
        if (examQuestion.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.MULTIPLE_ANSWER.value || examQuestion.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.MULTIPLE_ANSWER_IMAGE.value) {
            ExamQuestionResultCheckbox res = checkRepo.findByExamResultAndQuestion(exr, examQuestion);
            if (res != null) {
                answer = checkRepo.findByExamResultAndQuestion(exr, examQuestion).getAnswer();
            }
        } else if (examQuestion.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.SINGLE_ANSWER.value || examQuestion.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.SINGLE_ANSWER_IMAGE.value) {
            ExamQuestionResultRadio res = radioRepo.findByExamResultAndQuestion(exr, examQuestion);
            if (res != null) {
                answerRadio = res.getAnswer();
            }
        } else if (examQuestion.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.TEXT_INPUT.value) {
            ExamQuestionResultText res = textRepo.findByExamResultAndQuestion(exr, examQuestion);
            if (res != null) {
                answer = res.getAnswer();
            }
        } else if (examQuestion.getQuestionType().getQuestionTypeId() == QuestionType.QuestionTypes.IMAGE_TYPE.value) {
            ExamQuestionResultImage res = imageRepo.findByExamResultAndQuestion(exr, examQuestion);
            if (res != null) {
                answer = res.getAnswer();
            }
        }

        return new ExamQuestionAnswerView(examQuestion, nxId, prId, answerRadio, answer);
    }

    @Override
    public ExamQuestionAnswerView getExamQuestion(Integer questionId, String type) {
        ExamQuestion eq = examQuestionRepository.findByExamQuestionId(questionId).get();
        long qcount = examQuestionRepository.countByExamAndCategoryAndEditingStatusIn(eq.getExam(), eq.getCategory(), eq.getExam().getStatus() == Exam.Status.INACTIVE.value ? examQuestionEditingStatusNew : examQuestionEditingStatusOld);
        int nextPos = eq.getQuestionOrder() + 1;
        int prePos = eq.getQuestionOrder() - 1;
        int nxId = -1;
        int prId = -1;
        Optional<ExamQuestion> nxeq = null;
        Optional<ExamQuestion> preq = null;
        while (nextPos <= qcount) {
            nxeq = examQuestionRepository.findByExamAndCategoryAndQuestionOrderAndEditingStatusNot(
                    eq.getExam(), eq.getCategory(), nextPos, ExamQuestion.EditingStatus.TEMP_DELETE.value);
            System.out.println(nxeq.isPresent());
            if (nxeq.isPresent()) {
                if (nxeq.get().getStatus() == ExamQuestion.Status.ACTIVE.value
                        ? nxeq.get().getEditingStatus() != ExamQuestion.EditingStatus.TEMP_DELETE.value
                        : nxeq.get().getEditingStatus() == ExamQuestion.EditingStatus.TEMP_SAVE.value) {
                    break;
                }
            } //            if (nxeq.isPresent() && nxeq.get().getStatus() == ExamQuestion.Status.ACTIVE.value && nxeq.get().getEditingStatus() == ExamQuestion.EditingStatus.SAVED.value) {
            //                break;
            //            } 
            else {
                nxeq = null;
                nextPos++;
            }

        }

        while (prePos > 0) {
            preq = examQuestionRepository.findByExamAndCategoryAndQuestionOrderAndEditingStatusNot(
                    eq.getExam(), eq.getCategory(), prePos, ExamQuestion.EditingStatus.TEMP_DELETE.value);
            if (preq.isPresent()) {
                if (preq.get().getStatus() == ExamQuestion.Status.ACTIVE.value
                        ? preq.get().getEditingStatus() != ExamQuestion.EditingStatus.TEMP_DELETE.value
                        : preq.get().getEditingStatus() == ExamQuestion.EditingStatus.TEMP_SAVE.value) {
                    break;
                }
            } else {
                preq = null;
                prePos--;
            }

        }
        if (nxeq != null) {
            nxId = nxeq.get().getExamQuestionId();
        }
        if (preq != null) {
            prId = preq.get().getExamQuestionId();
        }
        return new ExamQuestionAnswerView(examQuestionRepository.findByExamQuestionId(questionId).get(), nxId, prId);
    }

    @Override
    public QuestionAnswerView getQuestion(Integer questionId) {
        Question question = questionRepository.findByQuestionIdAndStatusIn(questionId, questionActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en")));

        return new QuestionAnswerView(question);
    }

    @Override
    public int getDuration(Integer examId) {
        return examRepository.getDuration(examId);
    }

    @Override
    public boolean addSingleAnswer(SingleAnswerForm form) {

        ExamResult examResult = examResultRepository.findByExamIdAndUserIdAndScheduleId(form.getExamId(), SecurityUtil.getCurrentUserId(), form.getScheduleId());
        ExamQuestion question = examQuestionRepository.findByExamQuestionId(form.getExamQuestionId()).get();
        ExamQuestionResultRadio eq = radioRepo.findByExamResultAndQuestion(examResult, question);
//        if(eq != null){
//            radioRepo.deleteByExamQuestionResultRadioId(eq.getExamQuestionResultRadioId());
//        }
        Integer answer = form.getAnswer();
        String optionsStr = question.getOptions();
        byte isCorrect = 0;
        Integer mark = 0;
        Integer correctAnswer = -1;
        try {
            JSONObject optionDetail = new JSONObject(optionsStr);
            JSONArray options = optionDetail.getJSONArray("options");
            for (int i = 0; i < options.length(); i++) {
                JSONObject opt = options.getJSONObject(i);
                if (opt.getBoolean("isAnswer")) {
                    correctAnswer = opt.getInt("id");
                    if (opt.getInt("id") == answer) {
                        isCorrect = 1;
                        mark = question.getMark();
                    }
                }
            }
        } catch (JSONException ex) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
        }

        if (eq != null) {
            return radioRepo.save(new ExamQuestionResultRadio(eq.getExamQuestionResultRadioId(), examResult, question, answer, correctAnswer, isCorrect, mark)) != null;
        } else {
            return radioRepo.save(new ExamQuestionResultRadio(examResult, question, answer, correctAnswer, isCorrect, mark)) != null;
        }

    }

    @Override
    public boolean addMultipleAnswer(MultipleAnswerForm form) {
        ExamResult examResult = examResultRepository.findByExamIdAndUserIdAndScheduleId(form.getExamId(), SecurityUtil.getCurrentUserId(), form.getScheduleId());
        ExamQuestion question = examQuestionRepository.findByExamQuestionId(form.getExamQuestionId()).get();
        ExamQuestionResultCheckbox eq = checkRepo.findByExamResultAndQuestion(examResult, question);

        ArrayList<Integer> answer = form.getAnswer();
        String optionsStr = question.getOptions();
        Integer mark = 0;
        Integer correctCount = 0;
        Integer wrongCount = 0;
        ArrayList<Integer> correctAnswer = new ArrayList<>();
        try {
            JSONObject optionDetail = new JSONObject(optionsStr);
            JSONArray options = optionDetail.getJSONArray("options");
            for (int i = 0; i < options.length(); i++) {
                JSONObject opt = options.getJSONObject(i);
                if (opt.getBoolean("isAnswer")) {
                    correctAnswer.add(opt.getInt("id"));

                }
            }
            for (Integer ans : answer) {
                if (correctAnswer.contains(ans)) {
                    correctCount++;
                }
            }

            wrongCount = answer.size() - correctCount;
            mark = (question.getMark() / correctAnswer.size()) * correctCount;
        } catch (JSONException ex) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
        }

        StringBuilder answerString = new StringBuilder("");
        StringBuilder correctAnswerString = new StringBuilder("");

        answer.forEach(ans -> {
            answerString.append(ans).append(",");
        });

        correctAnswer.forEach(ans -> {
            correctAnswerString.append(ans).append(",");
        });

        if (eq != null) {
            return checkRepo.save(new ExamQuestionResultCheckbox(eq.getExamQuestionResultCheckboxId(), examResult, question, answerString.deleteCharAt(answerString.length() - 1).toString(), correctAnswerString.deleteCharAt(correctAnswerString.length() - 1).toString(), correctCount, wrongCount, mark)) != null;
        } else {
            return checkRepo.save(new ExamQuestionResultCheckbox(examResult, question, answerString.deleteCharAt(answerString.length() - 1).toString(), correctAnswerString.deleteCharAt(correctAnswerString.length() - 1).toString(), correctCount, wrongCount, mark)) != null;
        }

    }

    @Override
    public boolean addTextAnswer(TextAnswerForm form) {
        ExamResult examResult = examResultRepository.findByExamIdAndUserIdAndScheduleId(form.getExamId(), SecurityUtil.getCurrentUserId(), form.getScheduleId());
        ExamQuestion question = examQuestionRepository.findByExamQuestionId(form.getExamQuestionId()).get();
        ExamQuestionResultText eq = textRepo.findByExamResultAndQuestion(examResult, question);
        String answer = form.getAnswer();
        byte isCorrect = 0;
        Integer mark = 0;
        String correctAnswer = question.getAnswer();
        if (answer.equals(correctAnswer)) {
            isCorrect = 1;
            mark = question.getMark();
        }
        if (eq != null) {
            return textRepo.save(new ExamQuestionResultText(eq.getExamQuestionResultTextId(), examResult, question, answer, correctAnswer, isCorrect, mark)) != null;
        } else {
            return textRepo.save(new ExamQuestionResultText(examResult, question, answer, correctAnswer, isCorrect, mark)) != null;
        }

    }

    @Override
    public boolean addImageAnswer(ImageAnswerForm form) {
        ExamResult examResult = examResultRepository.findByExamIdAndUserIdAndScheduleId(form.getExamId(), SecurityUtil.getCurrentUserId(), form.getScheduleId());
        ExamQuestion question = examQuestionRepository.findByExamQuestionId(form.getExamQuestionId()).get();
        ExamQuestionResultImage eq = imageRepo.findByExamResultAndQuestion(examResult, question);
        byte isCorrect;
        String answer = form.getAnswer();
        String correctAnswer = question.getAnswer();
        Integer mark = 0;
        if (answer != null) {
            isCorrect = 1;
            mark = question.getMark();
        } else {
            isCorrect = 0;
        }

        Integer correctCount = 0;
        Integer wrongCount = 0;

        if (eq != null) {
            return imageRepo.save(new ExamQuestionResultImage(eq.getExamQuestionResultImageId(), examResult, question, answer, correctAnswer, isCorrect, mark)) != null;
        } else {
            return imageRepo.save(new ExamQuestionResultImage(examResult, question, answer, correctAnswer, isCorrect, mark)) != null;
        }
    }

    @Override
    public List<ExamView> listExams() {
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        List<ExamView> examList;
        String search = "";
        if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
            examList = StreamSupport.stream(examRepository
                    .getExamByListByAdmin(examActiveStatus, currentUser.getOrganization().getOrganizationId(), search, Exam.EditingStatus.SAVED.value).spliterator(), false)
                    .map(exam -> new ExamView(exam, examQuestionRepository.countByStatusAndExam(ExamQuestion.Status.ACTIVE.value, exam)))
                    .collect(Collectors.toList());
        } else {
            examList = StreamSupport.stream(examRepository
                    .getExamByListByUser(examActiveStatus, currentUser.getUserId(), search, currentUser.getOrganization().getOrganizationId(), Exam.EditingStatus.SAVED.value).spliterator(), false)
                    .map(exam -> new ExamView(exam, examQuestionRepository.countByStatusAndExam(ExamQuestion.Status.ACTIVE.value, exam)))
                    .collect(Collectors.toList());
        }
        return examList;
    }
}