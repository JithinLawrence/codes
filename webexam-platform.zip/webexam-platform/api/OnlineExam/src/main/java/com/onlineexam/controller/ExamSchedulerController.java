package com.onlineexam.controller;

import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.*;
import com.onlineexam.service.ExamSchedulerService;
import com.onlineexam.service.ScheduleAssignService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.CandidateScheduleAssignView;
import com.onlineexam.view.ExamScheduleView;
import com.onlineexam.view.FileUploadView;
import com.onlineexam.view.QuestionBankView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Ramshad
 */
@RestController
@RequestMapping("admin/exam_schedule")
public class ExamSchedulerController {

    @Autowired
    ExamSchedulerService examSchedulerService;
    
    @Autowired
    private ScheduleAssignService scheduleAssignService;

    @PostMapping
    public ExamScheduleView add(@Valid @RequestBody ExamScheduleForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examSchedulerService.add(form);
    }


    @PutMapping("/{scheduleId}")
    public ExamScheduleView edit(@Valid @RequestBody ExamScheduleForm form, BindingResult bindingResult,
                                 @PathVariable("scheduleId") Long scheduleId) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examSchedulerService.edit(form, scheduleId);
    }

    @DeleteMapping("/{scheduleId}")
    public ExamScheduleView delete(@PathVariable("scheduleId") Long scheduleId) {
        return examSchedulerService.delete(scheduleId);
    }

    @GetMapping("/list")
    public Pager<ExamScheduleView> listSchedules(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ) {
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        return examSchedulerService.listSchedules(search, limit, sort, type, page);
        
    }
    
    @PostMapping("/assignCandidate/{scheduleId}/{examId}")
    public CandidateScheduleAssignView addTempQuestionBankQuestion(@Valid @RequestBody AssignCandidatesForm form, BindingResult bindingResult,
            @PathVariable("scheduleId") Long scheduleId,
            @PathVariable("examId") Long examId){
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
       CandidateScheduleAssignView candidateScheduleAssignView = examSchedulerService.assignCandidates(form,scheduleId, examId);
        return candidateScheduleAssignView;
    }

    @PostMapping("/uploadCandidateList")
    public FileUploadView imageUpload(
            @Valid MultipleImageUploadForm uploadForm, BindingResult bindingResult,
            @RequestParam(value = "examId", required = false) Long examId,
            @RequestParam(value = "scheduleId", required = false) Long scheduleId
    ) {
        if (bindingResult.hasErrors()) {
            System.out.println("Inside binding errors");
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        FileUploadView view;
        ArrayList<String[]> userList = new ArrayList<>();
//        System.out.println("File name : "+uploadForm.getFile().get(0));
        userList = readStudentEmails(uploadForm.getFile().get(0));
//        System.out.println("Csv file userlist count : "+userList.size());
        examSchedulerService.createCSVCandidates(userList, examId, scheduleId);
        view = new FileUploadView("", ""); 
        return view;
    }

    public ArrayList<String[]> readStudentEmails(MultipartFile csvFile) {
        ArrayList<String[]> userList = new ArrayList<>();
        try {
            InputStreamReader isr = new InputStreamReader(csvFile.getInputStream());
            BufferedReader bufRead = new BufferedReader(isr);
            String line = "";
            while ((line = bufRead.readLine()) != null) {
                String[] nextLine = line.split(",");
                if (nextLine[0].isEmpty() || nextLine.length == 0) {
                    break;
                }
                userList.add(nextLine);
            }
            bufRead.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userList;
    }

    @DeleteMapping("/deleteCandidate/{scheduleId}/{userId}")
    public void delete(@PathVariable("scheduleId") Long scheduleId,
            @PathVariable("userId") Long userId) {
        System.out.println("Inside schedule delete controll");
        scheduleAssignService.deleteAssignedUser(scheduleId, userId);
    }

}