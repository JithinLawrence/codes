/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Grade;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author jinu
 */
public class GradeView {
    
    private Long gradeId;
    private String name;
    private String description;
    private Long organizationId;
    private byte status;
    @Json.DateTimeFormat
    private Date createDate;
    @Json.DateTimeFormat
    private Date updateDate;
    
    public GradeView(Grade grade){
        this.gradeId = grade.getGradeId();
        this.name = grade.getName();
        this.description = grade.getDescription();
        this.organizationId = grade.getOrganization().getOrganizationId();
        this.status = grade.getStatus();
        this.createDate = grade.getCreateDate();
        this.updateDate = grade.getUpdateDate();       
    }

    public Long getGradeId() {
        return gradeId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }  

    public Long getOrganizationId() {
        return organizationId;
    }
    
    
}
