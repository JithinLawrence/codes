/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service.impl;

import com.onlineexam.entity.Organization;
import com.onlineexam.entity.Question;
import com.onlineexam.entity.QuestionBank;
import com.onlineexam.entity.QuestionBankQuestions;
import com.onlineexam.entity.User;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.ExamQuestionForm;
import com.onlineexam.repository.QuestionBankQuestionsRepository;
import com.onlineexam.repository.QuestionBankRepository;
import com.onlineexam.repository.QuestionRepository;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.service.QuestionBankQuestionService;
import com.onlineexam.util.LanguageUtil;
import com.onlineexam.view.QuestionBankView;
import com.onlineexam.view.QuestionListView;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author jinu
 */
@Service
public class QuestionBankQuestionServiceImpl implements QuestionBankQuestionService {
    
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    private LanguageUtil languageUtil;
    
    @Autowired
    QuestionRepository questionRepository;
    
    @Autowired
    QuestionBankRepository questionBankRepository;
    
    @Autowired
    QuestionBankQuestionsRepository questionBankQuestionRepository;
    
    @Override
    public QuestionBankView addTempQuestionBankQuestion(ExamQuestionForm form, Long questionBankId){
        List<QuestionBankQuestions> questionList = new ArrayList<QuestionBankQuestions>();
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        QuestionBank questionBankObj = new QuestionBank();
        Organization organization = currentUser.getOrganization();
        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                if(User.Role.SUPPORT.value != currentUser.getRole()){
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
      }
        if(questionBankId==0){
               questionBankObj = questionBankRepository.save(new QuestionBank(
                    "temp",
                    null,
                    currentUser,
                    QuestionBank.EditingStatus.TEMP_SAVE.value,
                    organization                    
            ));
        }else{
           Optional<QuestionBank> questionBk =  questionBankRepository.findByQuestionBankId(questionBankId);
           questionBankObj = questionBk.get();
        }
        List<Integer> questions = form.getQuestionId();
        for(Integer question : questions){
            Optional<Question> questionObj = questionRepository.findByQuestionId(question);
            Question questn = questionObj.get();              
            QuestionBankQuestions questionBankQuestionsObj = questionBankQuestionRepository.save(new QuestionBankQuestions(
                    questn,
                    questionBankObj,
                    QuestionBankQuestions.EditingStatus.TEMP_SAVE.value,
                    currentUser
            ));
           questionList.add(questionBankQuestionsObj);
        }
       return new QuestionBankView(questionBankObj,null,null); 
    }
    
    @Override
    public List<QuestionListView> listQuestions(Long questionBankId) {
        List<QuestionListView> questionsList = new ArrayList<QuestionListView>();
        List<QuestionBankQuestions> qbList = questionBankQuestionRepository.findAllByQuestionBankId(questionBankId);
        for(QuestionBankQuestions question : qbList){
           Integer qstnId  = question.getQuestionBankQuestionsId().getQuestion().getQuestionId();
           Optional<Question> qtn = questionRepository.findByQuestionId(qstnId);
           System.out.println("Question object : "+qtn);
           questionsList.add(new QuestionListView(qtn.get()));
        }
        return questionsList;
    }
    
    @Transactional
    @Override
    public void tempDeleteQuestionBankQuestions(Long questionBankId, Integer questionId) {
        questionBankQuestionRepository.deleteByQuestionIdAndQuestionBankId(questionBankId, questionId);
    }
}
