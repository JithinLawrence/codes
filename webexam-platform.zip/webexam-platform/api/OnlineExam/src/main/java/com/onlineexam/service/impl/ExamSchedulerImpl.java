package com.onlineexam.service.impl;

import com.onlineexam.entity.Exam;
import com.onlineexam.entity.ExamResult;
import com.onlineexam.entity.Organization;
import com.onlineexam.entity.Question;
import com.onlineexam.entity.QuestionBank;
import com.onlineexam.entity.QuestionBankQuestions;
import com.onlineexam.entity.Schedule;
import com.onlineexam.entity.ScheduleAssignCandidate;
import com.onlineexam.entity.User;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.exception.UnauthorizedException;
import com.onlineexam.form.AssignCandidatesForm;
import com.onlineexam.form.ExamQuestionForm;
import com.onlineexam.form.ExamScheduleForm;
import com.onlineexam.form.UserForm;
import com.onlineexam.repository.ExamRepository;
import com.onlineexam.repository.ExamResultRepository;
import com.onlineexam.repository.ExamScheduleRepository;
import com.onlineexam.repository.ScheduleAssignCandidateRepository;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.security.util.TokenGenerator;
import com.onlineexam.service.ExamSchedulerService;
import com.onlineexam.service.UserService;
import com.onlineexam.util.LanguageUtil;
import com.onlineexam.util.MailServiceUtil;
import com.onlineexam.util.Pager;
import com.onlineexam.view.CandidateScheduleAssignView;
import com.onlineexam.view.ExamScheduleView;
import com.onlineexam.view.QuestionBankView;
import com.onlineexam.view.UserView;
import java.io.IOException;
import java.time.Duration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.data.domain.Sort;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;

@Service
public class ExamSchedulerImpl implements ExamSchedulerService {

    @Autowired
    ExamScheduleRepository scheduleRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ExamRepository examRepository;
    @Autowired
    private LanguageUtil languageUtil;
    @Autowired
    private ScheduleAssignCandidateRepository candidateRepository;
    @Autowired
    UserService userService;
    @Autowired
    private MailServiceUtil mailServiceUtil;
    
    @Autowired
    private TokenGenerator tokenGenerator;
    
    @Autowired
    ExamResultRepository examResultRepository;
    
    private static final String PURPOSE_FORGOT_PASSWORD_TOKEN = "EXAM_INTIMATION_TOKEN";
    
    private static final String PURPOSE_EXAM_INVITATION_TOKEN = "EXAM_INVITATION_TOKEN";
    
    @Value("${baseurl.online.exam}")
    private String clientBaseUrl;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    private final byte[] examScheduleActiveStatus = {Schedule.Status.ACTIVE.value};
    private final byte[] candidateRole = {User.Role.CANDIDATE.value};


    @Override
    public ExamScheduleView add(ExamScheduleForm form) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Exam exam = examRepository.findByExamId(form.getExamId()).get();
        ExamScheduleView examScheduleView;
        Long count;

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        
        if(exam.getType() == 1){//public exam 
            //check for the same schedule is already created or not
         count =  scheduleRepository.countByExamAndOrganizationAndStartTimeAndEndTimeAndType(exam, currentUser.getOrganization(), form.getStartTime(), form.getEndTime(), exam.getScheduleType());
         if(count > 0){
             throw new BadRequestException(languageUtil.getTranslatedText("schedule.exists.date", null, "en"));
         }else{
                examScheduleView = new ExamScheduleView(scheduleRepository.save(new Schedule(                      
                form.getStartTime(),
                form.getEndTime(),
                exam,
                currentUser,
                currentUser.getOrganization()
        )));
            Schedule schedule = scheduleRepository.findByScheduleId(examScheduleView.getScheduleId()).get();
            if(schedule !=null){
            List<User> candidateList = userRepository.findAllByOrganizationAndRoleInAndStatus(currentUser.getOrganization(), candidateRole, User.Status.ACTIVE.value);
            for(User candidate : candidateList){
                candidateRepository.save(new ScheduleAssignCandidate(
                        candidate,
                        exam,
                       schedule
                ));
               } 
            }    
         }
       
        }else{
             examScheduleView = new ExamScheduleView(scheduleRepository.save(new Schedule(
                form.getStartTime(),
                form.getEndTime(),
                exam,
                currentUser,
                currentUser.getOrganization()
        ))); 
        }

      return examScheduleView;
    }

    @Override
    public ExamScheduleView edit(ExamScheduleForm form, Long scheduleId) {
        Schedule schedule = scheduleRepository.findByScheduleIdAndStatusIn(scheduleId, examScheduleActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("Schedule.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
            if (!schedule.getUser().getUserId().equals(currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        Long scheduleCount = scheduleRepository.countByScheduleIdNotAndStatusIn(scheduleId, examScheduleActiveStatus);

        if (scheduleCount !=1) {
            throw new BadRequestException(languageUtil.getTranslatedText("schedule.id.notfound", null, "en"));
        }
        if (!Objects.isNull(schedule)) {
            schedule = scheduleRepository.save(schedule.update(form));
        }
        return new ExamScheduleView(schedule);
    }

    @Override
    public ExamScheduleView delete(Long scheduleId) {
        Schedule schedule = scheduleRepository.findByScheduleIdAndStatusIn(scheduleId, examScheduleActiveStatus).get();//orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("schedule.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
            if (!schedule.getUser().getUserId().equals(currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        Long ongoingExamCount = examResultRepository.CountByScheduleAndStatus(schedule,ExamResult.Status.INPROGRESS.value);
        if(ongoingExamCount > 0)
            throw new BadRequestException(languageUtil.getTranslatedText("schedule.can.not.delete", null, "en"));
        else{
           if(schedule.getExam().getType() == Exam.Type.PRIVATE.value){
               candidateRepository.deleteByScheduleId(schedule.getScheduleId());
               List<ScheduleAssignCandidate> scheduledCandidatesList = candidateRepository.findAllBySchedule(schedule);
               for(ScheduleAssignCandidate scheduleAssignCandidate : scheduledCandidatesList){                        
                       
                        try {
                            mailServiceUtil.sendExamCancellationMail(scheduleAssignCandidate.getUser().getEmail(), scheduleAssignCandidate.getUser().getFirstName(), schedule.getExam().getName(), schedule.getStartTime());
                        } catch (MessagingException | IOException ex) {
                            System.out.println("Mail sending failed.");
                            System.out.println(ex.getMessage());
                            throw new BadRequestException(languageUtil.getTranslatedText("mail.sending.failed", null, "en"));
                        }
 
               }
               
           }else{
               candidateRepository.deleteByScheduleId(schedule.getScheduleId());
           }
            if (!Objects.isNull(schedule)) {
            schedule = scheduleRepository.save(schedule.delete(schedule));
        }
        }
        
        return new ExamScheduleView(schedule);
    }

    @Override
    public Pager<ExamScheduleView> listSchedules(String search, Integer limit, String sort, boolean type, Integer page) {
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        Pager<ExamScheduleView> examSchedulePager = new Pager(0, 0, 0);
        Long queryCount= 0L;
        List<ExamScheduleView> examScheduleList = new ArrayList<ExamScheduleView>();
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
      
        if(currentUser.getRole() == User.Role.SUPER_ADMIN.value){
            queryCount = scheduleRepository.countScheduleList(examScheduleActiveStatus, search, currentUser.getOrganization().getOrganizationId());
         if(StringUtils.isEmpty(search)){
            examScheduleList = StreamSupport.stream(scheduleRepository
                .getScheduleListByAdmin(examScheduleActiveStatus, currentUser.getOrganization().getOrganizationId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(schedule -> new ExamScheduleView(schedule))
                .collect(Collectors.toList()); 
        }else{
             examScheduleList = StreamSupport.stream(scheduleRepository
                .getScheduleListBySearchAdmin(examScheduleActiveStatus, search, currentUser.getOrganization().getOrganizationId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(schedule -> new ExamScheduleView(schedule))
                .collect(Collectors.toList());
            }
        }else if(currentUser.getRole() == User.Role.EXAM_PLANNER.value){
            
            queryCount = scheduleRepository.countScheduleListByPlanner(examScheduleActiveStatus, search, currentUser.getOrganization().getOrganizationId(),currentUser.getUserId());
           
             if(StringUtils.isEmpty(search)){
            examScheduleList = StreamSupport.stream(scheduleRepository
                .getScheduleListByPlanner(examScheduleActiveStatus, currentUser.getOrganization().getOrganizationId(),currentUser.getUserId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(schedule -> new ExamScheduleView(schedule))
                .collect(Collectors.toList()); 
        }else{
               
             examScheduleList = StreamSupport.stream(scheduleRepository
                .getScheduleListBySearch(examScheduleActiveStatus, search,currentUser.getOrganization().getOrganizationId(),currentUser.getUserId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(schedule -> new ExamScheduleView(schedule))
                .collect(Collectors.toList());
        }
        }else{
            
        }
        
        examSchedulePager = new Pager(limit, queryCount.intValue(), page);
        examSchedulePager.setResult(examScheduleList);
        return examSchedulePager;
    }   
    

    @Override
    public void createCSVCandidates(ArrayList<String[]> userList, Long examId, Long scheduleId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Exam exam = examRepository.findByExamId(examId).get();
        Schedule schedule = scheduleRepository.findByScheduleId(scheduleId).get();
        List<Long> returnList = new ArrayList<>();
        int count=0;
        User user=null;
        String inviteCode = "thisIsTheInviteCode";
        for(int i=0;i<userList.size();i++){
            
            String[] emails = userList.get(i);
            for(int j=0;j<emails.length;j++){
                System.out.println("Emails array print : "+j+" value"+emails[j]);
                User user1 = userRepository.findByEmail(emails[j]).orElse(null);
                if(user1 == null){
                    if (isValid(emails[j])){
                        count++;
                          int index = emails[j].indexOf('@');
                            String firstName = emails[j].substring(0,index);
                            String password = "User@123";
                         //added to user table
                    userRepository.save(new User(
                        firstName,
                        null,
                        emails[j],
                        User.Role.CANDIDATE.value,
                        passwordEncoder.encode(password),
                        currentUser.getOrganization()
                    ));
                     //added new user to schedule
                    User newUser = userRepository.findByEmail(emails[j]).get();
                    candidateRepository.save(new ScheduleAssignCandidate(
                                            newUser,
                                            exam,
                                           schedule
                                    ));
                    //sending exam invitation mail along with login credentials
                        String id = String.format("%010d", newUser.getUserId());
                        Duration duration = Duration.ofMinutes(30);
                        TokenGenerator.Token passwordToken = tokenGenerator.create(PURPOSE_EXAM_INVITATION_TOKEN, id, duration);
                        String resetLink = clientBaseUrl + passwordToken.value;
                        try {
                            mailServiceUtil.sendExamInvitationMail(newUser.getEmail(), newUser.getFirstName(), resetLink, exam.getName(), schedule.getStartTime(), password);
                        } catch (MessagingException | IOException ex) {
                            System.out.println("Mail sending failed.");
                            System.out.println(ex.getMessage());
                            throw new BadRequestException(languageUtil.getTranslatedText("mail.sending.failed", null, "en"));
                        }
                        //add token in user table
                        newUser.setPasswordToken(passwordToken.value);
                        userRepository.save(newUser);
                    }             
                   
                }else{
                    count++;
                    ScheduleAssignCandidate scheduleAssignCandidate = candidateRepository.findByScheduleAndExamAndUserAndStatus(schedule,exam,user1,ScheduleAssignCandidate.Status.ACTIVE.value);
                    if(scheduleAssignCandidate == null){
                     //assign this user to schedule;
                     candidateRepository.save(new ScheduleAssignCandidate(
                                            user1,
                                            exam,
                                           schedule
                                    ));
                    }
                    
                String id = String.format("%010d", user1.getUserId());
                Duration duration = Duration.ofMinutes(30);
                TokenGenerator.Token passwordToken = tokenGenerator.create(PURPOSE_FORGOT_PASSWORD_TOKEN, id, duration);
                String resetLink = clientBaseUrl + passwordToken.value;
                try {
                    mailServiceUtil.sendExamIntimationMail(user1.getEmail(), user1.getFirstName(), resetLink, exam.getName(), schedule.getStartTime());
                } catch (MessagingException | IOException ex) {
                    System.out.println("Mail sending failed.");
                    System.out.println(ex.getMessage());
                    throw new BadRequestException(languageUtil.getTranslatedText("mail.sending.failed", null, "en"));
                }
                }
               
            }
    
        }
        if(count==0){
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.csv.format", null, "en"));
        }
        //return count;    
    }
    
    @Override
    public CandidateScheduleAssignView assignCandidates(AssignCandidatesForm form, Long scheduleId, Long examId){        
        List<ScheduleAssignCandidate> assignCandidateList = new ArrayList<ScheduleAssignCandidate>();
        Exam exam = examRepository.findByExamId(examId).get();
        int userCount=0,scheduleCount=0;
        Schedule schedule = scheduleRepository.findByScheduleIdAndExam(scheduleId, exam);
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        QuestionBank questionBankObj = new QuestionBank();
        Organization organization = currentUser.getOrganization();
        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));           
        }
      }     
        List<Long> users = form.getUserId();
        for(Long user : users){
            userCount++;
            User candidate = userRepository.findByUserId(user).get();
            ScheduleAssignCandidate scheduleAssignCandidate = candidateRepository.findByScheduleAndExamAndUserAndStatus(schedule,exam,candidate,ScheduleAssignCandidate.Status.ACTIVE.value);
            if(scheduleAssignCandidate == null){
                scheduleCount++;
               assignCandidateList. add( candidateRepository.save(new ScheduleAssignCandidate(
                    candidate,
                    exam,
                    schedule
                )));
            ///////////////
              User emailUser = userRepository.findByEmail(candidate.getEmail()).orElse(null);
        if (null == emailUser) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.valid.email", null, "en"));
        }
        if (User.Status.ACTIVE.value != emailUser.getStatus()) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.not.active", null, "en"));
        }
        String id = String.format("%010d", emailUser.getUserId());
        Duration duration = Duration.ofMinutes(30);
        TokenGenerator.Token passwordToken = tokenGenerator.create(PURPOSE_FORGOT_PASSWORD_TOKEN, id, duration);
        String resetLink = clientBaseUrl + passwordToken.value;
        try {
            mailServiceUtil.sendExamIntimationMail(emailUser.getEmail(), emailUser.getFirstName(), resetLink, exam.getName(), schedule.getStartTime());
        } catch (MessagingException | IOException ex) {
            System.out.println("Mail sending failed.");
            System.out.println(ex.getMessage());
            throw new BadRequestException(languageUtil.getTranslatedText("mail.sending.failed", null, "en"));
        }
        //add token in user table
//        emailUser.setPasswordToken(passwordToken.value);
//        userRepository.save(emailUser); 
        }
        }
        if((userCount == scheduleCount)&&(userCount!=0&&scheduleCount!=0)){
            
        }else if((userCount != scheduleCount)&&(userCount!=0&&scheduleCount!=0)){
            
        }else if(userCount > 0 && scheduleCount == 0){
             throw new BadRequestException(languageUtil.getTranslatedText("schedule.assign.exist", null, "en"));
        }else{
            
        }
       return new CandidateScheduleAssignView(assignCandidateList,examId,exam.getName(), scheduleId); 
    }
    
    public static boolean isValid(String email) 
    { 
        String emailRegex = "^(([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
                              
        Pattern pat = Pattern.compile(emailRegex); 
        if (email == null) 
        return false; 
        return pat.matcher(email).matches(); 
    } 
}