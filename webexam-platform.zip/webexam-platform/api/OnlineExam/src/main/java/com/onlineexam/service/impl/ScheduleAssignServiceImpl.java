/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service.impl;

import com.onlineexam.entity.Exam;
import com.onlineexam.entity.Schedule;
import com.onlineexam.entity.ScheduleAssignCandidate;
import com.onlineexam.entity.User;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.repository.ExamAssignRepository;
import com.onlineexam.repository.ExamResultRepository;
import com.onlineexam.repository.ExamScheduleRepository;
import com.onlineexam.repository.ScheduleAssignCandidateRepository;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.service.ScheduleAssignService;
import com.onlineexam.util.LanguageUtil;
import com.onlineexam.util.MailServiceUtil;
import com.onlineexam.util.Pager;
import com.onlineexam.view.ExamAssignListView;
import java.io.IOException;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 *
 * @author simon
 */
@Service
public class ScheduleAssignServiceImpl implements ScheduleAssignService{
    
    @Autowired
    ExamAssignRepository examAssignRepository;
    
    @Autowired
    ExamResultRepository examResultRepository;
    
    @Autowired
    ScheduleAssignCandidateRepository scheduleAssignCandidateRepository;
    
    @Autowired
    ExamScheduleRepository scheduleRepository;
    
    @Autowired
    private MailServiceUtil mailServiceUtil;
    
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    private LanguageUtil languageUtil;
    
    private final byte[] activeStatus = {ScheduleAssignCandidate.Status.ACTIVE.value};
    private final byte[] examScheduleActiveStatus = {Schedule.Status.ACTIVE.value};
    
    @Override
    public Pager<ExamAssignListView> getUpcommingList(String search, Integer limit, String sort, boolean type, Integer page, long userId){
        Pager<ExamAssignListView> examAssignPager = new Pager(0, 0, 0);
        Long queryCount;
        List<ExamAssignListView> examUpCommingList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        queryCount = examAssignRepository.countExamUpcommingAssignList(activeStatus, search, userId);
        examUpCommingList = StreamSupport.stream(examAssignRepository
                .getExamUpcommingAssignList(activeStatus, search, userId, PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .filter(exam -> examResultRepository.findByExamIdAndUserIdAndScheduleId(exam.getExam().getExamId(),SecurityUtil.getCurrentUserId(), exam.getSchedule().getScheduleId()) == null)
                .map(exam ->  new ExamAssignListView(exam))
                .collect(Collectors.toList());
        examAssignPager = new Pager(limit, queryCount.intValue(), page);
        examAssignPager.setResult(examUpCommingList);
        
        return examAssignPager;

    }
    
    @Override
    public Pager<ExamAssignListView> getElapsedList(String search, Integer limit, String sort, boolean type, Integer page, long userId){
        Pager<ExamAssignListView> examAssignPager = new Pager(0, 0, 0);
        Long queryCount;
        List<ExamAssignListView> examUpCommingList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        queryCount = examAssignRepository.countExamElapsedAssignList(activeStatus, search, userId);
        examUpCommingList = StreamSupport.stream(examAssignRepository
                .getExamElapsedAssignList(activeStatus, search, userId, PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(exam -> new ExamAssignListView(exam))
                .collect(Collectors.toList());
        examAssignPager = new Pager(limit, queryCount.intValue(), page);
        examAssignPager.setResult(examUpCommingList);
        return examAssignPager;

    }
    
    @Override 
    public void registerExam(long scheduleAssignId){
        examAssignRepository.setStatusRegistered(scheduleAssignId);
    }
    
    @Transactional
    @Override
    public void deleteAssignedUser(Long scheduleId, Long userId) {
        Schedule schedule = scheduleRepository.findByScheduleIdAndStatusIn(scheduleId, examScheduleActiveStatus).get();//orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("schedule.not.found", null, "en")));
        if(schedule.getExam().getType() == Exam.Type.PRIVATE.value){ 
            User user = userRepository.findByUserId(userId).get();
                       try {
                            mailServiceUtil.sendExamCancellationMail(user.getEmail(), user.getFirstName(), schedule.getExam().getName(), schedule.getStartTime());
                        } catch (MessagingException | IOException ex) {
                            System.out.println("Mail sending failed.");
                            System.out.println(ex.getMessage());
                            throw new BadRequestException(languageUtil.getTranslatedText("mail.sending.failed", null, "en"));
                        }
 
            scheduleAssignCandidateRepository.deleteByScheduleIdAndUserId(scheduleId, userId);
               
           }else{
            scheduleAssignCandidateRepository.deleteByScheduleIdAndUserId(scheduleId, userId);
        }
        
    }
  
}
