/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Category;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class CategoryListView {
    private final Long categoryId;
    private final String name;
    private final String description;
    private final String organization;
    private final Long organization_id;
    private final byte status;
    @Json.DateFormat
    private final Date createDate;
    @Json.DateFormat
    private final Date updateDate;

    public CategoryListView(Category category) {
        this.categoryId = category.getCategoryId();
        this.name = category.getName();
        this.description = category.getDescription();
        this.organization = category.getOrganization().getName();
        this.organization_id = category.getOrganization().getOrganizationId();
        this.status = category.getStatus();
        this.createDate = category.getCreateDate();
        this.updateDate = category.getUpdateDate();
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getOrganization() {
        return organization;
    }

    public Long getOrganization_id() {
        return organization_id;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    
    
    
}
