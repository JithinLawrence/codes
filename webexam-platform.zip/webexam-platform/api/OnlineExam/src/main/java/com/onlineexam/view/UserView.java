/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.User;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author nirmal
 */
public class UserView {

    private final long userId;
    private final String firstName;
    private final String lastName;
    private final String email;
    private final String status;
    private final String imageUrl;
    private final short role;
    private String grade;
    @Json.DateTimeFormat
    private final Date createDate;
    @Json.DateTimeFormat
    private final Date updateDate;

    public UserView(User user) {
        this.userId = user.getUserId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.email = user.getEmail();
        this.imageUrl = user.getImageUrl()!=null? user.getImageUrl() : "";
        if(user.getStatus()==1){
            this.status = "Approved";
        }else if(user.getStatus()==2){
            this.status = "Pending";
        }else{
            this.status = "Deleted";
        }
        this.role = user.getRole();
        if(user.getGrade()!=null){
          this.grade = user.getGrade().getName();          
        }
        this.createDate = user.getCreateDate();
        this.updateDate = user.getUpdateDate();
    }

    public long getUserId() {
        return userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getStatus() {
        return status;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public short getRole() {
        return role;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    
    public String getGrade() {
        return grade;
    }
}
