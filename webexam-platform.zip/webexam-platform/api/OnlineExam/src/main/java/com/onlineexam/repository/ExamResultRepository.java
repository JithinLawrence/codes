/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Exam;
import com.onlineexam.entity.ExamResult;
import com.onlineexam.entity.Schedule;
import com.onlineexam.entity.User;
import java.util.Date;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author jinu
 */
public interface ExamResultRepository extends Repository<ExamResult, Long> {

    float countByExam(Exam exam);

    Long countByExamAndStatus(Exam examEntity, byte value);

    ExamResult save(ExamResult examResult);

    Optional<ExamResult> findByExamResultId(long examresultId);

    @Query(value = "SELECT * FROM exam_result WHERE exam_id = ?1 AND user_id = ?2 AND schedule_id = ?3", nativeQuery = true)
    ExamResult findByExamIdAndUserIdAndScheduleId(long examId, long UserId, long scheduleId);

    @Query(value = "SELECT MAX(mark) FROM exam_result WHERE exam_id=?1", nativeQuery = true)
    Long findMaxScore(Long examId);

    @Query(value = "SELECT MIN(mark) FROM exam_result WHERE exam_id=?1", nativeQuery = true)
    Long findMinScore(Long examId);

    @Query(value = "SELECT AVG(mark) FROM exam_result WHERE exam_id=?1", nativeQuery = true)
    Long findAvgScore(Long examId);

    @Query(value = "select COUNT(*) FROM exam_result WHERE mark > (SELECT AVG(mark) FROM exam_result WHERE exam_id=?1 ) AND exam_id=?1", nativeQuery = true)
    Long findCountGTAvg(Long examId);

    @Query(value = "select COUNT(*) FROM exam_result WHERE mark < (SELECT AVG(mark) FROM exam_result WHERE exam_id=?1 ) AND exam_id=?1", nativeQuery = true)
    Long findCountLTAvg(Long examId);

    @Query(value = "SELECT COUNT(er.exam_result_id) FROM exam_result er "
            + " INNER JOIN exam e ON e.exam_id = er.exam_id"
            + " WHERE er.mark >= e.pass_mark AND er.exam_id =?1", nativeQuery = true)
    float findPassCount(Long examId);

    @Query(value = "SELECT COUNT(er.exam_result_id) FROM exam_result er "
            + " INNER JOIN exam e ON e.exam_id = er.exam_id"
            + " WHERE er.mark < e.pass_mark AND er.exam_id =?1", nativeQuery = true)
    float findFailCount(Long examId);

//    @Query(value = "SELECT DATE_FORMAT((TIMEDIFF((SELECT DATE_FORMAT(end_time, \"%H:%i\") FROM schedule WHERE exam_id=?1),(SELECT DATE_FORMAT(start_time, \"%H:%i\") FROM schedule WHERE exam_id=?1))), \"%H:%i\")as exam_schedule " +
//                    " FROM schedule s" +
//                    " INNER JOIN exam e ON e.exam_id = s.exam_id" +
//                    " WHERE e.exam_id=?1" , nativeQuery = true)
    @Query(value = "SELECT duration from exam where exam_id=?1", nativeQuery = true)
    Integer findExamSchedule(Long examId);

    @Query(value = "SELECT COUNT(*) FROM exam_result u JOIN exam e ON u.exam_id = e.exam_id JOIN schedule s on u.schedule_id = s.schedule_id WHERE u.status in ?1 AND u.user_id = ?3 AND (e.name like %?2% OR e.description like %?2%) AND u.status in ?1", nativeQuery = true)
    Long countExamResultList(byte[] activeStatus, String search, long userId);

    @Query(value = "SELECT u.* FROM exam_result u JOIN exam e ON u.exam_id = e.exam_id JOIN schedule s on u.schedule_id = s.schedule_id WHERE u.status in ?1 AND u.user_id = ?3 AND (e.name like %?2% OR e.description like %?2%) AND u.status in ?1", nativeQuery = true)
    Page<ExamResult> getExamResultList(byte[] activeStatus, String search, long userId, PageRequest of);

    ExamResult findByExamAndUser(Exam exam, User user);

    @Query(value = "SELECT start_time FROM exam_result where exam_id = ?1 AND user_id =?2 AND schedule_id=?3", nativeQuery = true)
    Date getStartTime(long examId, long userId, long scheduleId);

    @Transactional
    @Modifying
    @Query(value = "UPDATE exam_result SET status = ?4 ,mark = ?5 , end_time = NOW() WHERE exam_id = ?1 AND user_id =?2 AND schedule_id=?3", nativeQuery = true)
    void updateExamStatus(long examId, long userId, long scheduleId, byte status,int marks);
    
    @Query(value = "SELECT * FROM exam_result WHERE exam_id = ?1 AND user_id = ?2 AND schedule_id = ?3 AND status=?4", nativeQuery = true)
    ExamResult findByExamIdAndUserIdAndScheduleIdAndStatus(long examId, long UserId, long scheduleId, byte status);

    @Query(value = "SELECT COUNT(*) FROM exam_result WHERE exam_id = ?1 AND user_id = ?2 AND schedule_id = ?3 AND status=?4", nativeQuery = true)
    Long countByExamIdAndUserIdAndScheduleIdAndStatus(long examId, long UserId, long scheduleId, byte status);
    
    @Query(value = "SELECT COUNT(*) FROM exam_result WHERE schedule_id = ?1 AND status=?2", nativeQuery = true)
    Long CountByScheduleAndStatus(Schedule schedule, byte status);
}
