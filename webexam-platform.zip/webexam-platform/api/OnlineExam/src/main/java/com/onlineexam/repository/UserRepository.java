/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.User;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import com.onlineexam.entity.Organization;
import com.onlineexam.view.UserView;
import java.util.List;

/**
 *
 * @author nirmal
 */
public interface UserRepository extends Repository<User, Long> {

    Optional<User> findByUserId(Long userId);

    Optional<User> findByUserIdAndPassword(Long userId, String password);

    Optional<User> findByEmail(String email);

    Long countByStatusInAndFirstNameAndLastNameAndOrganizationAndEmail(byte[] status, String firstName, String lastName, Organization organization, String email);
    
    Long countByStatusInAndFirstNameAndLastNameAndUserIdNotAndOrganizationAndEmail(byte[] status, String firstName, String lastName, Long userId, Organization organization, String email);
    
//    Long countByStatusInAndFirstNameAndLastNameAndUserIdNot(byte[] status, String firstName, String lastName, Long userId);
    
    User save(User user);

    @Query(value = "SELECT COUNT(*) FROM user as u WHERE u.role in ?1 AND u.status in ?2 AND (u.first_name like %?3% OR u.last_name like %?3% OR u.email like %?3%) AND u.organization_id=?4 ", nativeQuery = true)
    Long countUserList(byte[] roles, byte[] status, String search, Long orgId);

    @Query(value = "SELECT * FROM user as u WHERE u.role in ?1 AND u.status in ?2 AND (u.first_name like %?3% OR u.last_name like %?3% OR u.email like %?3%) AND u.organization_id=?4", nativeQuery = true)
    Page<User> getUserList(byte[] roles, byte[] status, String search, Long orgId, Pageable page);

    Optional<User> findByUserIdAndStatus(Long userId, byte status);
    
    @Query(value = "SELECT COUNT(*) FROM user as u WHERE u.role in ?1 AND u.status in ?2 AND (u.first_name like %?3% OR u.last_name like %?3% OR u.email like %?3%) AND u.grade_id=?4 And u.organization_id=?5 ", nativeQuery = true)
    Long countCandidatesList(byte[] roles, byte[] status, String search, Long grade, Organization org);
    
    @Query(value = "SELECT * FROM user as u WHERE u.role in ?1 AND u.status in ?2 AND (u.first_name like %?3% OR u.last_name like %?3% OR u.email like %?3%) AND u.grade_id=?4 AND u.organization_id=?5 ", nativeQuery = true)
    Page<User> getCandidateListByGrade(byte[] roles, byte[] status, String search, Long grade, Organization org, Pageable page);   
    
    @Transactional
    @Modifying
    @Query(value = "update user set status = ?1 where user_id = ?2", nativeQuery = true)
    void editStatus(byte savedEditingStatus, Long examId);
    
   List<User> findAllByOrganizationAndRoleInAndStatus(Organization org, byte[] role, byte status);
   
   @Query(value="SELECT COUNT(*) FROM user WHERE user_id NOT IN(SELECT user_id FROM schedule_assign_candidate WHERE schedule_id=?1 AND status=?2) AND organization_id=?3 AND status=?4 AND role=?5 AND grade_id=?6" , nativeQuery = true)
   Long countUnassignedCandidateWithGrade(Long scheduleId, byte scheduleStatus, Long org, byte userStatus, byte userRole, Long gradeId);
   
   @Query(value = "SELECT * FROM user WHERE user_id NOT IN(SELECT user_id FROM schedule_assign_candidate WHERE schedule_id=?1 AND status=?2) AND organization_id=?3 AND status=?4 AND role=?5 AND grade_id=?6 ", nativeQuery = true)
   Page<User> getUnassignedCandidateListByGrade(Long scheduleId, byte scheduleStatus, Long org, byte userStatus, byte userRole, Long gradeId, Pageable page);
   
   @Query(value="SELECT COUNT(*) FROM user WHERE user_id NOT IN(SELECT user_id FROM schedule_assign_candidate WHERE schedule_id=?1 AND status=?2) AND organization_id=?3 AND status=?4 AND role=?5" , nativeQuery = true)
   Long countUnassignedCandidateWithOutGrade(Long scheduleId, byte scheduleStatus, Long org, byte userStatus, byte userRole);
   
   @Query(value = "SELECT * FROM user WHERE user_id NOT IN(SELECT user_id FROM schedule_assign_candidate WHERE schedule_id=?1 AND status=?2) AND organization_id=?3 AND status=?4 AND role=?5", nativeQuery = true)
   Page<User> getUnassignedCandidateListWithOutGrade(Long scheduleId, byte scheduleStatus, Long org, byte userStatus, byte userRole, Pageable page);
   
   @Query(value="SELECT * FROM user WHERE user_id IN(SELECT user_id FROM schedule_assign_candidate WHERE schedule_id=?1 AND status=1) AND status=1 AND role=3", nativeQuery = true)
   List<User> findAllScheduleAssignedCandidate(Long scheduleId);
}
