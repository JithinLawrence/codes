/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.QuestionBank;
import com.onlineexam.json.Json;
import java.util.Date;
import java.util.List;

/**
 *
 * @author sanal
 */
public class QuestionBankView {
    
    private Long questionBankId;
    private String title;
    private String description;
    private List<Long> categoryIds;
    private List<Long> gradeIds;
    private Long createdBy;
    private byte status;
    @Json.DateTimeFormat
    private Date createDate;
    @Json.DateTimeFormat
    private Date updateDate;

    public QuestionBankView(QuestionBank questionBank, List<Long> categoryIds, List<Long> gradeIds) {
        this.questionBankId = questionBank.getQuestionBankId();
        this.title = questionBank.getTitle();
        this.description = questionBank.getDescription();
        this.createdBy = questionBank.getUser().getUserId();
        this.status = questionBank.getStatus();
        this.createDate = questionBank.getCreateDate();
        this.updateDate = questionBank.getUpdateDate();
        this.categoryIds = categoryIds;
        this.gradeIds = gradeIds;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Long getQuestionBankId() {
        return questionBankId;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public List<Long> getGradeIds() {
        return gradeIds;
    }
    
}
