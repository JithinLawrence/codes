/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.Date;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author sanal
 */
@Entity
public class OrganizationStudents {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }
    @EmbeddedId
    private OrganizationStudentsId organizationStudentsId;
    private byte status;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;

    public OrganizationStudents() {
    }

    public OrganizationStudents(User user, Organization organization) {
        this.organizationStudentsId = new OrganizationStudentsId(user, organization);
        this.status = Status.ACTIVE.value;
        this.createDate = new Date();
    }

    public OrganizationStudentsId getOrganizationStudentsId() {
        return organizationStudentsId;
    }

    public void setOrganizationStudentsId(OrganizationStudentsId organizationStudentsId) {
        this.organizationStudentsId = organizationStudentsId;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

}
