/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.User;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author simon
 */
public class CandidateView {
    private final long userId;
    private final String firstName;
    private final String lastName;
    private final String email;
    private final short status;
    private final short role;
    @Json.DateFormat
    private Date dob;
    @Json.DateTimeFormat
    private final Date createDate;
    @Json.DateTimeFormat
    private final Date updateDate;
    private String imageUrl;
    private long gradeId;
    private long  organizationId;

    public CandidateView(User user) {
        this.userId = user.getUserId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.email = user.getEmail();
        this.status = user.getStatus();
        this.role = user.getRole();
        this.dob = user.getDob();
        this.createDate = user.getCreateDate();
        this.updateDate = user.getUpdateDate();
        this.imageUrl = user.getImageUrl();
        this.gradeId = user.getGrade().getGradeId();
        this.organizationId = user.getOrganization().getOrganizationId();
    }

    public long getUserId() {
        return userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public short getStatus() {
        return status;
    }

    public short getRole() {
        return role;
    }

    public Date getDob() {
        return dob;
    }
    
    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    
    public String getImageUrl() {
        return imageUrl;
    }
 

    public long getGradeId() {
        return gradeId;
    }

    public long getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(long organizationId) {
        this.organizationId = organizationId;
    }
    
}
