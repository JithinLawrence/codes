/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.ChangePasswordForm;
import com.onlineexam.form.ResetPasswordForm;
import com.onlineexam.form.UserForm;
import com.onlineexam.form.UserPasswordChangeForm;
import com.onlineexam.form.UserUpdateForm;
import com.onlineexam.service.UserService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.LoginView;
import com.onlineexam.view.UserView;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirmal
 */
@RestController
@RequestMapping("/users")
public class UsersController {

    @Autowired
    private UserService userService;

    @GetMapping
    public UserView currentUser() {
        return userService.currentUser();
    }

    @GetMapping("/checkLogin")
    public UserView checkLogin() {
        return userService.currentUser();
    }

    @PostMapping
    public UserView add(@Valid @RequestBody UserForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return userService.add(form);
    }

    @GetMapping("/list")
    public Pager<UserView> listUsers(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ) {
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }    
        return userService.listUsers(search, limit, sort,type,page);
    }

    @PutMapping("/{userId}")
    public UserView edit(
            @Valid @RequestBody UserUpdateForm form, BindingResult bindingResult,
            @PathVariable("userId") Long userId
    ) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return userService.edit(form, userId);
    }

    @PutMapping 
    public UserView editCurrentUser(@Valid @RequestBody UserUpdateForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return userService.editOwn(form, userService.currentUser().getUserId());
    }

    @DeleteMapping("/{userId}")
    public UserView delete(
            @PathVariable("userId") Long userId
    ) {
        return userService.delete(userId);
    }

    @PutMapping("/changePassword")
    public UserView changePassword (
            @Valid @RequestBody ChangePasswordForm form, BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return userService.updatePassword(form);
    }
    
    @PutMapping("/changeUserPassword/{userId}")
    public UserView changeUserPassword (
            @Valid @RequestBody UserPasswordChangeForm form, BindingResult bindingResult,
            @PathVariable("userId") Long userId
    ) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return userService.updateUserPassword(form,userId);
    }

    @PutMapping("/resetPassword")
    public UserView resetPassword (
            @Valid @RequestBody ResetPasswordForm form, BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return userService.resetPassword(form);
    }
}
