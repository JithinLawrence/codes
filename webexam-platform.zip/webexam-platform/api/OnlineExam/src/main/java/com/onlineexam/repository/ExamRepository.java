/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Exam;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author sanal
 */
public interface ExamRepository extends Repository<Exam, Long>{
    
    Optional<Exam> findByExamId(Long examId);
    
    @Query(value = "select e.* from exam as e where "
            + " (( e.status = ?1 and (e.editing_status = ?2 or e.editing_status= ?3 )) or "//active 
            + " ( e.status = ?4 and e.editing_status = ?5 )) "//active 
            + " and e.exam_id = ?6 "//active 
            , nativeQuery = true)
    Optional<Exam> findByExamIdAndAllStatusAndAllEditingStatus(byte examActiveStatus, byte examEditingStatusTempUpdate, 
            byte examEditingStatusSaved, byte examInactiveStatus, byte examEditingStatusTempSave, Long examId);
    
    
    Optional<Exam> findByExamIdAndStatusIn(Long examId, byte[] status);
    
    Optional<Exam> findByExamIdAndStatusInAndEditingStatusIn(Long examId, byte[] status, byte[] editingStatus);
    
    Long countByStatusInAndName(byte[] status, String name);
    
    Long countByStatusInAndNameAndExamIdNot(byte[] status, String name, Long examId);
    
    Long countByStatusInAndEditingStatusInAndName(byte[] status, byte[] editingStatus, String name);
    
//    Long countByExamIdAndStatusIn(Long examId, byte[] status);
    
    Long countByExamIdNotAndStatusInAndName(Long examId, byte[] status, String name);
    
    Long countByExamIdNotAndStatusInAndEditingStatusInAndName(Long examId, byte[] status, byte[] editingStatus, String name);
    
    @Query(value = "SELECT COUNT(*) FROM exam as u WHERE u.status in ?1 AND u.created_by = ?2 AND (u.name like %?3% OR u.description like %?3%) ", nativeQuery = true)
    Long countExamListByUser(byte[] status, Long userId, String search);
    
    @Query(value = "SELECT COUNT(*) FROM exam as u WHERE u.status in ?1 AND u.editing_status in ?2 AND (u.name like %?3% OR u.description like %?3%) ", nativeQuery = true)
    Long countExamListWithEditingStatus(byte[] status, byte[] editingStatus, String search);

    @Query(value = "SELECT * FROM exam as u WHERE u.status in ?1 AND u.created_by = ?2 AND (u.name like %?3% OR u.description like %?3%)", nativeQuery = true)
    Page<Exam> getExamListByUser(byte[] status, Long userId, String search, Pageable page);

    @Query(value = "SELECT * FROM exam as u WHERE u.status in ?1 AND u.editing_status in ?2 AND (u.name like %?3% OR u.description like %?3%)", nativeQuery = true)
    Page<Exam> getExamListWithEditingStatus(byte[] status, byte[] editingStatus, String search, Pageable page);

    Exam save(Exam exam);
    
    @Query(value = "SELECT COUNT(sc.exam_id) FROM schedule_assign_candidate sc\n" +
            "INNER JOIN exam e ON e.exam_id = sc.exam_id\n" +
            "WHERE sc.user_id=?1 AND (e.name like %?2% OR e.description like %?2%) AND e.status = 1 AND e.editing_status=1 " , nativeQuery = true)
    Long countCandidateExamList(Long userId, String search);
    
    @Query(value = "SELECT er.* FROM exam as er \n" +
            " INNER JOIN schedule_assign_candidate sc on sc.exam_id = er.exam_id\n" +
            " WHERE  er.status in ?1 AND sc.status in ?1 AND (er.name like %?2% OR er.description like %?2%) AND sc.user_id =?3 ", nativeQuery = true)
    Page<Exam> getCandidateExamList(byte[] status, String search, Long user, Pageable page);
    
    @Query(value="SELECT DISTINCT DATE_FORMAT(s.start_time,\"%d-%M-%Y %h.%i\") FROM exam e\n" +
            "INNER JOIN schedule_assign_candidate sc ON sc.exam_id = e.exam_id\n" +
            "INNER JOIN schedule s ON s.schedule_id = sc.schedule_id AND s.exam_id = sc.exam_id\n" +
            "WHERE e.exam_id =?2 AND e.status in ?1 AND s.schedule_id = ?3" , nativeQuery = true)
    String getExamStartDate(byte[] status, Long examId, Long scheduleId);
    
    @Query(value = "SELECT COUNT(sc.exam_result_id) FROM exam_result sc\n" +
            "WHERE sc.user_id=?1 AND sc.status=?2 " , nativeQuery = true)
    Long completedExamsCount(Long userId, byte status);
    
    @Query(value = "SELECT COUNT(sc.schedule_assign_id) FROM schedule_assign_candidate sc\n" +
            "INNER JOIN schedule s ON s.schedule_id = sc.schedule_id AND s.exam_id = sc.exam_id\n" +
            "WHERE sc.exam_id NOT IN (SELECT exam_id FROM exam_result WHERE user_id=?1) AND sc.user_id=?1 AND s.start_time > now() " , nativeQuery = true)
    Long upcomingExamsCount(Long userId);
    
    @Query(value = "SELECT COUNT(sc.schedule_assign_id) FROM schedule_assign_candidate sc\n" +
            "INNER JOIN schedule s ON s.schedule_id = sc.schedule_id AND s.exam_id = sc.exam_id\n" +
            "WHERE sc.exam_id NOT IN (SELECT exam_id FROM exam_result WHERE user_id=?1) AND sc.user_id=?1 AND s.start_time < now()" , nativeQuery = true)
    Long expiredExamsCount(Long userId);
    
    @Query(value = "SELECT COUNT(*) FROM exam as u WHERE u.status in ?1 AND u.organization_id = ?2 AND (u.name like %?3% OR u.description like %?3%) ", nativeQuery = true)
    Long countExamListByAdmin(byte[] status, Long org, String search);
    
    @Query(value = "SELECT * FROM exam as u WHERE u.status in ?1 AND u.organization_id = ?2 AND (u.name like %?3% OR u.description like %?3%)", nativeQuery = true)
    Page<Exam> getExamListByAdmin(byte[] status, Long org, String search, Pageable page);
    
    @Query(value = "SELECT duration FROM exam where exam_id = ?1", nativeQuery = true)
    int getDuration(int examId);
    
    @Query(value = "SELECT DISTINCT u.* FROM exam AS u \n" +
                    " INNER JOIN exam_question q ON q.exam_id = u.exam_id WHERE u.status in ?1 AND u.organization_id = ?2 AND (u.name like %?3% OR u.description like %?3%) AND u.editing_status =?4", nativeQuery = true)
    List<Exam> getExamByListByAdmin(byte[] status, Long org, String search, byte editingStatus);
    
    @Query(value = "SELECT DISTINCT u.* FROM exam AS u \n" +
                    " INNER JOIN exam_question q ON q.exam_id = u.exam_id WHERE u.status in ?1 AND u.created_by = ?2 AND (u.name like %?3% OR u.description like %?3%) AND u.organization_id=?4 AND u.editing_status=?5 ", nativeQuery = true)
    List<Exam> getExamByListByUser(byte[] status, Long userId, String search, Long org, byte editingStatus);
    
}
