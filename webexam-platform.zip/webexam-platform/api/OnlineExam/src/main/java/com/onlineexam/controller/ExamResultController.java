/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.service.ExamResultService;
import com.onlineexam.service.UserService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.ExamResultView;
import com.onlineexam.view.ExamResultsListView;
import java.util.HashMap;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author simon
 */

@RestController
@RequestMapping("/admin/exam_result")
public class ExamResultController {
    
        
    @Autowired
    private UserService userService;
    
    @Autowired
    private  ExamResultService examResultService;

    
    @GetMapping("/get_exam_history")
    public Pager<ExamResultsListView> examResultList(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ){
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        return examResultService.getResultsList(search, limit, sort, type, page,userService.currentUser().getUserId());
    }
    
    @GetMapping("/getExamResult")
    public HashMap<String , String> getExamResult(
            @RequestParam(value = "user") Long  user,
            @RequestParam(value = "examId") Long examId,
            @RequestParam(value = "scheduleId") Long scheduleId
            ){
       return examResultService.getExamResult(examId, user, scheduleId);
    }
    
    @GetMapping("/getExamQuestionResult")
    public List<ExamResultView> getExamQuestionResult(
            @RequestParam(value = "user") Long  user,
            @RequestParam(value = "examId") Long examId
            ){
       return examResultService.getExamQuestionResult(examId, user);
    }
    
    
}
