/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.form;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sanal
 */
public class ExamUpdateForm {
    @NotBlank
    @Size(max = 100)
    private String name;
    private String description;
    private String termsAndConditions;
    @NotNull
    private byte type;
    @NotNull
    private Integer duration;
    @NotNull
    private byte scheduleType;
    @NotNull
    private byte showMark;
    @NotNull
    private Integer totalMark;
    @NotNull
    private Integer passMark;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(String termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public byte getScheduleType() {
        return scheduleType;
    }

    public byte getShowMark() {
        return showMark;
    }

    public void setShowMark(byte showMark) {
        this.showMark = showMark;
    }

    public void setScheduleType(byte scheduleType) {
        this.scheduleType = scheduleType;
    }

    public Integer getTotalMark() {
        return totalMark;
    }

    public void setTotalMark(Integer totalMark) {
        this.totalMark = totalMark;
    }

    public Integer getPassMark() {
        return passMark;
    }

    public void setPassMark(Integer passMark) {
        this.passMark = passMark;
    }
    
}
