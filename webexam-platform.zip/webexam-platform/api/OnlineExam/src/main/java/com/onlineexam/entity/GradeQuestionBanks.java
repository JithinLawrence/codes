/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.Date;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author sanal
 */
@Entity
public class GradeQuestionBanks {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }
    @EmbeddedId
    private GradeQuestionBanksId gradeQuestionBanksId;
    private byte status;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;

    public GradeQuestionBanks() {
    }

    public GradeQuestionBanks(QuestionBank questionBank, Grade grade) {
        this.gradeQuestionBanksId = new GradeQuestionBanksId(questionBank, grade);
        this.status = Status.ACTIVE.value;
        this.createDate = new Date();
    }

    public GradeQuestionBanksId getGradeQuestionBanksId() {
        return gradeQuestionBanksId;
    }

    public void setGradeQuestionBanksId(GradeQuestionBanksId gradeQuestionBanksId) {
        this.gradeQuestionBanksId = gradeQuestionBanksId;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

}
