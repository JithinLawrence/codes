/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.ExamQuestionResultCheckbox;
import com.onlineexam.entity.ExamQuestionResultRadio;
import com.onlineexam.entity.ExamResult;
import com.onlineexam.entity.Question;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import javax.transaction.Transactional;

/**
 *
 * @author jinu
 */
public interface ExamResultCheckboxRepository extends Repository<ExamQuestionResultCheckbox, Integer>{
 
    @Query(value="SELECT count(*) FROM exam_question_result_checkbox where exam_result_id=?1 AND (correct_count>0 AND wrong_count=0)", nativeQuery = true)
    Integer countByExamResultId(Long examResultId);
    
    ExamQuestionResultCheckbox findByExamResultAndQuestion(ExamResult examResult, ExamQuestion question); 
    
    ExamQuestionResultCheckbox save(ExamQuestionResultCheckbox exqr);
    
    @Query(value = "delete from exam_question_result_radio where exam_question_result_radio_id = ?1 ", nativeQuery = true)
    void deleteByExamQuestionResultRadioId(Integer ExamQuestionResultCheckboxId);

    @Transactional
    @Modifying
    @Query(value = "update exam_question_result_checkbox set correct_count = ?1, mark = ?2 where exam_question_id = ?3", nativeQuery = true)
    void updateExamQuestionResultCheckboxItems(Integer is_correct, Integer mark, Integer examQuestionId);

}
