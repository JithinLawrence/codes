package com.onlineexam.controller;


import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.ExamEvaluateForm;
import com.onlineexam.form.ExamScheduleForm;
import com.onlineexam.form.QuestionBankForm;
import com.onlineexam.form.QuestionForm;
import com.onlineexam.service.ExamEvaluationService;
import com.onlineexam.service.ExamResultService;
import com.onlineexam.view.BasicView;
import com.onlineexam.view.ExamEvaluationView;
import com.onlineexam.view.ExamResultView;
import com.onlineexam.view.ExamScheduleView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/admin/exam_evaluate")
public class ExamEvaluationController {
    @Autowired
    private ExamEvaluationService examEvaluationService;

    @Autowired
    private  ExamResultService examResultService;

    @GetMapping("/getExamResult")
    public HashMap<String , String> getExamResult(
            @RequestParam(value = "user") Long  user,
            @RequestParam(value = "examId") Long examId,
            @RequestParam(value = "scheduleId") Long scheduleId
    ){
        return examResultService.getExamResult(examId, user, scheduleId);
    }



    @GetMapping("/getExamEvaluation")
    public List<ExamEvaluationView> getExamEvaluation(
            @RequestParam(value = "user") Long  user,
            @RequestParam(value = "examId") Long examId
    ){
        return examEvaluationService.getExamQuestionEvaluation(examId, user);
    }

    @PutMapping("/{examId}/{userId}")
    public ExamResultView edit(@Valid @RequestBody ExamEvaluateForm form, BindingResult bindingResult,
                                   @PathVariable("examId") Long examId, @PathVariable("userId") Long userId) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return examEvaluationService.edit(form,examId,userId);
    }



}
