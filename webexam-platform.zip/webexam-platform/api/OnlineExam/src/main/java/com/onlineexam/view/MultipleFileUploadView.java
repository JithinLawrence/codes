/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import java.util.List;

/**
 *
 * @author simon
 */
public class MultipleFileUploadView {
    private final String status;
    private final List<String> path;
    
    public MultipleFileUploadView(String status, List<String> path) {
        this.status = status;
        this.path = path;
    }

    public String getStatus() {
        return status;
    }

    public List<String> getPath() {
        return path;
    }
}
