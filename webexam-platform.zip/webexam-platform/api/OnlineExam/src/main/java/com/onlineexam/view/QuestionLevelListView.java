/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.QuestionLevel;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class QuestionLevelListView {
    private final Long questionLevelId;
    private final String name;
    private final String description;
    private final byte status;
    @Json.DateFormat
    private final Date createDate;
    @Json.DateFormat
    private final Date updateDate;

    public QuestionLevelListView(QuestionLevel questionLevel) {
        this.questionLevelId = questionLevel.getQuestionLevelId();
        this.name = questionLevel.getName();
        this.description = questionLevel.getDescription();
        this.status = questionLevel.getStatus();
        this.createDate = questionLevel.getCreateDate();
        this.updateDate = questionLevel.getUpdateDate();
    }   

    public Long getQuestionLevelId() {
        return questionLevelId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    
    
}
