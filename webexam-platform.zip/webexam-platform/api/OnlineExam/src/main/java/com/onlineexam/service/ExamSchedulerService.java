package com.onlineexam.service;

import com.onlineexam.entity.User;
import com.onlineexam.form.AssignCandidatesForm;
import com.onlineexam.form.ExamScheduleForm;
import com.onlineexam.util.Pager;
import com.onlineexam.view.CandidateScheduleAssignView;
import com.onlineexam.view.ExamScheduleView;

import java.util.ArrayList;
import java.util.List;

public interface ExamSchedulerService {

    ExamScheduleView add(ExamScheduleForm form);

    ExamScheduleView edit(ExamScheduleForm form, Long scheduleId);

    ExamScheduleView delete(Long scheduleId);

    Pager<ExamScheduleView> listSchedules(String search, Integer limit, String sort, boolean type, Integer page);

    CandidateScheduleAssignView assignCandidates(AssignCandidatesForm form , Long scheduleId, Long examId);

    void createCSVCandidates(ArrayList<String[]> userList, Long examId, Long scheduleId);
}
