/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.CandidateForm;
import com.onlineexam.form.ForgotPasswordForm;
import com.onlineexam.form.ForgotPasswordResetForm;
import com.onlineexam.form.ImageUploadForm;
import com.onlineexam.form.LoginForm;
import com.onlineexam.form.MultipleImageUploadForm;
import com.onlineexam.service.QuestionService;
import com.onlineexam.service.UserService;
import com.onlineexam.view.CandidateView;
import com.onlineexam.view.FileUploadView;
import com.onlineexam.view.GradeListView;
import com.onlineexam.view.LoginView;
import com.onlineexam.view.MultipleFileUploadView;
import com.onlineexam.view.UserView;
import java.util.List;
import javax.validation.Valid;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirmal
 */
@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private UserService userService;
    
    @Autowired
    QuestionService questionService;
    

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(LoginController.class);
//
//    @GetMapping
//    public UserView currentUser() {
//        return userService.currentUser();
//    }

    @PostMapping
    public LoginView login(@Valid @RequestBody LoginForm form, Errors errors) {
        return userService.login(form, errors);
    }

    @PutMapping
    public LoginView refresh(@RequestBody String refreshToken) {
        return userService.refresh(refreshToken);
    }

    @PostMapping("/forgotPassword")
    public ResponseEntity forgotPassword(
            @Valid @RequestBody ForgotPasswordForm form, BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        String token = userService.userForgotPassword(form.getEmail());
        System.out.println("TOKEN--" + token);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/forgotPasswordValidate/{token}")
    public ResponseEntity forgotPasswordValidate(@PathVariable("token") String token) {
        userService.userForgotPasswordValidate(token);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/forgotPasswordReset")
    public UserView forgotPasswordReset(
            @Valid @RequestBody ForgotPasswordResetForm form, BindingResult bindingResult
    ) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return userService.userForgotPasswordReset(form);
    }

    @GetMapping("/impression/{token}")
    public void impression(@PathVariable("token") String token) {
        LOGGER.info("Impression = " + token);
    }
    
    @PostMapping("/register")
    public CandidateView register(@Valid @RequestBody CandidateForm form, BindingResult bindingResult){
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return userService.register(form);
    }
    
     @PostMapping("/imageupload")
    public MultipleFileUploadView imageUpload(
            @Valid MultipleImageUploadForm uploadForm, BindingResult bindingResult){ 
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return questionService.imageUpload(uploadForm, 2);
    }
    @GetMapping("/getgrades")
    public List gradeList(){
        return userService.getGrades();
    }
    
    @GetMapping("/getorganizations")
    public List organizationsList(){
        return userService.getOrganizations();
    }
}