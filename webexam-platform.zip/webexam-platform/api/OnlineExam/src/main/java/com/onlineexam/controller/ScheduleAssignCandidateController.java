/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.service.ScheduleAssignService;
import com.onlineexam.service.UserService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.ExamAssignListView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author simon
 */

@RestController
@RequestMapping("/schedule_assign")
public class ScheduleAssignCandidateController {
    @Autowired
    private ScheduleAssignService scheduleAssignService;
    
    @Autowired
    private UserService userService;
    
    @GetMapping("/get_exam_upcomming")
    public Pager<ExamAssignListView> examUpcomingList(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ){
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        return scheduleAssignService.getUpcommingList(search, limit, sort, type, page,userService.currentUser().getUserId());
    }
    
    @GetMapping("/get_exam_history")
    public Pager<ExamAssignListView> examHistoryList(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ){
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        return scheduleAssignService.getElapsedList(search, limit, sort, type, page,userService.currentUser().getUserId());
    }
    
    @GetMapping("/register_exam/{scheduleAssignId}")
    public void registeerExam(@PathVariable("scheduleAssignId") long scheduleAssignId){
        System.out.println("ssss");
        scheduleAssignService.registerExam(scheduleAssignId);
    }
}
