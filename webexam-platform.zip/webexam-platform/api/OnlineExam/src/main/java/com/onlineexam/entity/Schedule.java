package com.onlineexam.entity;

import com.onlineexam.form.ExamScheduleForm;

import javax.persistence.*;
import java.util.Date;

/**
 * @author ramshad
 */

@Entity
public class Schedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long scheduleId;

    //private Long examId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_id")
    private Exam exam;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    private Organization organization;

    private byte status;
    private byte type;
    @Temporal(TemporalType.TIMESTAMP)
    private Date startTime;
    @Temporal(TemporalType.TIMESTAMP)
    private Date endTime;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User user;




    public Schedule() {

    }

    public Schedule(Date startTime, Date endTime, Exam exam, User user, Organization organization) {
        this.startTime = startTime;
        this.organization = organization;
        this.endTime = endTime;
        this.exam = exam;
        this.user = user;
        this.type = exam.getScheduleType();
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
        this.status = 1;
    }

    public Schedule update(ExamScheduleForm form){
        // this.exam = form.getExam();
        this.updateDate = new Date();
        this.startTime = form.getStartTime();
        this.endTime = form.getEndTime();
        return this;
    }

    public Schedule delete(Schedule schedule) {
        schedule.setStatus(Status.INACTIVE.value);
        schedule.setUpdateDate(new Date());
        return this;

    }

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);
        public final byte value;
        private Status(byte value) {
            this.value = value;
        }
    }
    public static enum Type {
        PUBLIC((byte) 1),
        PRIVATE((byte) 2);
        public final byte value;
        private Type(byte value) {
            this.value = value;
        }
    }

    public Exam getExam() {
        return exam;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

}