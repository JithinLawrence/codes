/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.QuestionBank;
import com.onlineexam.entity.QuestionBankQuestions;
import com.onlineexam.entity.QuestionBankQuestionsId;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author sanal
 */
public interface QuestionBankQuestionsRepository extends Repository<QuestionBankQuestions, QuestionBankQuestionsId>{
    
    QuestionBankQuestions save(QuestionBankQuestions questionBankQuestions);
    
    @Transactional
    @Modifying
    @Query(value = "delete from question_bank_questions where question_id = ?1 ", nativeQuery = true)
    void deleteByQuestionId(Integer questionId);
    
    @Query(value = "SELECT * FROM question_bank_questions as rv WHERE rv.question_id = ?1 AND rv.status = ?2 ", nativeQuery = true)
    List<QuestionBankQuestions> getListByQuestionId(Integer questionId, byte status);
    
    @Transactional
    @Modifying
    @Query(value = "UPDATE question_bank_questions set status=0 where editing_status = ?1 AND created_by =?2 ", nativeQuery = true)        
    void deleteAllByEditingStatusAndCreatedBy(byte editingStatus, Long userId);    
    
    @Query(value = "SELECT * FROM question_bank_questions as u WHERE u.question_bank_id = ?1 ", nativeQuery = true)
    List<QuestionBankQuestions> findAllByQuestionBankId(Long questionBankId);
    
    @Transactional
    @Modifying
    @Query(value = "DELETE FROM question_bank_questions where question_bank_id = ?1 AND question_id = ?2 ", nativeQuery = true)    
    void deleteByQuestionIdAndQuestionBankId(Long questionBankId, Integer questionId);
    
    @Transactional
    @Modifying
    @Query(value = "UPDATE question_bank_questions set editing_status=?1,status=1 WHERE question_bank_id = ?2 ", nativeQuery = true)    
    void updateQuestionBankQuestions(byte editingStatus, Long questionBankId);
    
    @Query(value="SELECT COUNT(*) FROM question_bank_questions where question_bank_id=?1 AND status=?2 AND editing_status=?2" , nativeQuery = true)
    Long countByQuestionBankId(Long qbId, byte status);
    
}
