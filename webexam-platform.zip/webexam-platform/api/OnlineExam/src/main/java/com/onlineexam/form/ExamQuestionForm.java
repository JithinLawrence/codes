/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.form;

import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sanal
 */
public class ExamQuestionForm {
//    private Integer examQuestionId;
//    @JoinColumn(name = "exam_id")
//    private Exam exam;
        @NotNull
        private List<Integer> questionId;
//    private Integer order;
//    private Integer mark;

    public List<Integer> getQuestionId() {
        return questionId;
    }

    public void setQuestionId(List<Integer> questionId) {
        this.questionId = questionId;
    }

    }
