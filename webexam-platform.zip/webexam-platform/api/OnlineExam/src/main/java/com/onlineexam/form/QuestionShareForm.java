/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.form;

import java.util.List;
import javax.validation.constraints.NotNull;

/**
 *
 * @author jinu
 */
public class QuestionShareForm {
    @NotNull
    private Integer questionId;
    @NotNull
    private List<Long> userIds;

    public Integer getQuestionId() {
        return questionId;
    }

    public List<Long> getUserIds() {
        return userIds;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public void setUserIds(List<Long> userIds) {
        this.userIds = userIds;
    }
}
