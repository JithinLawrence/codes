/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service.impl;

import com.onlineexam.entity.Grade;
import com.onlineexam.entity.Organization;
import com.onlineexam.entity.ScheduleAssignCandidate;
import com.onlineexam.entity.User;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.exception.NotFoundException;
import com.onlineexam.exception.UnauthorizedException;
import com.onlineexam.form.CandidateForm;
import com.onlineexam.form.ChangePasswordForm;
import com.onlineexam.form.ForgotPasswordResetForm;
import com.onlineexam.form.ImageUploadForm;
import com.onlineexam.form.LoginForm;
import com.onlineexam.form.ResetPasswordForm;
import com.onlineexam.form.UserForm;
import com.onlineexam.form.UserPasswordChangeForm;
import com.onlineexam.form.UserUpdateForm;
import com.onlineexam.repository.GradeRepository;
import com.onlineexam.repository.OrganizationRepository;
import com.onlineexam.repository.UserRepository;
import static com.onlineexam.security.AccessTokenUserDetailsService.PURPOSE_ACCESS_TOKEN;
import com.onlineexam.security.config.SecurityConfig;
import com.onlineexam.security.util.InvalidTokenException;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.security.util.TokenExpiredException;
import com.onlineexam.security.util.TokenGenerator;
import com.onlineexam.security.util.TokenGenerator.Status;
import com.onlineexam.security.util.TokenGenerator.Token;
import com.onlineexam.service.UserService;
import com.onlineexam.util.LanguageUtil;
import com.onlineexam.util.MailServiceUtil;
import com.onlineexam.util.Pager;
import com.onlineexam.util.storage.Storage;
import com.onlineexam.view.CandidateView;
import com.onlineexam.view.FileUploadView;
import com.onlineexam.view.GradeListView;
import com.onlineexam.view.LoginView;
import com.onlineexam.view.OrganizationListView;
import com.onlineexam.view.UserView;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import javax.mail.MessagingException;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author nirmal
 */
@Service
public class UserServiceImpl implements UserService {

    private static final String PURPOSE_REFRESH_TOKEN = "REFRESH_TOKEN";
    private static final String PURPOSE_FORGOT_PASSWORD_TOKEN = "FORGOT_PASSWORD_TOKEN";
    private final byte[] candidateActiveStatus = {User.Status.ACTIVE.value, User.Status.PENDING_FOR_APPROVAL.value};
    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private GradeRepository gradeRepository;

    @Autowired
    OrganizationRepository organizationRepository;
    
    @Autowired
    private TokenGenerator tokenGenerator;

    @Autowired
    private SecurityConfig securityConfig;

    @Autowired
    private LanguageUtil languageUtil;

    @Autowired
    private MailServiceUtil mailServiceUtil;

    @Autowired
    Storage amazonS3Storage;

    private final byte[] activeStatus = {User.Status.ACTIVE.value};
    private final byte[] roleList = {User.Role.EXAM_PLANNER.value};
    private final byte[] candidateList = {User.Role.CANDIDATE.value};
    private final byte[] roleListAdmin = {User.Role.SUPER_ADMIN.value, User.Role.EXAM_PLANNER.value, User.Role.SUPPORT.value};
    private final byte[] questionShareRole = {User.Role.SUPER_ADMIN.value, User.Role.EXAM_PLANNER.value};

    @Value("${baseurl.online.exam}")
    private String clientBaseUrl;
    
    @Value("${baseurl.online.exam.admin}")
    private String clientBaseUrlAdmin;

    @Override
    public UserView add(UserForm form) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.CANDIDATE.value != form.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }

        Long usernameCount = userRepository.countByStatusInAndFirstNameAndLastNameAndOrganizationAndEmail(activeStatus, form.getFirstName(), form.getLastName(), currentUser.getOrganization() , form.getEmail());
        if (usernameCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.name.exist", null, "en"));
        }

        if (userRepository.findByEmail(form.getEmail()).isPresent()) {
            throw new BadRequestException(languageUtil.getTranslatedText("email.already.exists", null, "en"));
        } else if (!Objects.equals(form.getPassword(), form.getConfirmPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.password.not.match", null, "en"));
        }

        return new UserView(userRepository.save(new User(
                form.getFirstName(),
                form.getLastName(),
                form.getEmail(),
                form.getRole(),
                passwordEncoder.encode(form.getPassword()),
                currentUser.getOrganization()
        )));
    }

    @Override
    public CandidateView register(CandidateForm form) {
        Long usernameCount = userRepository.countByStatusInAndFirstNameAndLastNameAndOrganizationAndEmail(activeStatus, form.getFirstName(), form.getLastName() , organizationRepository.findByOrganizationId(form.getOrganizationId()).get(), form.getEmail());       
        if (usernameCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.name.exist", null, "en"));
        }

        if (userRepository.findByEmail(form.getEmail()).isPresent()) {
            throw new BadRequestException(languageUtil.getTranslatedText("email.already.exists", null, "en"));
        } else if (!Objects.equals(form.getPassword(), form.getConfirmPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.password.not.match", null, "en"));
        }
        return new CandidateView(userRepository.save(new User(
                form.getFirstName(),
                form.getLastName(),
                form.getEmail(),
                form.getRole(),
                form.getDob(),
                passwordEncoder.encode(form.getPassword()),
                form.getImageUrl(),
                gradeRepository.findByGradeId(form.getGradeId()).get(),
                organizationRepository.findByOrganizationId(form.getOrganizationId()).get()
        )
        )
        );
    }

    @Override
    public FileUploadView imageUpload(ImageUploadForm uploadForm, int type) {
        String imageUrl = null;
        if (!validateImageFileName(uploadForm.getFile())) {
            LOGGER.error("Invalid file");
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.file", null, "en"));
        }
        String imgPath = "infoImage/";
        if (1 == type) {
            imgPath = "endoImage/";
        }
        try {
            String orgName = uploadForm.getFile().getOriginalFilename();
            String randStr = getRandomStr();
            if (null != orgName) {
                //orgName = orgName.replaceAll("\\s","");
                randStr = "_" + randStr + "." + FilenameUtils.getExtension(orgName);
            }
            Storage.Info imageInfo = amazonS3Storage.saveImage(imgPath + new Date().getTime() + randStr, uploadForm.getFile(), true);
            String imagePath = imageInfo.path;
            imageUrl = imagePath.substring(1);
        } catch (IOException ex) {
            LOGGER.error("error  " + ex);
        }
        return new FileUploadView("success", imageUrl);
    }

    private boolean validateImageFileName(MultipartFile file) {
        LOGGER.info("In logo image file name validation....");
        System.out.println(file.isEmpty());
        Boolean isValid = false;
        String fileName = file.getOriginalFilename();
        if ((fileName.endsWith(".png")) || (fileName.endsWith(".jpeg")) || (fileName.endsWith(".jpg")) || (fileName.endsWith(".gif"))) {
            LOGGER.info("In logo image file are valid");
            isValid = true;
        }
        return isValid;
    }

    private static String getRandomStr() {
        String zeros = "000000";
        Random rnd = new Random();
        String s = Integer.toString(rnd.nextInt(0X1000000), 16);
        s = zeros.substring(s.length()) + s;
        return s;
    }

    @Override
    public List<GradeListView> getGrades(){
        ArrayList<GradeListView> grades = new ArrayList<>();
        gradeRepository.findAll().forEach((Grade grade) -> {
            grades.add(new GradeListView(grade.getGradeId(), grade.getName()));
        });
        return grades;
    }

    @Override
    public UserView currentUser() {
        return new UserView(
                userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(NotFoundException::new)
        );
    }

    @Override
    public LoginView login(LoginForm form, Errors errors) throws BadRequestException {
        if (errors.hasErrors()) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en"));
        }
        User user = userRepository.findByEmail(form.getEmail()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en")));
        if (!passwordEncoder.matches(form.getPassword(), user.getPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en"));
        }
        if (User.Status.ACTIVE.value != user.getStatus()) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en"));
        }

        String id = String.format("%010d", user.getUserId());
        Token accessToken = tokenGenerator.create(PURPOSE_ACCESS_TOKEN, id, securityConfig.getAccessTokenExpiry());
        Token refreshToken = tokenGenerator.create(PURPOSE_REFRESH_TOKEN, id + user.getPassword(), securityConfig.getRefreshTokenExpiry());
        return new LoginView(user, accessToken, refreshToken);
    }
    
    @Override
    public LoginView loginAdmin(LoginForm form, Errors errors) throws BadRequestException {
        if (errors.hasErrors()) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en"));
        }
        User user = userRepository.findByEmail(form.getEmail()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en")));
        if (!passwordEncoder.matches(form.getPassword(), user.getPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en"));
        }
        if (User.Status.ACTIVE.value != user.getStatus()) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en"));
        }
        if(user.getRole() != User.Role.EXAM_PLANNER.value && user.getRole() != User.Role.SUPER_ADMIN.value && user.getRole() != User.Role.SUPPORT.value){
            throw new BadRequestException(languageUtil.getTranslatedText("user.access.denied", null, "en"));            
        }

        String id = String.format("%010d", user.getUserId());
        Token accessToken = tokenGenerator.create(PURPOSE_ACCESS_TOKEN, id, securityConfig.getAccessTokenExpiry());
        Token refreshToken = tokenGenerator.create(PURPOSE_REFRESH_TOKEN, id + user.getPassword(), securityConfig.getRefreshTokenExpiry());
        return new LoginView(user, accessToken, refreshToken);
    }

    @Override
    public LoginView refresh(String refreshToken) throws BadRequestException {
        Status status;
        try {
            status = tokenGenerator.verify(PURPOSE_REFRESH_TOKEN, refreshToken);
        } catch (InvalidTokenException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"), e);
        } catch (TokenExpiredException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"), e);
        }

        long userId;
        try {
            userId = Long.parseLong(status.data.substring(0, 10));
        } catch (NumberFormatException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"), e);
        }

        String password = status.data.substring(10);

        User user = userRepository.findByUserIdAndPassword(userId, password).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en")));

        String id = String.format("%010d", user.getUserId());
        Token accessToken = tokenGenerator.create(PURPOSE_ACCESS_TOKEN, id, securityConfig.getAccessTokenExpiry());
        return new LoginView(
                user,
                new LoginView.TokenView(accessToken.value, accessToken.expiry),
                new LoginView.TokenView(refreshToken, status.expiry)
        );
    }

    @Override
    public LoginView refreshAdmin(String refreshToken) throws BadRequestException {
        Status status;
        try {
            status = tokenGenerator.verify(PURPOSE_REFRESH_TOKEN, refreshToken);
        } catch (InvalidTokenException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"), e);
        } catch (TokenExpiredException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"), e);
        }

        long userId;
        try {
            userId = Long.parseLong(status.data.substring(0, 10));
        } catch (NumberFormatException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"), e);
        }

        String password = status.data.substring(10);

        User user = userRepository.findByUserIdAndPassword(userId, password).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("invalid.credantials", null, "en")));
        if(user.getRole() != User.Role.EXAM_PLANNER.value && user.getRole() != User.Role.SUPER_ADMIN.value && user.getRole() != User.Role.SUPPORT.value){
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        String id = String.format("%010d", user.getUserId());
        Token accessToken = tokenGenerator.create(PURPOSE_ACCESS_TOKEN, id, securityConfig.getAccessTokenExpiry());
        return new LoginView(
                user,
                new LoginView.TokenView(accessToken.value, accessToken.expiry),
                new LoginView.TokenView(refreshToken, status.expiry)
        );
    }

    @Override
    public Pager<UserView> listUsers(String search, Integer limit, String sort, boolean type, Integer page) {
        Pager<UserView> userPager = new Pager(0, 0, 0);
        Long queryCount;
        List<UserView> userList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        byte currentUserRole = currentUser.getRole();
        boolean a;
        queryCount = userRepository.countUserList(roleListAdmin, activeStatus, search, currentUser.getOrganization().getOrganizationId());

        userList = StreamSupport.stream(userRepository
                .getUserList(roleListAdmin, activeStatus, search, currentUser.getOrganization().getOrganizationId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(user -> new UserView(user))
                .collect(Collectors.toList());

        userPager = new Pager(limit, queryCount.intValue(), page);
        userPager.setResult(userList);
        return userPager;
    }

    @Override
    public Pager<UserView> listCandidates(String search, Integer limit, String sort, boolean type, Integer page, Long grade) {
        Pager<UserView> userPager = new Pager(0, 0, 0);
        Long queryCount;
        List<UserView> userList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        if(grade == 0){
            grade = null;
        }
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        byte currentUserRole = currentUser.getRole();
        boolean a;
        if(grade!=null){           
            queryCount = userRepository.countCandidatesList(candidateList, candidateActiveStatus, search,grade, currentUser.getOrganization());
            if(limit == 0)
                limit=queryCount.intValue();
            userList = StreamSupport.stream(userRepository
                    .getCandidateListByGrade(candidateList, candidateActiveStatus, search, grade, currentUser.getOrganization(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                    .map(user -> new UserView(user))
                    .collect(Collectors.toList());
        }else{
            queryCount = userRepository.countUserList(candidateList, candidateActiveStatus, search, currentUser.getOrganization().getOrganizationId());
            if(limit == 0)
                limit=queryCount.intValue();
            userList = StreamSupport.stream(userRepository
                    .getUserList(candidateList, candidateActiveStatus, search, currentUser.getOrganization().getOrganizationId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                    .map(user -> new UserView(user))
                    .collect(Collectors.toList());
        }

        userPager = new Pager(limit, queryCount.intValue(), page);
        userPager.setResult(userList);
        return userPager;
    }

    @Override
    @Transactional
    public UserView edit(UserUpdateForm form, Long userId) {
        User user = userRepository.findByUserId(userId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        if (!Objects.equals(currentUser.getUserId(), user.getUserId())) {
            if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
                if (User.Role.CANDIDATE.value != user.getRole() || form.getRole() != User.Role.CANDIDATE.value) {
                    throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
                }
            }
        } else {
            //User cannot change his own role
            form.setRole(user.getRole());
        }

        if (userRepository.findByEmail(form.getEmail()).isPresent()
                && !Objects.equals(userRepository.findByEmail(form.getEmail())
                        .orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")))
                        .getUserId(), user.getUserId())) {
            throw new BadRequestException(languageUtil.getTranslatedText("email.already.exists", null, "en"));
        }

        Long usernameCount = userRepository.countByStatusInAndFirstNameAndLastNameAndUserIdNotAndOrganizationAndEmail(activeStatus, form.getFirstName(), form.getLastName(), userId, currentUser.getOrganization(), form.getEmail());
        if (usernameCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.name.exist", null, "en"));
        }

        if (!Objects.isNull(user)) {
            user = userRepository.save(user.update(form));
        }
        return new UserView(user);
    }

    @Override
    @Transactional
    public UserView editOwn(UserUpdateForm form, Long userId) {
        User user = userRepository.findByUserId(userId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        byte currentUserRole = currentUser.getRole();
        if (!userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).isPresent()) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (form.getRole() != currentUserRole) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (userRepository.findByEmail(form.getEmail()).isPresent()
                && !Objects.equals(userRepository.findByEmail(form.getEmail())
                        .orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")))
                        .getUserId(), user.getUserId())) {
            throw new BadRequestException(languageUtil.getTranslatedText("email.already.exists", null, "en"));
        }

        Long usernameCount = userRepository.countByStatusInAndFirstNameAndLastNameAndUserIdNotAndOrganizationAndEmail(activeStatus, form.getFirstName(), form.getLastName(), userId, currentUser.getOrganization(), form.getEmail());
        if (usernameCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.name.exist", null, "en"));
        }

        if (!Objects.isNull(user)) {
            user = userRepository.save(user.update(form));
        }
        return new UserView(user);
    }

    @Override
    @Transactional
    public UserView updatePassword(ChangePasswordForm form) throws BadRequestException {
        User u = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(()
                -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        if (!userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).isPresent()) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
//        if (User.Role.SUPER_ADMIN.value == u.getRole()) {
//            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
//        }
        if (!Objects.equals(SecurityUtil.getCurrentUserId(), u.getUserId())) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (!passwordEncoder.matches(form.getOldPassword(), u.getPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.invalid.current.password", null, "en"));
        } else if (passwordEncoder.matches(form.getNewPassword(), u.getPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.new.password.used", null, "en"));
        } else if (!Objects.equals(form.getNewPassword(), form.getConfirmNewPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.password.not.match", null, "en"));
        }

        return userRepository.findByUserId(SecurityUtil.getCurrentUserId())
                .map((user) -> {
                    return new UserView(userRepository.save(user.changePassword(passwordEncoder.encode(form.getNewPassword()))));
                }).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
    }

    @Override
    @Transactional
    public UserView resetPassword(ResetPasswordForm form) {
        User user = userRepository.findByUserId(form.getUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        byte currentUserRole = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get().getRole();
        if (!userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).isPresent()) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (Objects.equals(SecurityUtil.getCurrentUserId(), user.getUserId())) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (currentUserRole != User.Role.SUPER_ADMIN.value) {
            if (User.Role.CANDIDATE.value != user.getRole()) {
                throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }

        String defPass = passwordEncoder.encode(form.getNewPassword());

        UserView uv = new UserView(userRepository
                .save(user.resetPassword(defPass)));

        return uv;
    }

    @Override
    @Transactional
    public UserView delete(Long userId) {
        User user = userRepository.findByUserId(userId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        byte currentUserRole = currentUser.getRole();
        if (!userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).isPresent()) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (Objects.equals(currentUser.getUserId(), user.getUserId())) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied.account.deletion", null, "en"));
        }
        if (currentUserRole != User.Role.SUPER_ADMIN.value) {
            if (User.Role.CANDIDATE.value != user.getRole()) {
                throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        if (!Objects.isNull(user)) {
            user = userRepository.save(user.delete(user));
        }
        return new UserView(user);
    }

    @Override
    public String userForgotPassword(String email) {
        User user = userRepository.findByEmail(email).orElse(null);
        if (null == user) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.valid.email", null, "en"));
        }
        if (User.Status.ACTIVE.value != user.getStatus()) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.not.active", null, "en"));
        }
//        if (user.getRole() == User.Role.SUPER_ADMIN.value) {
//            throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
//        }
        String id = String.format("%010d", user.getUserId());
        Duration duration = Duration.ofMinutes(30);
        Token passwordToken = tokenGenerator.create(PURPOSE_FORGOT_PASSWORD_TOKEN, id, duration);
        String resetLink = clientBaseUrl + "/forgotPasswordReset/" + passwordToken.value;
        try {
            mailServiceUtil.sendPasswordResetMail(user.getEmail(), user.getFirstName(), user.getLastName(), resetLink);
        } catch (MessagingException | IOException ex) {
            LOGGER.info("Mail sending failed.");
            LOGGER.error(ex.getMessage());
            throw new BadRequestException(languageUtil.getTranslatedText("mail.sending.failed", null, "en"));
        }
        //add token in user table
        user.setPasswordToken(passwordToken.value);
        userRepository.save(user);
        return resetLink;
    }

    @Override
    public String userForgotPasswordAdmin(String email) {
        User user = userRepository.findByEmail(email).orElse(null);
        if (null == user) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.valid.email", null, "en"));
        }
        if (User.Status.ACTIVE.value != user.getStatus()) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.not.active", null, "en"));
        }
        if(user.getRole() != User.Role.EXAM_PLANNER.value && user.getRole() != User.Role.SUPER_ADMIN.value && user.getRole() != User.Role.SUPPORT.value){
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        String id = String.format("%010d", user.getUserId());
        Duration duration = Duration.ofMinutes(30);
        Token passwordToken = tokenGenerator.create(PURPOSE_FORGOT_PASSWORD_TOKEN, id, duration);
        String resetLink = clientBaseUrlAdmin + "/forgotPasswordReset/" + passwordToken.value;
        try {
            mailServiceUtil.sendPasswordResetMail(user.getEmail(), user.getFirstName(), user.getLastName(), resetLink);
        } catch (MessagingException | IOException ex) {
            LOGGER.info("Mail sending failed.");
            LOGGER.error(ex.getMessage());
            throw new BadRequestException(languageUtil.getTranslatedText("mail.sending.failed", null, "en"));
        }
        //add token in user table
        user.setPasswordToken(passwordToken.value);
        userRepository.save(user);
        return resetLink;
    }

    @Override
    public UserView userForgotPasswordReset(ForgotPasswordResetForm form) {

        final Status status;
        try {
            status = tokenGenerator.verify(PURPOSE_FORGOT_PASSWORD_TOKEN, form.getToken());
        } catch (InvalidTokenException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"));
        } catch (TokenExpiredException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("forgot.token.expired", null, "en"));
        }

        long userId = Long.parseLong(status.data);
        User user = userRepository.findByUserId(userId).orElse(null);
        if (!form.getToken().equals(user.getPasswordToken())) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"));
        }
        if (User.Status.ACTIVE.value != user.getStatus()) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.not.active", null, "en"));
        }
        if (!Objects.equals(form.getNewPassword(), form.getConfirmNewPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.password.not.match", null, "en"));
        }

        return userRepository.findByUserId(user.getUserId())
                .map((u) -> {
                    return new UserView(userRepository.save(u.changePassword(passwordEncoder.encode(form.getNewPassword()))));
                }).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
    }

    @Override
    public boolean userForgotPasswordValidate(String token) {

        final Status status;
        try {
            status = tokenGenerator.verify(PURPOSE_FORGOT_PASSWORD_TOKEN, token);
        } catch (InvalidTokenException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"));
        } catch (TokenExpiredException e) {
            throw new BadRequestException(languageUtil.getTranslatedText("forgot.token.expired", null, "en"));
        }

        long userId = Long.parseLong(status.data);
        User user = userRepository.findByUserId(userId).orElse(null);
        if (!token.equals(user.getPasswordToken())) {
            throw new BadRequestException(languageUtil.getTranslatedText("access.token.expired", null, "en"));
        }
        if (User.Status.ACTIVE.value != user.getStatus()) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.not.active", null, "en"));
        }
        if (user.getRole() == User.Role.SUPER_ADMIN.value) {
            throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        return true;
    }

    @Override
    @Transactional
    public UserView updateUserPassword(UserPasswordChangeForm form , Long userId) throws BadRequestException {
        LOGGER.info("Inside update user password : "+userId);
        User u = userRepository.findByUserId(userId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        //User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        LOGGER.info("User firstname : "+u.getFirstName());
        if (null == u) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
//        if (User.Role.SUPER_ADMIN.value == u.getRole()) {
//            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
//        }
        if (!Objects.equals(userId, u.getUserId())) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
//        if (!passwordEncoder.matches(form.getOldPassword(), u.getPassword())) {
//            throw new BadRequestException(languageUtil.getTranslatedText("user.invalid.current.password", null, "en"));
//        } 
        if (passwordEncoder.matches(form.getNewPassword(), u.getPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.new.password.used", null, "en"));
        } else if (!Objects.equals(form.getNewPassword(), form.getConfirmNewPassword())) {
            throw new BadRequestException(languageUtil.getTranslatedText("user.password.not.match", null, "en"));
        }

        return userRepository.findByUserId(userId)
                .map((user) -> {
                    return new UserView(userRepository.save(user.changePassword(passwordEncoder.encode(form.getNewPassword()))));
                }).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
    }

    @Override
    @Transactional
    public void editStatus(Long userId) {
        User user = userRepository.findByUserId(userId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        byte currentUserRole = currentUser.getRole();
        if (!userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).isPresent()) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (Objects.equals(currentUser.getUserId(), user.getUserId())) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        if (currentUserRole != User.Role.SUPER_ADMIN.value) {
            if (User.Role.CANDIDATE.value != user.getRole()) {
                throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        if (!Objects.isNull(user)) {
           userRepository.editStatus(User.Status.ACTIVE.value,userId);
        }
        //return new UserView(user);
    }

    @Override
    public ArrayList<OrganizationListView> getOrganizations() {
        ArrayList<OrganizationListView> organization = new ArrayList<>();
        organizationRepository.findAll().forEach((Organization org) -> {
            organization.add(new OrganizationListView(org.getOrganizationId(), org.getName()));
        });
        return organization;
    }
    
    @Override
    public List<UserView> listUsers(){
        ArrayList<UserView> users = new ArrayList<>();
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Optional<Organization> organization = organizationRepository.findByOrganizationId(currentUser.getOrganization().getOrganizationId());
        userRepository.findAllByOrganizationAndRoleInAndStatus(organization.get(), roleList, User.Status.ACTIVE.value)
        .forEach((User user) -> {
            users.add(new UserView(user));
        });
        return users;
}
    
    @Override
    public Pager<UserView> listCandidateToAssign(String search, Integer limit, String sort, boolean type, Integer page, Long grade, Long scheduleId) {
        Pager<UserView> userPager = new Pager(0, 0, 0);
        Long queryCount;
        List<UserView> userList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        if(grade == 0){
            grade = null;
        }
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        byte currentUserRole = currentUser.getRole();
        boolean a;
        if(grade!=null){           
            queryCount = userRepository.countUnassignedCandidateWithGrade(scheduleId, ScheduleAssignCandidate.Status.ACTIVE.value, currentUser.getOrganization().getOrganizationId(), User.Status.ACTIVE.value, User.Role.CANDIDATE.value, grade);
            if(limit == 0)
                limit=queryCount.intValue();
            userList = StreamSupport.stream(userRepository
                    .getUnassignedCandidateListByGrade(scheduleId, ScheduleAssignCandidate.Status.ACTIVE.value, currentUser.getOrganization().getOrganizationId(), User.Status.ACTIVE.value, User.Role.CANDIDATE.value, grade, PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                    .map(user -> new UserView(user))
                    .collect(Collectors.toList());
        }else{
            queryCount = userRepository.countUnassignedCandidateWithOutGrade(scheduleId, ScheduleAssignCandidate.Status.ACTIVE.value, currentUser.getOrganization().getOrganizationId(), User.Status.ACTIVE.value, User.Role.CANDIDATE.value);
            if(limit == 0)
                limit=queryCount.intValue();
            userList = StreamSupport.stream(userRepository
                    .getUnassignedCandidateListWithOutGrade(scheduleId, ScheduleAssignCandidate.Status.ACTIVE.value, currentUser.getOrganization().getOrganizationId(), User.Status.ACTIVE.value, User.Role.CANDIDATE.value, PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                    .map(user -> new UserView(user))
                    .collect(Collectors.toList());
        }

        userPager = new Pager(limit, queryCount.intValue(), page);
        userPager.setResult(userList);
        return userPager;
    }
    
    @Override
    public List<UserView> listAssignedCandidates(Long scheduleId){
        ArrayList<UserView> users = new ArrayList<>();
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Optional<Organization> organization = organizationRepository.findByOrganizationId(currentUser.getOrganization().getOrganizationId());
        
        userRepository.findAllScheduleAssignedCandidate(scheduleId)
        .forEach((User user) -> {
            users.add(new UserView(user));
        });
        return users;
}
}
