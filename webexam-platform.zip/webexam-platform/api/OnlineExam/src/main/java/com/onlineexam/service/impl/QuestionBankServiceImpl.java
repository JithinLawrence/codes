/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service.impl;

import com.onlineexam.entity.Category;
import com.onlineexam.entity.CategoryQuestionBanks;
import com.onlineexam.entity.Grade;
import com.onlineexam.entity.GradeQuestionBanks;
import com.onlineexam.entity.Organization;
import com.onlineexam.entity.Question;
import com.onlineexam.entity.QuestionBank;
import com.onlineexam.entity.QuestionBankQuestions;
import com.onlineexam.entity.User;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.exception.UnauthorizedException;
import com.onlineexam.form.QuestionBankForm;
import com.onlineexam.repository.CategoryQuestionBanksRepository;
import com.onlineexam.repository.CategoryRepository;
import com.onlineexam.repository.GradeQuestionBanksRepository;
import com.onlineexam.repository.GradeRepository;
import com.onlineexam.repository.OrganizationRepositorySample;
import com.onlineexam.repository.QuestionBankQuestionsRepository;
import com.onlineexam.repository.QuestionBankRepository;
import com.onlineexam.repository.QuestionRepository;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.service.QuestionBankService;
import com.onlineexam.util.LanguageUtil;
import com.onlineexam.util.Pager;
import com.onlineexam.view.QuestionBankListView;
import com.onlineexam.view.QuestionBankView;
import com.onlineexam.view.QuestionsQBWiseView;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 *
 * @author sanal
 */
@Service
public class QuestionBankServiceImpl implements QuestionBankService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrganizationRepositorySample organizationRepositorySample;

    @Autowired
    private QuestionBankRepository questionBankRepository;

    @Autowired
    private CategoryQuestionBanksRepository categoryQuestionBanksRepository;

    @Autowired
    private GradeQuestionBanksRepository gradeQuestionBanksRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private GradeRepository gradeRepository;

    @Autowired
    private LanguageUtil languageUtil;

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private QuestionBankQuestionsRepository questionBankQuestionsRepository;

    private final byte[] questionBankActiveStatus = {QuestionBank.Status.ACTIVE.value};

    private final byte[] organizationActiveStatus = {Organization.Status.ACTIVE.value};

    private final byte[] questionActiveStatus = {Question.Status.ACTIVE.value};

    @Transactional
    @Override
    public void add(QuestionBankForm form, Long questionBankId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Organization organization = currentUser.getOrganization();

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                if (User.Role.SUPPORT.value != currentUser.getRole()) {
                    throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
                }
            }
        }

//        Long questionBankNameCount = questionBankRepository.countByStatusInAndTitle(questionBankActiveStatus, form.getTitle());
//        if (questionBankNameCount > 0) {
//            throw new BadRequestException(languageUtil.getTranslatedText("question.bank.name.exist", null, "en"));
//        }
        //Optional<QuestionBank> questionBnkObj = questionBankRepository.findByQuestionBankId(form.get)
        if (questionBankId != 0) {
            Optional<QuestionBank> questionBanks = questionBankRepository.findByQuestionBankId(questionBankId);
            questionBankRepository.updateQuestionBank(form.getTitle(), form.getDescription(), QuestionBank.EditingStatus.SAVED.value, questionBankId);

            questionBankQuestionsRepository.updateQuestionBankQuestions(QuestionBankQuestions.EditingStatus.SAVED.value, questionBankId);

            form.getCategories().forEach(categoryId -> {
                Category category = categoryRepository.findByCategoryIdAndStatus(categoryId, Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));
                categoryQuestionBanksRepository.save(new CategoryQuestionBanks(questionBanks.get(), category));
            });
            form.getGroups().forEach(groupId -> {
                Grade grade = gradeRepository.findByGradeIdAndStatus(groupId, Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("grade.not.found", null, "en")));
                gradeQuestionBanksRepository.save(new GradeQuestionBanks(questionBanks.get(), grade));
            });

        } else {
            QuestionBank questionBank = questionBankRepository.save(new QuestionBank(
                    form.getTitle(),
                    form.getDescription(),
                    currentUser,
                    QuestionBank.EditingStatus.SAVED.value,
                    organization
            ));
            form.getCategories().forEach(categoryId -> {
                Category category = categoryRepository.findByCategoryIdAndStatus(categoryId, Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));
                categoryQuestionBanksRepository.save(new CategoryQuestionBanks(questionBank, category));
            });
            form.getGroups().forEach(groupId -> {
                Grade grade = gradeRepository.findByGradeIdAndStatus(groupId, Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("grade.not.found", null, "en")));
                gradeQuestionBanksRepository.save(new GradeQuestionBanks(questionBank, grade));
            });

            new QuestionBankView(questionBank,
                    categoryQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    CategoryQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getCategoryQuestionBanksId())
                            .map(a -> a.getCategory())
                            .map(b -> b.getCategoryId()).collect(Collectors.toList()),
                    gradeQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    GradeQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getGradeQuestionBanksId())
                            .map(a -> a.getGrade())
                            .map(b -> b.getGradeId()).collect(Collectors.toList()));
        }
    }

    @Transactional
    @Override
    public QuestionBankView edit(QuestionBankForm form, Long questionBankId) {
        QuestionBank questionBank = questionBankRepository.findByQuestionBankIdAndStatusIn(questionBankId, questionBankActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.bank.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
            if (!questionBank.getUser().getUserId().equals(currentUser.getUserId())) {
//                if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
//                }
            }
        }

        if (questionBankId != 0) {
            Optional<QuestionBank> questionBanks = questionBankRepository.findByQuestionBankId(questionBankId);
            questionBankRepository.updateQuestionBank(form.getTitle(), form.getDescription(), QuestionBank.EditingStatus.SAVED.value, questionBankId);

            questionBankQuestionsRepository.updateQuestionBankQuestions(QuestionBankQuestions.EditingStatus.SAVED.value, questionBankId);
        }

//        Long questionBankNameCount = questionBankRepository.countByQuestionBankIdNotAndStatusInAndTitle(questionBankId, questionBankActiveStatus, form.getTitle());
//        if (questionBankNameCount > 0) {
//            throw new BadRequestException(languageUtil.getTranslatedText("question.bank.name.exist", null, "en"));
//        }

        if (!Objects.isNull(questionBank)) {
            questionBank = questionBankRepository.save(questionBank.update(form));
        }
        List<QuestionBank> questionBankTemp = new ArrayList<>();
        categoryQuestionBanksRepository.deleteByQuestionBankId(questionBank.getQuestionBankId());
        questionBankTemp.add(questionBank);//to remvove error: non final varibale inside lambda is not accessible
        form.getCategories().forEach(categoryId -> {
            Category category = categoryRepository.findByCategoryIdAndStatus(categoryId, Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));
            categoryQuestionBanksRepository.save(new CategoryQuestionBanks(questionBankTemp.get(0), category));
        });

        gradeQuestionBanksRepository.deleteByQuestionBankId(questionBank.getQuestionBankId());
        form.getGroups().forEach(groupId -> {
            Grade grade = gradeRepository.findByGradeIdAndStatus(groupId, Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("grade.not.found", null, "en")));
            gradeQuestionBanksRepository.save(new GradeQuestionBanks(questionBankTemp.get(0), grade));
        });
        return new QuestionBankView(questionBank,
                categoryQuestionBanksRepository
                        .getListByQuestionBankId(
                                questionBank.getQuestionBankId(),
                                CategoryQuestionBanks.Status.ACTIVE.value).stream()
                        .map(row -> row.getCategoryQuestionBanksId())
                        .map(a -> a.getCategory())
                        .map(b -> b.getCategoryId()).collect(Collectors.toList()),
                gradeQuestionBanksRepository
                        .getListByQuestionBankId(
                                questionBank.getQuestionBankId(),
                                GradeQuestionBanks.Status.ACTIVE.value).stream()
                        .map(row -> row.getGradeQuestionBanksId())
                        .map(a -> a.getGrade())
                        .map(b -> b.getGradeId()).collect(Collectors.toList()));
    }

    @Transactional
    @Override
    public QuestionBankView delete(Long questionBankId) {
        QuestionBank questionBank = questionBankRepository.findByQuestionBankIdAndStatusIn(questionBankId, questionBankActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.bank.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
            if (!questionBank.getUser().getUserId().equals(currentUser.getUserId())) {
//                if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
//                }
            }
        }

//        Long questionBankNameCount = questionBankRepository.countByQuestionBankIdAndStatusIn(questionBankId, questionBankActiveStatus);
//        if (questionBankNameCount > 0) {
//            throw new BadRequestException(languageUtil.getTranslatedText("question.bank.name.exist", null, "en"));
//        }
        Long questionCount = questionBankQuestionsRepository.countByQuestionBankId(questionBankId, QuestionBankQuestions.Status.ACTIVE.value);
        if (questionCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("questionbank.is.used", null, "en"));
        }
        if (!Objects.isNull(questionBank)) {
            questionBank = questionBankRepository.save(questionBank.delete(questionBank));
        }
        return new QuestionBankView(questionBank,
                categoryQuestionBanksRepository
                        .getListByQuestionBankId(
                                questionBank.getQuestionBankId(),
                                CategoryQuestionBanks.Status.ACTIVE.value).stream()
                        .map(row -> row.getCategoryQuestionBanksId())
                        .map(a -> a.getCategory())
                        .map(b -> b.getCategoryId()).collect(Collectors.toList()),
                gradeQuestionBanksRepository
                        .getListByQuestionBankId(
                                questionBank.getQuestionBankId(),
                                GradeQuestionBanks.Status.ACTIVE.value).stream()
                        .map(row -> row.getGradeQuestionBanksId())
                        .map(a -> a.getGrade())
                        .map(b -> b.getGradeId()).collect(Collectors.toList()));
    }

    @Override
    public Pager<QuestionBankView> listQuestionBanks(String search, Integer limit, String sort, boolean type, Integer page) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        Pager<QuestionBankView> questionBankPager = new Pager(0, 0, 0);
        Long queryCount = 0L;
        List<QuestionBankView> questionBankList = new ArrayList<>();
        if (StringUtils.isEmpty(search)) {
            search = "";
        }

        if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
            queryCount = questionBankRepository.countQuestionBankList(questionBankActiveStatus, search, QuestionBank.EditingStatus.SAVED.value, currentUser.getOrganization().getOrganizationId());
            questionBankList = StreamSupport.stream(questionBankRepository
                    .getQuestionBankList(questionBankActiveStatus, search, QuestionBank.EditingStatus.SAVED.value, currentUser.getOrganization().getOrganizationId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                    .map(questionBank -> new QuestionBankView(
                    questionBank,
                    categoryQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    CategoryQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getCategoryQuestionBanksId())
                            .map(a -> a.getCategory())
                            .map(b -> b.getCategoryId()).collect(Collectors.toList()),
                    gradeQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    GradeQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getGradeQuestionBanksId())
                            .map(a -> a.getGrade())
                            .map(b -> b.getGradeId()).collect(Collectors.toList())
            ))
                    .collect(Collectors.toList());
        } else {
            queryCount = questionBankRepository.countQuestionBankListByUser(questionBankActiveStatus, search, QuestionBank.EditingStatus.SAVED.value, currentUser.getOrganization().getOrganizationId(), currentUser.getUserId());
            questionBankList = StreamSupport.stream(questionBankRepository
                    .getQuestionBankListByUser(questionBankActiveStatus, search, QuestionBank.EditingStatus.SAVED.value, currentUser.getOrganization().getOrganizationId(), currentUser.getUserId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                    .map(questionBank -> new QuestionBankView(
                    questionBank,
                    categoryQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    CategoryQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getCategoryQuestionBanksId())
                            .map(a -> a.getCategory())
                            .map(b -> b.getCategoryId()).collect(Collectors.toList()),
                    gradeQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    GradeQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getGradeQuestionBanksId())
                            .map(a -> a.getGrade())
                            .map(b -> b.getGradeId()).collect(Collectors.toList())
            ))
                    .collect(Collectors.toList());
        }

        questionBankQuestionsRepository.deleteAllByEditingStatusAndCreatedBy(QuestionBankQuestions.EditingStatus.TEMP_SAVE.value, currentUser.getUserId());
        questionBankRepository.deleteByEditingStatusAndCreatedBy(QuestionBank.EditingStatus.TEMP_SAVE.value, currentUser.getUserId());
        questionBankPager = new Pager(limit, queryCount.intValue(), page);
        questionBankPager.setResult(questionBankList);
        return questionBankPager;
    }

    @Override
    public List<QuestionBankListView> listQuestionBanks() {
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        List<QuestionBankListView> questionBankList;
        if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
            questionBankList = StreamSupport.stream(questionBankRepository
                    .getQuestionBankList(questionBankActiveStatus, QuestionBank.EditingStatus.SAVED.value, currentUser.getOrganization().getOrganizationId()).spliterator(), false)
                    .map(questionBank -> new QuestionBankListView(
                    questionBank,
                    categoryQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    CategoryQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getCategoryQuestionBanksId())
                            .map(a -> a.getCategory())
                            .map(b -> b.getCategoryId()).collect(Collectors.toList()),
                    gradeQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    GradeQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getGradeQuestionBanksId())
                            .map(a -> a.getGrade())
                            .map(b -> b.getGradeId()).collect(Collectors.toList())
            ))
                    .collect(Collectors.toList());
            return questionBankList;
        } else {
            questionBankList = StreamSupport.stream(questionBankRepository
                    .getQuestionBankListByUser(questionBankActiveStatus, QuestionBank.EditingStatus.SAVED.value, currentUser.getOrganization().getOrganizationId(), currentUser.getUserId()).spliterator(), false)
                    .map(questionBank -> new QuestionBankListView(
                    questionBank,
                    categoryQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    CategoryQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getCategoryQuestionBanksId())
                            .map(a -> a.getCategory())
                            .map(b -> b.getCategoryId()).collect(Collectors.toList()),
                    gradeQuestionBanksRepository
                            .getListByQuestionBankId(
                                    questionBank.getQuestionBankId(),
                                    GradeQuestionBanks.Status.ACTIVE.value).stream()
                            .map(row -> row.getGradeQuestionBanksId())
                            .map(a -> a.getGrade())
                            .map(b -> b.getGradeId()).collect(Collectors.toList())
            ))
                    .collect(Collectors.toList());
            return questionBankList;
        }
    }

    @Override
    public Pager<QuestionsQBWiseView> listQuestionsForQB(Long questionBankId, String search, Integer limit, String sort,
            boolean type, Integer page, Integer categoryId, Integer groupId, Integer levelId) {
        Pager<QuestionsQBWiseView> examPager;
        Long queryCount = 0L;
        List<QuestionsQBWiseView> examList = new ArrayList<>();
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();

        if (questionBankId == 0) {
            if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
                queryCount = questionRepository.countQuestionListByAdmin(questionActiveStatus, currentUser.getOrganization().getOrganizationId(), search,
                        categoryId, groupId, levelId);
                if (groupId == 0) {
                    examList = StreamSupport.stream(questionRepository
                            .getQuestionListWithOutGradeByAdmin(questionActiveStatus, currentUser.getOrganization().getOrganizationId(), search, categoryId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionsQBWiseView(question))
                            .collect(Collectors.toList());
                } else {
                    examList = StreamSupport.stream(questionRepository
                            .getQuestionListWithGradeByAdmin(questionActiveStatus, currentUser.getOrganization().getOrganizationId(), search, categoryId, groupId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionsQBWiseView(question))
                            .collect(Collectors.toList());
                }
            } else {
                queryCount = questionRepository.countUserQuestionList(questionActiveStatus, search,
                        categoryId, groupId, levelId, currentUser.getUserId());
                if (groupId == 0) {
                    examList = StreamSupport.stream(questionRepository
                            .getUserQuestionListWithOutGrade(questionActiveStatus, search, categoryId, levelId, currentUser.getUserId(),
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionsQBWiseView(question))
                            .collect(Collectors.toList());
                } else {
                    examList = StreamSupport.stream(questionRepository
                            .getUserQuestionListWithGrade(questionActiveStatus, search, categoryId, groupId, levelId, currentUser.getUserId(),
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionsQBWiseView(question))
                            .collect(Collectors.toList());
                }
            }

        } else {
            QuestionBank qb = questionBankRepository.findByQuestionBankId(questionBankId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.bank.not.found", null, "en")));
            if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
                examList = StreamSupport.stream(questionRepository
                        .getAdminQuestionListNotInQBSelectWithSearch(search, categoryId, groupId, levelId,
                                questionBankActiveStatus,
                                questionBankId,
                                currentUser.getOrganization().getOrganizationId(),
                                Question.Status.ACTIVE.value,
                                PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)
                        )
                        .spliterator(), false)
                        .map(question -> new QuestionsQBWiseView(
                        question
                ))
                        .collect(Collectors.toList());
            } else {
                examList = StreamSupport.stream(questionRepository
                        .getUserQuestionListNotInQBSelectWithSearch(search, categoryId, groupId, levelId,
                                questionBankActiveStatus,
                                questionBankId,
                                currentUser.getUserId(),
                                Question.Status.ACTIVE.value,
                                PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)
                        )
                        .spliterator(), false)
                        .map(question -> new QuestionsQBWiseView(
                        question
                ))
                        .collect(Collectors.toList());
            }

        }
        examPager = new Pager(limit, queryCount.intValue(), page);
        examPager.setResult(examList);
        return examPager;
    }

    @Transactional
    @Override
    public QuestionBankView initEdit(Long questionBankId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("user.not.found", null, "en")));
        QuestionBank questionBank = questionBankRepository.findByQuestionBankId(questionBankId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.bank.not.found", null, "en")));
        List<Question> questions = new ArrayList<Question>();
        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (!Objects.equals(questionBank.getUser().getUserId(), currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }

        List<Long> grades = questionBankRepository.findAllByQuestionBankId(questionBankId);
        List<Long> categories = questionBankRepository.findAllCategoryByQuestionBankId(questionBankId);
//        questions = questionBankRepository.findAllQuestionsByQuestionBankId(questionBankId);

        return (new QuestionBankView(
                questionBank,
                categories,
                grades
        //                questions
        ));
    }

}
