/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service;

import com.onlineexam.form.MultipleImageUploadForm;
import com.onlineexam.form.QuestionForm;
import com.onlineexam.form.QuestionShareForm;
import com.onlineexam.form.QuestionUpdateForm;
import com.onlineexam.util.Pager;
import com.onlineexam.view.BasicView;
import com.onlineexam.view.CategoryListView;
import com.onlineexam.view.GradeListDetailView;
import com.onlineexam.view.MultipleFileUploadView;
import com.onlineexam.view.QuestionEditView;
import com.onlineexam.view.QuestionLevelListView;
import com.onlineexam.view.QuestionListView;
import com.onlineexam.view.QuestionTypeListView;
import java.util.List;

/**
 *
 * @author Libeesh
 */
public interface QuestionService {
    
    BasicView add(QuestionForm form);
    
    QuestionEditView get(Integer questionId);
    
    BasicView edit(QuestionForm form, Integer questionId);
    
    MultipleFileUploadView imageUpload(MultipleImageUploadForm uploadForm, int type);
    
    List<CategoryListView> listCategory();
    
    List<GradeListDetailView> listGrade();
    
    List<QuestionLevelListView> listQuestionLevel();
    
    List<QuestionTypeListView> listQuestionType();

    Pager<QuestionListView> list(String search, Integer limit, String sort, 
            boolean type, Integer page, Integer categoryId, Integer roupId, Integer levelId, Long questionBankId);
    
    BasicView shareQuestion(QuestionShareForm form);
    
    BasicView delete(Integer questionId);
}
