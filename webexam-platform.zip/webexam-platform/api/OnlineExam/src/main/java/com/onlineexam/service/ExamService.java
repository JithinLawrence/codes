/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service;

import com.onlineexam.entity.Category;
import com.onlineexam.entity.Exam;
import com.onlineexam.form.ExamForm;
import com.onlineexam.form.ExamQuestionForm;
import com.onlineexam.form.ExamQuestionUpdateForm;
import com.onlineexam.form.ExamUpdateForm;
import com.onlineexam.form.ImageAnswerForm;
import com.onlineexam.form.MultipleAnswerForm;
import com.onlineexam.form.SingleAnswerForm;
import com.onlineexam.form.TextAnswerForm;
import com.onlineexam.util.Pager;
import com.onlineexam.view.BasicView;
import com.onlineexam.view.CandidateScheduleAssignView;
import com.onlineexam.view.CategoryDashboardListView;
import com.onlineexam.view.ExamQuestionAnswerView;
import com.onlineexam.view.ExamQuestionGroupedView;
import com.onlineexam.view.ExamQuestionView;
import com.onlineexam.view.ExamView;
import com.onlineexam.view.QuestionAnswerView;
import com.onlineexam.view.QuestionBankListView;
import com.onlineexam.view.QuestionDashBoardView;
import com.onlineexam.view.QuestionExamWiseView;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author sanal
 */
public interface ExamService {

    ExamView add(ExamForm form);

    ExamQuestionGroupedView addTempExam(ExamQuestionForm form, Long examId);

    BasicView verifyEdit(Long examId);

    ExamQuestionGroupedView initEdit(Long examId);

    Long initCopy(Long examId);

    ExamQuestionGroupedView loadCopy(Long examId);

    ExamView edit(ExamUpdateForm form, Long examId);

    ExamView saveCopy(ExamUpdateForm form, Long examId);

    ExamQuestionGroupedView editTempExam(ExamQuestionUpdateForm form, Long examId);

    ExamView delete(Long examId);

    ExamQuestionGroupedView tempDeleteCategory(Long examId, Long categoryId);

    Pager<ExamView> listExams(String search, Integer limit, String sort, boolean type, Integer page);//

    Pager<QuestionExamWiseView> listQuestionsForExam(Long examId, String search, Integer limit, String sort,
            boolean type, Integer page, Integer categoryId, Integer groupId, Integer levelId);//

    List<ExamQuestionView> listExamQuestions(Long examId, String search);//
    
    List<ExamQuestionView> listExamQuestionsCategoryWise(Long examId, Long categoryId, String search);//

    Pager<CandidateScheduleAssignView> listCandidateExams(String search, Integer limit, String sort, boolean type, Integer page , Long user);

    List listStatusCounts(Long userId);

    HashMap<String, Long> getExamReport(Long examId);

    byte getAnswerStatus(long examId, long userId, long scheduleId);

    String getAgreement(long examId);

    String getName(long examId);
    
    List<CategoryDashboardListView> getExamCatagoryList(long examId, String type); 
    
    List<CategoryDashboardListView> getExamCatagoryList(long examId, long scheduleId, long userId); 
    
    List<QuestionDashBoardView> getExamQuestionList(long examId, long scheduleId, long userId);
    
    ExamQuestionAnswerView getExamQuestion(Integer questionId);
    
    ExamQuestionAnswerView getExamQuestion(Integer questionId, long scheduleId, long userId);
    
    ExamQuestionAnswerView getExamQuestion(Integer questionId, String type);

    QuestionAnswerView getQuestion(Integer questionId);

    int getDuration(Integer examId);
    
    boolean addSingleAnswer(SingleAnswerForm form);
    
    boolean addMultipleAnswer(MultipleAnswerForm form); 
    
    boolean addTextAnswer(TextAnswerForm form); 
    
    boolean addImageAnswer(ImageAnswerForm form); 
    
    List<ExamView> listExams();
}