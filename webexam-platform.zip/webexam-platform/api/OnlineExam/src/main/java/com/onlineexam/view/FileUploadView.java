/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

/**
 *
 * @author simon
 */
public class FileUploadView {
    private final String status;
    private final String path;
    
    public FileUploadView(String status, String path) {
        this.status = status;
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public String getStatus() {
        return status;
    }
}
