/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Question;
import com.onlineexam.entity.QuestionBank;
import com.onlineexam.json.Json;
import java.util.Date;
import java.util.List;

/**
 *
 * @author sanal
 */
public class QuestionEditView {
    
    private final Integer questionId;
    private final Long organizatioId;
    private final Long categoryId;
    private final List<Long> gradeIds;
    private final Long questionTypeId;
    private final Long questionLevelId;
    private final List<Long> questionBankIds;
    private final String imageUrl;
    private final String title;
    private final String description;
    private final Integer price;
    private final byte publishMarket;
    private final Integer mark;
    private final String answer;
    private final String options;
    private final Long createdBy;
    @Json.DateTimeFormat
    private final Date createDate;
    @Json.DateTimeFormat
    private final Date updateDate;

    public QuestionEditView(Question question, List<Long> questionBankIds, List<Long> gradeIds) {
        this.questionId = question.getQuestionId();
        this.organizatioId = question.getOrganization().getOrganizationId();
        this.categoryId = question.getCategory().getCategoryId();
        this.gradeIds = gradeIds;
        this.questionTypeId = question.getQuestionType().getQuestionTypeId();
        this.questionLevelId = question.getQuestionLevel().getQuestionLevelId();
        this.questionBankIds = questionBankIds;
        this.imageUrl = question.getImageUrl();
        this.title = question.getTitle();
        this.description = question.getDescription();
        this.price = question.getPrice();
        this.publishMarket = question.getPublishMarket();
        this.mark = question.getMark();
        this.answer = question.getAnswer();
        this.options = question.getOptions();
        this.createdBy = question.getUser().getUserId();
        this.createDate = question.getCreateDate();
        this.updateDate = question.getUpdateDate();
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public Long getOrganizatioId() {
        return organizatioId;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public List<Long> getGradeIds() {
        return gradeIds;
    }

    public Long getQuestionTypeId() {
        return questionTypeId;
    }

    public Long getQuestionLevelId() {
        return questionLevelId;
    }

    public List<Long> getQuestionBankIds() {
        return questionBankIds;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Integer getPrice() {
        return price;
    }

    public byte getPublishMarket() {
        return publishMarket;
    }

    public Integer getMark() {
        return mark;
    }

    public String getAnswer() {
        return answer;
    }

    public String getOptions() {
        return options;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    
}
