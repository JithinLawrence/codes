/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.GradeQuestions;
import com.onlineexam.entity.GradeQuestionsId;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author sanal
 */
public interface GradeQuestionsRepository extends Repository<GradeQuestions, GradeQuestionsId>{
    GradeQuestions save(GradeQuestions gradeQuestions);
    
    @Transactional
    @Modifying
    @Query(value = "delete from grade_questions where question_id = ?1 ", nativeQuery = true)
    void deleteByQuestionId(Integer questionId);
    
    @Query(value = "SELECT * FROM grade_questions as rv WHERE rv.question_id = ?1 AND rv.status = ?2 ", nativeQuery = true)
    List<GradeQuestions> getListByQuestionId(Integer questionId, byte status);
    
    @Query(value = "SELECT * FROM grade_questions as rv WHERE rv.question_id = ?1", nativeQuery = true)
    List<GradeQuestions> findAllByQuestionId(Integer questionId);
}
