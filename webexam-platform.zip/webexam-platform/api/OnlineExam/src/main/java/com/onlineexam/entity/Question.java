/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import com.onlineexam.form.QuestionForm;
import com.onlineexam.form.QuestionUpdateForm;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Libeesh
 */
@Entity
public class Question {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }

    public static enum PublishStatus {
        UNPUBLISHED((byte) 0),
        PUBLISHED((byte) 1);

        public final byte value;

        private PublishStatus(byte value) {
            this.value = value;
        }
    }

    public static enum SharedStatus {
        UNSHARED((byte) 0),
        SHARED((byte) 1);

        public final byte value;

        private SharedStatus(byte value) {
            this.value = value;
        }
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer questionId;
    private String title;
    private String description;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    private Organization organization;
    private String imageUrl;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_type_id")
    private QuestionType questionType;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_level_id")
    private QuestionLevel questionLevel;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User user;
    private Integer price;
    private byte publishMarket;
    private Integer mark;
    private String answer;
    private String options;
    private byte status;
    private byte sharedStatus;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shared_by")
    private User sharedUser;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    public Question() {
    }

    public Question(String title, String description, Organization organization, String imageUrl, Category category, QuestionType questionType, QuestionLevel questionLevel, User user, Integer price, byte publishMarket, Integer mark, String answer, String options, User sharedUser, byte sharedStatus) {
        this.title = title;
        this.description = description;
        this.organization = organization;
        this.imageUrl = imageUrl;
        this.category = category;
        this.questionType = questionType;
        this.questionLevel = questionLevel;
        this.user = user;
        this.price = price;
        this.publishMarket = publishMarket;
        this.mark = mark;
        this.answer = answer;
        this.options = options;
        this.sharedStatus = sharedStatus;
        this.status = Status.ACTIVE.value;
        this.sharedUser = sharedUser;
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }
    
    public Question update(QuestionForm form, Category category, QuestionType questionType, QuestionLevel questionLevel){
        this.title = form.getTitle();
        this.description = form.getDescription();
        this.imageUrl = form.getImageUrl();
        this.category = category;
        this.questionType = questionType;
        this.questionLevel = questionLevel;
        this.price = form.getPrice();
        this.publishMarket = form.getPublishMarket();
        this.mark = form.getMark();
        this.answer = form.getAnswer();
        this.options = form.getOptions();
        this.updateDate = new Date();
        return this;
    }
    
    public Question delete(Question question){
        question.setStatus(Status.INACTIVE.value);
        question.setUpdateDate(new Date());
        return this;
    }    

    public Integer getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public QuestionType getQuestionType() {
        return questionType;
    }

    public void setQuestionType(QuestionType questionType) {
        this.questionType = questionType;
    }

    public QuestionLevel getQuestionLevel() {
        return questionLevel;
    }

    public void setQuestionLevel(QuestionLevel questionLevel) {
        this.questionLevel = questionLevel;
    }

    public Integer getMark() {
        return mark;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getOptions() {
        return options;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public byte getPublishMarket() {
        return publishMarket;
    }

    public void setPublishMarket(byte publishMarket) {
        this.publishMarket = publishMarket;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public byte getSharedStatus() {
        return sharedStatus;
}

    public User getSharedUser() {
        return sharedUser;
    }

    public void setSharedStatus(byte sharedStatus) {
        this.sharedStatus = sharedStatus;
    }

    public void setSharedUser(User sharedUser) {
        this.sharedUser = sharedUser;
    }
    
   }
