/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service;

import com.onlineexam.exception.NotFoundException;
import com.onlineexam.form.CategoryForm;
import com.onlineexam.form.GradeForm;
import com.onlineexam.util.Pager;
import com.onlineexam.view.CategoryView;
import com.onlineexam.view.GradeView;

/**
 *
 * @author jinu
 */
public interface CommonService {
    
     Pager<GradeView> listGrades(String search, Integer limit, String sort,boolean type, Integer page);
     
     GradeView delete(Long gradeId) throws NotFoundException;
     
     GradeView add(GradeForm form);
     
     GradeView edit(GradeForm form, Long gradeId);
     
     Pager<CategoryView> listCategories(String search, Integer limit, String sort,boolean type, Integer page);
     
     CategoryView deleteCategory(Long categoryId) throws NotFoundException;
     
     CategoryView addCategory(CategoryForm form);
     
     CategoryView editCategory(CategoryForm form, Long categoryId);
    
}
