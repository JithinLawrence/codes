/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.util;

import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author Libeesh
 */
@Service
public class EncryptionUtil {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(EncryptionUtil.class);
    
    private static final String ENCODE_TYPE = "UTF-8";
    private static final String AES_ALG = "AES";
    private static final String AES_ALG_TYPE = "AES/CBC/PKCS5Padding";

    private static final String aesKey = "lkC2H19lkVbAKfakxlcdNMQdd0FkoRcd";
    private static final String aesIV = "krAWKLioQ0QjstnR";

    public static String decryptAES(String strToDecrypt) 
    {
        try
        {
            byte[] keyValue = aesKey.getBytes(ENCODE_TYPE);
            SecretKeySpec secretKey = new SecretKeySpec(keyValue, AES_ALG);
            byte[] ivValue = aesIV.getBytes(ENCODE_TYPE);
            IvParameterSpec ivspec = new IvParameterSpec(ivValue);
            Cipher cipher = Cipher.getInstance(AES_ALG_TYPE);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } 
        catch (Exception e) 
        {
            LOGGER.info("Error while decrypting: " + e.toString());
        }
        return null;
    }

    public static String encryptAES(String strToEncrypt) 
    {
        try
        {
            byte[] keyValue = aesKey.getBytes(ENCODE_TYPE);
            SecretKeySpec secretKey = new SecretKeySpec(keyValue, AES_ALG);
            byte[] ivValue = aesIV.getBytes(ENCODE_TYPE);
            IvParameterSpec ivspec = new IvParameterSpec(ivValue);
            Cipher cipher = Cipher.getInstance(AES_ALG_TYPE);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(ENCODE_TYPE)));
        } 
        catch (Exception e) 
        {
            LOGGER.info("Error while encrypting: " + e.toString());
        }
        return null;
    }
}
