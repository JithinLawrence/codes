package com.onlineexam.view;


import com.onlineexam.entity.ScheduleAssignCandidate;

import java.util.List;

/**
 * @author ramshad
 */
public class CandidateScheduleAssignView {

    List<ScheduleAssignCandidate> scheduleAssignCandidateList ;
    String exam;
    Long examId;
    Long scheduleId;
    String name;
    private String duration;
    private Long questionCount;
    private String startDate;
    private Long resultCount;

    public CandidateScheduleAssignView(List<ScheduleAssignCandidate> scheduleAssignCandidateList, Long examId, String exam, Long scheduleId) {
        this.scheduleAssignCandidateList = scheduleAssignCandidateList;
        this.examId = examId;
        this.exam = exam;
        this.scheduleId = scheduleId;
    }
    
    public CandidateScheduleAssignView(Long examId, String examName, Integer duration, Long questionCount, String startDate, Long scheduleId, Long count) {        
        this.examId = examId;
        this.name = examName;
        int hour = 0;
        String time;
       if (duration != 0 && duration > 60) {
            while (duration > 60) {
                hour = hour + duration / 60;
                duration = duration % 60;
            }
            time = hour + "h"+duration+"Min";
        } else {
           time =duration+"Min";
        }
        this.duration = time;
        this.questionCount = questionCount;
        this.startDate = startDate;  
        this.scheduleId = scheduleId;
        this.resultCount = count;
    }

    public List<ScheduleAssignCandidate> getScheduleAssignCandidateList() {
        return scheduleAssignCandidateList;
    }

    public void setScheduleAssignCandidateList(List<ScheduleAssignCandidate> scheduleAssignCandidateList) {
        this.scheduleAssignCandidateList = scheduleAssignCandidateList;
    }

    public String getExam() {
        return exam;
    }

    public void setExam(String exam) {
        this.exam = exam;
    }

    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }
    public Long getExamId() {
        return examId;
    }

    public void setExamId(Long examId) {
        this.examId = examId;
    }

    public String getName() {
        return name;
    }

    public String getDuration() {
        return duration;
    }

    public Long getQuestionCount() {
        return questionCount;
    }

    public String getStartDate() {
        return startDate;
    }

    public Long getResultCount() {
        return resultCount;
    }
    
}