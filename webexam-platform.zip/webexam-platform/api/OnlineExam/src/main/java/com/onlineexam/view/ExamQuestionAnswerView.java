/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.ExamResult;
import com.onlineexam.entity.QuestionType;
import com.onlineexam.repository.ExamResultCheckboxRepository;
import com.onlineexam.repository.ExamResultImageRepository;
import com.onlineexam.repository.ExamResultRadioRepository;
import com.onlineexam.repository.ExamResultRepository;
import com.onlineexam.repository.ExamResultTextRepository;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author simon
 */
public class ExamQuestionAnswerView {

    

    private Integer examQuestionId;
    private String title;
    private String description;
    private String imageUrl;
    private Long examId;
    private String exam;
    private Long questionTypeId;
    private String questionType;
    private Long questionLevelId;
    private String questionLevel;
    private String options;
    private Integer questionOrder;
    private Integer mark;
    private Integer nextQ;
    private Integer prevQ;
    private Integer answerRadio;
    private String answer;

    public ExamQuestionAnswerView(ExamQuestion examQuestion,Integer nextQ,Integer prevQ) {
      
        this.examQuestionId = examQuestion.getExamQuestionId();
        this.title = examQuestion.getTitle();
        this.description = examQuestion.getDescription();
        this.imageUrl = examQuestion.getImageUrl();
        this.examId = examQuestion.getExam().getExamId();
        this.exam = examQuestion.getExam().getName();
        this.questionTypeId = examQuestion.getQuestionType().getQuestionTypeId();
        this.questionType = examQuestion.getQuestionType().getName();
        this.questionLevelId = examQuestion.getQuestionLevel().getQuestionLevelId();
        this.questionLevel = examQuestion.getQuestionLevel().getName();
        this.options = examQuestion.getOptions();
        this.questionOrder = examQuestion.getQuestionOrder();
        this.mark = examQuestion.getMark();
        this.nextQ = nextQ;
        this.prevQ = prevQ;
        this.answer =  "";
        this.answerRadio = 0;
       
    }
    
    public ExamQuestionAnswerView(ExamQuestion examQuestion,Integer nextQ,Integer prevQ,Integer answerRadio,String answer) {
      
        this.examQuestionId = examQuestion.getExamQuestionId();
        this.title = examQuestion.getTitle();
        this.description = examQuestion.getDescription();
        this.imageUrl = examQuestion.getImageUrl();
        this.examId = examQuestion.getExam().getExamId();
        this.exam = examQuestion.getExam().getName();
        this.questionTypeId = examQuestion.getQuestionType().getQuestionTypeId();
        this.questionType = examQuestion.getQuestionType().getName();
        this.questionLevelId = examQuestion.getQuestionLevel().getQuestionLevelId();
        this.questionLevel = examQuestion.getQuestionLevel().getName();
        this.options = examQuestion.getOptions();
        this.questionOrder = examQuestion.getQuestionOrder();
        this.mark = examQuestion.getMark();
        this.nextQ = nextQ;
        this.prevQ = prevQ;
        this.answer =  answer;
        this.answerRadio = answerRadio;
        
    }

    public Integer getExamQuestionId() {
        return examQuestionId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Long getExamId() {
        return examId;
    }

    public String getExam() {
        return exam;
    }

    public Long getQuestionTypeId() {
        return questionTypeId;
    }

    public String getQuestionType() {
        return questionType;
    }

    public Long getQuestionLevelId() {
        return questionLevelId;
    }

    public String getQuestionLevel() {
        return questionLevel;
    }

    public String getOptions() {
        return options;
    }

    public Integer getQuestionOrder() {
        return questionOrder;
    }

    public Integer getMark() {
        return mark;
    }

    public Integer getNextQ() {
        return nextQ;
    }

    public void setNextQ(Integer nextQ) {
        this.nextQ = nextQ;
    }

    public Integer getPrevQ() {
        return prevQ;
    }

    public void setPrevQ(Integer prevQ) {
        this.prevQ = prevQ;
    }

    public void setExamQuestionId(Integer examQuestionId) {
        this.examQuestionId = examQuestionId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setExamId(Long examId) {
        this.examId = examId;
    }

    public void setExam(String exam) {
        this.exam = exam;
    }

    public void setQuestionTypeId(Long questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }

    public void setQuestionLevelId(Long questionLevelId) {
        this.questionLevelId = questionLevelId;
    }

    public void setQuestionLevel(String questionLevel) {
        this.questionLevel = questionLevel;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    public void setQuestionOrder(Integer questionOrder) {
        this.questionOrder = questionOrder;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }

    public Integer getAnswerRadio() {
        return answerRadio;
    }

    public void setAnswerRadio(Integer answerRadio) {
        this.answerRadio = answerRadio;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
    
}
