/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Question;

/**
 *
 * @author sanal s
 */
public class QuestionAnswerView {
    private Integer examQuestionId;
    private String title;
    private String description;
    private String imageUrl;
    private Long examId;
    private String exam;
    private Long questionTypeId;
    private String questionType;
    private Long questionLevelId;
    private String questionLevel;
    private String options;
    private Integer questionOrder;
    private Integer mark;
    private Integer nextQ;
    private Integer prevQ;

    public QuestionAnswerView(Question examQuestion) {

        this.examQuestionId = examQuestion.getQuestionId();
        this.title = examQuestion.getTitle();
        this.description = examQuestion.getDescription();
        this.imageUrl = examQuestion.getImageUrl();
        this.examId = 0L;
        this.exam = "";
        this.questionTypeId = examQuestion.getQuestionType().getQuestionTypeId();
        this.questionType = examQuestion.getQuestionType().getName();
        this.questionLevelId = examQuestion.getQuestionLevel().getQuestionLevelId();
        this.questionLevel = examQuestion.getQuestionLevel().getName();
        this.options = examQuestion.getOptions();
        this.questionOrder = 1;
        this.mark = examQuestion.getMark();
        this.nextQ = 0;
        this.prevQ = 0;

    }

    public Integer getExamQuestionId() {
        return examQuestionId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Long getExamId() {
        return examId;
    }

    public String getExam() {
        return exam;
    }

    public Long getQuestionTypeId() {
        return questionTypeId;
    }

    public String getQuestionType() {
        return questionType;
    }

    public Long getQuestionLevelId() {
        return questionLevelId;
    }

    public String getQuestionLevel() {
        return questionLevel;
    }

    public String getOptions() {
        return options;
    }

    public Integer getQuestionOrder() {
        return questionOrder;
    }

    public Integer getMark() {
        return mark;
    }

    public Integer getNextQ() {
        return nextQ;
    }

    public void setNextQ(Integer nextQ) {
        this.nextQ = nextQ;
    }

    public Integer getPrevQ() {
        return prevQ;
    }

    public void setPrevQ(Integer prevQ) {
        this.prevQ = prevQ;
    }

    public void setExamQuestionId(Integer examQuestionId) {
        this.examQuestionId = examQuestionId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setExamId(Long examId) {
        this.examId = examId;
    }

    public void setExam(String exam) {
        this.exam = exam;
    }

    public void setQuestionTypeId(Long questionTypeId) {
        this.questionTypeId = questionTypeId;
    }

    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }

    public void setQuestionLevelId(Long questionLevelId) {
        this.questionLevelId = questionLevelId;
    }

    public void setQuestionLevel(String questionLevel) {
        this.questionLevel = questionLevel;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    public void setQuestionOrder(Integer questionOrder) {
        this.questionOrder = questionOrder;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }
    
}
