package com.onlineexam.form;

import java.util.List;
import javax.validation.constraints.NotNull;

/**
 @author ramshad
 */
public class AssignCandidatesForm {
    @NotNull
    private List<Long> userId;
//    Long scheduleId;
//    Long examId;
//    String exam;

    public AssignCandidatesForm() {
    }

//    @Override
//    public String toString() {
//        return "scheduleId "+scheduleId+
//                "examId "+examId+
//                "exam "+exam+
//                "userList "+userList;
//    }

    public List<Long> getUserId() {
        return userId;
    }

    public void setUserId(List<Long> userId) {
        this.userId = userId;
    }
}