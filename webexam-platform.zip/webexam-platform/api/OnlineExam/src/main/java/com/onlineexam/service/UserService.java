/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service;

import com.onlineexam.exception.BadRequestException;
import com.onlineexam.exception.NotFoundException;
import com.onlineexam.form.CandidateForm;
import com.onlineexam.form.ChangePasswordForm;
import com.onlineexam.form.ForgotPasswordResetForm;
import com.onlineexam.form.ImageUploadForm;
import com.onlineexam.form.LoginForm;
import com.onlineexam.form.ResetPasswordForm;
import com.onlineexam.form.UserForm;
import com.onlineexam.form.UserPasswordChangeForm;
import com.onlineexam.form.UserUpdateForm;
import com.onlineexam.util.Pager;
import com.onlineexam.view.CandidateView;
import com.onlineexam.view.FileUploadView;
import com.onlineexam.view.GradeListView;
import com.onlineexam.view.LoginView;
import com.onlineexam.view.OrganizationListView;
import com.onlineexam.view.UserView;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.Errors;

/**
 *
 * @author nirmal
 */
public interface UserService {

    UserView add(UserForm form);
    
    CandidateView register(CandidateForm form);
    
    UserView currentUser();

    LoginView login(LoginForm form, Errors errors) throws BadRequestException;
    
    LoginView loginAdmin(LoginForm form, Errors errors) throws BadRequestException;

    FileUploadView imageUpload(ImageUploadForm uploadForm, int type);
    
    List<GradeListView> getGrades();
    
    List<OrganizationListView> getOrganizations();

    LoginView refresh(String refreshToken) throws BadRequestException;

    LoginView refreshAdmin(String refreshToken) throws BadRequestException;

    Pager<UserView> listUsers(String search, Integer limit, String sort,boolean type, Integer page);

    Pager<UserView> listCandidates(String search, Integer limit, String sort,boolean type, Integer page, Long gradeId);

    UserView updatePassword(ChangePasswordForm form);

    UserView updateUserPassword(UserPasswordChangeForm form, Long userId);

    UserView resetPassword(ResetPasswordForm form);
    
    UserView edit(UserUpdateForm form, Long userId)throws NotFoundException;
    
    UserView editOwn(UserUpdateForm form, Long userId)throws NotFoundException;;

    UserView delete(Long userId) throws NotFoundException;

    String userForgotPassword(String email);

    String userForgotPasswordAdmin(String email);

    UserView userForgotPasswordReset(ForgotPasswordResetForm form);

    boolean userForgotPasswordValidate(String token);
    
    void editStatus(Long userId) throws NotFoundException;
    
    List<UserView> listUsers();
    
    Pager<UserView> listCandidateToAssign(String search, Integer limit, String sort,boolean type, Integer page, Long gradeId, Long scheduleId);
    
    List<UserView> listAssignedCandidates(Long scheduleId);

}
