/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.ExamQuestionResultImage;
import com.onlineexam.entity.ExamResult;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import javax.transaction.Transactional;

/**
 *
 * @author jinu
 */
public interface ExamResultImageRepository extends Repository<ExamQuestionResultImage, Integer>{
    
    ExamQuestionResultImage save(ExamQuestionResultImage exqr);

//    @Query(value="SELECT SUM(correct_count) FROM exam_question_result_image WHERE exam_result_id=?1 AND ((correct_count=1 AND wrong_count=0) || (correct_count>0 AND wrong_count=0)) ", nativeQuery = true)
//    Integer countByExamResultId(Long examResult);
    
    ExamQuestionResultImage findByExamResultAndQuestion(ExamResult examResult, ExamQuestion question); 
    
    Integer countByExamResultAndIsCorrect(ExamResult examResult, byte isCorrect);

    @Transactional
    @Modifying
    @Query(value = "update exam_question_result_image set is_correct = ?1, mark = ?2 where exam_question_id = ?3", nativeQuery = true)
    void updateExamQuestionResultImageRepoItems(Integer is_correct, Integer mark, Integer examQuestionId);



}
