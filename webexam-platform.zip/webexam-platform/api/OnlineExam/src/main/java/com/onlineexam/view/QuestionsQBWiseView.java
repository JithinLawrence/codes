/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Question;

/**
 *
 * @author jinu
 */
public class QuestionsQBWiseView {
    private final Integer questionId;
    private final String title;
    private final Long categoryId;
    private final String category;
    private final Long questionLevelId;
    private final String questionLevel;
    private final Integer mark;
    private final byte status;
    
    public QuestionsQBWiseView(Question question) {
        this.questionId = question.getQuestionId();
        this.title = question.getTitle();
        this.categoryId = question.getCategory().getCategoryId();
        this.category = question.getCategory().getName();
        this.questionLevelId = question.getQuestionLevel().getQuestionLevelId();
        this.questionLevel = question.getQuestionLevel().getName();        
        this.mark = question.getMark();
        this.status = question.getStatus();
    }

    public String getTitle() {
        return title;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public String getCategory() {
        return category;
    }

    public Long getQuestionLevelId() {
        return questionLevelId;
    }

    public String getQuestionLevel() {
        return questionLevel;
    }

    public Integer getMark() {
        return mark;
    }

    public byte getStatus() {
        return status;
    }

    public Integer getQuestionId() {
        return questionId;
    }
    
}
