/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.Date;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author sanal
 */
@Entity
public class GradeQuestions {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }
    @EmbeddedId
    private GradeQuestionsId gradeQuestionsId;
    private byte status;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;

    public GradeQuestions() {
    }

    public GradeQuestions(Question question, Grade grade) {
        this.gradeQuestionsId = new GradeQuestionsId(question, grade);
        this.status = Status.ACTIVE.value;
        this.createDate = new Date();
    }

    public GradeQuestionsId getGradeQuestionsId() {
        return gradeQuestionsId;
    }

    public void setGradeQuestionsId(GradeQuestionsId gradeQuestionsId) {
        this.gradeQuestionsId = gradeQuestionsId;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

}
