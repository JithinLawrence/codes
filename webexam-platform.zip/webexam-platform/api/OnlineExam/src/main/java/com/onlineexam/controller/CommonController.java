/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.service.QuestionService;
import com.onlineexam.view.CategoryListView;
import com.onlineexam.view.GradeListDetailView;
import com.onlineexam.view.QuestionLevelListView;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.CategoryForm;
import com.onlineexam.form.GradeForm;
import com.onlineexam.service.CommonService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.CategoryView;
import com.onlineexam.view.GradeView;
import com.onlineexam.view.QuestionTypeListView;
import javax.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author Libeesh
 */
@RestController
@RequestMapping("/admin/common")
public class CommonController {

    @Autowired
    private QuestionService questionService;
     @Autowired CommonService commonService;
    
    @PostMapping
    public GradeView add(@Valid @RequestBody GradeForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return commonService.add(form);
    }
    
    @PostMapping("/addCategory")
    public CategoryView add(@Valid @RequestBody CategoryForm form, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return commonService.addCategory(form);
    }

    @GetMapping("/category")
    public List<CategoryListView> listCategory() {

        return questionService.listCategory();
    }

    @GetMapping("/group")
    public List<GradeListDetailView> listGrade() {

        return questionService.listGrade();
    }

    @GetMapping("/level")
    public List<QuestionLevelListView> listQuestionLevel() {

        return questionService.listQuestionLevel();
    }
    
    @GetMapping("/type")
    public List<QuestionTypeListView> listQuestionType() {

        return questionService.listQuestionType();
    }
    
     @GetMapping("/listGrades")
    public Pager<GradeView> listGrades(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ) {
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }    
        return commonService.listGrades(search, limit, sort,type,page);
    }
    
    @DeleteMapping("/{gradeId}")
    public GradeView delete(@PathVariable("gradeId") Long gradeId){
        return commonService.delete(gradeId);
    }
    
    @PutMapping("/{gradeId}")
    public GradeView edit(@Valid @RequestBody GradeForm form, BindingResult bindingResult,
            @PathVariable("gradeId") Long gradeId){
        if(bindingResult.hasErrors()){
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return commonService.edit(form, gradeId);
    }
    
    @GetMapping("/listCategories")
    public Pager<CategoryView> listCategories(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type
    ) {
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }    
        return commonService.listCategories(search, limit, sort,type,page);
    }
    
    @DeleteMapping("/category/{categoryId}")
    public CategoryView deleteCategory(@PathVariable("categoryId") Long categoryId){
        return commonService.deleteCategory(categoryId);
    }
    
    @PutMapping("/category/{categoryId}")
    public CategoryView editCategory(@Valid @RequestBody CategoryForm form, BindingResult bindingResult,
            @PathVariable("categoryId") Long categoryId){
        if(bindingResult.hasErrors()){
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return commonService.editCategory(form, categoryId);
    }
}
