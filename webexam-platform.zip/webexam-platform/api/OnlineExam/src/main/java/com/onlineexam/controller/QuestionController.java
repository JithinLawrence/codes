/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.MultipleImageUploadForm;
import com.onlineexam.form.QuestionForm;
import com.onlineexam.form.QuestionShareForm;
import com.onlineexam.form.QuestionUpdateForm;
import com.onlineexam.service.QuestionService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.BasicView;
import com.onlineexam.view.MultipleFileUploadView;
import com.onlineexam.view.QuestionEditView;
import com.onlineexam.view.QuestionListView;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Libeesh
 */
@RestController
@RequestMapping("/admin/question")
public class QuestionController {

    @Autowired
    private QuestionService questionService;
    
    @PostMapping
    public BasicView add(@Valid @RequestBody QuestionForm form, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return questionService.add(form);
    }

    @GetMapping("/{questionId}")
    public QuestionEditView get(@PathVariable("questionId") Integer questionId) {
        return questionService.get(questionId);
    }

    @PutMapping("/{questionId}")
    public BasicView edit(@Valid @RequestBody QuestionForm form, BindingResult bindingResult,
            @PathVariable("questionId") Integer questionId) {
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return questionService.edit(form, questionId);
    }

    @GetMapping("/list")
    public Pager<QuestionListView> listQuestions(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type,
            @RequestParam(value = "categoryId", required = false) Integer categoryId,
            @RequestParam(value = "groupId", required = false) Integer groupId,
            @RequestParam(value = "levelId", required = false) Integer levelId,
            @RequestParam(value = "questionBankId", required = false) Long questionBankId
    ) {
        if (limit == null) {
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        if (null == categoryId) {
            categoryId = 0;
        }
        if (null == groupId) {
            groupId = 0;
        }
        if (null == levelId) {
            levelId = 0;
        }
        return questionService.list(search, limit, sort, type, page, 
                categoryId, groupId, levelId, questionBankId);
    }
    
    @DeleteMapping("/{questionId}")
    public void delete(@PathVariable("questionId") Integer questionId) {
        questionService.delete(questionId);
    }
    
    @PostMapping("/imageupload")
    public MultipleFileUploadView imageUpload(
            @Valid MultipleImageUploadForm uploadForm, BindingResult bindingResult){
        if (bindingResult.hasErrors()) {
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return questionService.imageUpload(uploadForm, 2);
    }

    @PostMapping("/share")
    public BasicView shareQuestion(@Valid @RequestBody QuestionShareForm form, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            throw new BadRequestException(bindingResult.getAllErrors().get(0).getDefaultMessage());
}
        return questionService.shareQuestion(form);
    }

}
