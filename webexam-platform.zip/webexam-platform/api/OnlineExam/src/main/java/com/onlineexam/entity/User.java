/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import com.onlineexam.form.UserUpdateForm;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author nirmal
 */
@Entity
public class User {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1),
        PENDING_FOR_APPROVAL((byte) 2);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }

    public static enum Role {
        SUPER_ADMIN((byte) 1),
        EXAM_PLANNER((byte) 2),
        CANDIDATE((byte) 3),
        SUPPORT((byte) 4);

        public final byte value;

        private Role(byte value) {
            this.value = value;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String passwordToken;
    private byte role;
    private String imageUrl;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    private Organization organization;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grade_id")
    private Grade grade;
    @Temporal(TemporalType.DATE)
    private Date dob;
    private byte status;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    public User() {
    }

    public User(Long userId) {
        this.userId = userId;
    }

    public User(String firstName, String lastName, String email, byte role, String password, Organization organization) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.organization = organization;
        this.status = Status.ACTIVE.value;
        this.role = role;
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }
    
    public User(String firstName, String lastName, String email, byte role, Date dob, String password, String imageUrl, Grade grade, Organization organization) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.imageUrl = imageUrl;
        this.organization = organization;
        this.grade = grade;
        this.status = Status.ACTIVE.value;
        this.role = role;
        this.dob = dob;
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }
    
    public User update(UserUpdateForm form) {
        this.role = form.getRole();
        this.email = form.getEmail();
        this.firstName = form.getFirstName();
        this.lastName = form.getLastName();
        this.updateDate = new Date();
        return this;
    }

    public User changePassword(String password) {
        this.password = password;
        this.updateDate = new Date();
        this.passwordToken = null;
        return this;
    }

    public User resetPassword(String password) {
        this.password = password;
        this.updateDate = new Date();
        return this;
    }

    public User delete(User user) {
        user.setEmail("DELETED_" + user.getEmail() + "_" + new Date().toString());
        user.setStatus(Status.INACTIVE.value);
        user.setUpdateDate(new Date());
        return user;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public String getPasswordToken() {
        return passwordToken;
    }

    public void setPasswordToken(String passwordToken) {
        this.passwordToken = passwordToken;
    }

    public byte getRole() {
        return role;
    }

    public void setRole(byte role) {
        this.role = role;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }
    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userId != null ? userId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof User)) {
            return false;
        }
        User other = (User) object;
        return Objects.equals(this.userId, other.userId);
    }

    @Override
    public String toString() {
        return "com.videoadservice.entity.User[ userId=" + userId + " ]";
    }
}
