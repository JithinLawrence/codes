/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service;

import com.onlineexam.form.ExamQuestionForm;
import com.onlineexam.view.QuestionBankView;
import com.onlineexam.view.QuestionListView;
import java.util.List;

/**
 *
 * @author jinu
 */
public interface QuestionBankQuestionService {

    QuestionBankView addTempQuestionBankQuestion(ExamQuestionForm form, Long questionBankId);

    List<QuestionListView> listQuestions(Long questionBankId);

    void tempDeleteQuestionBankQuestions(Long questionBankId, Integer questionId);

}
