/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Exam;
import com.onlineexam.entity.Organization;
import java.util.Optional;
import org.springframework.data.repository.Repository;

/**
 *
 * @author sanal
 */
public interface OrganizationRepositorySample extends Repository<Organization, Long>{
    Optional<Organization> findByOrganizationIdAndStatusIn(Long organizationId, byte[] status);
}
