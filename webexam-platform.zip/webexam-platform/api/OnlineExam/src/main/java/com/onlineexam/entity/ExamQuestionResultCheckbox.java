/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.ArrayList;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jinu
 */
@Entity
public class ExamQuestionResultCheckbox {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer examQuestionResultCheckboxId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_result_id")
    private ExamResult examResult;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_question_id")
    private ExamQuestion question;
    private String answer;
    private String correctAnswer;
    private Integer correctCount;
    private Integer wrongCount;
    private Integer mark;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    public ExamQuestionResultCheckbox() {
    }

    public ExamQuestionResultCheckbox(Integer examQuestionResultCheckboxId, ExamResult examResult, ExamQuestion question, String answer, String correctAnswer, Integer correctCount, Integer wrongCount, Integer mark) {
        this.examQuestionResultCheckboxId = examQuestionResultCheckboxId;
        this.examResult = examResult;
        this.question = question;
        this.answer = answer;
        this.correctAnswer = correctAnswer;
        this.correctCount = correctCount;
        this.wrongCount = wrongCount;
        this.mark = mark;

        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }

    public ExamQuestionResultCheckbox(ExamResult examResult, ExamQuestion question, String answer, String correctAnswer, Integer correctCount, Integer wrongCount, Integer mark) {
        this.examResult = examResult;
        this.question = question;
        this.answer = answer;
        this.correctAnswer = correctAnswer;
        this.correctCount = correctCount;
        this.wrongCount = wrongCount;
        this.mark = mark;
        
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }

    
    public ExamQuestion getQuestion() {
        return question;
    }

    public Integer getMark() {
        return mark;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setQuestion(ExamQuestion question) {
        this.question = question;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getAnswer() {
        return answer;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public Integer getExamQuestionResultCheckboxId() {
        return examQuestionResultCheckboxId;
    }

    public void setExamQuestionResultCheckboxId(Integer examQuestionResultCheckboxId) {
        this.examQuestionResultCheckboxId = examQuestionResultCheckboxId;
    }

    public ExamResult getExamResult() {
        return examResult;
    }

    public void setExamResult(ExamResult examResult) {
        this.examResult = examResult;
    }

    public Integer getCorrectCount() {
        return correctCount;
    }

    public Integer getWrongCount() {
        return wrongCount;
    }

    public void setCorrectCount(Integer correctCount) {
        this.correctCount = correctCount;
    }

    public void setWrongCount(Integer wrongCount) {
        this.wrongCount = wrongCount;
    }

}
