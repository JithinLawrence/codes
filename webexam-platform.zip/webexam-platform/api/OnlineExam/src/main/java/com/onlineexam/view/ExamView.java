/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Exam;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class ExamView {
    private Long examId;
    private String name;
    private String description;
    private String termsAndConditions;
    private byte type;
    private Integer duration;
    private byte scheduleType;
    private byte showMark;
    private Integer totalMark;
    private Integer passMark;
    private Long createdBy;
    private byte status;
    @Json.DateTimeFormat
    private Date createDate;
    @Json.DateTimeFormat
    private Date updateDate;
    private Long questionCount;
    private String startDate;

    public ExamView(Exam exam, Long questionCount) {
        this.examId = exam.getExamId();
        this.name = exam.getName();
        this.description = exam.getDescription();
        this.termsAndConditions = exam.getTermsAndConditions() == null ? "" : exam.getTermsAndConditions();
        this.type = exam.getType();
        this.duration = exam.getDuration();
        this.scheduleType = exam.getScheduleType();
        this.showMark = exam.getShowMark();
        this.totalMark = exam.getTotalMark();
        this.passMark = exam.getPassMark();
        this.createdBy = exam.getUser().getUserId();
        this.status = exam.getStatus();
        this.createDate = exam.getCreateDate();
        this.updateDate = exam.getUpdateDate();
        this.questionCount = questionCount;
    }
    
    public ExamView(Exam exam, Long questionCount , String startDate) {        
        this.examId = exam.getExamId();
        this.name = exam.getName();
        this.description = exam.getDescription();
        this.termsAndConditions = exam.getTermsAndConditions() == null ? "" : exam.getTermsAndConditions();
        this.type = exam.getType();
        this.duration = exam.getDuration();
        this.scheduleType = exam.getScheduleType();
        this.showMark = exam.getShowMark();
        this.totalMark = exam.getTotalMark();
        this.passMark = exam.getPassMark();
        this.createdBy = exam.getUser().getUserId();
        this.status = exam.getStatus();
        this.createDate = exam.getCreateDate();
        this.updateDate = exam.getUpdateDate();
        this.questionCount = questionCount;
        this.startDate = startDate;
    }

    public Long getExamId() {
        return examId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getTermsAndConditions() {
        return termsAndConditions;
    }

    public byte getType() {
        return type;
    }

    public Integer getDuration() {
        return duration;
    }

    public byte getScheduleType() {
        return scheduleType;
    }

    public byte getShowMark() {
        return showMark;
    }

    public Integer getTotalMark() {
        return totalMark;
    }

    public Integer getPassMark() {
        return passMark;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public Long getQuestionCount() {
        return questionCount;
    }
    
    public String getStartDate() {
        return startDate;
    }
    
}
