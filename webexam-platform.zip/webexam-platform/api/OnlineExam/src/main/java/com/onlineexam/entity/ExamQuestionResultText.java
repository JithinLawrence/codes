/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jinu
 */
@Entity
public class ExamQuestionResultText {

    public static enum IsCorrect {
        WRONG((byte) 0),
        CORRECT((byte) 1);

        public final byte value;

        private IsCorrect(byte value) {
            this.value = value;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer examQuestionResultTextId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_result_id")
    private ExamResult examResult;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_question_id")
    private ExamQuestion question;
    private String answer;
    private String correctAnswer;
    private byte isCorrect;
    private Integer mark;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    public ExamQuestionResultText() {
    }

    public ExamQuestionResultText(Integer examQuestionResultTextId, ExamResult examResult, ExamQuestion question, String answer, String correctAnswer, byte isCorrect, Integer mark) {
        this.examQuestionResultTextId = examQuestionResultTextId;
        this.examResult = examResult;
        this.question = question;
        this.answer = answer;
        this.correctAnswer = correctAnswer;
        this.isCorrect = isCorrect;
        this.mark = mark;

        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }

    public ExamQuestionResultText(ExamResult examResult, ExamQuestion question, String answer, String correctAnswer, byte isCorrect, Integer mark) {
        this.examResult = examResult;
        this.question = question;
        this.answer = answer;
        this.correctAnswer = correctAnswer;
        this.isCorrect = isCorrect;
        this.mark = mark;

        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }

    public Integer getExamQuestionResultTextId() {
        return examQuestionResultTextId;
    }

    public ExamQuestion getQuestion() {
        return question;
    }

    public byte getIsCorrect() {
        return isCorrect;
    }

    public Integer getMark() {
        return mark;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setExamQuestionResultTextId(Integer examQuestionResultTextId) {
        this.examQuestionResultTextId = examQuestionResultTextId;
    }

    public void setQuestion(ExamQuestion question) {
        this.question = question;
    }

    public void setIsCorrect(byte isCorrect) {
        this.isCorrect = isCorrect;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getAnswer() {
        return answer;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public ExamResult getExamResult() {
        return examResult;
    }

    public void setExamResult(ExamResult examResult) {
        this.examResult = examResult;
    }
}
