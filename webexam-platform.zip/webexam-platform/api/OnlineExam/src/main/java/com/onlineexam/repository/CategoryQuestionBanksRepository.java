/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.CategoryQuestionBanks;
import com.onlineexam.entity.CategoryQuestionBanksId;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author sanal
 */
public interface CategoryQuestionBanksRepository extends Repository<CategoryQuestionBanks, CategoryQuestionBanksId>{
    CategoryQuestionBanks save(CategoryQuestionBanks categoryQuestionBanks);
    
    @Transactional
    @Modifying
    @Query(value = "delete from category_question_banks where question_bank_id = ?1 ", nativeQuery = true)
    void deleteByQuestionBankId(Long questionBankId);
    
    @Query(value = "SELECT * FROM category_question_banks as rv WHERE rv.question_bank_id = ?1 AND rv.status = ?2 ", nativeQuery = true)
    List<CategoryQuestionBanks> getListByQuestionBankId(Long questionBankId, byte status);
}
