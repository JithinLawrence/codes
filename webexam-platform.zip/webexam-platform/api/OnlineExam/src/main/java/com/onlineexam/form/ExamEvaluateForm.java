package com.onlineexam.form;




import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

public class ExamEvaluateForm {



    @NotNull
    private Integer totalMarks;
    @NotNull
    private Long examResultId;

    @Valid
    private List<ExamEvaluationInnerForm> examEvaluationInnerForm;

    /*@NotNull
    private Map<String,String> marksMap;*/

    public List<ExamEvaluationInnerForm> getExamEvaluationInnerForm() {
        return examEvaluationInnerForm;
    }

    public void setExamEvaluationInnerForm(List<ExamEvaluationInnerForm> examEvaluationInnerForm) {
        this.examEvaluationInnerForm = examEvaluationInnerForm;
    }

    public Integer getTotalMarks() {
        return totalMarks;
    }

    public void setTotalMarks(Integer totalMarks) {
        this.totalMarks = totalMarks;
    }

    public Long getExamResultId() {
        return examResultId;
    }

    public void setExamResultId(Long examResultId) {
        this.examResultId = examResultId;
    }




    public static class ExamEvaluationInnerForm {

        @NotNull
        private Integer id;
        @NotNull
        private Integer value;
        @NotNull
        private Long typeId;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public Integer getValue() {
            return value;
        }

        public void setValue(Integer value) {
            this.value = value;
        }

        public Long getTypeId() {
            return typeId;
        }

        public void setTypeId(Long typeId) {
            this.typeId = typeId;
        }

        //        @NotNull
//        private Map<String,String> marksMap;
//
//        public Map<String, String> getMarksMap() {
//            return marksMap;
//        }
//
//        public void setMarksMap(Map<String, String> marksMap) {
//            this.marksMap = marksMap;
//        }
    }



}
