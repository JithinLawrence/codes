/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Grade;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class GradeListDetailView {
    private final Long gradeId;
    private final String name;
    private final String description;
    private final String organization;
    private final Long organization_id;
    private final byte status;
    @Json.DateFormat
    private final Date createDate;
    @Json.DateFormat
    private final Date updateDate;

    public GradeListDetailView(Grade grade) {
        this.gradeId = grade.getGradeId();
        this.name = grade.getName();
        this.description = grade.getDescription();
        this.organization = grade.getOrganization().getName();
        this.organization_id = grade.getOrganization().getOrganizationId();
        this.status = grade.getStatus();
        this.createDate = grade.getCreateDate();
        this.updateDate = grade.getUpdateDate();
    }

    public Long getGradeId() {
        return gradeId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getOrganization() {
        return organization;
    }

    public Long getOrganization_id() {
        return organization_id;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    
}
