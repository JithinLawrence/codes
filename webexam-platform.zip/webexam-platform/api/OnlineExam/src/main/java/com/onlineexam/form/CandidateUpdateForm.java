/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.form;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
/**
 *
 * @author simon
 */
public class CandidateUpdateForm {
    @NotBlank
    @Size(max = 50, message = "{name.length.exceeded}")
    private String firstName;
    @Size(max = 50, message = "{name.length.exceeded}")
    private String lastName;
    @NotBlank(message = "{please.enter.details}")
    @Size(max = 255)
    @Email
    private String email;
    private Byte role;
    private int companyId;
    @Pattern(regexp = "[(http(s)?):\\/\\/(www\\.)?a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)", 
            message = "user.invalid.password.pattern")
    private String imageUrl;    
    @NotBlank
    private long gradeId;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String name) {
        this.firstName = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String name) {
        this.lastName = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Byte getRole() {
        return role;
    }

    public void setRole(Byte role) {
        this.role = role;
    }

    public int getCompanyId() {
        return companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }
    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    public long getGrade() {
        return gradeId;
    }

    public void setGrade(int gradeId) {
        this.gradeId = gradeId;
    }
}
