/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Category;
import com.onlineexam.entity.Grade;
import com.onlineexam.entity.Organization;
import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Pageable;

/**
 *
 * @author Libeesh
 */
public interface CategoryRepository extends Repository<Category, Long> {

    Optional<Category> findByCategoryId(Long categoryId);

    Optional<Category> findByCategoryIdAndStatus(Long categoryId, byte status);

    List<Category> findAllByStatusAndOrganization(byte status, Organization org);
    
    @Query(value = "SELECT * FROM category as g WHERE g.status = ?1 AND (g.name like %?2% OR g.description like %?2% ) AND g.organization_id=?3", nativeQuery = true)
    Page<Category> getCategoryList(byte status, String search, Long orgId, Pageable page);
    
    Category save(Category category);
    
    Long countByCategoryIdNotAndStatusAndName(Long categoryId,byte status, String name);
    
    @Query(value = "SELECT COUNT(*) FROM category as g WHERE g.status = ?1 AND ( g.name like %?2% OR g.description like %?2% ) AND g.organization_id=?3" , nativeQuery=true)
    Long countCategoryList(byte status, String search, Long orgId); 
    
    Long countByStatusAndNameAndOrganization(byte status, String name, Organization org);
}
