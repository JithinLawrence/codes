/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.controller;

import com.onlineexam.service.UserService;
import com.onlineexam.util.Pager;
import com.onlineexam.view.UserView;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 *
 * @author jinu
 */
@RestController
@RequestMapping("/admin/candidates")
public class CandidateController {
  
    @Autowired
    private UserService userService;    
  
    @GetMapping("/list")
    public Pager<UserView> listUsers(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type,
            @RequestParam(value = "grade", required = false) Long grade
    ) {
        if (limit == null){
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        if(grade == null){
            grade = 0L;
        }
      
        return userService.listCandidates(search, limit, sort,type,page, grade);
    }
    
    @PutMapping("/{userId}")
    public void editStatus(
            @PathVariable("userId") Long userId
    ) {
        userService.editStatus(userId);
    }   
    
    @GetMapping("/listCandidateToAssign")
    public Pager<UserView> listCandidateToAssign(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "page", required = false) Integer page,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "type", required = false) boolean type,
            @RequestParam(value = "grade", required = false) Long grade,
            @RequestParam(value = "scheduleId", required = false) Long scheduleId
    ) {
        if(limit == 2){
            limit = 0;
        }
        if (limit == null){
            limit = 10;
        }
        if (page == null) {
            page = 1;
        }
        if(grade == null){
            grade = 0L;
        }
      
        return userService.listCandidateToAssign(search, limit, sort,type,page, grade, scheduleId);
    }
    
    @GetMapping("/listAssignedCandidates")
    public List<UserView> listAssignedCandidates(
            @RequestParam(value = "scheduleId", required = false) Long scheduleId               
    ) {
      
        return userService.listAssignedCandidates(scheduleId);
    }
}
