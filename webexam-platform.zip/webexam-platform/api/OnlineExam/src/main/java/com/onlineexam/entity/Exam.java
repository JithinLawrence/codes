/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import com.onlineexam.form.ExamUpdateForm;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author sanal
 */
@Entity
public class Exam {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }

    public static enum EditingStatus {
        SAVED((byte) 1),
        TEMP_SAVE((byte) 2),
        TEMP_UPDATE((byte) 3);

        public final byte value;

        private EditingStatus(byte value) {
            this.value = value;
        }
    }
    
    public static enum Type {
        PUBLIC((byte) 1),
        PRIVATE((byte) 2);

        public final byte value;

        private Type(byte value) {
            this.value = value;
        }
    }
    
    public static enum ShowMarks {
        SHOW_LATER((byte) 0),
        SHOW_RIGHT_AFTER_EXAM((byte) 1);

        public final byte value;

        private ShowMarks(byte value) {
            this.value = value;
        }
    }
    
    public static enum PendingReview {
        PENDING((byte) 0),
        REVIEWED((byte) 1);

        public final byte value;

        private PendingReview(byte value) {
            this.value = value;
        }
    }
    
    public static enum ScheduleType {
        FLEXI((byte) 1),
        FIXED((byte) 2);

        public final byte value;

        private ScheduleType(byte value) {
            this.value = value;
        }
    }
    
    @Id
    @Column(name="exam_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long examId;
    private String name;
    private String description;
    private String termsAndConditions;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    private Organization organization;
    private byte type;
    private Integer duration;
    private byte scheduleType;
    private Integer totalMark;
    private Integer passMark;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User user;
    private byte status;
    private byte editingStatus;
    private byte showMark;
    private byte pendingReview;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    
    @OneToMany(mappedBy="exam", fetch = FetchType.LAZY)
    private Set<ScheduleAssignCandidate> products = new HashSet<ScheduleAssignCandidate>(0);

    public Exam() {
    }

    public Exam(String name, String description, String termsAndConditions, Organization organization, byte type, Integer duration, byte scheduleType, Integer totalMark, Integer passMark, User user, byte status, byte editingStatus, byte showMark) {
        this.name = name;
        this.description = description;
        this.termsAndConditions = termsAndConditions;
        this.organization = organization;
        this.type = type;
        this.duration = duration;
        this.scheduleType = scheduleType;
        this.totalMark = totalMark;
        this.passMark = passMark;
        this.user = user;
        this.status = status;
        this.editingStatus = editingStatus;
        this.showMark = showMark;
        this.pendingReview = PendingReview.PENDING.value;

        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }

    public Exam activateExam(String name, String description, String termsAndConditions, byte type, Integer duration, byte scheduleType, Integer totalMark, Integer passMark, User user, byte status, byte editingStatus, byte showMark) {
        this.name = name;
        this.description = description;
        this.termsAndConditions = termsAndConditions;
        this.type = type;
        this.duration = duration;
        this.scheduleType = scheduleType;
        this.totalMark = totalMark;
        this.passMark = passMark;
        this.user = user;
        this.status = status;
        this.editingStatus = editingStatus;
        this.showMark = showMark;
        this.pendingReview = PendingReview.PENDING.value;

        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
        return this;
    }
    
    public Exam update(ExamUpdateForm form){
        this.name = form.getName();
        this.type = form.getType();
        this.duration = form.getDuration();
        this.description = form.getDescription();
        this.termsAndConditions = form.getTermsAndConditions();
        this.scheduleType = form.getScheduleType();
        this.totalMark = form.getTotalMark();
        this.passMark = form.getPassMark();
        this.description = form.getDescription();
        this.updateDate = new Date();
        this.showMark = form.getShowMark();
        return this;
    }
    
    public Exam copy(ExamUpdateForm form){
        this.name = form.getName();
        this.type = form.getType();
        this.duration = form.getDuration();
        this.description = form.getDescription();
        this.termsAndConditions = form.getTermsAndConditions();
        this.scheduleType = form.getScheduleType();
        this.totalMark = form.getTotalMark();
        this.passMark = form.getPassMark();
        this.description = form.getDescription();
        this.updateDate = new Date();
        this.showMark = form.getShowMark();
        this.status = Status.ACTIVE.value;
        this.editingStatus = EditingStatus.SAVED.value;
        return this;
    }
    
    public Exam delete(Exam exam){
        this.status = Status.INACTIVE.value;
        this.updateDate = new Date();
        return this;
    }

    public Long getExamId() {
        return examId;
    }

    public void setExamId(Long examId) {
        this.examId = examId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(String termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public byte getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(byte scheduleType) {
        this.scheduleType = scheduleType;
    }

    public Integer getTotalMark() {
        return totalMark;
    }

    public void setTotalMark(Integer totalMark) {
        this.totalMark = totalMark;
    }

    public Integer getPassMark() {
        return passMark;
    }

    public void setPassMark(Integer passMark) {
        this.passMark = passMark;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public byte getEditingStatus() {
        return editingStatus;
    }

    public void setEditingStatus(byte editingStatus) {
        this.editingStatus = editingStatus;
    }

    public byte getShowMark() {
        return showMark;
    }

    public void setShowMark(byte showMark) {
        this.showMark = showMark;
    }

    public byte getPendingReview() {
        return pendingReview;
    }

    public void setPendingReview(byte pendingReview) {
        this.pendingReview = pendingReview;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Set<ScheduleAssignCandidate> getProducts() {
        return products;
    }

    public void setProducts(Set<ScheduleAssignCandidate> products) {
        this.products = products;
    }
      
}
