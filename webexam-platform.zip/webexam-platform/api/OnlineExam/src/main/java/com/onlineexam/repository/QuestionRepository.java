/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Question;
import com.onlineexam.entity.User;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author Libeesh
 */
public interface QuestionRepository extends Repository<Question, Integer>{

    Optional<Question> findByQuestionId(Integer questionId);
    
    Question save(Question question);

    @Query(value = "SELECT COUNT(distinct q.question_id) FROM question as q "
            + " left join grade_questions as gq on (gq.question_id = q.question_id) "
            + " WHERE q.status in ?1 AND q.created_by = ?2 AND "
            + " (q.title like %?3% or q.description like %?3%) AND "
            + " IF(?4 > 0, q.category_id, 0) = ?4 AND IF(?5 > 0, gq.grade_id, 0) = ?5 AND IF(?6 > 0, q.question_level_id, 0) = ?6 ", nativeQuery = true)
    Long countQuestionListByUser(byte[] status, Long userId, String search, Integer categoryId, 
            Integer groupId, Integer levelId);
    
    @Query(value = "SELECT * FROM question as q "
            + " inner join grade_questions as gq on (q.question_id = gq.question_id) "
            + " WHERE q.status in ?1 AND q.created_by = ?2 AND "
            + "(q.title like %?3% or q.description like %?3%) AND "
            + "IF(?4 > 0, q.category_id, 0) = ?4 AND IF(?5 > 0, gq.grade_id, 0) = ?5 AND IF(?6 > 0, q.question_level_id, 0) = ?6 "
            + " ", nativeQuery = true)
    Page<Question> getQuestionListWithGradeByUser(byte[] status, Long userId, String search, Integer categoryId, 
            Integer groupId, Integer levelId, Pageable page);
    
    @Query(value = "SELECT * FROM question as q "
            + " WHERE q.status in ?1 AND q.created_by = ?2 AND "
            + "(q.title like %?3% or q.description like %?3%) AND "
            + "IF(?4 > 0, q.category_id, 0) = ?4 AND IF(?5 > 0, q.question_level_id, 0) = ?5 "
            + " ", nativeQuery = true)
    Page<Question> getQuestionListWithOutGradeByUser(byte[] status, Long userId, String search, Integer categoryId, 
            Integer levelId, Pageable page);
    
    Optional<Question> findByQuestionIdAndStatusInAndUser(Integer questionId, byte[] status, User user);
    
    Optional<Question> findByQuestionIdAndStatusIn(Integer questionId, byte[] status);
    
    @Query(value = "SELECT COUNT(u.*) FROM question as u WHERE u.status in ?1 ", nativeQuery = true)
    Long countQuestionList(byte[] status);
    
    @Query(value = "select distinct q.* from question as q "
            + " left join grade_questions as gq on (gq.question_id = q.question_id) "
            + " where q.created_by = ?1 AND q.status = ?2 AND (q.title like %?3% or q.description like %?3%) AND "
            + "IF(?4 > 0, q.category_id, 0) = ?4 AND IF(?5 > 0, gq.grade_id, 0) = ?5 AND IF(?6 > 0, q.question_level_id, 0) = ?6 "
            + "and q.question_id not in (select ieq.question_id from exam_question as ieq where ieq.exam_id = ?9 and ieq.status in ?7 and ieq.editing_status in ?8 ) "
            + " group by q.question_id"//Status:EditingStatus -> Active:temp_update|saved, Inactive:temp_save|
            , nativeQuery = true)
    Page<Question> getQuestionListNotInExamSelectWithSearchByUser(Long userId, byte questionStatus, String search, Integer categoryId, 
            Integer groupId, Integer levelId, byte[] examQuestionStatus, byte[] examQuestionEditingStatus, Long examId, Pageable page);
    
    @Query(value = "SELECT COUNT(distinct q.question_id) FROM question as q "
            + " left join grade_questions as gq on (gq.question_id = q.question_id) "
            + " WHERE q.status in ?1 AND "
            + " (q.title like %?2% or q.description like %?2%) AND "
            + " IF(?3 > 0, q.category_id, 0) = ?3 AND IF(?4 > 0, gq.grade_id, 0) = ?4 AND IF(?5 > 0, q.question_level_id, 0) = ?5 AND q.created_by = ?6 ", nativeQuery = true)
    Long countUserQuestionList(byte[] status, String search, Integer categoryId, 
            Integer groupId, Integer levelId , Long userId);
    
    @Query(value = "SELECT * FROM question as q "
            + " WHERE q.status in ?1 AND "
            + "(q.title like %?2% or q.description like %?2%) AND "
            + "IF(?3 > 0, q.category_id, 0) = ?3 AND IF(?4 > 0, q.question_level_id, 0) = ?4 AND q.created_by = ?5"
            + " ", nativeQuery = true)
    Page<Question> getUserQuestionListWithOutGrade(byte[] status, String search, Integer categoryId, 
            Integer levelId, Long userId, Pageable page);
    
     @Query(value = "SELECT * FROM question as q "
            + " inner join grade_questions as gq on (q.question_id = gq.question_id) "
            + " WHERE q.status in ?1 AND "
            + "(q.title like %?2% or q.description like %?2%) AND "
            + "IF(?3 > 0, q.category_id, 0) = ?3 AND IF(?4 > 0, gq.grade_id, 0) = ?4 AND IF(?5 > 0, q.question_level_id, 0) = ?5 AND q.created_by = ?6 "
            + " ", nativeQuery = true)
    Page<Question> getUserQuestionListWithGrade(byte[] status, String search, Integer categoryId, 
            Integer groupId, Integer levelId, Long userId, Pageable page);
    
    @Query(value = "select distinct q.* from question as q "
            + " left join grade_questions as gq on (gq.question_id = q.question_id) "
            + " where (q.title like %?1% or q.description like %?1%) AND "
            + "IF(?2 > 0, q.category_id, 0) = ?2 AND IF(?3 > 0, gq.grade_id, 0) = ?3 AND IF(?4 > 0, q.question_level_id, 0) = ?4 "
            + "and q.question_id NOT IN (select ieq.question_id from question_bank_questions as ieq where ieq.question_bank_id = ?6 and ieq.status in ?5 ) AND q.created_by = ?7 AND q.status=?8 "
            + " group by q.question_id"//Status:EditingStatus -> Active:temp_update|saved, Inactive:temp_save|
            , nativeQuery = true)
    Page<Question> getUserQuestionListNotInQBSelectWithSearch(String search, Integer categoryId, 
            Integer groupId, Integer levelId, byte[] questionBankStatus, Long examId, Long userId, byte questionStatus, Pageable page);
    
    @Query(value = "SELECT COUNT(distinct q.question_id) FROM question as q "
            + " INNER JOIN grade_questions as gq on (gq.question_id = q.question_id) "
            + " INNER JOIN question_bank_questions as qq on (qq.question_id = q.question_id) "
            + " WHERE q.status in ?1 AND "
            + " (q.title like %?2% or q.description like %?2%) AND "
            + " IF(?3 > 0, q.category_id, 0) = ?3 AND IF(?4 > 0, gq.grade_id, 0) = ?4 AND IF(?5 > 0, q.question_level_id, 0) = ?5 AND qq.editing_status=1 AND qq.status=1 AND qq.question_bank_id = ?6", nativeQuery = true)
    Long countQBQuestionListByUser(byte[] status, String search, Integer categoryId, 
            Integer groupId, Integer levelId,Long questionBankId);
    
//    @Query(value = "SELECT * FROM question as q "
//            + " inner join question_bank_questions as qq on (qq.question_id = q.question_id) "
//            + " WHERE qq.editing_status=1 AND qq.status=1 AND qq.question_bank_id=?1"
//            + " ", nativeQuery = true)
            
    @Query(value = "SELECT * FROM question as q "
            + " inner join question_bank_questions as qq on (qq.question_id = q.question_id) "
            + " WHERE q.status in ?1 AND "
            + "(q.title like %?2% or q.description like %?2%) AND "
            + "IF(?3 > 0, q.category_id, 0) = ?3 AND IF(?4 > 0, q.question_level_id, 0) = ?4 AND qq.editing_status=1 AND qq.status=1 AND qq.question_bank_id=?5 "
            + " ", nativeQuery = true)
    Page<Question> getQBQuestionListWithOutGradeByUser(byte[] status, String search, Integer category, Integer level, Long questionBankId, Pageable page);
    
    @Query(value = "SELECT * FROM question as q "
            + " inner join grade_questions as gq on (q.question_id = gq.question_id) "
            + " inner join question_bank_questions as qq on (qq.question_id = q.question_id) "
            + " WHERE q.status in ?1 AND "
            + "(q.title like %?2% or q.description like %?2%) AND "
            + "IF(?3 > 0, q.category_id, 0) = ?3 AND IF(?4 > 0, gq.grade_id, 0) = ?4 AND IF(?5 > 0, q.question_level_id, 0) = ?5 AND qq.editing_status=1 AND qq.status=1 AND qq.question_bank_id=?6 "
            + " ", nativeQuery = true)
    Page<Question> getQBQuestionListWithGradeByUser(byte[] status, String search, Integer categoryId, 
            Integer groupId, Integer levelId, Long questionBankId, Pageable page);
    
    @Query(value = "SELECT COUNT(distinct q.question_id) FROM question as q "
            + " left join grade_questions as gq on (gq.question_id = q.question_id) "
            + " WHERE q.status in ?1 AND q.organization_id = ?2 AND "
            + " (q.title like %?3% or q.description like %?3%) AND "
            + " IF(?4 > 0, q.category_id, 0) = ?4 AND IF(?5 > 0, gq.grade_id, 0) = ?5 AND IF(?6 > 0, q.question_level_id, 0) = ?6 ", nativeQuery = true)
    Long countQuestionListByAdmin(byte[] status, Long org, String search, Integer categoryId, 
            Integer groupId, Integer levelId);
    @Query(value = "SELECT * FROM question as q "
            + " inner join grade_questions as gq on (q.question_id = gq.question_id) "
            + " WHERE q.status in ?1 AND q.organization_id = ?2 AND "
            + "(q.title like %?3% or q.description like %?3%) AND "
            + "IF(?4 > 0, q.category_id, 0) = ?4 AND IF(?5 > 0, gq.grade_id, 0) = ?5 AND IF(?6 > 0, q.question_level_id, 0) = ?6 "
            + " ", nativeQuery = true)
    Page<Question> getQuestionListWithGradeByAdmin(byte[] status, Long org, String search, Integer categoryId, 
            Integer groupId, Integer levelId, Pageable page);
    
    @Query(value = "SELECT * FROM question as q "
            + " WHERE q.status in ?1 AND q.organization_id = ?2 AND "
            + "(q.title like %?3% or q.description like %?3%) AND "
            + "IF(?4 > 0, q.category_id, 0) = ?4 AND IF(?5 > 0, q.question_level_id, 0) = ?5 "
            + " ", nativeQuery = true)
    Page<Question> getQuestionListWithOutGradeByAdmin(byte[] status, Long org, String search, Integer categoryId, 
            Integer levelId, Pageable page);
    
    @Query(value = "select distinct q.* from question as q "
            + " left join grade_questions as gq on (gq.question_id = q.question_id) "
            + " where (q.title like %?1% or q.description like %?1%) AND "
            + "IF(?2 > 0, q.category_id, 0) = ?2 AND IF(?3 > 0, gq.grade_id, 0) = ?3 AND IF(?4 > 0, q.question_level_id, 0) = ?4 "
            + "and q.question_id NOT IN (select ieq.question_id from question_bank_questions as ieq where ieq.question_bank_id = ?6 and ieq.status in ?5 ) AND q.organization_id = ?7 AND q.status=?8 "
            + " group by q.question_id"//Status:EditingStatus -> Active:temp_update|saved, Inactive:temp_save|
            , nativeQuery = true)
    Page<Question> getAdminQuestionListNotInQBSelectWithSearch(String search, Integer categoryId, 
            Integer groupId, Integer levelId, byte[] questionBankStatus, Long questionBankId, Long org, byte questionStatus, Pageable page);
    
    @Query(value = "select distinct q.* from question as q "
            + " left join grade_questions as gq on (gq.question_id = q.question_id) "
            + " where q.organization_id = ?1 AND q.status = ?2 AND (q.title like %?3% or q.description like %?3%) AND "
            + "IF(?4> 0, q.category_id, 0) = ?4 AND IF(?5 > 0, gq.grade_id, 0) = ?5 AND IF(?6 > 0, q.question_level_id, 0) = ?6 "
            + "and q.question_id not in (select ieq.question_id from exam_question as ieq where ieq.exam_id = ?9 and ieq.status in ?7 and ieq.editing_status in ?8 ) "
            + " group by q.question_id"//Status:EditingStatus -> Active:temp_update|saved, Inactive:temp_save|
            , nativeQuery = true)
    Page<Question> getQuestionListNotInExamSelectWithSearchByAdmin(Long org, byte questionStatus, String search, Integer categoryId, 
            Integer groupId, Integer levelId, byte[] examQuestionStatus, byte[] examQuestionEditingStatus, Long examId, Pageable page);
    
    @Query(value = "SELECT COUNT(q.question_id) FROM question q"
            + " INNER JOIN category c on c.category_id = q.category_id"
            + " where c.category_id = ?1 AND c.organization_id=?2" , nativeQuery = true)
    Long countByCategoryIdAndOrg(Long categoryId, Long org);
    
    @Query(value = "SELECT COUNT(q.grade_id) FROM grade_questions q"
            + " INNER JOIN grade c on c.grade_id = q.grade_id"
            + " where c.grade_id = ?1 AND c.organization_id=?2" , nativeQuery = true)
    Long countByGradeIdAndOrg(Long gradeId, Long org);
}
