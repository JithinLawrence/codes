package com.onlineexam.repository;

import com.onlineexam.entity.Exam;
import com.onlineexam.entity.Organization;
import com.onlineexam.entity.Schedule;
import java.util.Date;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import java.util.Optional;

public interface ExamScheduleRepository extends Repository<Schedule, Long> {

    Optional<Schedule> findByScheduleId(Long scheduleId);
    Schedule save(Schedule schedule);

    //@Query(value = "SELECT count(*) FROM schedule as s WHERE s.status in ?1 AND (s.startTime like %?2% OR s.endTime like %?%)", nativeQuery = true)
    @Query(value = "SELECT count(*) FROM schedule as s\n" +
                    "INNER JOIN exam e ON e.exam_id = s.exam_id\n" +
                    "WHERE s.status IN ?1 AND (e.name like %?2%) AND s.organization_id=?3", nativeQuery = true)
    Long countScheduleList(byte[] examScheduleActiveStatus, String search, Long org);
    
    @Query(value = "SELECT count(*) FROM schedule as s\n" +
                    "INNER JOIN exam e ON e.exam_id = s.exam_id\n" +
                    "WHERE s.status IN ?1 AND (e.name like %?2%) AND s.organization_id=?3 AND s.created_by = ?4", nativeQuery = true)
    Long countScheduleListByPlanner(byte[] examScheduleActiveStatus, String search, Long org, Long userId);

    @Query(value = "SELECT * FROM schedule as s WHERE s.status in ?1 AND s.organization_id=?2 ", nativeQuery = true)
    Page<Schedule> getScheduleListByAdmin(byte[] status, Long org, Pageable page);
    
    @Query(value = "SELECT * FROM schedule as s\n" +
                    "INNER JOIN exam e ON e.exam_id = s.exam_id\n" +
                    "WHERE s.status IN ?1 AND (e.name like %?2%) AND s.organization_id =?3 AND s.created_by = ?4 ", nativeQuery = true)
    Page<Schedule> getScheduleListBySearch(byte[] status, String search, Long org, Long userId, Pageable page);
    
    @Query(value = "SELECT * FROM schedule as s\n" +
                    "INNER JOIN exam e ON e.exam_id = s.exam_id\n" +
                    "WHERE s.status IN ?1 AND (e.name like %?2%) AND s.organization_id = ?3 ", nativeQuery = true)
    Page<Schedule> getScheduleListBySearchAdmin(byte[] status, String search, Long org, Pageable page);


    Optional<Schedule> findByScheduleIdAndStatusIn(Long scheduleId, byte[] examScheduleActiveStatus);

    @Query(value = "SELECT count(*) FROM schedule as s WHERE s.schedule_id=?1 and s.status in ?2  ", nativeQuery = true)
    Long countByScheduleIdNotAndStatusIn(Long scheduleId, byte[] examScheduleActiveStatus);
    
    @Query(value="SELECT DATE_FORMAT(start_time,\"%d/%m/%Y %H:%i\") from schedule where exam_id=?1 AND status=?2 AND schedule_id=?3" , nativeQuery = true)
    String findByExamAndStatus(Exam exam, byte status, Long scheduleId);
    
    @Query(value = "SELECT * FROM schedule as s WHERE s.status in ?1 AND s.organization_id=?2 AND s.created_by=?3", nativeQuery = true)
    Page<Schedule> getScheduleListByPlanner(byte[] status, Long org, Long userId, Pageable page);
    
    Long countByExamAndOrganizationAndStartTimeAndEndTimeAndType(Exam exam, Organization organization, Date startTime, Date endTime, byte type);
    
    Schedule findByScheduleIdAndExam(Long scheduleId, Exam exam);

    Long countByExamAndStatusAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(Exam exam, byte status, Date startTime, Date endTime);
    
    Long countByExamAndStatusAndEndTimeGreaterThanEqual(Exam exam, byte status, Date endTime);
    
    Long countByExamAndStatus(Exam exam, byte status);

}
