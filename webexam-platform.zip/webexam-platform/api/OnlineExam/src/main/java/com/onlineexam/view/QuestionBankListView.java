/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.QuestionBank;
import java.util.List;

/**
 *
 * @author sanal
 */
public class QuestionBankListView {
    
    private Long questionBankId;
    private String name;
    private List<Long> categoryIds;
    private List<Long> gradeIds;

    public QuestionBankListView(QuestionBank questionBank, List<Long> categoryIds, List<Long> gradeIds) {
        this.questionBankId = questionBank.getQuestionBankId();
        this.name = questionBank.getTitle();
        this.categoryIds = categoryIds;
        this.gradeIds = gradeIds;
    }

    public String getName() {
        return name;
    }

    public Long getQuestionBankId() {
        return questionBankId;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public List<Long> getGradeIds() {
        return gradeIds;
    }
    
}
