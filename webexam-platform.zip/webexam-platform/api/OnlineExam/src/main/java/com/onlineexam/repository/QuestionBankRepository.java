/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Question;
import com.onlineexam.entity.QuestionBank;
import com.onlineexam.entity.User;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author sanal
 */
public interface QuestionBankRepository extends Repository<QuestionBank, Long>{
    
    Optional<QuestionBank> findByQuestionBankId(Long questionBankId);
    
    Optional<QuestionBank> findByQuestionBankIdAndStatusIn(Long questionBankId, byte[] status);
    
    Long countByStatusInAndTitle(byte[] status, String title);
    
//    Long countByQuestionBankIdAndStatusIn(Long questionBankId, byte[] status);
    
    Long countByQuestionBankIdNotAndStatusInAndTitle(Long questionBankId, byte[] status, String title);
    
//    Long countByStatusInAndTitleOrDescription(byte[] status, String title, String description);
    
//    Page<QuestionBank> findByStatusInAndTitleOrDescription(byte[] status, String title, String description, Pageable page);
    
    @Query(value = "SELECT COUNT(*) FROM question_bank as u WHERE u.status in ?1 AND (u.title like %?2% OR u.description like %?2%) AND u.editing_status=?3 AND u.organization_id=?4 ", nativeQuery = true)
    Long countQuestionBankList(byte[] status, String search, byte editingStatus, Long org);

    @Query(value = "SELECT * FROM question_bank as u WHERE u.status in ?1 AND (u.title like %?2% OR u.description like %?2%) AND u.editing_status=?3 AND u.organization_id=?4 ", nativeQuery = true)
    Page<QuestionBank> getQuestionBankList(byte[] status, String search, byte editingStatus, Long org, Pageable page);

    @Query(value = "SELECT * FROM question_bank as u WHERE u.status in ?1 AND u.editing_status=?2 AND u.organization_id=?3", nativeQuery = true)
    List<QuestionBank> getQuestionBankList(byte[] status, byte editingStatus, Long org);
    
    @Query(value = "SELECT * FROM question_bank as u WHERE u.status in ?1 AND u.editing_status=?2 AND u.organization_id=?3 AND u.created_by=?4 ", nativeQuery = true)
    List<QuestionBank> getQuestionBankListByUser(byte[] status, byte editingStatus, Long org, Long userId);
    
    QuestionBank save(QuestionBank questionBank);
    
    @Transactional
    @Modifying
    @Query(value = "UPDATE question_bank set status=0 where editing_status = ?1 AND created_by = ?2", nativeQuery = true)
    void deleteByEditingStatusAndCreatedBy(byte editingStatus, Long userId);
    
    @Transactional
    @Modifying
    @Query(value = "UPDATE question_bank set title=?1,description=?2,editing_status=?3,update_date=now(),status=1 WHERE question_bank_id = ?4 ", nativeQuery = true)
    void updateQuestionBank(String title, String desc, byte editingStatus, Long questionBankId);
    
    @Query(value = "SELECT grade_id FROM grade_question_banks where question_bank_id = ?1 ", nativeQuery = true)
    List<Long> findAllByQuestionBankId(Long questionBankId);
    
    @Query(value = "SELECT q.* FROM question q INNER JOIN question_bank_questions qb on qb.question_id = q.question_id WHERE qb.question_bank_id = ?1 ", nativeQuery = true)
    List<Question> findAllQuestionsByQuestionBankId(Long questionBankId);
    
    @Query(value = "SELECT category_id FROM category_question_banks where question_bank_id = ?1 ", nativeQuery = true)
    List<Long> findAllCategoryByQuestionBankId(Long questionBankId);
    
    @Query(value = "SELECT COUNT(*) FROM question_bank as u WHERE u.status in ?1 AND (u.title like %?2% OR u.description like %?2%) AND u.editing_status=?3 AND u.organization_id=?4 AND u.created_by=?5 ", nativeQuery = true)
    Long countQuestionBankListByUser(byte[] status, String search, byte editingStatus, Long org, Long userId);

    @Query(value = "SELECT * FROM question_bank as u WHERE u.status in ?1 AND (u.title like %?2% OR u.description like %?2%) AND u.editing_status=?3 AND u.organization_id=?4 AND u.created_by=?5 ", nativeQuery = true)
    Page<QuestionBank> getQuestionBankListByUser(byte[] status, String search, byte editingStatus, Long org, Long userId, Pageable page);
    
    @Query(value = "SELECT COUNT(gr.grade_id) FROM grade_question_banks as gr"
            + " INNER JOIN grade g on g.grade_id = gr.grade_id"
            + " where g.grade_id=?1 AND g.organization_id=?2" , nativeQuery = true)
    Long countByGradeId(Long gradeId , Long org);
    
    @Query( value = "SELECT COUNT(cr.category_id) FROM category_question_banks as cr"
            + " INNER JOIN category c on c.category_id = cr.category_id"
            + " where c.category_id=?1 AND c.organization_id=?2" , nativeQuery = true)
    Long countByCategoryId(Long categoryId, Long org);
    
}
