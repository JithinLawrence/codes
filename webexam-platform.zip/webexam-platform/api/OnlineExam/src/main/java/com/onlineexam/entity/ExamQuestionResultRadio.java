/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jinu
 */
@Entity
public class ExamQuestionResultRadio {

    public static enum IsCorrect {
        WRONG((byte) 0),
        CORRECT((byte) 1);

        public final byte value;

        private IsCorrect(byte value) {
            this.value = value;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer examQuestionResultRadioId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_result_id")
    private ExamResult examResult;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_question_id")
    private ExamQuestion question;
    private Integer answer;
    private Integer correctAnswer;
    private byte isCorrect;
    private Integer mark;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    public ExamQuestionResultRadio() {
    }

    public ExamQuestionResultRadio(ExamResult examResult, ExamQuestion question, Integer answer, Integer correctAnswer, byte isCorrect, Integer mark) {
        this.examResult = examResult;
        this.question = question;
        this.answer = answer;
        this.correctAnswer = correctAnswer;
        this.isCorrect = isCorrect;
        this.mark = mark;
        
        
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }
    
    public ExamQuestionResultRadio(Integer examQuestionResultRadioId, ExamResult examResult, ExamQuestion question, Integer answer, Integer correctAnswer, byte isCorrect, Integer mark) {
        this.examQuestionResultRadioId = examQuestionResultRadioId;
        this.examResult = examResult;
        this.question = question;
        this.answer = answer;
        this.correctAnswer = correctAnswer;
        this.isCorrect = isCorrect;
        this.mark = mark;
        
        
        Date dt = new Date();
        this.createDate = dt;
        this.updateDate = dt;
    }

    public ExamQuestion getQuestion() {
        return question;
    }

    public Integer getAnswer() {
        return answer;
    }

    public Integer getCorrectAnswer() {
        return correctAnswer;
    }

    public byte getIsCorrect() {
        return isCorrect;
    }

    public Integer getMark() {
        return mark;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setQuestion(ExamQuestion question) {
        this.question = question;
    }

    public void setAnswer(Integer answer) {
        this.answer = answer;
    }

    public void setCorrectAnswer(Integer correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public void setIsCorrect(byte isCorrect) {
        this.isCorrect = isCorrect;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Integer getExamQuestionResultRadioId() {
        return examQuestionResultRadioId;
    }

    public void setExamQuestionResultRadioId(Integer examQuestionResultRadioId) {
        this.examQuestionResultRadioId = examQuestionResultRadioId;
    }

    public ExamResult getExamResult() {
        return examResult;
    }

    public void setExamResult(ExamResult examResult) {
        this.examResult = examResult;
    }
}
