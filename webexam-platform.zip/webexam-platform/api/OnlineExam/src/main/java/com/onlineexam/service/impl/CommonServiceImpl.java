/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service.impl;

import com.onlineexam.entity.*;
import com.onlineexam.entity.Grade;
import com.onlineexam.entity.Organization;
import com.onlineexam.entity.User;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.exception.UnauthorizedException;
import com.onlineexam.form.CategoryForm;
import com.onlineexam.form.GradeForm;
import com.onlineexam.repository.CategoryRepository;
import com.onlineexam.repository.GradeRepository;
import com.onlineexam.repository.OrganizationRepository;
import com.onlineexam.repository.QuestionBankRepository;
import com.onlineexam.repository.QuestionRepository;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.service.CommonService;
import com.onlineexam.util.LanguageUtil;
import com.onlineexam.util.Pager;
import com.onlineexam.view.CategoryView;
import com.onlineexam.view.GradeView;
import java.awt.print.Pageable;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 *
 * @author jinu
 */
@Service
public class CommonServiceImpl implements CommonService{
    
    @Autowired
    GradeRepository gradeRepository;
    
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    private LanguageUtil languageUtil;
    
    @Autowired
    CategoryRepository categoryRepository;
    
    @Autowired
    OrganizationRepository organizationRepository;
    
    @Autowired
    QuestionBankRepository questionBankRepository;
    
    @Autowired
    QuestionRepository questionRepository;
    
    @Override
    public Pager<GradeView> listGrades(String search, Integer limit, String sort, boolean type, Integer page) {
        Pager<GradeView> gradePager = new Pager(0, 0, 0);
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Long queryCount;
        List<GradeView> gradeList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        queryCount = gradeRepository.countGradeList(Grade.Status.ACTIVE.value, search, currentUser.getOrganization().getOrganizationId());

        gradeList = StreamSupport.stream(gradeRepository
                .getGradeList(Grade.Status.ACTIVE.value, search, currentUser.getOrganization().getOrganizationId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(grade -> new GradeView(grade))
                .collect(Collectors.toList());

        gradePager = new Pager(limit, queryCount.intValue(), page);
        gradePager.setResult(gradeList);
        return gradePager;
    }
    
 @Override
    @Transactional
    public GradeView delete(Long gradeId) {
        Grade grade = gradeRepository.findByGradeId(gradeId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("grade.not.found", null, "en")));
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        byte currentUserRole = currentUser.getRole();
        if (!userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).isPresent()) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
      
        if (currentUserRole != User.Role.SUPER_ADMIN.value) {
                throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));           
        }
        
        if(questionBankRepository.countByGradeId(gradeId, currentUser.getOrganization().getOrganizationId()) > 0 || 
           questionRepository.countByGradeIdAndOrg(gradeId, currentUser.getOrganization().getOrganizationId()) > 0){
            throw new BadRequestException(languageUtil.getTranslatedText("grade.exist", null, "en"));
        } 
        
        if (!Objects.isNull(grade)) {
            grade = gradeRepository.save(grade.delete(grade));
        }
        return new GradeView(grade);
    }
    
    @Override
    public GradeView add(GradeForm form) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Organization curUserOrganization = organizationRepository.findByOrganizationId(currentUser.getOrganization().getOrganizationId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("organization.not.found", null, "en")));
        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }

        Long questionBankNameCount = gradeRepository.countByStatusAndNameAndOrganization(Grade.Status.ACTIVE.value, form.getName(), currentUser.getOrganization());
        if (questionBankNameCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("grade.name.exist", null, "en"));
        }

        return new GradeView(gradeRepository.save(new Grade(
                form.getName(),
                form.getDescription(),
                Grade.Status.ACTIVE.value,
                curUserOrganization
        )));
    }
    
    @Override
    public GradeView edit(GradeForm form, Long gradeId) {
        Grade grade = gradeRepository.findByGradeId(gradeId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("grade.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
                    throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        Long gradeNameCount = gradeRepository.countByGradeIdNotAndStatusAndName(gradeId, Grade.Status.ACTIVE.value, form.getName());
        if (gradeNameCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("grade.name.exist", null, "en"));
        }

        if (!Objects.isNull(grade)) {
            grade = gradeRepository.save(grade.update(form));
        }
        return new GradeView(grade);
    }
    
     @Override
    public Pager<CategoryView> listCategories(String search, Integer limit, String sort, boolean type, Integer page) {
        Pager<CategoryView> categoryPager = new Pager(0, 0, 0);
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Long queryCount;
        List<CategoryView> categoryList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        queryCount = categoryRepository.countCategoryList(Category.Status.ACTIVE.value, search, currentUser.getOrganization().getOrganizationId());

        categoryList = StreamSupport.stream(categoryRepository
                .getCategoryList(Category.Status.ACTIVE.value, search, currentUser.getOrganization().getOrganizationId(), PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                .map(category -> new CategoryView(category))
                .collect(Collectors.toList());

        categoryPager = new Pager(limit, queryCount.intValue(), page);
        categoryPager.setResult(categoryList);
        return categoryPager;
    }
    
 @Override
    @Transactional
    public CategoryView deleteCategory(Long categoryId) {
        Category category = categoryRepository.findByCategoryId(categoryId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        byte currentUserRole = currentUser.getRole();
        if (!userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).isPresent()) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
      
        if (currentUserRole != User.Role.SUPER_ADMIN.value) {
                throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));           
        }
        if(questionBankRepository.countByCategoryId(categoryId, currentUser.getOrganization().getOrganizationId()) > 0 || 
           questionRepository.countByCategoryIdAndOrg(categoryId, currentUser.getOrganization().getOrganizationId()) > 0){
            throw new BadRequestException(languageUtil.getTranslatedText("category.exist", null, "en"));
        }       
        
        if (!Objects.isNull(category)) {
            category = categoryRepository.save(category.delete(category));
        }
        return new CategoryView(category);
    }
    
    @Override
    public CategoryView addCategory(CategoryForm form) {
       User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
       Organization curUserOrganization = organizationRepository.findByOrganizationId(currentUser.getOrganization().getOrganizationId()).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("organization.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.EXAM_PLANNER.value != currentUser.getRole()) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }

        Long categoryNameCount = categoryRepository.countByStatusAndNameAndOrganization(Category.Status.ACTIVE.value, form.getName(), currentUser.getOrganization());
        if (categoryNameCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("category.name.exist", null, "en"));
        }

        return new CategoryView(categoryRepository.save(new Category(
                form.getName(),
                form.getDescription(),
                Category.Status.ACTIVE.value,
                curUserOrganization
        )));
    }
    
    @Override
    public CategoryView editCategory(CategoryForm form, Long categoryId) {
        Category category = categoryRepository.findByCategoryId(categoryId).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
        if (null == currentUser) {
            throw new UnauthorizedException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        if (currentUser.getRole() != User.Role.SUPER_ADMIN.value) {
                    throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        Long categoryNameCount = categoryRepository.countByCategoryIdNotAndStatusAndName(categoryId, Category.Status.ACTIVE.value, form.getName());
        if (categoryNameCount > 0) {
            throw new BadRequestException(languageUtil.getTranslatedText("category.name.exist", null, "en"));
        }

        if (!Objects.isNull(category)) {
            category = categoryRepository.save(category.update(form));
        }
        return new CategoryView(category);
    }
}
