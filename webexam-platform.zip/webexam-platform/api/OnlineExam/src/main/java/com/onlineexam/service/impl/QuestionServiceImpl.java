/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service.impl;

import com.onlineexam.entity.Category;
import com.onlineexam.entity.CategoryQuestionBanks;
import com.onlineexam.entity.Grade;
import com.onlineexam.entity.GradeQuestions;
import com.onlineexam.entity.Organization;
import com.onlineexam.entity.Question;
import com.onlineexam.entity.QuestionBank;
import com.onlineexam.entity.QuestionBankQuestions;
import com.onlineexam.entity.QuestionLevel;
import com.onlineexam.entity.QuestionType;
import com.onlineexam.entity.User;
import com.onlineexam.exception.BadRequestException;
import com.onlineexam.form.MultipleImageUploadForm;
import com.onlineexam.form.QuestionForm;
import com.onlineexam.form.QuestionShareForm;
import com.onlineexam.form.QuestionUpdateForm;
import com.onlineexam.repository.CategoryRepository;
import com.onlineexam.repository.GradeQuestionsRepository;
import com.onlineexam.repository.GradeRepository;
import com.onlineexam.repository.QuestionBankQuestionsRepository;
import com.onlineexam.repository.QuestionBankRepository;
import com.onlineexam.repository.QuestionLevelRepository;
import com.onlineexam.repository.QuestionRepository;
import com.onlineexam.repository.QuestionTypeRepository;
import com.onlineexam.repository.UserRepository;
import com.onlineexam.security.util.SecurityUtil;
import com.onlineexam.service.QuestionService;
import com.onlineexam.util.LanguageUtil;
import com.onlineexam.util.Pager;
import com.onlineexam.util.storage.Storage;
import com.onlineexam.view.BasicView;
import com.onlineexam.view.CategoryListView;
import com.onlineexam.view.GradeListDetailView;
import com.onlineexam.view.MultipleFileUploadView;
import com.onlineexam.view.QuestionEditView;
import com.onlineexam.view.QuestionLevelListView;
import com.onlineexam.view.QuestionListView;
import com.onlineexam.view.QuestionTypeListView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.logging.Level;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Libeesh
 */
@Service
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private GradeRepository gradeRepository;

    @Autowired
    private GradeQuestionsRepository gradeQuestionsRepository;

    @Autowired
    private QuestionBankQuestionsRepository questionBankQuestionsRepository;

    @Autowired
    private QuestionBankRepository questionBankRepository;

    @Autowired
    private QuestionLevelRepository questionLevelRepository;

    @Autowired
    private QuestionTypeRepository questionTypeRepository;

    private final byte[] activeStatus = {Question.Status.ACTIVE.value};

    private final byte[] questionBankActiveStatus = {QuestionBank.Status.ACTIVE.value};
    private final byte active = 1;

    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private LanguageUtil languageUtil;

    @Autowired
    Storage amazonS3Storage;

//    @Value("${aws.cloudfront.url}")
//    private String cloudfrontUrl;
    @Value("${aws.image.path.prepent}")
    private String imagePathPrepent;
    
    @Value("${image.max.file.size}")
    private String imageMaxFileSize;

    //question with same name is allowed
    @Override
    public BasicView add(QuestionForm form) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Organization organization = currentUser.getOrganization();

        if (User.Role.CANDIDATE.value == currentUser.getRole()) {
            throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }

        Category category = categoryRepository.findByCategoryIdAndStatus(form.getCategoryId(), Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));
        QuestionType questionType = questionTypeRepository.findByQuestionTypeIdAndStatus(form.getQuestionTypeId(), QuestionType.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.type.not.found", null, "en")));
        QuestionLevel questionLevel = questionLevelRepository.findByQuestionLevelIdAndStatus(form.getQuestionLevelId(), QuestionLevel.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.level.not.found", null, "en")));

        if ((form.getAnswer().trim().isEmpty()) && questionType.getQuestionTypeId().equals(QuestionType.QuestionTypes.TEXT_INPUT.value)) {
            throw new BadRequestException(languageUtil.getTranslatedText("answer.required", null, "en"));
        }
        if (!Objects.equals(QuestionType.QuestionTypes.IMAGE_TYPE.value, form.getQuestionTypeId())
                && !Objects.equals(QuestionType.QuestionTypes.TEXT_INPUT.value, form.getQuestionTypeId())) {
            form.setAnswer(validateJSONOptions(form.getOptions()));
        }
        Question question = questionRepository.save(
                new Question(form.getTitle(), form.getDescription(), organization, form.getImageUrl(), category,
                        questionType, questionLevel, currentUser, form.getPrice(), form.getPublishMarket(), form.getMark(), form.getAnswer(),
                        form.getOptions(), null, Question.SharedStatus.UNSHARED.value)
        );
        form.getQuestionBankIds().forEach(questionBankId -> {
            QuestionBank questionBank = questionBankRepository.findByQuestionBankIdAndStatusIn(questionBankId, questionBankActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.bank.not.found", null, "en")));
            questionBankQuestionsRepository.save(new QuestionBankQuestions(question, questionBank, QuestionBankQuestions.EditingStatus.SAVED.value, currentUser));
        });
        form.getGroupIds().forEach(groupId -> {
            Grade grade = gradeRepository.findByGradeIdAndStatus(groupId, Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("grade.not.found", null, "en")));
            gradeQuestionsRepository.save(new GradeQuestions(question, grade));
        });

        return new BasicView("OK");
    }

    @Override
    public QuestionEditView get(Integer questionId) {
        Question question = questionRepository.findByQuestionIdAndStatusIn(questionId, activeStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en")));
        User currentUser = userRepository.findByUserIdAndStatus(SecurityUtil.getCurrentUserId(), User.Status.ACTIVE.value).get();
//        Organization organization = currentUser.getOrganization();

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.CANDIDATE.value == currentUser.getRole() || !Objects.equals(question.getUser().getUserId(), currentUser.getUserId())) {
                if (User.Role.SUPPORT.value == currentUser.getRole() || !Objects.equals(question.getUser().getUserId(), currentUser.getUserId())) {
                    throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
                }
            }
        }
        if (!currentUser.getOrganization().getOrganizationId().equals(question.getOrganization().getOrganizationId())) {
            throw new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en"));
        }

        return new QuestionEditView(question,
                questionBankQuestionsRepository
                        .getListByQuestionId(
                                question.getQuestionId(),
                                CategoryQuestionBanks.Status.ACTIVE.value).stream()
                        .map(row -> row.getQuestionBankQuestionsId())
                        .map(a -> a.getQuestionBank())
                        .map(b -> b.getQuestionBankId()).collect(Collectors.toList()),
                gradeQuestionsRepository
                        .getListByQuestionId(
                                question.getQuestionId(),
                                GradeQuestions.Status.ACTIVE.value).stream()
                        .map(row -> row.getGradeQuestionsId())
                        .map(a -> a.getGrade())
                        .map(b -> b.getGradeId()).collect(Collectors.toList()));
    }

    @Override
    public BasicView edit(QuestionForm form, Integer questionId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
//        Organization organization = currentUser.getOrganization();

        Question question = questionRepository.findByQuestionIdAndStatusIn(questionId, activeStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.CANDIDATE.value == currentUser.getRole() || !Objects.equals(question.getUser().getUserId(), currentUser.getUserId())) {
                throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
            }
        }
        if (!currentUser.getOrganization().getOrganizationId().equals(question.getOrganization().getOrganizationId())) {
            throw new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en"));
        }

        Category category = categoryRepository.findByCategoryIdAndStatus(form.getCategoryId(), Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));
        QuestionType questionType = questionTypeRepository.findByQuestionTypeIdAndStatus(form.getQuestionTypeId(), QuestionType.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.type.not.found", null, "en")));
        QuestionLevel questionLevel = questionLevelRepository.findByQuestionLevelIdAndStatus(form.getQuestionLevelId(), QuestionLevel.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.level.not.found", null, "en")));

        if ((form.getAnswer().trim().isEmpty()) && question.getQuestionType().getQuestionTypeId().equals(QuestionType.QuestionTypes.TEXT_INPUT.value)) {
            throw new BadRequestException(languageUtil.getTranslatedText("answer.required", null, "en"));
        }
        if (!Objects.equals(QuestionType.QuestionTypes.IMAGE_TYPE.value, form.getQuestionTypeId())
                && !Objects.equals(QuestionType.QuestionTypes.TEXT_INPUT.value, form.getQuestionTypeId())) {
            form.setAnswer(validateJSONOptions(form.getOptions()));
        }
        if(("").equals(form.getImageUrl()) && question.getImageUrl() != null && (!"".equals(question.getImageUrl())) ){
            try {
                amazonS3Storage.delete(question.getImageUrl());
            } catch (IOException ex) {
                throw new BadRequestException(languageUtil.getTranslatedText("unable.to.delete.image", null, "en"));
//                java.util.logging.Logger.getLogger(QuestionServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        question = questionRepository.save(question.update(form, category, questionType, questionLevel));
        List<Question> questionTemp = new ArrayList<>();
        questionBankQuestionsRepository.deleteByQuestionId(question.getQuestionId());
        questionTemp.add(question);//to remvove error: non final varibale inside lambda is not accessible
        form.getQuestionBankIds().forEach(questionBankId -> {
            QuestionBank questionBank = questionBankRepository.findByQuestionBankIdAndStatusIn(questionBankId, questionBankActiveStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.bank.not.found", null, "en")));
            questionBankQuestionsRepository.save(new QuestionBankQuestions(questionTemp.get(0), questionBank, QuestionBankQuestions.EditingStatus.SAVED.value, currentUser));
        });
        gradeQuestionsRepository.deleteByQuestionId(question.getQuestionId());
        form.getGroupIds().forEach(groupId -> {
            Grade grade = gradeRepository.findByGradeIdAndStatus(groupId, Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("grade.not.found", null, "en")));
            gradeQuestionsRepository.save(new GradeQuestions(questionTemp.get(0), grade));
        });

        return new BasicView("OK");
    }

    private String validateJSONOptions(String optionDetails) {
        String correctAnswerFromOptions = "";
        try {
            JSONObject optionDetail = new JSONObject(optionDetails);
            Long questionTypeId = optionDetail.getLong("questionTypeId");
            JSONArray options = optionDetail.getJSONArray("options");
            if (options.length() <= 1) {
                throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
            } else {
                int multipleAnswerCount = 0;
                int singleAnswerCount = 0;
                for (int i = 0; i < options.length(); i++) {
                    Integer id = options.getJSONObject(i).getInt("id");
                    if (id == 0) {
                        throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
                    }
                    Boolean isAnswer = options.getJSONObject(i).getBoolean("isAnswer");
                    if (Objects.equals(QuestionType.QuestionTypes.MULTIPLE_ANSWER.value, questionTypeId)
                            || Objects.equals(QuestionType.QuestionTypes.MULTIPLE_ANSWER_IMAGE.value, questionTypeId)) {
                        if (isAnswer) {
                            correctAnswerFromOptions = "".equals(correctAnswerFromOptions) ?  id.toString() : correctAnswerFromOptions + "," + id.toString();
                            multipleAnswerCount++;
                        }
                    } else if (Objects.equals(QuestionType.QuestionTypes.SINGLE_ANSWER.value, questionTypeId)
                            || Objects.equals(QuestionType.QuestionTypes.SINGLE_ANSWER_IMAGE.value, questionTypeId)) {
                        if (isAnswer) {
                            correctAnswerFromOptions = id.toString();
                            singleAnswerCount++;
                        }
                    }
                    if (Objects.equals(QuestionType.QuestionTypes.MULTIPLE_ANSWER.value, questionTypeId)
                            || Objects.equals(QuestionType.QuestionTypes.SINGLE_ANSWER.value, questionTypeId)) {
                        String value = options.getJSONObject(i).getString("value");
                        if ("".equals(value)) {
                            throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
                        }
                    } else if (Objects.equals(QuestionType.QuestionTypes.MULTIPLE_ANSWER_IMAGE.value, questionTypeId)
                            || Objects.equals(QuestionType.QuestionTypes.SINGLE_ANSWER_IMAGE.value, questionTypeId)) {
                        String src = options.getJSONObject(i).getString("src");
                        if ("".equals(src)) {
                            throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
                        }
                    }
                }
                if (Objects.equals(QuestionType.QuestionTypes.MULTIPLE_ANSWER.value, questionTypeId)
                        || Objects.equals(QuestionType.QuestionTypes.MULTIPLE_ANSWER_IMAGE.value, questionTypeId)) {
                    if (multipleAnswerCount <= 0 && multipleAnswerCount >= options.length()) {
                        throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
                    }
                } else if (Objects.equals(QuestionType.QuestionTypes.SINGLE_ANSWER.value, questionTypeId)
                        || Objects.equals(QuestionType.QuestionTypes.SINGLE_ANSWER_IMAGE.value, questionTypeId)) {
                    if (singleAnswerCount != 1) {
                        throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
                    }
                }
            }
        } catch (JSONException ex) {
            throw new BadRequestException(languageUtil.getTranslatedText("invalid.options", null, "en"));
        }
        return correctAnswerFromOptions;
    }

    @Transactional
    @Override
    public BasicView delete(Integer questionId) {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
//        Organization organization = currentUser.getOrganization();

        Question question = questionRepository.findByQuestionIdAndStatusIn(questionId, activeStatus).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en")));

        if (User.Role.SUPER_ADMIN.value != currentUser.getRole()) {
            if (User.Role.CANDIDATE.value == currentUser.getRole() || !Objects.equals(question.getUser().getUserId(), currentUser.getUserId())) {
                if (User.Role.SUPPORT.value == currentUser.getRole() || !Objects.equals(question.getUser().getUserId(), currentUser.getUserId())) {
                    throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
                }
            }
        }
        if (!currentUser.getOrganization().getOrganizationId().equals(question.getOrganization().getOrganizationId())) {
            throw new BadRequestException(languageUtil.getTranslatedText("question.not.found", null, "en"));
        }

        questionBankQuestionsRepository.deleteByQuestionId(question.getQuestionId());
        
        if (!Objects.isNull(question)) {
            question = questionRepository.save(question.delete(question));
        }
        return new BasicView("OK");
    }

    @Override
    public MultipleFileUploadView imageUpload(MultipleImageUploadForm uploadForm, int type) {
//        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
//        if (User.Role.CANDIDATE.value == currentUser.getRole()) {
//            throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
//        }
        List<String> imageUrls = new ArrayList<>();
        uploadForm.getFile().forEach(file -> {
            if (!validateImageFileName(file)) {
                LOGGER.error("Invalid file");
                throw new BadRequestException(languageUtil.getTranslatedText("invalid.file", null, "en"));
            }
            if (file.getSize() > Long.valueOf(imageMaxFileSize)) {
                LOGGER.error("Large file");
                throw new BadRequestException(languageUtil.getTranslatedText("invalid.file.size", null, "en"));
            }
            String imgPath = "question/";
            try {
                String orgName = file.getOriginalFilename();
                String randStr = getRandomStr();
                if (null != orgName) {
                    //orgName = orgName.replaceAll("\\s","");
                    randStr = "_" + randStr + "." + FilenameUtils.getExtension(orgName);
                }
                Storage.Info imageInfo = amazonS3Storage.save(imgPath + new Date().getTime() + randStr, file, true);
                String imagePath = imageInfo.path;
                String imageUrl = imagePath.substring(1);
                System.out.println("sssssssssssss");
                System.out.println(imageUrl);
                imageUrls.add(imagePathPrepent + imageUrl);
            } catch (IOException ex) {
                LOGGER.error("error  " + ex);
            }
        });

        return new MultipleFileUploadView("success", imageUrls);
    }

    private boolean validateImageFileName(MultipartFile file) {
        LOGGER.info("In logo image file name validation....");
        System.out.println(file.isEmpty());
        Boolean isValid = false;
        String fileName = file.getOriginalFilename();
        if (
                (fileName.endsWith(".png")) || 
                (fileName.endsWith(".PNG")) || 
                (fileName.endsWith(".jpeg")) || 
                (fileName.endsWith(".JPEG")) || 
                (fileName.endsWith(".jpg")) || 
                (fileName.endsWith(".JPG")) || 
                (fileName.endsWith(".gif")) ||
                (fileName.endsWith(".GIF"))
                ) {
            LOGGER.info("In logo image file are valid");
            isValid = true;
        }
        return isValid;
    }

    private static String getRandomStr() {
        String zeros = "000000";
        Random rnd = new Random();
        String s = Integer.toString(rnd.nextInt(0X1000000), 16);
        s = zeros.substring(s.length()) + s;
        return s;
    }

    @Override
    public Pager<QuestionListView> list(String search, Integer limit, String sort,
            boolean type, Integer page, Integer categoryId, Integer groupId, Integer levelId, Long questionBankId) {
        Pager<QuestionListView> questionPager;
        Long queryCount;
        List<QuestionListView> questionList;
        if (StringUtils.isEmpty(search)) {
            search = "";
        }
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        if (questionBankId == 0) {
            if (currentUser.getRole() == User.Role.SUPER_ADMIN.value) {
                queryCount = questionRepository.countQuestionListByAdmin(activeStatus, currentUser.getOrganization().getOrganizationId(), search,
                        categoryId, groupId, levelId);
                if (groupId == 0) {
                    questionList = StreamSupport.stream(questionRepository
                            .getQuestionListWithOutGradeByAdmin(activeStatus, currentUser.getOrganization().getOrganizationId(), search, categoryId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionListView(question))
                            .collect(Collectors.toList());
                } else {
                    questionList = StreamSupport.stream(questionRepository
                            .getQuestionListWithGradeByAdmin(activeStatus, currentUser.getOrganization().getOrganizationId(), search, categoryId, groupId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionListView(question))
                            .collect(Collectors.toList());
                }
            } else {
                queryCount = questionRepository.countQuestionListByUser(activeStatus, currentUser.getUserId(), search,
                        categoryId, groupId, levelId);
                if (groupId == 0) {
                    questionList = StreamSupport.stream(questionRepository
                            .getQuestionListWithOutGradeByUser(activeStatus, currentUser.getUserId(), search, categoryId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionListView(question))
                            .collect(Collectors.toList());
                } else {
                    questionList = StreamSupport.stream(questionRepository
                            .getQuestionListWithGradeByUser(activeStatus, currentUser.getUserId(), search, categoryId, groupId, levelId,
                                    PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                            .map(question -> new QuestionListView(question))
                            .collect(Collectors.toList());
                }
            }

        } else {
            queryCount = questionRepository.countQBQuestionListByUser(activeStatus, search,
                    categoryId, groupId, levelId, questionBankId);
            if (groupId == 0) {
                questionList = StreamSupport.stream(questionRepository
                        .getQBQuestionListWithOutGradeByUser(activeStatus, search, categoryId, levelId, questionBankId,
                                PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                        .map(question -> new QuestionListView(question))
                        .collect(Collectors.toList());
            } else {
                questionList = StreamSupport.stream(questionRepository
                        .getQBQuestionListWithGradeByUser(activeStatus, search, categoryId, groupId, levelId, questionBankId,
                                PageRequest.of(page - 1, limit, (type == true) ? Sort.Direction.DESC : Sort.Direction.ASC, sort)).spliterator(), false)
                        .map(question -> new QuestionListView(question))
                        .collect(Collectors.toList());
            }
        }
        questionPager = new Pager(limit, queryCount.intValue(), page);
        questionPager.setResult(questionList);
        return questionPager;
    }

    @Override
    public List<CategoryListView> listCategory() {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        return categoryRepository.findAllByStatusAndOrganization(active, currentUser.getOrganization()).stream()
                .map(category -> new CategoryListView(category))
                .collect(Collectors.toList());
    }

    @Override
    public List<GradeListDetailView> listGrade() {
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        return gradeRepository.findAllByStatusAndOrganization(active, currentUser.getOrganization()).stream()
                .map(grade -> new GradeListDetailView(grade))
                .collect(Collectors.toList());
    }

    @Override
    public List<QuestionLevelListView> listQuestionLevel() {
        return questionLevelRepository.findAllByStatus(active).stream()
                .map(questionLevel -> new QuestionLevelListView(questionLevel))
                .collect(Collectors.toList());
    }

    @Override
    public List<QuestionTypeListView> listQuestionType() {
        return questionTypeRepository.findAllByStatus(active).stream()
                .map(questionType -> new QuestionTypeListView(questionType))
                .collect(Collectors.toList());
    }

    @Override
    public BasicView shareQuestion(QuestionShareForm form) {
        System.out.println(form);
        User currentUser = userRepository.findByUserId(SecurityUtil.getCurrentUserId()).get();
        Organization organization = currentUser.getOrganization();

        if (User.Role.SUPPORT.value != currentUser.getRole()) {
            throw new BadRequestException(languageUtil.getTranslatedText("permission.denied", null, "en"));
        }
        Optional<Question> question = questionRepository.findByQuestionId(form.getQuestionId());

        Category category = categoryRepository.findByCategoryIdAndStatus(question.get().getCategory().getCategoryId(), Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("category.not.found", null, "en")));
        QuestionType questionType = questionTypeRepository.findByQuestionTypeIdAndStatus(question.get().getQuestionType().getQuestionTypeId(), QuestionType.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.type.not.found", null, "en")));
        QuestionLevel questionLevel = questionLevelRepository.findByQuestionLevelIdAndStatus(question.get().getQuestionLevel().getQuestionLevelId(), QuestionLevel.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("question.level.not.found", null, "en")));

        form.getUserIds().forEach(userId -> {
            Optional<User> user = userRepository.findByUserId(userId);
            Question questionObj = questionRepository.save(
                    new Question(question.get().getTitle(), question.get().getDescription(), organization, question.get().getImageUrl(), category,
                            questionType, questionLevel, user.get(), question.get().getPrice(), question.get().getPublishMarket(), question.get().getMark(), question.get().getAnswer(),
                            question.get().getOptions(), currentUser, Question.SharedStatus.SHARED.value));

            List<GradeQuestions> findAllByQuestionId = gradeQuestionsRepository.findAllByQuestionId(question.get().getQuestionId());
            findAllByQuestionId.forEach(gradeQuestion -> {
                Grade grade = gradeRepository.findByGradeIdAndStatus(gradeQuestion.getGradeQuestionsId().getGrade().getGradeId(), Category.Status.ACTIVE.value).orElseThrow(() -> new BadRequestException(languageUtil.getTranslatedText("grade.not.found", null, "en")));
                gradeQuestionsRepository.save(new GradeQuestions(questionObj, grade));
            });

        });

        return new BasicView("OK");
    }

}
