/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jinu
 */
@Entity
public class ScheduleAssignCandidate {
    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }

    public static enum RegisterStatus {
        REGISTERED((byte) 1),
        NOTREGISTERED((byte) 0);

        public final byte value;

        private RegisterStatus(byte value){
            this.value = value;
        }
    }

    @Id
    @Column(name="schedule_assign_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long scheduleAssignId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "schedule_id")
    private Schedule schedule;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_id")
    private Exam exam;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;
    private byte registerStatus;
    private byte status;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    public Long getScheduleAssignId() {
        return scheduleAssignId;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public Exam getExam() {
        return exam;
    }

    public User getUser() {
        return user;
    }

    public byte getRegisterStatus() {
        return registerStatus;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setScheduleAssignId(Long scheduleAssignId) {
        this.scheduleAssignId = scheduleAssignId;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setRegisterStatus(byte registerStatus) {
        this.registerStatus = registerStatus;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public ScheduleAssignCandidate(){

    }

    public ScheduleAssignCandidate(User user,Exam exam, Schedule schedule){
        this.schedule = schedule;
        this.exam = exam;
        this.user = user;
        this.registerStatus = ScheduleAssignCandidate.RegisterStatus.NOTREGISTERED.value;
        this.status =ScheduleAssignCandidate.Status.ACTIVE.value;
        this.createDate = new Date();
        this.updateDate = new Date();

    }
}