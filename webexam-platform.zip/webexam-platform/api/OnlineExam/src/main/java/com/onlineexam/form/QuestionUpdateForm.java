/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.form;

import java.util.List;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sanal
 */
public class QuestionUpdateForm {
    @NotBlank
    @Size(max = 4000, message = "{question.title.max.size}")
    private String title;
    private String description;
    private String imageUrl;
    @NotNull
    private Long categoryId;
    @NotNull
    private List<Long> groupIds;
//    @NotNull
    private List<Long> questionBankIds;
    @NotNull
    private Long questionLevelId;
    @NotNull
    @Max(value = 1000, message = "{mark.max.size}")
    @Min(value = 1, message = "{mark.min.size}")
    private Integer mark;
    private String answer;
    @NotNull
    private Integer price;
    @NotNull
    private byte publishMarket;
    @NotBlank
    private String options;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public List<Long> getGroupIds() {
        return groupIds;
    }

    public void setGroupIds(List<Long> groupIds) {
        this.groupIds = groupIds;
    }

    public List<Long> getQuestionBankIds() {
        return questionBankIds;
    }

    public void setQuestionBankIds(List<Long> questionBankIds) {
        this.questionBankIds = questionBankIds;
    }

    public Long getQuestionLevelId() {
        return questionLevelId;
    }

    public void setQuestionLevelId(Long questionLevelId) {
        this.questionLevelId = questionLevelId;
    }

    public Integer getMark() {
        return mark;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public byte getPublishMarket() {
        return publishMarket;
    }

    public void setPublishMarket(byte publishMarket) {
        this.publishMarket = publishMarket;
    }

    public String getOptions() {
        return options;
    }

    public void setOptions(String options) {
        this.options = options;
    }
    
}
