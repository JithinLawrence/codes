/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Category;
import com.onlineexam.entity.ExamQuestion;
import java.util.List;

/**
 *
 * @author simon
 */
public class CategoryDashboardListView {
    
    
    private  Long categoryId;
    private  String name;
    private  Integer totalMarks;
    private  Long questionCount;
    private List<QuestionDashBoardView> qlist; 

    public CategoryDashboardListView(Long categoryId, String name, Integer  totalMarks, Long questionCount, List<QuestionDashBoardView> qlist) {
        this.categoryId = categoryId;
        this.name = name;
        this.totalMarks = totalMarks;
        this.questionCount = questionCount;
        this.qlist = qlist;
    }
    
    public CategoryDashboardListView(Category category, Integer totalMarks, Long questionCount,  List<QuestionDashBoardView> qlist) {
        this.categoryId = category.getCategoryId();
        this.name = category.getName();
        this.totalMarks = totalMarks;
        this.questionCount = questionCount;
        this.qlist = qlist;
    }
   
    
    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getTotalMarks() {
        return totalMarks;
    }

    public void setTotalMarks(Integer totalMarks) {
        this.totalMarks = totalMarks;
    }

    public Long getQuestionCount() {
        return questionCount;
    }

    public void setQuestionCount(Long questionCount) {
        this.questionCount = questionCount;
    }
    
    public List<QuestionDashBoardView> getQlist() {
        return qlist;
    }

    public void setQlist(List<QuestionDashBoardView> qlist) {
        this.qlist = qlist;
    }
}
