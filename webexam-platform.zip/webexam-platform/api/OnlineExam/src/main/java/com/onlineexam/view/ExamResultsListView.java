/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.ExamResult;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author simon
 */
public class ExamResultsListView {

    private long examResultId;
    private String name;
    private String description;
    private int mark;
    private byte status;
    private long examId;
    private long scheduleId;
    @Json.DateTimeFormat
    private Date startTime;

    

    public ExamResultsListView(ExamResult exam) {
        this.examResultId = exam.getExamResultId();
        this.examId = exam.getExam().getExamId();
        this.scheduleId = exam.getSchedule().getScheduleId();
        this.name = exam.getExam().getName();
        this.description = exam.getExam().getDescription();
        this.mark = exam.getMark();
        this.startTime = exam.getSchedule().getStartTime();
        this.status=exam.getStatus();
    }

    public ExamResultsListView(long examResultId, String name, String description, int mark, byte status, Date startTime,long examId, long scheduleId) {
        this.examResultId = examResultId;
        this.name = name;
        this.description = description;
        this.mark = mark;
        this.status = status;
        this.startTime = startTime;
        this.examId=examId;
        this.scheduleId = scheduleId;
    }

    public long getExamResultId() {
        return examResultId;
    }

    public void setExamResultId(long examResultId) {
        this.examResultId = examResultId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public long getExamId() {
        return examId;
    }

    public void setExamId(long examId) {
        this.examId = examId;
    }

    public long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(long scheduleId) {
        this.scheduleId = scheduleId;
    }
        
    
}
