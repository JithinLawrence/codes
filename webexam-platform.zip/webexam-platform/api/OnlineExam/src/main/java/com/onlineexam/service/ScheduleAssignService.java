/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.service;

import com.onlineexam.util.Pager;
import com.onlineexam.view.ExamAssignListView;

/**
 *
 * @author simon
 */
public interface ScheduleAssignService {

    Pager<ExamAssignListView> getUpcommingList(String search, Integer limit, String sort, boolean type, Integer page, long userId);

    Pager<ExamAssignListView> getElapsedList(String search, Integer limit, String sort, boolean type, Integer page, long userId);

    void registerExam(long scheduleAssignId);
    
    void deleteAssignedUser(Long scheduleId, Long userId);
}
