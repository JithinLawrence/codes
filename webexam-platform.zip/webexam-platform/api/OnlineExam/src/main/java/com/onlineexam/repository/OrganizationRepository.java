/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Organization;
import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.Repository;

/**
 *
 * @author jinu
 */
public interface OrganizationRepository extends Repository<Organization, Long>{
    
    Optional<Organization> findByOrganizationId(Long organizationId);
    
    List<Organization> findAll() ;
    
}
