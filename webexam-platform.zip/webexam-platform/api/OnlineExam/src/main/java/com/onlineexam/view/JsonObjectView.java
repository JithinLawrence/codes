/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

/**
 *
 * @author jinu
 */
public class JsonObjectView {
    private  boolean isAnswer;
    private Integer id;
    private String value;
    
    public JsonObjectView(boolean isAnswer, Integer id, String value){
        this.isAnswer = isAnswer;
        this.id = id;
        this.value = value;
    }

    public boolean isIsAnswer() {
        return isAnswer;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }
    
}
