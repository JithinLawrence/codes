/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.exception;

import static org.springframework.http.HttpStatus.NOT_ACCEPTABLE;
import org.springframework.web.server.ResponseStatusException;

/**
 *
 * @author sanal
 */
public class NotAcceptableException extends ResponseStatusException {

    public NotAcceptableException() {
        super(NOT_ACCEPTABLE);
    }

    public NotAcceptableException(String reason) {
        super(NOT_ACCEPTABLE, reason);
    }

    public NotAcceptableException(String reason, Throwable cause) {
        super(NOT_ACCEPTABLE, reason, cause);
    }
}
