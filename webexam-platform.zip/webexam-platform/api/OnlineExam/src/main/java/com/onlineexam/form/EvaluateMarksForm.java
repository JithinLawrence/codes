package com.onlineexam.form;

import javax.validation.constraints.NotNull;
import java.util.Map;

public class EvaluateMarksForm {
    @NotNull
    private Map<Integer,Integer> marks;

    public Map<Integer, Integer> getMarks() {
        return marks;
    }

    public void setMarks(Map<Integer, Integer> marks) {
        this.marks = marks;
    }
}
