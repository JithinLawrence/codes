package com.onlineexam.view;

import com.onlineexam.entity.Exam;
import com.onlineexam.entity.Schedule;

import java.util.Date;
import com.onlineexam.json.Json;

/**
 * @author ramshad
 */

public class ExamScheduleView {

    private Long scheduleId;
    private Long examId;
    private byte status;
    private byte type;
    @Json.DateTimeFormat
    private Date startTime;
    @Json.DateTimeFormat
    private Date endTime;
    @Json.DateTimeFormat
    private Date createDate;
    @Json.DateTimeFormat
    private Date updateDate;
    private String examName;
    private byte examType;
    private Long createdBy;

    public ExamScheduleView(Schedule schedule ){
        this.createDate = schedule.getCreateDate();
        this.endTime = schedule.getEndTime();
        this.scheduleId = schedule.getScheduleId();
        this.status = schedule.getStatus();
        this.updateDate = schedule.getUpdateDate();
        this.startTime = schedule.getStartTime();
        this.examId = schedule.getExam().getExamId();
        this.examName = schedule.getExam().getName();
        this.examType = schedule.getExam().getType();
        this.createdBy = schedule.getUser().getUserId();
    }

    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Long getExamId() {
        return examId;
    }

    public void setExamId(Long examId) {
        this.examId = examId;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }

    public byte getExamType() {
        return examType;
    }

    public void setExamType(byte examType) {
        this.examType = examType;
    }

    public Long getCreatedBy() {
        return createdBy;
    }
}