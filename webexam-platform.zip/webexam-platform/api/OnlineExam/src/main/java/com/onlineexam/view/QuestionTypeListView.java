/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.QuestionType;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class QuestionTypeListView {
    private final Long questionTypeId;
    private final String name;
    private final String description;
    private final byte status;
    @Json.DateFormat
    private final Date createDate;
    @Json.DateFormat
    private final Date updateDate;

    public QuestionTypeListView(QuestionType questionType) {
        this.questionTypeId = questionType.getQuestionTypeId();
        this.name = questionType.getName();
        this.description = questionType.getDescription();
        this.status = questionType.getStatus();
        this.createDate = questionType.getCreateDate();
        this.updateDate = questionType.getUpdateDate();
    }   

    public Long getQuestionTypeId() {
        return questionTypeId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
    
    
}
