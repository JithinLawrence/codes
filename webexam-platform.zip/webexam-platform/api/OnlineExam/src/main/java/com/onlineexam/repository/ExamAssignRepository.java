/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.ScheduleAssignCandidate;
import javax.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
/**
 *
 * @author simon
 */
public interface ExamAssignRepository extends Repository<ScheduleAssignCandidate, Long>{

    
    @Query(value = "SELECT COUNT(*) FROM schedule_assign_candidate u JOIN exam e ON u.exam_id = e.exam_id JOIN schedule s on u.schedule_id = s.schedule_id WHERE u.status in ?1 AND u.user_id = ?3 AND (e.name like %?2% OR e.description like %?2%) AND s.start_time >= NOW()", nativeQuery = true)
    Long countExamUpcommingAssignList(byte[] status, String search, long userId);
    

    @Query(value = "SELECT * FROM schedule_assign_candidate u JOIN exam e ON u.exam_id = e.exam_id JOIN schedule s on u.schedule_id = s.schedule_id WHERE u.status in ?1 AND u.user_id = ?3 AND (e.name like %?2% OR e.description like %?2%) AND s.end_time >= NOW()", nativeQuery = true)
    Page<ScheduleAssignCandidate> getExamUpcommingAssignList(byte[] status, String search, long userId, Pageable page);
    
    @Query(value = "SELECT COUNT(*) FROM schedule_assign_candidate u JOIN exam e ON u.exam_id = e.exam_id JOIN schedule s on u.schedule_id = s.schedule_id WHERE u.status in ?1 AND u.user_id = ?3 AND (e.name like %?2% OR e.description like %?2%) AND s.start_time >= NOW()", nativeQuery = true)
    Long countExamElapsedAssignList(byte[] status, String search, long userId);
    

    @Query(value = "SELECT u.* FROM schedule_assign_candidate u JOIN exam e ON u.exam_id = e.exam_id JOIN schedule s on u.schedule_id = s.schedule_id WHERE u.status in ?1 AND u.user_id = ?3 AND (e.name like %?2% OR e.description like %?2%) AND s.start_time >= NOW()", nativeQuery = true)
    Page<ScheduleAssignCandidate> getExamElapsedAssignList(byte[] status, String search, long userId, Pageable page);
    
    @Transactional
    @Modifying
    @Query(value = "UPDATE schedule_assign_candidate SET register_status = 1 where schedule_assign_id = ?1", nativeQuery = true)
    void setStatusRegistered (long scheduleAssignId);
}
