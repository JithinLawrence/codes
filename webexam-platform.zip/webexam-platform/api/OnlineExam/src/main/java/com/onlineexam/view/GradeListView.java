/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

/**
 *
 * @author simon
 */
public class GradeListView {
    private long gradeId;
    private String gradeName; 

    public GradeListView(long gradeId, String gradeName) {
        this.gradeId = gradeId;
        this.gradeName = gradeName;
    }

    public String getGradeName() {
        return gradeName;
    }
    

    public long getGradeId() {
        return gradeId;
    }

    

}
