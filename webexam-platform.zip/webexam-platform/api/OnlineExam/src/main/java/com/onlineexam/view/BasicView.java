/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

/**
 *
 * @author jyothis
 */
public class BasicView {

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BasicView() {
    }

    public BasicView(String status) {
        this.status = status;
    }

}
