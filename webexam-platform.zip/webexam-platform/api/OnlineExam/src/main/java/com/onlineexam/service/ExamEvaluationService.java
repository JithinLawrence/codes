package com.onlineexam.service;

import com.onlineexam.form.ExamEvaluateForm;
import com.onlineexam.view.ExamEvaluationView;
import com.onlineexam.view.ExamResultView;

import java.util.HashMap;
import java.util.List;

public interface ExamEvaluationService {

    HashMap<String, String> getExamResult(Long examId, Long userId, Long scheduleId);
    List<ExamEvaluationView> getExamQuestionEvaluation(Long examId, Long userId);
    public ExamResultView edit(ExamEvaluateForm form, Long examId, Long userId);
}
