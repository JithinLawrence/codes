/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.entity;

import java.util.Date;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author sanal
 */
@Entity
public class QuestionBankQuestions {

    public static enum Status {
        INACTIVE((byte) 0),
        ACTIVE((byte) 1);

        public final byte value;

        private Status(byte value) {
            this.value = value;
        }
    }
    
    public static enum EditingStatus {
        TEMP_SAVE((byte) 0),
        SAVED((byte) 1);

        public final byte value;

        private EditingStatus(byte value) {
            this.value = value;
        }
    }
     
    @EmbeddedId
    private QuestionBankQuestionsId questionBankQuestionsId;
    private byte editingStatus;
    private byte status;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private User user;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;

    public QuestionBankQuestions() {
    }

    public QuestionBankQuestions(Question question, QuestionBank questionBank, byte editingStatus, User user) {
        this.questionBankQuestionsId = new QuestionBankQuestionsId(question, questionBank);
        this.editingStatus = editingStatus;
        this.status = Status.ACTIVE.value;
        this.createDate = new Date();
        this.user = user;
    }
    
    public QuestionBankQuestions delete(QuestionBankQuestions questionBankQuestions){
        questionBankQuestions.setStatus(Status.INACTIVE.value);
        return this;
    }    

    public QuestionBankQuestionsId getQuestionBankQuestionsId() {
        return questionBankQuestionsId;
    }

    public void setQuestionBankQuestionsId(QuestionBankQuestionsId questionBankQuestionsId) {
        this.questionBankQuestionsId = questionBankQuestionsId;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public byte getEditingStatus() {
        return editingStatus;
    }

    public void setEditingStatus(byte editingStatus) {
        this.editingStatus = editingStatus;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }  
}
