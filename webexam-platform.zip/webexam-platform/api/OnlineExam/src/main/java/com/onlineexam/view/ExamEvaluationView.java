/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import java.util.List;

/**
 *
 * @author jinu
 */
public class ExamEvaluationView {
    private final Long examResultId;
    private final Integer questionId;
    private final Long typeId;
    private final String answer;
    private final String correctAnswer;
    private final Integer mark;
    private final List<JsonObjectView> options;
    private final String title;
    private final Integer newMark;

    public ExamEvaluationView(Long examResultId, Integer questionId, Long typeId, String answer, String correctAnswer, Integer mark, List<JsonObjectView> options, String title, Integer newMark){
        this.examResultId = examResultId;
        this.questionId = questionId;
        this.typeId = typeId;
        this.answer = answer;
        this.correctAnswer = correctAnswer;
        this.mark = mark;
        this.options = options;
        this.title = title;
        this.newMark = newMark;
    }


    public Integer getNewMark() {
        return newMark;
    }

    public Long getExamResultId() {
        return examResultId;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public Long getTypeId() {
        return typeId;
    }

    public String getAnswer() {
        return answer;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public Integer getMark() {
        return mark;
    }

    public List<JsonObjectView> getOptions() {
        return options;
    }

    public String getTitle() {
        return title;
    }
   
}
