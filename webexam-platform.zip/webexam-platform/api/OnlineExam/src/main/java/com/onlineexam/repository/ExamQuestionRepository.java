/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.Category;
import com.onlineexam.entity.Exam;
import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.Question;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

/**
 *
 * @author sanal
 */
public interface ExamQuestionRepository extends Repository<ExamQuestion, Integer> {

    Optional<ExamQuestion> findByExamQuestionId(Integer examQuestionId);

    Optional<ExamQuestion> findByExamQuestionIdAndEditingStatusIn(Integer examQuestionId, byte[] editingStatus);

    Optional<ExamQuestion> findByExamAndCategoryAndExamQuestionIdAndEditingStatusIn(Exam exam, Category category, Integer examQuestionId, byte[] editingStatus);

    Optional<ExamQuestion> findByExamAndExamQuestionIdAndEditingStatusIn(Exam exam, Integer examQuestionId, byte[] editingStatus);

    Optional<ExamQuestion> findByExamQuestionIdAndStatusInAndEditingStatusIn(Integer examQuestionId, byte[] status, byte[] editingStatus);

    Optional<ExamQuestion> findByQuestionAndExamAndStatusIn(Question question, Exam exam, byte[] status);

    Optional<ExamQuestion> findByQuestionAndExamAndStatusInAndEditingStatusIn(Question question, Exam exam, byte[] status, byte[] editingStatus);

    List<ExamQuestion> findByExamAndCategoryAndEditingStatusInAndTitleLike(Exam exam, Category category, byte[] editingStatus, String title);
    
    List<ExamQuestion> findByExamAndEditingStatusInAndTitleLike(Exam exam, byte[] editingStatus, String title);

    List<ExamQuestion> findByExamAndEditingStatusIn(Exam exam, byte[] editingStatus);

    List<ExamQuestion> findByExamAndStatusAndEditingStatusIn(Exam exam, byte status, byte[] editingStatus);

    List<ExamQuestion> findByExamAndEditingStatusInOrderByCategoryOrderAscQuestionOrderAsc(Exam exam, byte[] editingStatus);

    List<ExamQuestion> findByExamAndStatusInAndEditingStatusInOrderByCategoryOrderAscQuestionOrderAsc(Exam exam, byte[] status, byte[] editingStatus);

    List<ExamQuestion> findByExamAndStatusInOrderByQuestionOrderAsc(Exam exam, byte[] status);

    Optional<ExamQuestion> findByExamAndCategoryAndQuestionOrder(Exam exam, Category category, Integer questionOrder);
    
    Optional<ExamQuestion> findByExamAndQuestionOrder(Exam exam, Integer questionOrder);
    
    Optional<ExamQuestion> findByExamAndCategoryAndQuestionOrderAndEditingStatusNot(Exam exam, Category category, Integer questionOrder, byte editingStatus);

    List<ExamQuestion> findByExamAndCategoryAndStatusInAndEditingStatusIn(Exam exam, Category category, byte[] status, byte[] editingStatus);

    List<ExamQuestion> findByExamAndStatusIn(Exam exam, byte[] status);

    List<ExamQuestion> findByExamAndCategoryAndEditingStatusIn(Exam exam, Category category, byte[] editingStatus);

    List<ExamQuestion> findByExamAndCategory(Exam exam, Category category);

    Long countByExamAndCategoryAndStatusInAndEditingStatusIn(Exam exam, Category category, byte[] status, byte[] editingStatus);

    Long countByExamAndCategoryAndEditingStatusIn(Exam exam, Category category, byte[] editingStatus);

    Long countByExamAndCategory(Exam exam, Category category);
    
    Long countByExamAndEditingStatusIn(Exam exam, byte[] editingStatus);
    
    Long countByExam(Exam exam);

    ExamQuestion save(ExamQuestion examQuestion);

    Long countByStatusAndEditingStatusAndExam(byte status, byte editingStatus, Exam exam);
    
    Long countByStatusAndExam(byte status, Exam exam);

    @Transactional
    @Modifying
    @Query(value = "delete from exam_question where exam_id = ?1 and status = ?2 and editing_status = ?3", nativeQuery = true)
    void deleteByExamIdAndExamQuestionInactiveStatus(Long examId, byte inactiveStatus, byte tempSaveStatus);

    @Transactional
    @Modifying
    @Query(value = "update exam_question set status = ?1 where exam_id = ?2 and status = ?3 and editing_status = ?4 ", nativeQuery = true)
    void deleteByExamIdAndExamQuestionActiveStatusAndEditingStatus(byte inactiveStatus, Long examId, byte activeStatus, byte editingStatus);

    @Transactional
    @Modifying
    @Query(value = "update exam_question set editing_status = ?1 where exam_id = ?2 and status = ?3 and editing_status in ?4 ", nativeQuery = true)
    void revertByExamId(byte savedEditingStatus, Long examId, byte activeStatus, byte[] updateAndDeleteeditingStatuses);

    @Transactional
    @Modifying
    @Query(value = "delete from exam_question where exam_id = ?1 and category_id = ?2 ", nativeQuery = true)
    void deleteByExamIdAndCategoryId(Long examId, Long categoryId);

    @Transactional
    @Modifying
    @Query(value = "delete from exam_question where exam_question_id = ?1 and exam_id = ?2 and category_id = ?3 ", nativeQuery = true)
    void deleteByExamQuestionIdAndExamIdAndCategoryId(Integer examQuestionId, Long examId, Long categoryId);

    @Transactional
    @Modifying
    @Query(value = "delete from exam_question where exam_question_id = ?1 and exam_id = ?2 ", nativeQuery = true)
    void deleteByExamQuestionIdAndExamId(Integer examQuestionId, Long examId);

    List<ExamQuestion> findByExamOrderByQuestionOrder(Exam exam);
    
     @Query(value = "SELECT sum(mark) FROM online_exam.exam_question WHERE exam_id = ?1 AND category_id = ?2 AND editing_status = 1;", nativeQuery = true)
    Integer totalMarksByExamIdAndCategoryId(Long examId, Long categoryId);
    
     @Query(value = "SELECT sum(mark) FROM online_exam.exam_question WHERE exam_id = ?1 AND category_id = ?2 AND (editing_status = ?3 OR editing_status = ?4);", nativeQuery = true)
    Integer totalMarksByExamIdAndCategoryIdAndEditingStatusIn(Long examId, Long categoryId, byte editingStatusSaved, byte editingStatusTempSave);

}