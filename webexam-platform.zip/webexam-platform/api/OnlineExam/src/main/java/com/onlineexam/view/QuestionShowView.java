/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Category;
import com.onlineexam.entity.Grade;
import com.onlineexam.entity.QuestionBank;
import com.onlineexam.entity.QuestionLevel;
import com.onlineexam.entity.QuestionType;
import com.onlineexam.entity.User;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class QuestionShowView {
    private Integer questionId;
    private String title;
    private String description;
    private String imageUrl;
    private QuestionBank questionBank;
    private Grade grade;
    private Category category;
    private QuestionType questionType;
    private QuestionLevel questionLevel;
    private User user;
    private Integer mark;
    private String answer;
    private byte options;
    private byte status;
    @Json.DateTimeFormat
    private Date createDate;
    @Json.DateTimeFormat
    private Date updateDate;

    public QuestionShowView(Integer questionId, String title, String description, String imageUrl, QuestionBank questionBank, Grade grade, Category category, QuestionType questionType, QuestionLevel questionLevel, User user, Integer mark, String answer, byte options, byte status, Date createDate, Date updateDate) {
        this.questionId = questionId;
        this.title = title;
        this.description = description;
        this.imageUrl = imageUrl;
        this.questionBank = questionBank;
        this.grade = grade;
        this.category = category;
        this.questionType = questionType;
        this.questionLevel = questionLevel;
        this.user = user;
        this.mark = mark;
        this.answer = answer;
        this.options = options;
        this.status = status;
        this.createDate = createDate;
        this.updateDate = updateDate;
    }
    
    

    public Integer getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public QuestionBank getQuestionBank() {
        return questionBank;
    }

    public void setQuestionBank(QuestionBank questionBank) {
        this.questionBank = questionBank;
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public QuestionType getQuestionType() {
        return questionType;
    }

    public void setQuestionType(QuestionType questionType) {
        this.questionType = questionType;
    }

    public QuestionLevel getQuestionLevel() {
        return questionLevel;
    }

    public void setQuestionLevel(QuestionLevel questionLevel) {
        this.questionLevel = questionLevel;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Integer getMark() {
        return mark;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public byte getOptions() {
        return options;
    }

    public void setOptions(byte options) {
        this.options = options;
    }

    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
}
