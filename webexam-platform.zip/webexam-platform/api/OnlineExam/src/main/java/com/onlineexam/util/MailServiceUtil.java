/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.util;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author Libeesh
 */
@Service
public class MailServiceUtil {

    @Value("${mail.smtp.host}")
    private String host;
    @Value("${mail.smtp.port}")
    private String port;
    @Value("${mail.smtp.user}")
    private String userName;
    @Value("${mail.smtp.password}")
    private String password;
    @Value("${mail.smtp.from}")
    private String from;
    
    @Autowired
    private LanguageUtil languageUtil;

    public void sendPasswordResetMail(String email, String firstName, String lastName, String link) throws MessagingException, IOException {
        String subject = languageUtil.getTranslatedText("mail.subject", null, "en");
        //String content = firstName + " " + languageUtil.getTranslatedText("hi", null, "en")+"!<br/>" +
        String content = "Hi " + firstName + "!<br/>" +
                languageUtil.getTranslatedText("click.link.to.reset.password", null, "en") +" <br/>" +
                link + "<br/><br/><br/>" +
                "--Web Exam--";

        String receipient = email;
        sendMail(subject, content, receipient);
    }
    
    public void sendNewUserMail(String email, String firstName, String link) throws MessagingException, IOException {
        String subject = languageUtil.getTranslatedText("mail.subject.new.user", null, "en");
        String content = firstName + " " + languageUtil.getTranslatedText("dear", null, "en")+"<br/><br/>" +
                languageUtil.getTranslatedText("mail.new.user.content.1", null, "en") +" <br/>" +                
                languageUtil.getTranslatedText("mail.new.user.content.2", null, "en")+" <br/>" +
                link + "<br/>" +
                languageUtil.getTranslatedText("mail.new.user.contact.administrator", null, "en")+" <br/><br/>" +

                "--PrimeCaster Video Platform--";

        String receipient = email;
        sendMail(subject, content, receipient);
    }
    
     public void sendExamIntimationMail(String email, String firstName, String link, String examName, Date date) throws MessagingException, IOException {
        String subject = examName + " "+languageUtil.getTranslatedText("mail.subject.exam.intimation", null, "en");
        String content = "Dear" + " " + firstName + "," + "<br/><br/>" +
                languageUtil.getTranslatedText("mail.exam.intimation.content.1", null, "en") +" "+examName+" scheduled on "+date+"."+" <br/>" +                
//                languageUtil.getTranslatedText("mail.exam.intimation.content.2", null, "en")+" <br/>" +
//                link + "<br/><br/>" +  
        languageUtil.getTranslatedText("mail.exam.intimation.content.3", null, "en")+" <br/><br/>"+
//                languageUtil.getTranslatedText("mail.new.user.contact.administrator", null, "en")+" <br/><br/>" +
            "Support," +"<br/>"+
                "--PrimeCaster Video Platform--";

        String receipient = email;
        sendMail(subject, content, receipient);
    }
     
     public void sendExamInvitationMail(String email, String firstName, String link, String examName, Date date, String password) throws MessagingException, IOException {
        String subject = examName + " "+languageUtil.getTranslatedText("mail.subject.exam.invitation", null, "en");
        String content = "Dear" + " " + firstName + "," + "<br/><br/>" +
                languageUtil.getTranslatedText("mail.exam.invitation.content.1", null, "en") +" "+examName+" scheduled on "+date+"."+"<br/><br/>" +                
                languageUtil.getTranslatedText("mail.exam.intimation.content.2", null, "en")+" <br/>" +
                link + "<br/><br/>" +  
                languageUtil.getTranslatedText("mail.exam.invitation.content.2", null, "en")+" <br/>"+
                "Username : "+email+" <br/>"+
                "Password: "+password+" <br/><br/>"+
                languageUtil.getTranslatedText("mail.exam.invitation.content.3", null, "en")+" <br/><br/>" +

                "--PrimeCaster Video Platform--";

        String receipient = email;
        sendMail(subject, content, receipient);
    }
     
      public void sendExamCancellationMail(String email, String firstName, String examName, Date date) throws MessagingException, IOException {
        String subject = examName + " "+languageUtil.getTranslatedText("mail.subject.exam.cancellation", null, "en");
        String content = "Dear" + " " + firstName + "," + "<br/><br/>" +
                "The exam "+examName+" scheduled on "+date+" is cancelled. We will inform the updated schedule later."+"<br/><br/>" +                
                "Support"+"<br/>"+
                "--PrimeCaster Video Platform--";

        String receipient = email;
        sendMail(subject, content, receipient);
    }

    public void sendMail(String subject, String content, String receipient) throws MessagingException, IOException {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.ssl", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port);

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(userName, password);
            }
        });
        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(from, false));
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(receipient));
        msg.setSubject(subject);
        msg.setSentDate(new Date());
        MimeBodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(content, "text/html; charset=UTF-8");
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);
        msg.setContent(multipart);
        Transport.send(msg);
    }
}
