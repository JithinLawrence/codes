/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.form;

import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sanal
 */
public class ExamQuestionUpdateForm {

    @Valid
    private List<ExamQuestionUpdateInnerForm> examQuestionUpdateInnerForm;
    
    @NotNull
    private List<Integer> deletedData;

    public List<ExamQuestionUpdateInnerForm> getExamQuestionUpdateInnerForm() {
        return examQuestionUpdateInnerForm;
    }

    public void setExamQuestionUpdateInnerForm(List<ExamQuestionUpdateInnerForm> examQuestionUpdateInnerForm) {
        this.examQuestionUpdateInnerForm = examQuestionUpdateInnerForm;
    }

    public List<Integer> getDeletedData() {
        return deletedData;
    }

    public void setDeletedData(List<Integer> deletedData) {
        this.deletedData = deletedData;
    }

    public static class ExamQuestionUpdateInnerForm {

        @NotNull
        private Integer examQuestionId;
        @NotNull
        private Integer questionId;
        @NotNull
        private Integer categoryOrder;
        @NotNull
        private Integer questionOrder;
        @NotNull
        @Max(value = 10000, message = "{total.mark.max.size}")
        @Min(value = 1, message = "{total.mark.min.size}")
        private Integer mark;

        public Integer getExamQuestionId() {
            return examQuestionId;
        }

        public void setExamQuestionId(Integer examQuestionId) {
            this.examQuestionId = examQuestionId;
        }

        public Integer getQuestionId() {
            return questionId;
        }

        public void setQuestionId(Integer questionId) {
            this.questionId = questionId;
        }

        public Integer getCategoryOrder() {
            return categoryOrder;
        }

        public void setCategoryOrder(Integer categoryOrder) {
            this.categoryOrder = categoryOrder;
        }

        public Integer getQuestionOrder() {
            return questionOrder;
        }

        public void setQuestionOrder(Integer questionOrder) {
            this.questionOrder = questionOrder;
        }

        public Integer getMark() {
            return mark;
        }

        public void setMark(Integer mark) {
            this.mark = mark;
        }

    }

}
