/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.Exam;
import java.util.LinkedHashMap;
import java.util.List;

/**
 *
 * @author sanal
 */
public class ExamQuestionGroupedView {

    private final Long examId;
    private final byte examStatus;
    private final String name;
    private final Integer duration;
    private final String description;
    private final String termsAndConditions;
    private final byte examType;
    private final byte scheduleType;
    private final byte showMark;
    private final Integer passMark;
    private final Integer totalMark;
    private final List<Integer> questionIds;
    private final List<Integer> examQuestionIds;
    private final List<TableData> tableData;
    private final LinkedHashMap<Long, List<ExamQuestionView>> examQuestionGroup;

    public ExamQuestionGroupedView(LinkedHashMap<Long, List<ExamQuestionView>> examQuestionGroup, List<Integer> questionIds,
            List<Integer> examQuestionIds, Exam exam, List<TableData> tableData) {
        this.examId = exam.getExamId();
        this.examStatus = exam.getStatus();
        this.name = exam.getName();
        this.duration = exam.getDuration();
        this.description = exam.getDescription();
        this.termsAndConditions = exam.getTermsAndConditions() == null ? "" : exam.getTermsAndConditions();
        this.examType = exam.getType();
        this.scheduleType = exam.getScheduleType();
        this.showMark = exam.getShowMark();
        this.passMark = exam.getPassMark();
        this.totalMark = exam.getTotalMark();
        this.questionIds = questionIds;
        this.examQuestionIds = examQuestionIds;
        this.examQuestionGroup = examQuestionGroup;
        this.tableData = tableData;
    }
    
    public static class TableData {
        private final Long categoryId;
        private final String category;
        private final Integer marks;
        private final Integer categoryOrder;
        private final Integer questionOrder;
        private final Integer questions;

        public TableData(Long categoryId, String category, Integer marks, Integer categoryOrder, Integer questionOrder, Integer questions) {
            this.categoryId = categoryId;
            this.category = category;
            this.marks = marks;
            this.categoryOrder = categoryOrder;
            this.questionOrder = questionOrder;
            this.questions = questions;
        }

        public Long getCategoryId() {
            return categoryId;
        }

        public String getCategory() {
            return category;
        }

        public Integer getMarks() {
            return marks;
        }

        public Integer getCategoryOrder() {
            return categoryOrder;
        }

        public Integer getQuestionOrder() {
            return questionOrder;
        }

        public Integer getQuestions() {
            return questions;
        }
        
    }

    public Long getExamId() {
        return examId;
    }

    public byte getExamStatus() {
        return examStatus;
    }

    public String getName() {
        return name;
    }

    public Integer getDuration() {
        return duration;
    }

    public String getDescription() {
        return description;
    }

    public String getTermsAndConditions() {
        return termsAndConditions;
    }

    public byte getExamType() {
        return examType;
    }

    public byte getScheduleType() {
        return scheduleType;
    }

    public byte getShowMark() {
        return showMark;
    }

    public Integer getPassMark() {
        return passMark;
    }

    public Integer getTotalMark() {
        return totalMark;
    }

    public List<Integer> getQuestionIds() {
        return questionIds;
    }

    public List<Integer> getExamQuestionIds() {
        return examQuestionIds;
    }

    public LinkedHashMap<Long, List<ExamQuestionView>> getExamQuestionGroup() {
        return examQuestionGroup;
    }

    public List<TableData> getTableData() {
        return tableData;
    }

}
