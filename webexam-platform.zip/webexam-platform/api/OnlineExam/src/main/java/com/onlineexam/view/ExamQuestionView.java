/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.json.Json;
import java.util.Date;

/**
 *
 * @author sanal
 */
public class ExamQuestionView {
    private final Integer examQuestionId;
    private final String title;
    private final String description;
    private final String imageUrl;
    private final Long examId;
    private final String exam;
    private final Integer questionId;
    private final String question;
    private final Long categoryId;
    private final String category;
    private final Long questionTypeId;
    private final String questionType;
    private final Long questionLevelId;
    private final String questionLevel;
    private final String answer;
    private final String options;
    private final Integer categoryOrder;
    private final Integer questionOrder;
    private final Integer mark;
    private final byte status;
    @Json.DateTimeFormat
    private final Date createDate;
    @Json.DateTimeFormat
    private final Date updateDate;
    private final Integer questionCount;

    public ExamQuestionView(ExamQuestion examQuestion) {
        this.examQuestionId = examQuestion.getExamQuestionId();
        this.title = examQuestion.getTitle();
        this.description = examQuestion.getDescription();
        this.imageUrl = examQuestion.getImageUrl();
        this.examId = examQuestion.getExam().getExamId();
        this.exam = examQuestion.getExam().getName();
        this.questionId = examQuestion.getQuestion().getQuestionId();
        this.question = examQuestion.getQuestion().getTitle();
        this.categoryId = examQuestion.getCategory().getCategoryId();
        this.category = examQuestion.getCategory().getName();
        this.questionTypeId = examQuestion.getQuestionType().getQuestionTypeId();
        this.questionType = examQuestion.getQuestionType().getName();
        this.questionLevelId = examQuestion.getQuestionLevel().getQuestionLevelId();
        this.questionLevel = examQuestion.getQuestionLevel().getName();
        this.answer = examQuestion.getAnswer();
        this.options = examQuestion.getOptions();
        this.categoryOrder = examQuestion.getCategoryOrder();
        this.questionOrder = examQuestion.getQuestionOrder();
        this.mark = examQuestion.getMark();
        this.status = examQuestion.getStatus();
        this.createDate = examQuestion.getCreateDate();
        this.updateDate = examQuestion.getUpdateDate();
        this.questionCount = 1;
    }

    public Integer getExamQuestionId() {
        return examQuestionId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Long getExamId() {
        return examId;
    }

    public String getExam() {
        return exam;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public String getQuestion() {
        return question;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public String getCategory() {
        return category;
    }

    public Long getQuestionTypeId() {
        return questionTypeId;
    }

    public String getQuestionType() {
        return questionType;
    }

    public Long getQuestionLevelId() {
        return questionLevelId;
    }

    public String getQuestionLevel() {
        return questionLevel;
    }

    public String getAnswer() {
        return answer;
    }

    public String getOptions() {
        return options;
    }

    public Integer getCategoryOrder() {
        return categoryOrder;
    }

    public Integer getQuestionOrder() {
        return questionOrder;
    }

    public Integer getMark() {
        return mark;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public Integer getQuestionCount() {
        return questionCount;
    }
    
}
