/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;



import com.onlineexam.entity.Category;
import com.onlineexam.json.Json;
import java.util.Date;



/**
 *
 * @author jinu
 */
public class CategoryView {
    
    private Long categoryId;
    private String name;
    private String description;
    private Long organizationId;
    private byte status;
    @Json.DateTimeFormat
    private Date createDate;
    @Json.DateTimeFormat
    private Date updateDate;
    
    public CategoryView(Category category){
        this.categoryId = category.getCategoryId();
        this.name = category.getName();
        this.description = category.getDescription();
        this.organizationId = category.getOrganization().getOrganizationId();
        this.status = category.getStatus();
        this.createDate = category.getCreateDate();
        this.updateDate = category.getUpdateDate();       
    }

    public Long getCategoryId() {
        return categoryId;
    }    
  
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public byte getStatus() {
        return status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }       

    public Long getOrganizationId() {
        return organizationId;
    }
    
    
}
