/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.repository;

import com.onlineexam.entity.ExamQuestion;
import com.onlineexam.entity.ExamQuestionResultRadio;
import com.onlineexam.entity.ExamResult;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import javax.transaction.Transactional;

/**
 *
 * @author jinu
 */
public interface ExamResultRadioRepository extends Repository<ExamQuestionResultRadio, Integer> {

    ExamQuestionResultRadio save(ExamQuestionResultRadio exqr);
    
    @Query(value = "delete from exam_question_result_radio where exam_question_result_radio_id = ?1 ", nativeQuery = true)
    void deleteByExamQuestionResultRadioId(Integer examQuestionResultRadioId);

    Integer countByExamResultAndIsCorrect(ExamResult examResult, byte isCorrect);

    ExamQuestionResultRadio findByExamResultAndQuestion(ExamResult examResult, ExamQuestion question);

    @Transactional
    @Modifying
    @Query(value = "update exam_question_result_radio set is_correct = ?1, mark = ?2 where exam_question_id = ?3", nativeQuery = true)
    void updateExamQuestionResultRadioItems(Integer is_correct, Integer mark, Integer examQuestionId);

}
