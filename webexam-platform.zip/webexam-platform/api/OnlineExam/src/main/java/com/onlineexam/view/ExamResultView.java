/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.onlineexam.view;

import java.util.List;
import com.onlineexam.view.JsonObjectView;

/**
 *
 * @author jinu
 */
public class ExamResultView {
    private final Long examResultId;
    private final Integer questionId;
    private final Long typeId;
    private final String answer;
    private final String correctAnswer;
    private final Integer mark;
    private final List<JsonObjectView> options;
    private final String title;

    
    public ExamResultView(Long examResultId, Integer questionId, Long typeId, String answer, String correctAnswer, Integer mark, List<JsonObjectView> options, String title){
        this.examResultId = examResultId;
        this.questionId = questionId;
        this.typeId = typeId;
        this.answer = answer;
        this.correctAnswer = correctAnswer;
        this.mark = mark;
        this.options = options;
        this.title = title;

    }


    public Long getExamResultId() {
        return examResultId;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public Long getTypeId() {
        return typeId;
    }

    public String getAnswer() {
        return answer;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public Integer getMark() {
        return mark;
    }

    public List<JsonObjectView> getOptions() {
        return options;
    }

    public String getTitle() {
        return title;
    }
   
}
