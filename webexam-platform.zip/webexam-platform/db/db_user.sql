CREATE USER `online_exam`@`localhost` IDENTIFIED BY 'online_exam';
GRANT ALL ON `online_exam`.* TO `online_exam`@`localhost`;

INSERT INTO `online_exam`.`user` (`first_name`, `last_name`, `email`, `password`, `role`, `status`, `create_date`, `update_date`) VALUES ('Admin', 'WE', 'examadmin@gmail.com', '{bcrypt}$2a$10$vuO8/O26VPHVnk9G18s0g.QovVv6S7dJIFnlF3E8tCK1tnT1/JlB2', '1', '1', '2020-06-29 16:14:14', '2020-06-29 16:14:16');

