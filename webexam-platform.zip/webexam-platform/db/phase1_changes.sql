use online_exam;

CREATE TABLE `organization` (
  `organization_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `description` VARCHAR(1000) NULL,
  `created_by` INT(11) NOT NULL,
  `status` TINYINT(4) NOT NULL,
  `create_date` DATETIME NOT NULL,
  `update_date` DATETIME NOT NULL,
  PRIMARY KEY (`organization_id`));


CREATE TABLE `question_bank_questions` (
  `question_bank_id` int(10) unsigned NOT NULL,
  `question_id` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`question_id`,`question_bank_id`),
  KEY `fk_question_bank_questions_ref_qb_idx` (`question_bank_id`),
  CONSTRAINT `fk_question_bank_questions_ref_q` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_question_bank_questions_ref_qb` FOREIGN KEY (`question_bank_id`) REFERENCES `question_bank` (`question_bank_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `grade_questions` (
  `grade_id` int(10) unsigned NOT NULL,
  `question_id` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`question_id`,`grade_id`),
  KEY `fk_grade_questions_ref_g_idx` (`grade_id`),
  CONSTRAINT `fk_grade_questions_ref_g` FOREIGN KEY (`grade_id`) REFERENCES `grade` (`grade_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_grade_questions_ref_q` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `grade_question_banks` (
  `grade_id` int(10) unsigned NOT NULL,
  `question_bank_id` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`question_bank_id`,`grade_id`),
  KEY `fk_grade_question_banks_ref_g_idx` (`grade_id`),
  CONSTRAINT `fk_grade_question_banks_ref_g` FOREIGN KEY (`grade_id`) REFERENCES `grade` (`grade_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_grade_question_banks_ref_q` FOREIGN KEY (`question_bank_id`) REFERENCES `question_bank` (`question_bank_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `organization_students` (
  `organization_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`organization_id`),
  KEY `fk_organization_students_ref_g_idx` (`organization_id`),
  CONSTRAINT `fk_organization_students_ref_o` FOREIGN KEY (`organization_id`) REFERENCES `organization` (`organization_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_organization_students_ref_s` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


ALTER TABLE `question` 
ADD COLUMN `price` INT(11) NULL AFTER `options`,
ADD COLUMN `publish_market` TINYINT(4) NULL AFTER `price`;
-- changes 1
UPDATE `question` SET `publish_market`='1';


ALTER TABLE `exam` 
ADD COLUMN `terms_and_conditions` TEXT NULL DEFAULT NULL AFTER `description`;


ALTER TABLE `question` 
DROP FOREIGN KEY `question_ref_question_bank`,
DROP FOREIGN KEY `question_ref_grade`;
ALTER TABLE `question` 
DROP COLUMN `grade_id`,
DROP COLUMN `question_bank_id`,
DROP INDEX `question_ref_grade_idx` ,
DROP INDEX `question_ref_question_bank_idx` ;

ALTER TABLE `exam` 
ADD COLUMN `organization_id` INT(10) UNSIGNED NOT NULL AFTER `description`;

INSERT INTO `organization` (`organization_id`, `name`, `description`, `created_by`, `status`, `create_date`, `update_date`) VALUES ('1', 'org', 'desc', '1', '1', '2020-07-07 09:06:02', '2020-07-07 09:06:02');

UPDATE `exam` SET `organization_id`='1';

ALTER TABLE `exam` 
ADD INDEX `fk_exam_ref_organization_idx` (`organization_id` ASC);
ALTER TABLE `exam` 
ADD CONSTRAINT `fk_exam_ref_organization`
  FOREIGN KEY (`organization_id`)
  REFERENCES `organization` (`organization_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


ALTER TABLE `question_bank` 
ADD COLUMN `organization_id` INT(10) UNSIGNED NOT NULL AFTER `description`;

UPDATE `question_bank` SET `organization_id`='1';

ALTER TABLE `question_bank` 
ADD INDEX `fk_question_bank_ref_organization_idx` (`organization_id` ASC);
ALTER TABLE `question_bank` 
ADD CONSTRAINT `fk_question_bank_ref_organization`
  FOREIGN KEY (`organization_id`)
  REFERENCES `organization` (`organization_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


ALTER TABLE `user` 
ADD COLUMN `organization_id` INT(10) UNSIGNED NOT NULL AFTER `image_url`;

UPDATE `user` SET `organization_id`='1';

ALTER TABLE `user` 
ADD INDEX `fk_user_ref_organization_idx` (`organization_id` ASC);
ALTER TABLE `user` 
ADD CONSTRAINT `fk_user_ref_organization`
  FOREIGN KEY (`organization_id`)
  REFERENCES `organization` (`organization_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;



ALTER TABLE `category` 
ADD COLUMN `organization_id` INT(10) UNSIGNED NOT NULL AFTER `description`;
  
UPDATE `category` SET `organization_id`='1';

ALTER TABLE `category` 
ADD INDEX `fk_category_ref_organization_idx` (`organization_id` ASC);
ALTER TABLE `category` 
ADD CONSTRAINT `fk_category_ref_organization`
  FOREIGN KEY (`organization_id`)
  REFERENCES `organization` (`organization_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `grade` 
ADD COLUMN `organization_id` INT(10) UNSIGNED NOT NULL AFTER `description`;

UPDATE `grade` SET `organization_id`='1';

ALTER TABLE `grade` 
ADD INDEX `fk_grade_ref_organization_idx` (`organization_id` ASC);
ALTER TABLE `grade` 
ADD CONSTRAINT `fk_grade_ref_organization`
  FOREIGN KEY (`organization_id`)
  REFERENCES `organization` (`organization_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


ALTER TABLE `question` 
ADD COLUMN `organization_id` INT(10) UNSIGNED NOT NULL AFTER `description`;

UPDATE `question` SET `organization_id`='1';

ALTER TABLE `question` 
ADD INDEX `fk_question_ref_organization_idx` (`organization_id` ASC);
ALTER TABLE `question` 
ADD CONSTRAINT `fk_question_ref_organization`
  FOREIGN KEY (`organization_id`)
  REFERENCES `organization` (`organization_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

CREATE TABLE `category_question_banks` (
  `category_id` int(10) unsigned NOT NULL,
  `question_bank_id` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`question_bank_id`,`category_id`),
  KEY `fk_category_question_banks_ref_g_idx` (`category_id`),
  CONSTRAINT `fk_category_question_banks_ref_c` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_category_question_banks_ref_q` FOREIGN KEY (`question_bank_id`) REFERENCES `question_bank` (`question_bank_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  
ALTER TABLE `exam_question` 
ADD COLUMN `category_order` INT(11) NOT NULL AFTER `order`;



-- change 2
ALTER TABLE `exam_question` 
DROP COLUMN `grade_id`,
DROP COLUMN `question_bank_id`;

-- change 3
ALTER TABLE `exam_question` 
DROP COLUMN `created_by`;
----change 4---------------------------------
ALTER TABLE `schedule` ADD COLUMN `created_by` INT(11) NOT NULL AFTER `status`;

