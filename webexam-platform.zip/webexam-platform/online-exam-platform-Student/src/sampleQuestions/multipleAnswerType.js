import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import Button from '@material-ui/core/Button';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import Box from '@material-ui/core/Box';
import { Typography, Divider, Checkbox } from '@material-ui/core';


const useStyles = makeStyles((theme) => ({
    chkbxMain: {
    },
    options: {
        margin: theme.spacing(3)
    }
}));

export default function SingleAnswer() {
    const classes = useStyles();
    const [checkedValue, setCheckedValue] = React.useState(10)
    const [value, setValue] = React.useState('female');

    const handleChange = (event) => {
        setValue(event.target.value);
    };

    return (
        <>
            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                        <Typography variant="h4">Q2. Which all are correct?</Typography>
                        <FormControl className={classes.options} component="fieldset">
                            <RadioGroup aria-label="question 1" value={value} name="q1" onChange={handleChange}>
                                <FormControlLabel value="1" control={<Checkbox />} label="Elephants are black" />
                                <FormControlLabel value="2" control={<Checkbox />} label="Ostriches are birds" />
                                <FormControlLabel value="3" control={<Checkbox />} label="Dolphins live in deserts" />
                                <FormControlLabel value="4" control={<Checkbox />} label="Dogs eat grass" />
                            </RadioGroup>
                        </FormControl>
                    </div>
                    <br></br>
                    <br></br>
                </div>
            </Box>
            
        </>
    );
}
