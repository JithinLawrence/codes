import React, { useEffect, useState } from "react";
let dt = new Date();
dt.setMinutes(dt.getMinutes() + 30);
export default function CountdownTimer(start) {
    const [startTimer, setTimer] = useState(start);
    const calculateTimeLeft = (startTimer) => {
        if (startTimer) {
            const difference = +dt - new Date();
            let timeLeft = {};

            if (difference > 0) {
                timeLeft = {
                    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                    minutes: Math.floor((difference / 1000 / 60) % 60),
                    seconds: Math.floor((difference / 1000) % 60)
                };
            }

            return timeLeft;
        }
        return "0"
    };

    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft(startTimer));

    useEffect(() => {
        setTimeout(() => {
            setTimeLeft(calculateTimeLeft(startTimer));
        }, 1000);
    });

    const timerComponents = [];

    Object.keys(timeLeft).forEach(interval => {
        if (!timeLeft[interval]) {
            if (interval == "seconds") {
                timeLeft[interval] = "00";
            }
            else {
                return ""
            }
        }
        if (interval == "seconds") {
            timerComponents.push(
                <span>
                    {timeLeft[interval]}
                </span>
            );
        } else {
            timerComponents.push(
                <span>
                    {timeLeft[interval]}{":"}
                </span>
            );
        }
    });

    return (
        <div>
            {timerComponents.length ? timerComponents : <span>Time's up!</span>}
        </div>
    );
}

