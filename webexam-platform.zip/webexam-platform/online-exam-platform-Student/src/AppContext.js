import React from 'react';

const NO_OP = () => { };


const AppContext = React.createContext();
if (process.env.NODE_ENV !== 'production') {
  AppContext.displayName = 'AppContext';
}

const useAppContext = () => React.useContext(AppContext);

function AppContextProvider({ init, children }) {
  const [title, setTitle] = React.useState('Web Exam');
  const [displayAll, setDisplayAll] = React.useState("true");
  React.useEffect(() => { document.title = title ? 'Web Exam / - ' + title : 'Web exam /'; }, [title]);
  const getTitle = () => title;
  const getDisplayAll = () => displayAll;


  const context = { setTitle, getTitle , setDisplayAll, getDisplayAll};

  return <AppContext.Provider value={context}>{children}</AppContext.Provider>;
}


export default useAppContext;
export { AppContextProvider };
