import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import FormControl from '@material-ui/core/FormControl';
import { Link } from "react-router-dom";
import { Grid } from '@material-ui/core';
import Checkbox from '@material-ui/core/Checkbox';
import Typography from '@material-ui/core/Typography';


const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    mainPaper: {
        width: "80% !important",
        textAlign: "center",
        marginLeft: "10%",
        marginTop: "5%"
    },
    h1Agreement: {
        textAlign: "center",
        textDecoration: "underline",
    },
    title: {
        textAlign: "center",
        paddingBottom: theme.spacing(3)
    },
    agrBody: {
        padding: "10px",
    },
    agrChkP: {
        fontWeight: "bold",
        fontSize: "16px",

    }
});



export default function Agreement() {
    const classes = useStyles();
    const [agree, setAgree] = React.useState(false);
    const handleClickAgreement = () => {
        setAgree(!agree);
    }

    function SetStart() {
        if (agree) {
            return (
                <Link style={{ textDecoration: 'none' }} to="/exam">
                    <Button
                        color="secondary"
                        variant="contained"
                    >
                        Start
                </Button></Link>
            )
        } else {
            return (
                <Button
                    color=".error"
                    variant="contained"
                >
                    Start
                </Button>
            )
        }


    }
    return (
        <div className={classes.mainPaper}>
            <Grid container justify="center">

                <Grid item justify="center">
                    <Typography variant="h2" className={classes.title}>Examination 1</Typography>
                    <Typography variant="h6" className={classes.h1Agreement}>Terms and Conditions</Typography>
                    <br></br>
                    <div className={classes.agrBody}>
                        <p>Please go through the instructionsPlease go through the instructions and click the agree checkbox to confirm that you
                        read and understood all instructions.Please go through the instructions and click the agree checkbox to confirm that you
                        read and understood all instructions. and click the agree checkbox to confirm that you
                        read and understood all instructions.Please go through the instructions and click the agree checkbox to confirm that you
                        read and understood all instructions. and click the agree checkbox to confirm that you
                    read and understood all instructions.</p>
                    </div>
                </Grid>

            </Grid>
            <Grid container justify="center">
                <Grid item>
                    <FormControl>
                        <p className={classes.agrChkP}><Checkbox name="" onClick={handleClickAgreement} > </Checkbox> I Agree</p>
                    </FormControl>
                </Grid>
            </Grid>
            <Grid container justify="center">
                <Grid item>
                    <SetStart />
                </Grid>
            </Grid>
            <br></br>
            <br></br>
        </div>
    );
}