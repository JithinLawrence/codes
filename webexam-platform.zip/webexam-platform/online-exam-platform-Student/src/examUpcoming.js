import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box';
import pink from '@material-ui/core/colors/pink';
import lightGreen from '@material-ui/core/colors/lightGreen';
import lightBlue from '@material-ui/core/colors/lightBlue';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import LaunchIcon from '@material-ui/icons/Launch';
import PlayCircleFilledWhiteIcon from '@material-ui/icons/PlayCircleFilledWhite';
import DoneOutlineTwoToneIcon from '@material-ui/icons/DoneOutlineTwoTone';
import FormControl from '@material-ui/core/FormControl';
import { TextField } from '@material-ui/core';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    mainContainer: {
        width: "100%"
    },
    mainGridContainer: {
        flexGrow: 1,
    },
    mainGrid: {
        margin: "10px;",
        // height: "35% !important"
    },
    examTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        textAlign: "center",
        paddingTop: "20px",
        fontWeight: "bold"
    },
    examDetailP: {
        marginLeft: "10px",

    },
    bottomDiv: {
        height: "auto",
        textAlign: "center"
    },
    numberBoxTotal: {
        backgroundColor: "#b24c00 !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",
    },
    numberBox1: {
        backgroundColor: theme.palette.secondary.main + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    numberBox2: {
        backgroundColor: lightGreen['A700'] + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    numberBox3: {
        backgroundColor: pink[500] + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    outerChip: {
        backgroundColor: "white",
        color: "rgba(0, 0, 0, 0.87)",
        fontSize: "16px",
        fontWeight: "normal",
        margin: "20px",

    },
    outerChipTotal: {
        color: "rgba(0, 0, 0, 0.87)",
        fontSize: "16px",
        height: "auto",
        fontWeight: "normal",
        margin: "20px",
        backgroundColor: "white !important",
        boxShadow: "3px 3px 1px 1px #ccc;",
        textAlign: "left",
        width: "150px",
        paddingRight: "80px",

    },
    chipGridMain: {

    },
    reviewButton: {
        marginTop: "13%",
        marginBottom: "13%",
        backgroundColor: lightBlue[500] + " !important",
    },
    resultButton: {
        marginTop: "13%",
        marginBottom: "13%",
        backgroundColor: theme.palette.secondary.light + " !important",
    }
});

function createData(id, examName, startDate, expiredDate, totalQuestions, duration, applied, attended, result) {
    return { id, examName, startDate, expiredDate, totalQuestions, duration, applied, attended, result };
}

const rows = [
    createData(1, "exam1", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T10:30:00'), 10, "30 minutes", 0, 0, 0),
    createData(2, "exam2", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T10:30:00'), 10, "30 minutes", 0, 0, 0),
    createData(3, "exam3", new Date('2019-08-20T10:00:00'), new Date('2019-08-20T10:50:00'), 20, "50 minutes", 1, 0, 0),
    createData(4, "exam4", new Date('2019-08-21T10:00:00'), new Date('2019-08-21T10:50:00'), 20, "50 minutes", 1, 0, 0),
    createData(5, "exam5", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 1, 0, 0),
    createData(6, "exam5", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 0, 0, 0),
    createData(7, "exam7", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 1, 0, 0),
    createData(8, "exam8", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 0, 0, 0),


];



export default function ExamUpcoming() {
    const classes = useStyles();
    const [examRegisterOpen, examRegisterSetOpen] = React.useState(false);
    const [examStartOpen, examStartSetOpen] = React.useState(false);

    const handleCloseExamRegister = hasChange => {
        examRegisterSetOpen(false);
    };
    const handleClickOpenExamRegister = () => {
        examRegisterSetOpen(true);
    };

    const handleCloseExamStart = hasChange => {
        examStartSetOpen(false);
    };
    const handleClickOpenExamStart = () => {
        examStartSetOpen(true);
    };

    function displayApplicationStatus(applied) {
        if (applied == 0) {
            return (
                <LaunchIcon onClick={handleClickOpenExamRegister} />
            );
        } else if (applied == 1) {
            return (
                <DoneOutlineTwoToneIcon />
            );
        }
    }


    function hasAttendedExam(attendence, id) {
        if (attendence === 0) {
            return (
                <Button variant="contained"
                    color="secondary"
                    justify="right"
                    className={classes.resultButton}
                    onClick={handleClickOpenExamStart}>
                    <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
            );

        } else if (attendence === 1) {
            return (
                <Button variant="contained"
                    color="secondary"
                    disabled
                    justify="right"
                    className={classes.resultButton} >
                    <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
            );
        }

    }

    return (
        <div>
            <h1>Upcoming Exams</h1>
            <Divider></Divider>
            <Box className={classes.toolbar} display="flex" flexDirection="row-reverse">

    
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        ></TextField>
                    </FormControl>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Title</TableCell>
                            <TableCell align="center">Duration</TableCell>
                            <TableCell align="center">Schedule</TableCell>
                            <TableCell align="center">Apply</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.examName}
                                </TableCell>
                                <TableCell align="center">{row.duration}</TableCell>
                                <TableCell align="center">{row.startDate.toDateString()} {row.startDate.getHours()}:{row.startDate.getMinutes()}</TableCell>
                                <TableCell align="center">
                                    {displayApplicationStatus(row.applied)}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}