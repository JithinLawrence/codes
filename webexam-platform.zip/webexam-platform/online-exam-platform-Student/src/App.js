import React from 'react';
import ForgotPassword from './forgotPassword';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Drawer from '@material-ui/core/Drawer';
import clsx from 'clsx';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import DashboardSharpIcon from '@material-ui/icons/Dashboard';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import Button from '@material-ui/core/Button';
import Tooltip from '@material-ui/core/Tooltip';
import Link from '@material-ui/core/Link';
import MenuIcon from '@material-ui/icons/Menu';
import { withStyles } from "@material-ui/core";
import { BrowserRouter as Router, Route, Switch, useRouteMatch, useHistory } from 'react-router-dom';
import Register from './register';
import SignIn from './SignIn';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Fade from '@material-ui/core/Fade'
import useAppContext from './AppContext';
import DashBoard from './dashboard';
import Exam from './exam';
import ExamResult from './examResult';
import ExamUpcoming from './examUpcoming';
import Agreement from './agreement';
import ExamHistory from './examHistory';
import { PasswordChange } from './profile'
import ProfileChange from './profile'
import HistoryIcon from '@material-ui/icons/History';
import AccountCircleRoundedIcon from '@material-ui/icons/AccountCircleRounded';
import TocIcon from '@material-ui/icons/Toc';

const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
    },
    toolbar: {
        paddingRight: 24, // keep right padding when drawer closed
    },
    toolbarIcon: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: '0 8px',
        ...theme.mixins.toolbar,
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
    },
    appBarShift: {
        marginLeft: drawerWidth,
        zIndex: theme.zIndex.drawer + 1,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    menuButton: {
        marginRight: 36,
    },
    menuButtonHidden: {
        display: 'none',
    },
    title: {
        flexGrow: 1,
    },
    drawerPaper: {
        position: 'relative',
        whiteSpace: 'nowrap',
        backgroundColor: "#e9e9e9",
        borderRight: 0,
        paddingTop: theme.spacing(10),
        overflow: "hidden",
        width: drawerWidth,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    drawerPaperClose: {
        overflowX: 'hidden',
        backgroundColor: "#e9e9e9",
        paddingTop: theme.spacing(10),
        overflow: "hidden",
        borderRight: 0,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        width: theme.spacing(7),
        [theme.breakpoints.up('sm')]: {
            width: theme.spacing(7),
        },
    },
    appBarSpacer: theme.mixins.toolbar,
    content: {
        flexGrow: 1,
        height: '100vh',
        overflow: 'auto',
        paddingTop: theme.spacing(10),
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(2),
        paddingBottom: theme.spacing(5)
    },
    container: {
        paddingTop: theme.spacing(4),
        paddingBottom: theme.spacing(4),
    },
    paper: {
        padding: theme.spacing(2),
        display: 'flex',
        overflow: 'auto',
        flexDirection: 'column',
    },
    profileMenu: {
        marginTop: theme.spacing(4)
    },
    bottomDiv: {
        marginBottom: "50px",
    }


}));

function Copyright() {
    return (
        <Typography variant="body2" color="textSecondary" align="center">
            {'Copyright © '}
            <Link color="inherit" href="https://material-ui.com/">
                Your Website
      </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

function MenuLink({ to, icon: Icon, text }) {
    const history = useHistory();
    const match = useRouteMatch(to);
    return (
        <Tooltip title={text} placement="right-end">
            <StyledListItem button selected={match && match.isExact} onClick={() => history.push(to)}>
                <ListItemIcon><Icon color="secondary" fontSize="small" /></ListItemIcon>
                <ListItemText primary={text} />
            </StyledListItem>
        </Tooltip>
    );
}
const StyledListItem = withStyles({
    root: {
        "&$selected": {
            backgroundColor: "white"
        },
        "&:hover": {
            backgroundColor: "white !important"
        }

    },
    selected: {}
})(ListItem);

export default function App() {
    const appContext = useAppContext();
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);
    const [profileOpen, setProfileOpen] = React.useState(false);
    const [passwordOpen, setPasswordOpen] = React.useState(false);
    const [anchorEl, setAnchorEl] = React.useState(null);
    const accountsOpen = Boolean(anchorEl);
    const handleDrawerOpen = () => {
        setOpen(!open);
    };
    const handleProfileClick = (event) => {
        console.log(event.currentTarget)
        setAnchorEl(event.currentTarget);
    };

    const handleProfileClose = () => {
        setAnchorEl(null);
    };
    const handleProfileChange = () => {
        setProfileOpen(true);
    };
    const handlePasswordChange = () => {
        setPasswordOpen(true);
    };
    const handleProfileChangeClose = hasChange => {
        setProfileOpen(false);
    };
    const handlePasswordChangeClose = hasChange => {
        setPasswordOpen(false);
    };


    return (

        <Router>
            <Switch>
                <Route path="/exam" component={Exam} />
                <Route path="/register" component={Register} />
                <Route path="/signin" component={SignIn} />
                <Route path="/forgotpassword" component={ForgotPassword} />
                <Route path="/">
                    <div className={classes.root}>
                        <CssBaseline />
                        <AppBar position="absolute" color="secondary" className={classes.appBar}>
                            <Toolbar className={classes.toolbar}>
                                <IconButton
                                    edge="start"
                                    color="inherit"
                                    aria-label="open drawer"
                                    onClick={handleDrawerOpen}
                                    className={clsx(classes.menuButton)}
                                >
                                    <MenuIcon />
                                </IconButton>
                                <Typography component="h1" variant="h6" color="inherit" noWrap className={classes.title}>
                                    {appContext.getTitle()}
                                </Typography>
                                <Button color="inherit" onClick={handleProfileClick}>
                                    <AccountCircleRoundedIcon />
                                    <Typography variant="caption"> &nbsp; Test User </Typography>
                                </Button>
                                <Menu
                                    id="profile-menu"
                                    className={classes.profileMenu}
                                    elevation={0}
                                    anchorEl={anchorEl}
                                    keepMounted
                                    open={accountsOpen}
                                    onClose={handleProfileClose}
                                    TransitionComponent={Fade}
                                >
                                    <MenuItem onClick={handleProfileChange}>Edit Profile</MenuItem>
                                    <MenuItem onClick={handlePasswordChange}>Change Password</MenuItem>
                                    <MenuItem onClick={handleProfileClose}>Logout</MenuItem>
                                </Menu>
                            </Toolbar>
                        </AppBar>
                        <Drawer
                            style={{ display: appContext.getDisplayAll() }}
                            variant="permanent"
                            classes={{
                                paper: clsx(classes.drawerPaper, !open && classes.drawerPaperClose),
                            }}
                            open={open}
                        >

                            <List>
                                <MenuLink to="/dashboard" icon={DashboardSharpIcon} text="Dashboard" />
                                <MenuLink to="/upcoming" icon={TocIcon} text="Upcoming Exams" />
                                <MenuLink to="/history" icon={HistoryIcon} text="Exam History" />
                                {/* <MenuLink to="/questionbanklist" icon={LibraryBooksRoundedIcon} text="Question bank" />
                        <MenuLink to="/questions" icon={CreateOutlinedSharpIcon} text="Questions" />
                        <MenuLink to="/exams" icon={AssignmentTurnedInRoundedIcon} text="Exams" />
                        <MenuLink to="/examschedule" icon={ScheduleSharpIcon} text="Exam scheduler" />
                        <MenuLink to="/students" icon={SchoolRoundedIcon} text="Candidates" />
                        <MenuLink to="/users" icon={AccountBoxRoundedIcon} text="Users" /> */}
                            </List>
                        </Drawer>
                        <main className={classes.content}>
                            <div className={classes.toolbar} />
                            <Switch>
                                <Route path="/dashboard" component={DashBoard} />
                                <Route path="/result" component={ExamResult} />
                                <Route path="/upcoming" component={ExamUpcoming} />
                                <Route path="/history" component={ExamHistory} />
                                <Route path="/" component={DashBoard} />
                            </Switch>
                        </main>
                    </div>
                    {/* <Copyright /> */}
                    <PasswordChange open={passwordOpen} onClose={handlePasswordChangeClose} />
                    <ProfileChange open={profileOpen} onClose={handleProfileChangeClose} />
                </Route>
            </Switch>
        </Router>

    );
}
