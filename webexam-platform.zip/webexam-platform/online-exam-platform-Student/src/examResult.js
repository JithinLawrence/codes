import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box'
import Grid from '@material-ui/core/Grid';
import Radio from '@material-ui/core/Radio';
import { Typography, TextareaAutosize } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
    mainDiv:{
        marginLeft : "10%",
        alignItems: "center",
        justifyContent : "center",
        justifyItems :"center",
    },
    chkbxMain: {
        // width:"50%"
    },
    textBoxAuto:{
        // minWidth : '30rem',
        [theme.breakpoints.up('sm')]: {
            minWidth : '30rem',

        },
        [theme.breakpoints.down('sm')]: {
            minWidth : '15rem',

        },
    },
    options: {
        margin: theme.spacing(3)
    },
    correctAnswer: {
        backgroundColor: "lightgreen",
        paddingTop : "4px"
    },
    wrongAnswer: {
        backgroundColor: "#eea29a",
    },
    detailsBox:{
        // border : "1px black solid",
        // padding : "10px",
        // fontSize : "16px",
        // fontWeight : "bold",
        // marginLeft : "10%",
        [theme.breakpoints.up('sm')]: {
            width : "40%",

        },
        
        // textAlign : "center",

    }
}));
const boxProps = {
    display: "flex",
    bgcolor: 'background.paper',
    // style: { height: '3rem' },
    borderLeft: '5px solid',
    borderColor: "secondary.main",
    justifyContent: "flex-start",
    margin: 1,
    padding: 1,
    boxShadow: 3,
    minHeight: "180px !important",
};
const chartsProps = {
    display: "flex",
    bgcolor: 'background.paper',
    justifyContent: "center",
    margin: 3,
    padding: 1,
};

const successData = [
    { success: 'pass', percentage: 75 },
    { success: 'fail', percentage: 50 },
];

const examStatusData = [
    { status: 'Assigned', count: 20 },
    { status: 'Not started', count: 30 },
    { status: 'In progress', count: 30 },
    { status: 'Incomplete', count: 40 },
    { status: 'Completed', count: 50 },
];
const scoreData = [
    { score: 'max score', count: 70 },
    { score: 'min score', count: 30 },
    { score: 'average score', count: 30 },
];

const scoreChartProps = {
    data: scoreData,
    title: 'Score analysis',
    width: '250',
    height: '500',
    valueField: 'count',
    argumentField: 'score',
    scaleName: 'zoom',
}
const successChartProps = {
    data: successData,
    title: 'pass/fail analysis',
    valueField: "percentage",
    argumentField: "success",
}
const examstatusChartProps = {
    data: examStatusData,
    title: 'Exam status/ Candidates count',
    width: '380',
    height: '500',
    valueField: "count",
    argumentField: "status"
}

export default function ExamResult() {
    const classes = useStyles();
    const [checkedValue, setCheckedValue] = React.useState(10)
    const [value, setValue] = React.useState('female');

    const handleChange = (event) => {
        setValue(event.target.value);
    };
    return (
        <div className={classes.mainDiv}>
            <h1>Exam Name/Exam Result</h1>
            <br></br>
            <Grid container >
                <Grid item sm={12}>
                    <Box {...boxProps} className={classes.detailsBox}>
                        Examination Name : Exam 1 <br></br>
                        Examination Date : 12/05/2020 10:30<br></br>
                        Total Duration : 60 minutes<br></br>
                        Total Questions :50<br></br>
                        Total Marks :{50 * 2}<br></br>
                        Answered Correct : 37<br></br>
                        Marks Scored : {37 * 2}
                    </Box>
                </Grid>
            </Grid>

            <br></br>
            <br></br>
            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                        <Typography variant="h4">Q1. Which one is correct?</Typography>
                        <p><Radio value="1" disabled />Elephants are white<br></br></p>
                        <p className={classes.correctAnswer}> <Radio value="2" disabled checked="true" />Ostriches are birds<br></br></p>
                        <p><Radio value="3" disabled />Camels live in seas <br></br></p>
                        <p><Radio value="4" disabled />Tigers eat grass<br></br></p>
                    </div>
                    <br></br>
                    <br></br>
                </div>
            </Box>


            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                        <Typography variant="h4">Q2. Which one is  correct now?</Typography>
                        <p className={classes.wrongAnswer}><Radio value="1" disabled checked="true" />facebook is a book<br></br></p>
                        <p><Radio value="2" disabled />Google is an animal<br></br></p>
                        <p><Radio value="3" disabled />Microsoft is a car maker<br></br></p>
                        <p className={classes.correctAnswer} ><Radio value="4"disabled checked="true" />Tesla produces flame throwers 
                       <br></br></p>
                    </div>
                    <br></br>
                    <br></br>
                </div>
            </Box>
            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                    <Typography variant="h4">Q2. Enter a line?</Typography><br></br>
                    <TextareaAutosize rowsMax={5} className={classes.textBoxAuto} disabled> 
                    Declarative
React makes it painless to create interactive UIs. Design simple views for each state in your application, and React will efficiently update and render just the right components when your data changes.

Declarative views make your code more predictable and easier to debug.

Component-Based
Build encapsulated components that manage their own state, then compose them to make complex UIs.

Since component logic is written in JavaScript instead of templates, you can easily pass rich data through your app and keep state out of the DOM.
                    
                    </TextareaAutosize>
                    </div>
                </div>
            </Box>
        </div>

    )
}