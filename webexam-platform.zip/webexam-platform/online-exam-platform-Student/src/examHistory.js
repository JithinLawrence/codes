import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import { Link } from "react-router-dom";
import ListAltIcon from '@material-ui/icons/ListAlt';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import FormControl from '@material-ui/core/FormControl';
import { TextField } from '@material-ui/core';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    mainContainer: {
        width: "100%"
    },
    mainGridContainer: {
        flexGrow: 1,
    },
    mainGrid: {
        margin: "10px;",
        // height: "35% !important"
    },
    noDecLink:{
        textDecoration : "none",
    }
});

function createData(id, examName, startDate, expiredDate, totalQuestions, duration, applied, attended, result) {
    return { id, examName, startDate, expiredDate, totalQuestions, duration, applied, attended, result };
}

const rows = [
    createData(1, "exam1", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T10:30:00'), 10, "30 minutes", 0, 0, 0),
    createData(2, "exam2", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T10:30:00'), 10, "30 minutes", 0, 0, 0),
    createData(3, "exam3", new Date('2019-08-20T10:00:00'), new Date('2019-08-20T10:50:00'), 20, "50 minutes", 0, 0, 0),
    createData(4, "exam4", new Date('2019-08-21T10:00:00'), new Date('2019-08-21T10:50:00'), 20, "50 minutes", 1, 1, 1),
    createData(5, "exam5", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 1, 1, 1),
    createData(6, "exam6", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 1, 1, 1),
    createData(7, "exam7", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 1, 1, 1),
    createData(8, "exam8", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 1, 1, 1),

];


export default function ExamHistory() {
    const classes = useStyles();
    return (
        <div>
            <h1>Exam History</h1>
            <Divider></Divider>
            <Box className={classes.toolbar} display="flex" flexDirection="row-reverse">

    
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        ></TextField>
                    </FormControl>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Title</TableCell>
                            <TableCell align="center">Duration</TableCell>
                            <TableCell align="center">Schedule</TableCell>
                            <TableCell align="center">Result</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.examName}
                                </TableCell>
                                <TableCell align="center">{row.duration}</TableCell>
                                <TableCell align="center">{row.startDate.toDateString()} {row.startDate.getHours()}:{row.startDate.getMinutes()}</TableCell>
                                <TableCell align="center">
                                    <Link style={{ textDecoration: 'none', color: "black" }}  to="/result"> <ListAltIcon fontSize="default"/></Link>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}