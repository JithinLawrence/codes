import React from 'react';
import { makeStyles, useTheme } from "@material-ui/core/styles";
import { Typography, Grid } from '@material-ui/core';
import SingleAnswer from './sampleQuestions/singleAnswerType';
import MultipleAnswer from './sampleQuestions/multipleAnswerType';
import Box from '@material-ui/core/Box';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import Avatar from '@material-ui/core/Avatar';
import Chip from '@material-ui/core/Chip';
import { grey } from '@material-ui/core/colors';
import CountdownTimer from './countDownTimer';
import CssBaseline from '@material-ui/core/CssBaseline';
import clsx from 'clsx';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import useAppContext from './AppContext';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Link from '@material-ui/core/Link';
import { BrowserRouter as Router, Link as RouterLink, Switch, Route, useHistory } from 'react-router-dom';
import PlayCircleFilledWhiteIcon from '@material-ui/icons/PlayCircleFilledWhite';
import Card from '@material-ui/core/Card';
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import PropTypes from "prop-types";

const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({

    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    drawer: {
        justifyContent: 'center',
        backgroundColor: grey[400],
        borderColor: "secondary",
        flexWrap: 'wrap',
        height: '97vh',
    },
    catogories: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    questions: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    dialog: {
        padding: theme.spacing(3)
    },
    dialogTitle: {
        backgroundColor: theme.palette.primary.main,
    },
    catogoryChip: {
        margin: theme.spacing(0.5),
        backgroundColor: theme.palette.primary.main,
    },
    purple: {
        color: theme.palette.getContrastText(theme.palette.primary.main),
        backgroundColor: theme.palette.primary.main,
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    blue: {
        color: theme.palette.getContrastText(theme.palette.primary.main),
        backgroundColor: theme.palette.secondary.main,
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    caption: {
        margin: theme.spacing(3)
    },
    questionArea: {
        [theme.breakpoints.up('sm')]: {
            width: `calc(115% - ${drawerWidth}px)`,
        },

        paddingTop: theme.spacing(3)
    },
    nextbtn: {
        margin: theme.spacing(3)
    },
    prevbtn: {
        margin: theme.spacing(3)
    },
    timerDiv: {
        fontSize: 20,

    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    title: {
        flexGrow: 1,
    },
    content: {
        paddingTop: theme.spacing(5)
    },
    catTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        alignItems: "center",
        fontWeight: "bold",
        display: "flex",
    },
    catTitle: {
        marginLeft: "20px",
        alignSelf: "center"
    },
    catDetailP: {
        marginLeft: "10px",

    },
    grid: {
        [theme.breakpoints.up('sm')]: {
            width: `calc(115% - ${drawerWidth}px)`,
            marginLeft: theme.spacing(3)

        },
        paddingTop: theme.spacing(3),

    },
    attendButton: {
        margin: theme.spacing(2)
    },
    smPanel: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper
    }


}));
function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        "aria-controls": `simple-tabpanel-${index}`
    };
}

export default function Exam() {
    const classes = useStyles();
    const theme = useTheme();
    const smUp = useMediaQuery(theme.breakpoints.up('sm'));
    const drawerDisp = smUp ? '' : 'none';
    const smrawerDisp = smUp ? 'none' : '';
    const gridSpacing = smUp ? '10' : '3';
    const [value, setValue] = React.useState(-1);

    const handleChange = (event, newValue) => {
        if (newValue == value) {
            setValue(-1)
        } else {
            setValue(newValue);
        }
    };

    return (
        <>
            <Box className={classes.smPanel} flexGrow={1} display={smrawerDisp}>
                <AppBar position="sticky">
                    <Tabs
                        value={value}
                        aria-label="simple tabs example"
                        onChange={handleChange}
                    >
                        <Tab label="1" {...a11yProps(0)} />
                        <Tab label="2" {...a11yProps(1)} />
                        <Tab label="3" {...a11yProps(2)} />
                        <Tab label="4" {...a11yProps(3)} />
                        <Tab label="5" {...a11yProps(4)} />
                    </Tabs>
                </AppBar>
                <TabPanel value={value} index={0}>
                    <IconButton><Avatar className={classes.purple}>1</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>2</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>3</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>4</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>5</Avatar></IconButton>


                </TabPanel>
                <TabPanel value={value} index={1}>
                    <IconButton><Avatar className={classes.purple}>1</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>2</Avatar></IconButton>

                </TabPanel>
                <TabPanel value={value} index={2}>
                    <IconButton><Avatar className={classes.purple}>1</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>2</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>3</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>4</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>5</Avatar></IconButton>
                </TabPanel>
                <TabPanel value={value} index={3}>
                    <IconButton><Avatar className={classes.purple}>1</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>2</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>3</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>4</Avatar></IconButton>
                </TabPanel>
                <TabPanel value={value} index={4}>
                    <IconButton><Avatar className={classes.purple}>1</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>2</Avatar></IconButton>
                    <IconButton><Avatar className={classes.purple}>3</Avatar></IconButton>

                </TabPanel>
            </Box>
            <Box display="flex">
                <Box
                    color="primary"
                    variant="permanent"
                    width={drawerWidth}
                    className={classes.drawer}
                    display={drawerDisp}
                >
                    <Typography className={classes.caption} variant="h6">Catagory</Typography>
                    <Box className={classes.catogories}>
                        <IconButton><Avatar className={classes.purple}>1</Avatar></IconButton>
                        <IconButton><Avatar className={classes.purple}>2</Avatar></IconButton>
                        <IconButton><Avatar className={classes.purple}>3</Avatar></IconButton>
                        <IconButton><Avatar className={classes.purple}>4</Avatar></IconButton>
                        <IconButton><Avatar className={classes.purple}>5</Avatar></IconButton>
                    </Box>

                </Box>

                <Box className={classes.questionArea} flexWrap="wrap" display="flex">
                    <Box className={classes.questionArea} flexShrink={1} mx={2}>
                        <Box display="flex" alignItems="center">
                            <Box flex={1} justifyContent="right">
                                <Typography variant="h4">Examination 1</Typography>
                            </Box>
                            <Box justifyContent="left" className={classes.timerDiv}  >
                                <CountdownTimer start={false} ></CountdownTimer>
                            </Box>
                        </Box>
                        <Divider />
                        <div className={classes.question}>
                            <Grid container className={classes.grid} spacing={gridSpacing} alignItems="center">

                                <Grid item className={classes.gridItem} md={4} sm={6} xs={6} >
                                    <Card>
                                        <Box borderRadius={16}>
                                            <Box className={classes.catTitleDiv} display="flex">
                                                <Box mx={1} >
                                                    <Avatar className={classes.blue} >1</Avatar>
                                                </Box>
                                                <Box flexGrow={1} >
                                                    <Box display="flex" justifyContent="center" style={{ marginRight: theme.spacing(3) }}>
                                                        Biology
                                                </Box>
                                                </Box>
                                            </Box>
                                            <p className={classes.catDetailP} >Question Count: 5</p>
                                            <p className={classes.catDetailP} >Marks: 50</p>
                                            <Divider />
                                            <div className={classes.bottomDiv}>
                                                <Grid container justify="center" spacing={2} >
                                                    <Grid item xs={5.5}>
                                                        <Link component={RouterLink} to="/exam/catagory">
                                                            <Button variant="contained"
                                                                color="secondary"
                                                                justify="right"
                                                                className={classes.attendButton}>
                                                                <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
                                                        </Link>
                                                    </Grid>

                                                </Grid>
                                            </div>
                                        </Box>
                                    </Card>
                                </Grid>
                                <Grid item className={classes.gridItem} md={4} sm={6} xs={6}>
                                    <Card>
                                        <Box borderRadius={10}>
                                            <Box className={classes.catTitleDiv} display="flex">
                                                <Box mx={1} >
                                                    <Avatar className={classes.blue} >2</Avatar>
                                                </Box>
                                                <Box flexGrow={1} >
                                                    <Box display="flex" justifyContent="center" style={{ marginRight: theme.spacing(3) }}>
                                                        English
                                                </Box>
                                                </Box>
                                            </Box>
                                            <p className={classes.catDetailP} >Question Count: 5</p>
                                            <p className={classes.catDetailP} >Marks: 50</p>
                                            <Divider />
                                            <div className={classes.bottomDiv}>
                                                <Grid container justify="center" spacing={2}>
                                                    <Grid item xs={5.5}>
                                                        <Link component={RouterLink} to="/exam/catagory">
                                                            <Button variant="contained"
                                                                color="secondary"
                                                                justify="right"
                                                                className={classes.attendButton}>
                                                                <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
                                                        </Link>
                                                    </Grid>

                                                </Grid>
                                            </div>
                                        </Box>
                                    </Card>
                                </Grid>
                                <Grid item className={classes.gridItem} md={4} sm={6} xs={6}>
                                    <Card>
                                        <Box borderRadius={16}>
                                            <Box className={classes.catTitleDiv} display="flex">
                                                <Box mx={1} >
                                                    <Avatar className={classes.blue} >3</Avatar>
                                                </Box>
                                                <Box flexGrow={1} >
                                                    <Box display="flex" justifyContent="center" style={{ marginRight: theme.spacing(3) }}>
                                                        Chemistry
                                                </Box>
                                                </Box>
                                            </Box>
                                            <p className={classes.catDetailP} >Question Count: 5</p>
                                            <p className={classes.catDetailP} >Marks: 50</p>
                                            <Divider />
                                            <div className={classes.bottomDiv}>
                                                <Grid container justify="center" spacing={2}>
                                                    <Grid item xs={5.5}>
                                                        <Link component={RouterLink} to="/exam/catagory">
                                                            <Button variant="contained"
                                                                color="secondary"
                                                                justify="right"
                                                                className={classes.attendButton}>
                                                                <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
                                                        </Link>
                                                    </Grid>

                                                </Grid>
                                            </div>
                                        </Box>
                                    </Card>
                                </Grid>
                                <Grid item className={classes.gridItem} md={4} sm={6} xs={6}>
                                    <Card>
                                        <Box borderRadius={16}>
                                            <Box className={classes.catTitleDiv} display="flex">
                                                <Box mx={1} >
                                                    <Avatar className={classes.blue} >4</Avatar>
                                                </Box>
                                                <Box flexGrow={1} >
                                                    <Box display="flex" justifyContent="center" style={{ marginRight: theme.spacing(3) }}>
                                                        Physics
                                                </Box>
                                                </Box>
                                            </Box>
                                            <p className={classes.catDetailP} >Question Count: 5</p>
                                            <p className={classes.catDetailP} >Marks: 50</p>
                                            <Divider />
                                            <div className={classes.bottomDiv}>
                                                <Grid container justify="center" spacing={2}>
                                                    <Grid item xs={5.5}>
                                                        <Link component={RouterLink} to="/exam/catagory">
                                                            <Button variant="contained"
                                                                color="secondary"
                                                                justify="right"
                                                                className={classes.attendButton}>
                                                                <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
                                                        </Link>
                                                    </Grid>

                                                </Grid>
                                            </div>
                                        </Box>
                                    </Card>
                                </Grid>
                                <Grid item className={classes.gridItem} md={4} sm={6} xs={6}>
                                    <Card>
                                        <Box borderRadius={16}>
                                            <Box className={classes.catTitleDiv} display="flex">
                                                <Box mx={1} >
                                                    <Avatar className={classes.blue} >5</Avatar>
                                                </Box>
                                                <Box flexGrow={1} >
                                                    <Box display="flex" justifyContent="center" style={{ marginRight: theme.spacing(3) }}>
                                                        Maths
                                                </Box>
                                                </Box>
                                            </Box>
                                            <p className={classes.catDetailP} >Question Count: 5</p>
                                            <p className={classes.catDetailP} >Marks: 50</p>
                                            <Divider />
                                            <div className={classes.bottomDiv}>
                                                <Grid container justify="center" spacing={2}>
                                                    <Grid item xs={5.5}>
                                                        <Link component={RouterLink} to="/exam/catagory">
                                                            <Button variant="contained"
                                                                color="secondary"
                                                                justify="right"
                                                                className={classes.attendButton}>
                                                                <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
                                                        </Link>
                                                    </Grid>

                                                </Grid>
                                            </div>
                                        </Box>
                                    </Card>
                                </Grid>
                            </Grid>
                        </div>
                    </Box>

                </Box>
            </Box>
        </>
    )
}