import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import { Link } from "react-router-dom";
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import lightBlue from '@material-ui/core/colors/lightBlue';
import ListAltIcon from '@material-ui/icons/ListAlt';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import LaunchIcon from '@material-ui/icons/Launch';
import ExamRegister from './examRegister'
import ExamStart from './examStart';
import PlayCircleFilledWhiteIcon from '@material-ui/icons/PlayCircleFilledWhite';
import DoneOutlineTwoToneIcon from '@material-ui/icons/DoneOutlineTwoTone';
import ArrowForwardIosOutlinedIcon from '@material-ui/icons/ArrowForwardIosOutlined';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    mainContainer: {
        width: "100%"
    },
    mainGridContainer: {
        flexGrow: 1,
    },
    mainGrid: {
        margin: "10px;",
        // height: "35% !important"
    },
    examTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        textAlign: "center",
        paddingTop: "20px",
        fontWeight: "bold"
    },
    examDetailP: {
        marginLeft: "10px",

    },
    bottomDiv: {
        height: "auto",
        textAlign: "center"
    },
    reviewButton: {
        marginTop: "13%",
        marginBottom: "13%",
        backgroundColor: lightBlue[500] + " !important",
    },
    resultButton: {
        marginTop: "13%",
        marginBottom: "13%",
        backgroundColor: theme.palette.secondary.light + " !important",
    }
});

function createData(id, examName, startDate, expiredDate, totalQuestions, duration, applied, attended, result) {
    return { id, examName, startDate, expiredDate, totalQuestions, duration, applied, attended, result };
}

const rows = [
    createData(1, "exam1", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T10:30:00'), 10, "30 minutes", 0, 0, 0),
    createData(2, "exam2", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T10:30:00'), 10, "30 minutes", 0, 0, 0),
    createData(3, "exam3", new Date('2019-08-20T10:00:00'), new Date('2019-08-20T10:50:00'), 20, "50 minutes", 0, 0, 0),
    createData(4, "exam4", new Date('2019-08-21T10:00:00'), new Date('2019-08-21T10:50:00'), 20, "50 minutes", 1, 0, 0),
    createData(5, "exam5", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 1, 0, 0),

];

const rows2 = [
    createData(1, "exam01", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T08:30:00'), 10, "30 minutes",1,1,1),
    createData(2, "exam02", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T10:35:00'), 10, "30 minutes",1,1,1),
];

export default function DashBoard() {
    const classes = useStyles();
    const [examRegisterOpen, examRegisterSetOpen] = React.useState(false);
    const [examStartOpen, examStartSetOpen] = React.useState(false);

    const handleCloseExamRegister = hasChange => {
        examRegisterSetOpen(false);
    };
    const handleClickOpenExamRegister = () => {
        examRegisterSetOpen(true);
    };

    const handleCloseExamStart = hasChange => {
        examStartSetOpen(false);
    };
    const handleClickOpenExamStart = () => {
        examStartSetOpen(true);
    };

    function displayApplicationStatus(applied) {
        if (applied == 0) {
            return (
                <LaunchIcon onClick={handleClickOpenExamRegister} />
            );
        } else if (applied == 1) {
            return (
                <DoneOutlineTwoToneIcon />
            );
        }
    }
    function hasExamResult(result, id) {
        if (result === 0) {
            return (
                <Button variant="contained"
                    color="secondary"
                    justify="right"
                    disabled
                    className={classes.reviewButton}>
                    <ListAltIcon></ListAltIcon> Result</Button>
            );

        } else if (result === 1) {
            return (
                <Link to="/result" ><Button variant="contained"
                    color="secondary"
                    justify="right"
                    className={classes.reviewButton}>
                    <ListAltIcon></ListAltIcon> Result</Button>
                </Link>
            );
        }

    }

    function hasAttendedExam(attendence, id) {
        if (attendence === 0) {
            return (
                <Button variant="contained"
                    color="secondary"
                    justify="right"
                    className={classes.resultButton}
                    onClick={handleClickOpenExamStart}>
                    <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
            );

        } else if (attendence === 1) {
            return (
                <Button variant="contained"
                    color="secondary"
                    disabled
                    justify="right"
                    className={classes.resultButton} >
                    <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
            );
        }

    }

    return (
        <div>
            <br></br>
            <h2>Todays Exams</h2>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={10}>
                    <Grid container spacing={5}>
                        {rows2.map((item) => (
                            <Grid key={item.id} item md={3}>
                                <Card>
                                    <Box borderRadius={16}>
                                        <div className={classes.examTitleDiv}>
                                            {item.examName}
                                        </div>
                                        <p className={classes.examDetailP} >Start: {item.startDate.toDateString()} {item.startDate.getHours()}:{item.startDate.getMinutes()}</p>
                                        <p className={classes.examDetailP} >Time duration: {item.duration}</p>
                                        <Divider />
                                        <div className={classes.bottomDiv}>
                                            <Grid container justify="center" spacing={2}>
                                                <Grid item xs={5.5}>
                                                    <Button variant="contained"
                                                        color="secondary"
                                                        justify="right"
                                                        className={classes.resultButton}
                                                        onClick={handleClickOpenExamStart}>
                                                        <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
                                                </Grid>
                                                {/* <Grid item  xs={5.5}>

                                                    {hasExamResult(item.result, item.id)}

                                                </Grid> */}
                                            </Grid>
                                        </div>
                                    </Box>
                                </Card>
                            </Grid>
                        ))}
                    </Grid>
                </Grid>
            </Grid>

            <br></br>
            <br></br>



            <br></br>
            <br></br>
            <h2>Upcoming Exams</h2>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Title</TableCell>
                            <TableCell align="center">Duration</TableCell>
                            <TableCell align="center">Schedule</TableCell>
                            <TableCell align="center">Apply</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.examName}
                                </TableCell>
                                <TableCell align="center">{row.duration}</TableCell>
                                <TableCell align="center">{row.startDate.toDateString()} {row.startDate.getHours()}:{row.startDate.getMinutes()}</TableCell>
                                <TableCell align="center">
                                    {displayApplicationStatus(row.applied)}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                <Link style ={{float:"right", fontSize:"16px",color:"black", textDecoration:"none"}} to="/upcoming" >...View All</Link>
            </TableContainer>
            
            <ExamRegister open={examRegisterOpen} onClose={handleCloseExamRegister} />
            <ExamStart open={examStartOpen} onClose={handleCloseExamStart} />
        </div>
    );
}