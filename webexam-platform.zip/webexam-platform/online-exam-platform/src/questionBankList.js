import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import EditSharpIcon from '@material-ui/icons/EditSharp';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import { Link } from "react-router-dom";
import useAppContext from './AppContext';
import { TextField } from '@material-ui/core';
import QuestionBankCreate from './questionBankCreate';
import QuestionBankEdit from './questionBankEdit';
import ListIcon from '@material-ui/icons/List';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    }
});

function createData(title, catogory, grade, difficulty, marks, created_at) {
    return { title, catogory, grade, difficulty, marks,created_at };
}

const rows = [
    createData('QB1', 'Maths', 1, 'Hard', 24 , '1/05/2020 9:00'),
    createData('QB2', 'Science', 2, 'Easy', 37 ,'11/04/2020 9:00'),
    createData('QB3', 'History',1, 'Medium', 24, '21/04/2020 9:00'),
    createData('QB4', 'English', 4, 'Easy', 67, '22/03/2020 9:00'),
    createData('QB5', 'Chemistry',2, 'Hard', 49, '20/06/2020 9:00'),
];

export default function QuestionBankList() {
    const classes = useStyles();
    const [qBCreateOpen, setOpenQBCreate] = React.useState(false);

    const handleCloseQBCreate = hasChange => {
        setOpenQBCreate(false);
    };
    const handleClickOpenQBCreate = () => {
        setOpenQBCreate(true);
    };
    const [qBEditOpen, setOpenQBEdit] = React.useState(false);

    const handleCloseQBEdit = hasChange => {
        setOpenQBEdit(false);
    };
    const handleClickOpenQBEdit = () => {
        setOpenQBEdit(true);
    };
    return (
        <div>
            <h1>Question Bank List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

                <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                        <Button
                            variant="contained"
                            color="secondary"
                            justify="right"
                            onClick={handleClickOpenQBCreate}
                        >
                            Add Question Bank
                        </Button>
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                            label="Search"
                            id="titleSearch"
                        ></TextField>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-grade-label">Group</InputLabel>
                        <Select
                            labelId="select-grade-label"
                            id="select-grade"
                            value={""}
                        >
                            <MenuItem value={1}>1</MenuItem>
                            <MenuItem value={2}>2</MenuItem>
                            <MenuItem value={3}>3</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-catagory-label">Catagory</InputLabel>
                        <Select
                            labelId="select-catagory-label"
                            id="select-catagory"
                            value={""}
                        >
                            <MenuItem value={"maths"}>Maths</MenuItem>
                            <MenuItem value={"english"}>English</MenuItem>
                            <MenuItem value={"science"}>Science</MenuItem>
                        </Select>
                    </FormControl>
                    {/* <FormControl className={classes.formControl}>
                        <InputLabel id="select-difficulty-label">Difficulty</InputLabel>
                        <Select
                            labelId="select-difficulty-label"
                            id="select-difficulty"
                            value={""}
                        >
                            <MenuItem value={"hard"}>Hard</MenuItem>
                            <MenuItem value={"mediyum"}>Medium</MenuItem>
                            <MenuItem value={"easy"}>Easy</MenuItem>
                        </Select>
                    </FormControl> */}
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Name</TableCell>
                            <TableCell align="center">Questions</TableCell>
                            <TableCell align="center">Created at</TableCell>
                            {/* <TableCell align="right">Marks</TableCell> */}
                            <TableCell align="center">Action</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.title}
                                </TableCell>
                               <TableCell align="center"> <Link style={{ textDecoration: 'none', color: "black" }} color="inherit" color="inherit" to="questions"> <ListIcon /></Link></TableCell>
                                <TableCell align="center">{row.created_at}</TableCell>
                                <TableCell align="center"><EditSharpIcon fontSize="small" onClick={handleClickOpenQBEdit} />  <DeleteSharpIcon style={{ color: red[500] }} fontSize="small" /></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <QuestionBankCreate  open={qBCreateOpen} onClose={handleCloseQBCreate}  />
            <QuestionBankEdit  open={qBEditOpen} onClose={handleCloseQBEdit}  />
        </div>
    );
}