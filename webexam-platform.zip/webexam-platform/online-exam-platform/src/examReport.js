import React from 'react';
import Box from '@material-ui/core/Box'
import Grid from '@material-ui/core/Grid';
import PieChart from './charts/pieChart';
import BarChart from './charts/barChart';
import useAppContext from './AppContext';
import CanvasJSReact from './charts/canvasjs.react';



const boxProps = {
    display: "flex",
    bgcolor: 'background.paper',
    style: { height: '3rem' },
    borderLeft: '5px solid',
    borderColor: "secondary.main",
    justifyContent: "flex-start",
    margin: 1,
    padding: 1,
    boxShadow: 3
};
const chartsProps = {
    display: "flex",
    bgcolor: 'background.paper',
    justifyContent: "center",
    margin: 3,
    padding: 1,
};

const successData = [
    { label: 'pass', y: 33 },
    { label: 'fail', y: 57 },
];

const examStatusData = [
    { label: 'Applied', y: 20 },
    { label: 'Attended', y: 30 },
    { label: 'Incomplete', y: 40 },
    { label: 'Completed', y: 50 },
];
const scoreData = [
    { label: 'max score', y: 70 },
    { label: 'min score', y: 30 },
    { label: 'average score', y: 30 },
];

const scoreChartProps = {
    data: scoreData,
    title: 'Score analysis',
    width: '250',
    height: '500',
    valueField: 'y',
    argumentField: 'label',
    scaleName: 'zoom',
}
const successChartProps = {
    data: successData,
    title: 'pass/fail analysis',
    valueField: "y",
    argumentField: "label",
}
const examstatusChartProps = {
    data: examStatusData,
    title: 'Exam status/ Candidates count',
    width: '380',
    height: '500',
    valueField: "y",
    argumentField: "label"
}

export default function ExamReport() {
    var CanvasJS = CanvasJSReact.CanvasJS;
    var CanvasJSChart = CanvasJSReact.CanvasJSChart;

    const optionsStatus = {
        animationEnabled: true,
        theme: "light2",
        title: {
            text: "Exam status/ Candidates count",
            margin: 30,
            fontWeight: "normal",
            fontSize: 20
        },
        axisX: {
            title: "Status",
        },
        axisY: {
            title: "Count",
            reversed: false,

        },
        data: [{
            type: "column",
            dataPoints: examStatusData
        }]
    }
    const optionsScore = {
        animationEnabled: true,
        theme: "light2",
        title: {
            text: 'Score analysis',
            fontWeight: "normal",
            fontSize: 20,
            margin: 30,
        },
        axisX: {
            title: "Status",
        },
        axisY: {
            title: "Count",
            reversed: false,

        },
        data: [{
            type: "column",
            dataPoints: scoreData
        }]
    }
    const optionsSuccess = {
        theme: "light2",
        animationEnabled: true,
        exportEnabled: false,
        title:{
            fontWeight: "normal",
            margin: 30,
            text: 'pass/fail analysis',
            fontSize: 20,
        },
        creditText:"",
        data: [{
            type: "pie",
            showInLegend: true,
            legendText: "{label}",
            toolTipContent: "{label}: <strong>{y}%</strong>",
            indexLabel: "{y}%",
            indexLabelPlacement: "inside",
            dataPoints: successData
        }]
    }
    return (
        <div>
            <h1>Exam Report</h1>
            <Grid container spacing={4}>
                <Grid item  xs={12} sm={12} md={6}>
                    <Box  {...boxProps}>
                        Assigned candidates :20
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={6}>
                    <Box  {...boxProps}>
                        Attended candidates :15
                    </Box>
                </Grid>
                <Grid item  xs={12} sm={12} md={6}>
                    <Box  {...boxProps}>
                        Total Time: 30mins
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={6}>
                    <Box  {...boxProps}>
                        Total Questions : 5
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={6}>
                    <Box  {...boxProps}>
                        Candidates more than average score: 1
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={6}>
                    <Box  {...boxProps}>
                        Candidates less than average score: 1
                    </Box>
                </Grid>
            </Grid>
            <Grid container spacing={2} >
                <Grid item xs={12}  sm={12} md={4}>
                    <Box  {...chartsProps}>
                        {/* <Box><BarChart {...examstatusChartProps} /></Box> */}
                        <CanvasJSChart options={optionsStatus} />
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={4}>
                    <Box  {...chartsProps}>
                        {/* <BarChart {...scoreChartProps} /> */}
                        <CanvasJSChart options={optionsScore} />
                    </Box>
                </Grid>
                <Grid item xs={12} sm={12} md={4}>
                    <Box  {...chartsProps}>
                        {/* <PieChart {...successChartProps} /> */}
                        <CanvasJSChart options={optionsSuccess} />
                    </Box>
                </Grid>
            </Grid>
        </div>

    )
}