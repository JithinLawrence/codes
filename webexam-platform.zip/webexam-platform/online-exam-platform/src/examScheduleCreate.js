import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardTimePicker,
    KeyboardDatePicker,
} from '@material-ui/pickers';
import useAppContext from './AppContext';
import ExamAssign from './examAssign'


const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    datePicker: {
        marginLeft:theme.spacing(3),
    },
    datePickerContainer: {
        marginTop: theme.spacing(3),
    }


}));



export default function ExamSchedule() {
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);

    const handleClose = hasChange => {
        setOpen(false);
    };
    const handleClick = () => {
        setOpen(true);
    };

    const [selectedStartDate, setSelectedStartDate] = React.useState(new Date('2014-08-18T21:11:54'));
    const handleStartDateChange = (date) => {
        setSelectedStartDate(date);
    };
    const [selectedEndDate, setSelectedEndDate] = React.useState(new Date('2014-08-18T21:11:54'));
    const handleEndDateChange = (date) => {
        setSelectedEndDate(date);
    };

    return (
        <div >
            <h1>Create Exam Schedule</h1>
            <Box display="flex"  m={1} p={1}>
                <Box p={1}>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-exam-name-label">Exam name</InputLabel>
                        <Select
                            className={classes.inputField}
                            labelId="select-exam-name-label"
                            id="select-exam-name"
                            value={""}
                            required
                        >
                            <MenuItem value={"Exam 1"}>1</MenuItem>
                            <MenuItem value={"Exam 2"}>2</MenuItem>
                            <MenuItem value={"Exam 3"}>3</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
            </Box>
            <Grid container  >
                <Grid item sm={12} md={12} py={5}>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <Grid className={classes.datePickerContainer} container >
                            <KeyboardDatePicker
                                margin="normal"
                                className={classes.datePicker}
                                id="start-date-picker-dialog"
                                label="Exam schedule start date "
                                format="MM/dd/yyyy"
                                value={selectedStartDate}
                                onChange={handleStartDateChange}
                                KeyboardButtonProps={{
                                    'aria-label': 'change date',
                                }}
                            />
                            <KeyboardTimePicker
                                margin="normal"
                                className={classes.datePicker}
                                id="start-time-picker"
                                label="Exam schedule start time "
                                value={selectedStartDate}
                                onChange={handleStartDateChange}
                                KeyboardButtonProps={{
                                    'aria-label': 'change time',
                                }}
                            />
                        </Grid>
                    </MuiPickersUtilsProvider>
                </Grid>
                <Grid item sm={12} md={12}>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <Grid container className={classes.datePickerContainer} >
                            <KeyboardDatePicker
                                margin="normal"
                                className={classes.datePicker}
                                id="end-date-picker-dialog"
                                label="Exam schedule end date"
                                format="MM/dd/yyyy"
                                value={selectedEndDate}
                                onChange={handleEndDateChange}
                                KeyboardButtonProps={{
                                    'aria-label': 'change date',
                                }}
                            />
                            <KeyboardTimePicker
                                className={classes.datePicker}
                                margin="normal"
                                id="end-time-picker"
                                label="Exam schedule expire time"
                                value={selectedEndDate}
                                onChange={handleEndDateChange}
                                KeyboardButtonProps={{
                                    'aria-label': 'change time',
                                }}
                            />
                        </Grid>
                    </MuiPickersUtilsProvider>
                </Grid>

            </Grid>
            <Box display="flex" flex={1}  m={1} p={1}>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.assignBtn}
                    onClick={handleClick}
                >
                    Assign Candidates
                </Button>
                

            </Box>
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
            <Button
                    variant="contained"
                    className={classes.submitButton}
                >
                    Cancel
                </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.submitButton}
                >
                    Create
                </Button>

            </Box>
            <ExamAssign open={open} onClose={handleClose} />
        </div >
    )
}