import React from 'react';
import { Link } from "react-router-dom"; 

import Box from '@material-ui/core/Box';
import Divider from '@material-ui/core/Divider';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/Paper';
import Select from '@material-ui/core/Select';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { TextField } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

import ListIcon from '@material-ui/icons/List';

import theme from './theme';
import ExamPlannerAdd from './examPlannerAdd';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration : "none"
    }
});

function createData(id,firstName, lastName, email, grade) {
    return { id, firstName, lastName, email ,grade};
}

const rows = [
    createData(1, "Student1", "Student1", "student1@noemail.com", 3),
    createData(2, "Student1", "Student1", "student1@noemail.com", 4),
    createData(3, "Student1", "Student1", "student1@noemail.com", 8),
];



export default function CandidatesList(){
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);

    const handleClose = hasChange => {
        setOpen(false);
    };
    const handleClickOpen = () => {
        setOpen(true);
    };
    return (
        <div>
            <h1>Candidates List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar} display="flex" flexDirection="row-reverse">

    
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        ></TextField>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-grade-label">Group</InputLabel>
                        <Select
                            labelId="select-grade-label"
                            id="select-grade"
                            value={""}
                        >
                            <MenuItem value={1}>1</MenuItem>
                            <MenuItem value={2}>2</MenuItem>
                            <MenuItem value={3}>3</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
            </Box>
            <Box className={classes.toolbar}>

                {/* <Box flexGrow={1} alignContent="flex-start">
                    <Link>
                    <Button
                        variant="contained"
                        color="secondary"
                        className={classes.addButton}
                        onClick={handleClickOpen}
                    >
                      Add Exam Planner
                    </Button>
                    </Link>
                </Box> */}
                
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Id</TableCell>
                            <TableCell align="center">First Name</TableCell>
                            <TableCell align="center">Last Name</TableCell>
                            <TableCell align="center">Email</TableCell>
                            <TableCell align="center">Group</TableCell>
                            <TableCell align="center">Exam List</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.id}
                                </TableCell>
                                <TableCell align="center">{row.firstName}</TableCell>
                                <TableCell align="center">{row.lastName}</TableCell>
                                <TableCell align="center">{row.email}</TableCell>
                                <TableCell align="center">{row.grade}</TableCell>
                                <TableCell align="center"> <Link to="/studentsexam" style={{ textDecoration: 'none', color: "black" }}><ListIcon fontSize="default" /></Link></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <ExamPlannerAdd open={open} onClose={handleClose} />
        </div>
    )
}