import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid, IconButton } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import ExamCatogoryEdit from './examCatogoryEdit'
import ExamAddQuestions from './examAddQuestions';
import PageviewRoundedIcon from '@material-ui/icons/PageviewRounded';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
    },
    addButton: {
        marginTop: theme.spacing(3),
    },
    previewButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
}));

const rows = [
    createData('Maths', 'All', 10, 24),
    createData('Science', 'All', 20, 37),
    createData('Maths', 'All', 10, 24),
    createData('Science', 'All', 20, 37),
    createData('Maths', 'All', 10, 24),
    createData('Science', 'All', 20, 37),

];

function createData(subject, difficulty, marks, qCount) {
    return { subject, difficulty, marks, qCount };
}

export default function ExamCreate() {
    const classes = useStyles();

    const [open, setOpen] = React.useState(false);
    const [catOpen, setCatOpen] = React.useState(false);

    const handleClose = hasChange => {
        setOpen(false);
    };
    const handleCatClose = hasChange => {
        setCatOpen(false);
    };
    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleCatClick = () => {
        setCatOpen(true);
    };
    return (
        <div >
            <h1>Exam 1</h1>
            <Grid container>
                <Grid item sm={12} md={6}>
                    <FormControl className={classes.formControl}>
                        <TextField required id="name" value="Exam 1" className={classes.inputField} label="Exam Name" />
                    </FormControl>
                </Grid>
                <Grid item sm={12} md={6}>
                    <FormControl className={classes.formControl}>
                        <TextField id="duration" required className={classes.inputField} label="Duration of exam (in minutes)" />
                    </FormControl>
                </Grid>
                <Grid item sm={12} md={6}>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-exam-type-label">Exam type</InputLabel>
                        <Select
                            className={classes.inputField}
                            labelId="select-exam-type-label"
                            id="select-exam-type"
                            value={""}
                            required
                        >
                            <MenuItem value={"flexi"}>flexi</MenuItem>
                            <MenuItem value={"Fixed"}>Fixed</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item sm={12} md={6}>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-exam-schedule-label">Exam schedule type</InputLabel>
                        <Select
                            className={classes.inputField}
                            labelId="select-exam-schedule-label"
                            id="select-exam-schedule"
                            value={""}
                            required
                        >
                            <MenuItem value={1}>1</MenuItem>
                            <MenuItem value={2}>2</MenuItem>
                            <MenuItem value={3}>3</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid container>
                    <Button
                        variant="contained"
                        color="secondary"
                        className={classes.addButton}
                        onClick={handleClickOpen}
                    >
                        Add Question
                    </Button>
                </Grid>
            </Grid>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Subject</TableCell>
                            <TableCell align="right">Difficulty Level</TableCell>
                            <TableCell align="right">Marks</TableCell>
                            <TableCell align="right">Total Question Count</TableCell>
                            <TableCell align="right">Delete</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    <Button disableRipple onClick={handleCatClick}>{row.subject}</Button>
                                </TableCell>
                                <TableCell align="right">{row.difficulty}</TableCell>
                                <TableCell align="right">{row.marks}</TableCell>
                                <TableCell align="right">{row.qCount}</TableCell>
                                <TableCell align="right"><DeleteSharpIcon style={{ color: red[500] }} fontSize="small" /></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <Box display="flex" flex={1} justifyContent="center" m={2} p={1}>
                <Typography variant="h6"> Passing marks for exam/Total mark </Typography>
            </Box>
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                <TextField required flexGrow={1} id="passmark" label="" />/100
            </Box>
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                <Button
                    variant="contained"
                    className={classes.cancelButton}
                >
                    Cancel
                </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.submitButton}
                >
                    Submit
                </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.previewButton}
                >
                    <PageviewRoundedIcon />
                    Preview
                </Button>

            </Box>
            <ExamAddQuestions open={open} onClose={handleClose} />
            <ExamCatogoryEdit open={catOpen} onClose={handleCatClose} />
        </div >

    )
}