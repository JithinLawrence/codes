import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import EditSharpIcon from '@material-ui/icons/EditSharp';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import GroupAddRoundedIcon from '@material-ui/icons/GroupAddRounded';
import { Link } from "react-router-dom";
import useAppContext from './AppContext';
import { TextField } from '@material-ui/core';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    }
});

function createData(title, scheduleStart,scheduleEnd) {
    return { title, scheduleStart,scheduleEnd };
}

const rows = [
    createData('Exam 1', "1/02/2020 9:00"," 5/02/2020 19:00"),
    createData('Exam 2', "3/02/2020 9:00","5/02/2020 19:00"),
    createData('Exam 3', "1/05/2020 9:00","5/02/2020 19:00"),
    createData('Exam 4', "15/02/2020 9:00","25/02/2020 19:00"),
    createData('Exam 5', "1/07/2020 9:00","5/08/2020 19:00"),
];

export default function QuestionBank() {
    const classes = useStyles();

    return (
        <div>
            <h1>Exam Schedule List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

                <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                    <Link style={{ textDecoration: 'none', color: "black" }} to="/examschedulecreate" className={classes.btnprimary} >
                        <Button
                            variant="contained"
                            color="secondary"
                            justify="right"
                        >
                            Create Schedule
                    </Button>
                    </Link>
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        ></TextField>
                    </FormControl>
                </Box>
                
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Title</TableCell>
                            <TableCell align="right">Schedule Start</TableCell>
                            <TableCell align="right">Schedule End</TableCell>
                            <TableCell align="right">Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.title}
                                </TableCell>
                                <TableCell align="right">{row.scheduleStart}</TableCell>
                                <TableCell align="right">{row.scheduleEnd}</TableCell>
                                <TableCell align="right"><Link style={{ textDecoration: 'none', color: "black" }} to="/examcandidates"><GroupAddRoundedIcon fontSize="small" /></Link>&nbsp;&nbsp;<Link style={{ textDecoration: 'none', color: "black" }} to="/examscheduleedit"><EditSharpIcon fontSize="small" /></Link>  <DeleteSharpIcon style={{ color: red[500] }}  fontSize="small" /></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}