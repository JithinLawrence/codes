import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';


const useStyles = makeStyles((theme) => ({
  chkbxMain: {
  },
  formControl: {
    margin: theme.spacing(3),
  },
  imageUpload: {
      padding: '10px',
      color: 'white',
      backgroundColor: theme.palette.primary.main,
  }
}));

export default function SingleAnswerImage() {
  const classes = useStyles();
  const [checkedValue, setCheckedValue] = React.useState(10)
  const [optionsArray, setOptionsArray] = React.useState([{id:0, value:"option A"}, 
  {id:1,value:"option B"},
   {id:2,value:"option C"}, 
   {id:3,value:"option D"}]);

   const handleDeleteOption = id => {
    const list = [...optionsArray];
    list.splice(id, 1);
    setOptionsArray(resetOptionsArray(list));

    
  };

  const handleChange = e =>{
    setCheckedValue(e.target.value);
      setOptionsArray(optionsArray);
  }
  const handleInputChange = (e, id) => {
    const { name, value } = e.target;
    const list = [...optionsArray];
    list[id]["value"] = value;
    setOptionsArray(list);
  };

  const addCheckbox = () => {
    setOptionsArray(resetOptionsArray([...optionsArray, { id: 1, value: "new option" }]));
  };

  function resetOptionsArray(list){
    list.map(function(item,index){
      item["id"] = index;
    })
    return list;
  }

  return (
    <div className={classes.chkbxMain}>
        <div>
         <TableContainer component={Paper}>
         <Table className={classes.table} aria-label="simple table">
            <TableHead>
              <TableRow>
              <TableCell>Option</TableCell>
              <TableCell>Correct Answer</TableCell>
              <TableCell>Option Image</TableCell>
              <TableCell>Delete</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {optionsArray.map(function(item,index){
              return(
                <TableRow key={index} >
                <TableCell>option {item.id +1}</TableCell>
                <TableCell><Radio name={item.id + "radioOption"} value={item.id}  checked = {checkedValue == item.id} 
                onChange={handleChange}
                 > </Radio></TableCell>
                <TableCell> <input
                        accept="image/*"
                        className={classes.imageUpload}
                        // style={{ backgroundColor: 'rgb(85, 108, 214)', padding: "10px", color: 'white' }}
                        id="rais-button-file"
                        multiple
                        type="file"
                    /></TableCell>
                <TableCell><Button onClick={() => handleDeleteOption(index)} >
                    <DeleteSharpIcon style={{ color: red[500] }} fontSize="default" />
                    </Button></TableCell>
                </TableRow>
              )
            })}        
            </TableBody>   
         </Table>
         </TableContainer>
         </div>
      <div>
          <br></br>
          <br></br>
      <Button variant="contained" color="primary" onClick={addCheckbox} >
          Add option
      </Button>
      </div>
    <br></br>
    <br></br>
    </div>
    
  );
}
