import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Avatar from '@material-ui/core/Avatar';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import DialogActions from '@material-ui/core/DialogActions';
import Chip from '@material-ui/core/Chip';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 150,
        paddingRight: theme.spacing(2)
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        marginRight: theme.spacing(3),

    },
    submitButton: {
        marginLeft: theme.spacing(3),
    },
    table: {
        minWidth: 50,
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    dialog: {
        paddingTop: theme.spacing(8),
    },
    dialogActionsCenter: {
        justifyContent: "center",
        marginTop: theme.spacing(1),

    },
    dialogActionsLeft: {
        justifyContent: "left",
        marginBottom: theme.spacing(1),
        marginLeft: theme.spacing(2),
        paddingTop: 0
    },
    outerChipTotal: {
        color: "rgba(0, 0, 0, 0.87)",
        fontSize: "24px",
        // height: "auto",
        fontWeight: "normal",
        margin: "20px",
        backgroundColor: "white !important",
        boxShadow: "3px 3px 1px 1px #ccc;",
        textAlign: "left",
        height: "40px !important",
        width: "200px !important",

    },
    numberBoxTotal: {
        backgroundColor: theme.palette.secondary.light + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        width: theme.spacing(10),
        height: theme.spacing(10),
        marginLeft: theme.spacing(2),
        height: "40px !important",
        width: "40px !important",
    },
}));

const rows = [
    createData('what is Science', 'hard', 20),
    createData('what is Maths', 'easy', 10),
    createData('what is Science', 'medium', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),


];

function createData(title, difficulty, marks) {
    return { title, difficulty, marks };
}

export default function ExamCatogoryEdit({ open, onClose }) {

    const classes = useStyles();
    let totalMarks = 0;
    const [total, setTotal] = React.useState(0)
    const [updateTotal,setUpdateTotal] = React.useState(false)
    const handleChange = (e, i) => {
        rows[i].marks = e.target.value;
        setUpdateTotal(!updateTotal);
    }
    let i = 0;
    let x;
    React.useEffect(() => {
        for (x = 0; x < rows.length; x++) {
            totalMarks += parseInt(rows[x].marks);
            
        }
        setTotal(totalMarks);
    }, [updateTotal])
    return (
        <Dialog className={classes.dialog} fullWidth maxWidth="lg" open={open} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Edit Questions</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogActions className={classes.dialogActionsLeft}>
                <Box display="flex" style={{ width: '100%' }}>
                    <Box flexGrow={1}>
                        <Chip
                            className={classes.outerChipTotal}
                            color='secondary'
                            avatar={<Avatar className={classes.numberBoxTotal} >{total}</Avatar>}
                            label="Total Marks"
                        />

                    </Box>

                    <Box alignSelf="flex-end">
                        <FormControl className={classes.formControl} >
                            <TextField
                                label="Search"
                                id="titleSearch"
                            ></TextField>
                        </FormControl>
                    </Box>
                </Box>
            </DialogActions>
            <DialogContent>
                <TableContainer component={Paper} >
                    <Table className={classes.table} aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell >Title</TableCell>
                                <TableCell align="right">Difficulty</TableCell>
                                <TableCell align="right">Marks</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.map(function (row, index) {
                                return (
                                    <TableRow key={index}>
                                        <TableCell component="th" scope="row">{row.title}</TableCell>
                                        <TableCell align="right">{row.difficulty}</TableCell>
                                        <TableCell align="right"><TextField style={{ maxWidth: "40px" }} onChange={e => handleChange(e, index)} type="number" defaultValue={row.marks} /></TableCell>
                                    </TableRow>
                                )
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
            </DialogContent>
            <DialogActions className={classes.dialogActionsCenter}>
                <Button
                    variant="contained"
                    className={classes.cancelButton}
                    onClick={() => onClose()}
                >
                    cancel
                        </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.submitButton}
                >
                    Add
                        </Button>
            </DialogActions>
        </Dialog>
    )
}