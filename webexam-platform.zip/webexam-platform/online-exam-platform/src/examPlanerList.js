import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import { Link } from "react-router-dom"; 
import useAppContext from './AppContext';
import UserAdd from './examPlannerAdd';
import UserEdit from './examPlannerEdit';
import UserPasswordChange from './userPasswordChange';
import FormControl from '@material-ui/core/FormControl';
import { TextField } from '@material-ui/core';
import EditSharpIcon from '@material-ui/icons/EditSharp';


const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration : "none"
    }
});

function createData(id,firstName, lastName, email) {
    return { id, firstName, lastName, email};
}

const rows = [
    createData(1, "John", "Doe", "johnDoe@noemail.com"),
    createData(2, "Jane", "Doe", "janeDoe@noemail.com"),
    createData(3, "Sam", "Samuel", "S_Samuel@noemail.com"),
];



export default function UserList(){
    const classes = useStyles();

    const [openUserAdd, setOpenUserAdd] = React.useState(false);

    const handleCloseUserAdd = hasChange => {
        setOpenUserAdd(false);
    };
    const handleClickOpenUserAdd = () => {
        setOpenUserAdd(true);
    };

    const [openUserEdit, setOpenUserEdit] = React.useState(false);

    const handleCloseUserEdit = hasChange => {
        setOpenUserEdit(false);
    };

    const handleCloseUserEditPassword = hasChange => {
        setOpenUserEdit(false);
        setOpenUserPasswordChange(true);
    };

    const handleClickOpenUserEdit = () => {
        setOpenUserEdit(true);
    };


    const [openUserPasswordChange, setOpenUserPasswordChange] = React.useState(false);

    const handleCloseUserPasswordChange = hasChange => {
        setOpenUserPasswordChange(false);
    };
    const handleClickOpenUserPasswordChange = () => {
        setOpenUserEdit(false);
        setOpenUserPasswordChange(true);
    };


    return (
        <div>
            <h1>User List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

                <Box flexGrow={1} margin={2.5}  alignContent="flex-start">
                    <Button
                        variant="contained"
                        color="secondary"
                        className={classes.addButton}
                        onClick={handleClickOpenUserAdd}
                    >
                      Add User
                    </Button>
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        ></TextField>
                    </FormControl>
                </Box>
                
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Id</TableCell>
                            <TableCell align="center">First Name</TableCell>
                            <TableCell align="center">Last Name</TableCell>
                            <TableCell align="center">Email</TableCell>
                            <TableCell align="center">Edit</TableCell>
                            <TableCell align="center">Delete</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.id}
                                </TableCell>
                                <TableCell align="center">{row.firstName}</TableCell>
                                <TableCell align="center">{row.lastName}</TableCell>
                                <TableCell align="center">{row.email}</TableCell>
                                <TableCell align="center"> <EditSharpIcon fontSize="small" onClick={handleClickOpenUserEdit} /></TableCell>
                                <TableCell align="center"> <DeleteSharpIcon style={{ color: red[500] }} fontSize="small" /></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <UserAdd open={openUserAdd} onClose={handleCloseUserAdd} />
            <UserEdit open={openUserEdit} onClose={handleCloseUserEdit}   onPasswordChangeBegin={handleCloseUserEditPassword}  />
            <UserPasswordChange open={openUserPasswordChange} onClose={handleCloseUserPasswordChange} />
        </div>
    )
}

