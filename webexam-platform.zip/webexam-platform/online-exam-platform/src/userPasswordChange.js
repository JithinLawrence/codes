import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';


const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
        marginLeft: "10px"
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
}));
function createData(title, difficulty, marks) {
    return { title, difficulty, marks };
}
const rows = [
    createData('what is Science', 'hard', 20),
    createData('what is Maths', 'easy', 10),
    createData('what is Science', 'medium', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),

];


export default function UserPasswordChange({ open, onClose }) {
    const classes = useStyles();

    return(
        <Dialog  maxWidth="lg" open={open} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Change User Password</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
                <div >
                <Grid container>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>
                        {/* <InputLabel id="old-password-label">Password</InputLabel> */}
                            <TextField
                            type="Password"
                            fullWidth
                            label="Old Password"
                            id="oldPassword"
                            labelId ="old-password-label">
                            </TextField>
                            </FormControl>
                    </Grid>    
                    {/* <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>
                    <InputLabel id="last-name-label">Last Name</InputLabel>
                        <TextField
                        label="Last Name"
                        id="plannerLastName"
                        labelId ="last-name-label">
                        </TextField>
                        </FormControl>
                    </Grid>     */}
                </Grid>
                <br></br>
                <Grid container>
                    
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>
                        {/* <InputLabel id="new-password-label">Password</InputLabel> */}
                            <TextField
                            type="Password"
                            fullWidth
                            label="newPassword"
                            id="newPassword"
                            labelId ="new-password-label">
                            </TextField>
                            </FormControl>
                    </Grid>
                </Grid>

                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            onClick={() => onClose()}
                        >
                            Submit
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            color="error."
                            onClick={() => onClose()}
                        >
                            cancel
                        </Button>
                    </Box>
                </div >
            </DialogContent>
        </Dialog>
    
    )
}