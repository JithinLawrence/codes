import React from 'react';
import theme from './theme';
import Avatar from '@material-ui/core/Avatar';
import Box from '@material-ui/core/Box'
import Chip from '@material-ui/core/Chip';
import FormControl from '@material-ui/core/FormControl';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import pink from '@material-ui/core/colors/pink';
import lightGreen from '@material-ui/core/colors/lightGreen';
import lightBlue from '@material-ui/core/colors/lightBlue';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { TextField } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

import SearchIcon from '@material-ui/icons/Search';
import ListAltIcon from '@material-ui/icons/ListAlt';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },


    mainGrid:{
        margin: "50px;",
        // height: "35% !important"
    },
    examTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        textAlign: "center",
        paddingTop: "20px",
        fontWeight: "bold"
    },
    examDetailP: {
        marginLeft: "10px",

    },
    bottomDiv: {
        height: "80px",
        textAlign: "center"
    },
    numberBoxTotal:{
        backgroundColor: "#b24c00 !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",
    },
    numberBox1: {
        backgroundColor: theme.palette.secondary.main + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    numberBox2: {
        backgroundColor: lightGreen['A700'] + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    numberBox3: {
        backgroundColor: pink[500] + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    outerChip: {
        color: "rgba(0, 0, 0, 0.87)",
        fontSize: "16px",
        height: "auto",
        fontWeight: "normal",
        margin:"20px",
        backgroundColor : "white !important",
        boxShadow :"3px 3px 1px 1px #ccc;",
        textAlign:"left",
        width:"150px",
        // paddingRight:"65px",


    },
    outerChipTotal: {
        color: "rgba(0, 0, 0, 0.87)",
        fontSize: "16px",
        height: "auto",
        fontWeight: "normal",
        margin:"20px",
        backgroundColor : "white !important",
        boxShadow :"3px 3px 1px 1px #ccc;",
        textAlign:"left",
        width:"150px",
        paddingRight:"65px",

    },
    reviewButton: {
        marginTop: "10%",
        backgroundColor: lightBlue[500] + " !important",
    },
    resultButton: {
        marginTop: "10%",
        backgroundColor: theme.palette.secondary.light + " !important",
    }
});

function createData(id, examName, startDate, expiredDate, totalQuestions, duration, applied, attended, result) {
    return { id, examName, startDate, expiredDate, totalQuestions, duration, applied, attended, result };
}

const rows = [
    createData(1, "exam1", new Date('2019-08-18T10:00:00'), new Date('2019-08-18T10:30:00'), 10, "30 minutes", 0, 0, 0),
    createData(3, "exam3", new Date('2019-08-20T10:00:00'), new Date('2019-08-20T10:50:00'), 20, "50 minutes", 0, 0, 0),
    createData(4, "exam4", new Date('2019-08-21T10:00:00'), new Date('2019-08-21T10:50:00'), 20, "50 minutes", 1, 1, 1),
    createData(5, "exam5", new Date('2019-08-22T10:00:00'), new Date('2019-08-22T10:40:00'), 15, "40 minutes", 1, 1, 1),

];

export default function CandidatesExamList() {
    const classes = useStyles();

    return (
        <div> 
            <h2>Exam List</h2>          
            <Grid container>
                <Grid item md={3} sm={6}>
                    <Chip
                        className={classes.outerChipTotal}
                        color='secondary'
                        avatar={<Avatar color='secondary' className={classes.numberBoxTotal} >6</Avatar>}
                        label="All"
                    />
                </Grid>
                <Grid item md={3} sm={6}>
                    <Chip
                        className={classes.outerChip}
                        color='secondary'
                        avatar={<Avatar color='secondary' className={classes.numberBox1} >6</Avatar>}
                        label="Completed"
                    />
                </Grid>
                <Grid item md={3} sm={6}>
                    <Chip
                        className={classes.outerChip}
                        color='secondary'
                        avatar={<Avatar color='secondary' className={classes.numberBox2} >0</Avatar>}
                        label="Yet to start"
                    />
                </Grid>
                <Grid item md={3} sm={6}>
                    <Chip
                        className={classes.outerChip}
                        color='secondary'
                        avatar={<Avatar color='secondary' className={classes.numberBox3} >0</Avatar>}
                        label="Expired"startDate
                    />
                </Grid>
            </Grid>
            {/* <Grid container>
                {rows.map((item) => (

                    <Grid item className={classes.mainGrid} md={4} sm={6}>

                        <Card>
                            <Box borderRadius={16}>
                                <div className={classes.examTitleDiv}>
                                    {item.examName}
                                </div>
                <p className={classes.examDetailP} >Start: {item.startDate.toDateString()} {item.startDate.getHours()}:{item.startDate.getMinutes()}</p>
                <p className={classes.examDetailP} >Expired: {item.expiredDate.toDateString()} {item.expiredDate.getHours()}:{item.expiredDate.getMinutes()}</p>
                <p className={classes.examDetailP} >No of Question: {item.totalQuestions}</p>
                <p className={classes.examDetailP} >Time duration: {item.duration}</p>
                                <Divider />
                                <div className={classes.bottomDiv}>
                                    <Grid container>
                                    <Grid item md={6} sm={6}>
                                    <Button variant="contained"
                                        color="secondary"
                                        justify="right"
                                        className={classes.resultButton} >
                                        <ListAltIcon></ListAltIcon> Result</Button>
                                    </Grid>
                                    <Grid item md={6} sm={6}>
                                    <Button variant="contained"
                                        color="secondary"
                                        justify="right"
                                        className={classes.reviewButton}>
                                        <SearchIcon></SearchIcon> Review</Button>
                                        </Grid>
                                    </Grid>
                                </div>
                            </Box>
                        </Card>

                    </Grid>


                ))}


            </Grid> */}

            
            <Box className={classes.toolbar} display="flex" flexDirection="row-reverse">

    
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        ></TextField>
                    </FormControl>
                    {/* <FormControl className={classes.formControl}>
                        <InputLabel id="select-grade-label">Group</InputLabel>
                        <Select
                            labelId="select-grade-label"
                            id="select-grade"
                            value={""}
                        >
                            <MenuItem value={1}>1</MenuItem>
                            <MenuItem value={2}>2</MenuItem>
                            <MenuItem value={3}>3</MenuItem>
                        </Select>
                    </FormControl> */}
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Title</TableCell>
                            <TableCell align="center">Duration</TableCell>
                            <TableCell align="center">Schedule</TableCell>
                            <TableCell align="center">Total Questions</TableCell>
                            <TableCell align="center">Result</TableCell>
                            <TableCell align="center">Review</TableCell>
                            {/* <TableCell align="center">Apply</TableCell> */}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.examName}
                                </TableCell>
                                <TableCell align="center">{row.duration}</TableCell>
                                <TableCell align="center">{row.startDate.toDateString()} {row.startDate.getHours()}:{row.startDate.getMinutes()}</TableCell>
                                {/* <TableCell align="center">
                                    {displayApplicationStatus(row.applied)}
                                </TableCell> */}
                                <TableCell align="center">{row.totalQuestions}</TableCell>
                                <TableCell align="center"> <ListAltIcon></ListAltIcon></TableCell>
                                <TableCell align="center"><SearchIcon></SearchIcon></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}