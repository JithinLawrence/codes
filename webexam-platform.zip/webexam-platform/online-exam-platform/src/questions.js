import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import EditSharpIcon from '@material-ui/icons/EditSharp';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import { Link } from "react-router-dom";
import useAppContext from './AppContext';
import { TextField } from '@material-ui/core';
import SingleAnswer from './sampleQuestions/singleAnswerType';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import PageviewRoundedIcon from '@material-ui/icons/PageviewRounded';


const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    dialog: {
        padding: theme.spacing(1),
    },
    dialogTitle: {
        backgroundColor: theme.palette.grey[300],
    }, 
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
});

function createData(title, catogory, grade, difficulty, marks) {
    return { title, catogory, grade, difficulty, marks };
}

const rows = [
    createData('What is Frozen yoghurt', 'Maths', 1, 'Hard', 24),
    createData('What is Ice cream sandwich', 'Science', 2, 'Easy', 37),
    createData('What is Eclair', 'English', 1, 'Medium', 24),
    createData('What is Cupcake', 'Maths', 4, 'Easy', 67),
    createData('What is Gingerbread', 'Science', 2, 'Hard', 49),
];

export default function Questions() {
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);

    const handleClose = hasChange => {
        setOpen(false);
    };
    const handlePreview = () => {
        setOpen(true);
    };
    return (
        <div>
            <h1>Question List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

                <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                    <Link style={{ textDecoration: 'none', color: "black" }} to="/questioncreate" className={classes.btnprimary} >
                        <Button
                            variant="contained"
                            color="secondary"
                            justify="right"
                        >
                            Add Question
                        </Button>
                    </Link>
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                            label="Search"
                            id="titleSearch"
                        ></TextField>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-grade-label">Group</InputLabel>
                        <Select
                            labelId="select-grade-label"
                            id="select-grade"
                            value={""}
                        >
                            <MenuItem value={1}>1</MenuItem>
                            <MenuItem value={2}>2</MenuItem>
                            <MenuItem value={3}>3</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-catagory-label">Catagory</InputLabel>
                        <Select
                            labelId="select-catagory-label"
                            id="select-catagory"
                            value={""}
                        >
                            <MenuItem value={"maths"}>Maths</MenuItem>
                            <MenuItem value={"english"}>English</MenuItem>
                            <MenuItem value={"science"}>Science</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-difficulty-label">Difficulty</InputLabel>
                        <Select
                            labelId="select-difficulty-label"
                            id="select-difficulty"
                            value={""}
                        >
                            <MenuItem value={"hard"}>Hard</MenuItem>
                            <MenuItem value={"mediyum"}>Medium</MenuItem>
                            <MenuItem value={"easy"}>Easy</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Title</TableCell>
                            <TableCell align="right">Catagory</TableCell>
                            <TableCell align="right">Group</TableCell>
                            <TableCell align="right">Difficulty</TableCell>
                            <TableCell align="right">Marks</TableCell>
                            <TableCell align="right">Preview</TableCell>
                            <TableCell align="right">Action</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows.map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">
                                    {row.title}
                                </TableCell>
                                <TableCell align="right">{row.catogory}</TableCell>
                                <TableCell align="right">{row.grade}</TableCell>
                                <TableCell align="right">{row.difficulty}</TableCell>
                                <TableCell align="right">{row.marks}</TableCell>
                                <TableCell align="right"><PageviewRoundedIcon onClick={handlePreview} fontSize="small" /></TableCell>
                                <TableCell align="right"><Link style={{ textDecoration: 'none', color: "black" }} to="/questionedit"><EditSharpIcon fontSize="small" /></Link>  <DeleteSharpIcon style={{ color: red[500] }} fontSize="small" /></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            < QuestionPreview isOpen={open} onClose={handleClose} />
        </div>
    );
}

function QuestionPreview({ isOpen, onClose }) {
    const classes = useStyles();
    const [qno, setQno] = React.useState(1);
    const [btntext, setBtntext] = React.useState("next");
    const handleNext = () => {
        setQno(qno + 1);
    };
    const handlePrev = () => {
        setQno(qno - 1);
    };
    return (
        <Dialog className={classes.dialog} fullWidth maxWidth="sm" open={isOpen} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" className={classes.dialogTitle} disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Preview</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
            </DialogTitle>
            <DialogContent>
                <SingleAnswer />
            </DialogContent>
        </Dialog>
    )
}