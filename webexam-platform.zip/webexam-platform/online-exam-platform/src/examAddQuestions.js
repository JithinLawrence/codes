import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import DialogActions from '@material-ui/core/DialogActions';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 150,
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        marginRight: theme.spacing(3),

    },
    submitButton: {
        marginLeft: theme.spacing(3),
    },
    table: {
        minWidth: 50,
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    dialog: {
        paddingTop: theme.spacing(8),
    },
    dialogActionsCenter: {
        justifyContent: "center",
        marginTop: theme.spacing(1),

    },
    dialogActionsLeft: {
        justifyContent: "left",
        marginBottom: theme.spacing(1),
        marginLeft: theme.spacing(2),
        paddingTop: 0
    }
}));

const rows = [
    createData('what is Science', 'hard', 20),
    createData('what is Maths', 'easy', 10),
    createData('what is Science', 'medium', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),
    

];

function createData(title, difficulty, marks) {
    return { title, difficulty, marks };
}

export default function ExamAddQuestions({ open, onClose }) {
    const classes = useStyles();
    return (
        <Dialog className={classes.dialog} fullWidth maxWidth="lg" open={open} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Add Questions</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogActions className={classes.dialogActionsLeft}>
                <Grid container>
                    <Grid item xs={12} sm={6} md={3}>
                        <FormControl className={classes.formControl}>
                            <InputLabel id="select-subject-label">Question Bank</InputLabel>
                            <Select
                                className={classes.inputField}
                                labelId="select-subject-label"
                                id="select-subject"
                                value={""}
                                required
                            >
                                <MenuItem value={1}>Qustion bank1</MenuItem>
                                <MenuItem value={2}>Qustion bank2</MenuItem>
                                <MenuItem value={3}>Qustion bank3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={6} md={3}>
                        <FormControl className={classes.formControl}>
                            <InputLabel id="select-subject-label">Catagory</InputLabel>
                            <Select
                                className={classes.inputField}
                                labelId="select-subject-label"
                                id="select-subject"
                                value={""}
                                required
                            >
                                <MenuItem value={1}>1</MenuItem>
                                <MenuItem value={2}>2</MenuItem>
                                <MenuItem value={3}>3</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12}  sm={6} md={3}>
                        <FormControl className={classes.formControl}>
                            <InputLabel id="select-Difficulty-label">Difficulty</InputLabel>
                            <Select
                                className={classes.inputField}
                                labelId="select-difficulty-label"
                                id="select-difficulty"
                                value={""}
                                required
                            >
                                <MenuItem value={"hard"}>hard</MenuItem>
                                <MenuItem value={"easy"}>easy</MenuItem>
                                <MenuItem value={"medium"}>medium</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12}  sm={6} md={3}>
                        <FormControl className={classes.formControl}>
                            <TextField
                                label="Search"
                                id="titleSearch"
                            ></TextField>
                        </FormControl>
                    </Grid>
                </Grid>
            </DialogActions>
            <DialogContent>
                <TableContainer component={Paper} >
                    <Table className={classes.table} aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell>Select</TableCell>
                                <TableCell >Title</TableCell>
                                <TableCell align="right">Difficulty</TableCell>
                                <TableCell align="right">Marks</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.map((row) => (
                                <TableRow key={row.name}>
                                    <TableCell padding="checkbox">
                                        <Checkbox />
                                    </TableCell>
                                    <TableCell component="th" scope="row">{row.title}</TableCell>
                                    <TableCell align="right">{row.difficulty}</TableCell>
                                    <TableCell align="right">{row.marks}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </DialogContent>
            <DialogActions className={classes.dialogActionsCenter}>
                <Button
                    variant="contained"
                    className={classes.cancelButton}
                    onClick={() => onClose()}
                >
                    cancel
                        </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.submitButton}
                >
                    Add
                        </Button>
            </DialogActions>
        </Dialog>
    )
}