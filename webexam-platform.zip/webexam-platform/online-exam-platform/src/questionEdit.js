import React, { useState, useEffect } from 'react';
import { Container } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import CKEditor from '@ckeditor/ckeditor5-react';  
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import SingleAnswer from './questionType/singleAnswerType';
import MultipleAnswer from './questionType/multipleAnswerType';
import useAppContext from './AppContext';

// NOTE: Use the editor from source (not a build)!

const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(1),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
    imageUpload: {
        padding: '10px',
        color: 'white',
        backgroundColor: theme.palette.primary.main,
    }
}));

export default function QuestionEdit() {
    const[mark,setMark] = useState("0");
    const classes = useStyles();
    const[ckd,setCkd] = useState("--");
    const[questionType,setQuestionType] = useState(0);

    function QuestionTypeSelected(){
        if(questionType == 1){
            return(
                <SingleAnswer></SingleAnswer>
            );
        }else if (questionType == 2){
            return(
                <MultipleAnswer></MultipleAnswer>
            );
        }else{
            return("");
        }
    }

    const selectQuestionType = (event) =>{
        setQuestionType(event.target.value);
    }

    useEffect(() => {
        document
          .querySelector("input[type='number']")
          .addEventListener("keypress", evt => {
            if (evt.which === 8) {
              return;
            }
            if (evt.which < 48 || evt.which > 57) {
              evt.preventDefault();
            }
          });
      }, []);
      
    return (
        
       
        <Container component="main" fixed>
            <h1>Edit Question</h1>
            <div className={classes.paper}>
                <form className={classes.form} noValidate>
                    <Grid container className={classes.root} spacing={2} fullWidth>
                        <Grid item xs={6} >
                            <label>Catgeory/Subject</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-category-select-label" >Category/Subject *</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-category-select-label"
                                    id="question-category-select"
                                    label="Category/Subject"
                                    required
                                >

                                    <MenuItem value="">
                                        <em>Select</em>
                                    </MenuItem>
                                    <MenuItem value="1">English</MenuItem>
                                    <MenuItem value="2">Mathematics</MenuItem>
                                    <MenuItem value="3">Science</MenuItem>
                                    <MenuItem value="4">History</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={6}>
                            <label>Grade Level</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-grade-level-label" >Grade Level *</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-grade-level-label"
                                    id="question-grade-level"
                                    label="GradeLevel"
                                    required
                                >
                                    <MenuItem value="">
                                        <em>Select</em>
                                    </MenuItem>
                                    <MenuItem value="1">1</MenuItem>
                                    <MenuItem value="2">2</MenuItem>
                                    <MenuItem value="3">3</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>



                    <Grid container className={classes.root} spacing={2} fullWidth>
                        <Grid item xs={6} >
                            <label>Question type</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-type-select-label" >Question Type *</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-type-select-label"
                                    id="question-type-select"
                                    label="QuestionType"
                                    required
                                    onChange={selectQuestionType}
                                >
                                    <MenuItem value="">
                                        <em>Select</em>
                                    </MenuItem>
                                    <MenuItem value="1">Single Answer</MenuItem>
                                    <MenuItem value="2">Multiple Answer</MenuItem>
                                    <MenuItem value="3">Text Input</MenuItem>
                                    <MenuItem value="4">Image Type</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={6}>
                            <label>Difficulty Level</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-creation-level-label" >Difficulty level *</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-difficulty-level-label"
                                    id="question-difficulty-level"
                                    label="DifficultyLevel"
                                    required
                                >
                                    <MenuItem value="">
                                        <em>Select</em>
                                    </MenuItem>
                                    <MenuItem value="1">Easy</MenuItem>
                                    <MenuItem value="2">Medium</MenuItem>
                                    <MenuItem value="3">Hard</MenuItem> 
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={6} >
                            <label>Question Bank</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-creation-QB-label" >QB</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-creation-QB-label"
                                    id="question-creation-QB"
                                    label="Question Bank"
                                    required
                                >
                                    <MenuItem value="">
                                        <em>Select</em>
                                    </MenuItem>
                                    <MenuItem value="1">QB1</MenuItem>
                                    <MenuItem value="2">QB2</MenuItem>
                                    <MenuItem value="3">QB3</MenuItem>
                                </Select>
                            </FormControl>

                        </Grid>
                    </Grid>

                    <br></br>

                    <input
                        accept="image/*"
                        className={classes.imageUpload}
                        // style={{ backgroundColor: 'rgb(85, 108, 214)', padding: "10px", color: 'white' }}
                        id="rais-button-file"
                        multiple
                        type="file"
                    />
                    <br></br>
                    <br></br>
                    <label>Question Title</label>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="questionTitle"
                        label="Question Title"
                        name="title"
                        autoComplete="title"
                    />
                    <br></br>
                <br></br>
                <div>
                <label>Description</label>
                <br></br>
                <br></br>
                <CKEditor  
                    editor={ ClassicEditor }  
                    data=""  
                    onInit={ editor => {  
                        // You can store the "editor" and use when it is needed.  
                        console.log( 'Editor is ready to use!', editor );  
                    } }  
                    onChange={ ( event, editor ) => {  
                        const data = editor.getData();  
                        setCkd(data);
                        console.log( { event, editor, data } );  
                    } }  
                    onBlur={ ( event, editor ) => {  
                        console.log( 'Blur.', editor );  
                    } }  
                    onFocus={ ( event, editor ) => {  
                        console.log( 'Focus.', editor );  
                    } }  
                />  
                </div>
                    <br></br>
                    <br></br>
                    <label>Marks*</label>
                    <br></br>
                    <TextField
                        id="question-marks"
                        type="number"
                        InputLabelProps={{
                            shrink: true
                        }}
                    />
                    <br></br>
                    <br></br>
                    <br></br>
                    
                    <div className="questionTypeSelected">
                    <Grid>
                        <QuestionTypeSelected></QuestionTypeSelected>
                    </Grid>
                    </div>

                    <label>Correct Answer</label>
                    <br></br>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        
                        id="correctAnswer"
                        label="Correct Answer"
                        name="answer"
                    />


                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        color="primary"
                        className={classes.submit}
                    >
                        Create Question
              </Button>
                </form>
            </div>
            <Box mt={8}>
            </Box>
        </Container>
    );
}