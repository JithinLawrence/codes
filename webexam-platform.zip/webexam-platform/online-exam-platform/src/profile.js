import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    grid: {
        justifyContent: "center"
    }
}));

function PasswordChange({ open, onClose }) {
    const classes = useStyles();

    return (
        <Dialog maxWidth="lg" open={open} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Change Password</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
                <div >
                    <Grid container>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="first-name-label">First Name</InputLabel> */}
                            <TextField

                                label="Current Password"
                                labelId="current-password-label"
                                fullWidth
                                type="password"
                                id="currentPassword">
                            </TextField>
                        </Grid>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="last-name-label">Last Name</InputLabel> */}
                            <TextField
                                label="New Password"
                                id="newPassword"
                                fullWidth
                                type="password"
                                labelId="new-password-label">
                            </TextField>
                        </Grid>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="email-label">Email</InputLabel> */}
                            <TextField
                                fullWidth
                                label="Confirm new password"
                                id="confirmNewPassword"
                                type="password"
                                labelId="confirm-new-password-label">
                            </TextField>
                        </Grid>

                    </Grid>
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                        >
                            Submit
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            onClick={() => onClose()}
                        >
                            cancel
                        </Button>
                    </Box>
                </div >
            </DialogContent>
        </Dialog >

    )
}

function ProfileChange({ open, onClose }) {
    const classes = useStyles();

    return (
        <Dialog maxWidth="lg" open={open} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Edit Profile</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
                <div >
                    <Grid container>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="first-name-label">First Name</InputLabel> */}
                            <TextField

                                label="First Name"
                                labelId="first-name-label"
                                fullWidth
                                id="plannerFirstName">
                            </TextField>
                        </Grid>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="last-name-label">Last Name</InputLabel> */}
                            <TextField
                                label="Last Name"
                                id="plannerLastName"
                                fullWidth
                                labelId="last-name-label">
                            </TextField>
                        </Grid>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="email-label">Email</InputLabel> */}
                            <TextField
                                type="email"
                                fullWidth
                                label="Email"
                                id="email"
                                labelId="email-label">
                            </TextField>
                        </Grid>

                    </Grid>
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                        >
                            Submit
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            color="error."
                            onClick={() => onClose()}
                        >
                            cancel
                        </Button>
                    </Box>
                </div >
            </DialogContent>
        </Dialog >

    )
}

export default ProfileChange;
export { PasswordChange };
