import React from 'react';
import Box from '@material-ui/core/Box'
import Grid from '@material-ui/core/Grid';
import PieChart from './charts/pieChart';
import BarChart from './charts/barChart';
import useAppContext from './AppContext';

const boxProps = {
    display: "flex",
    bgcolor: 'background.paper',
    style: { height: '3rem' },
    borderLeft: '5px solid',
    borderColor: "secondary.main",
    justifyContent: "flex-start",
    margin: 1,
    padding: 1,
    boxShadow: 3
};
const chartsProps = {
    display: "flex",
    bgcolor: 'background.paper',
    justifyContent: "center",
    margin: 3,
    padding: 1,
};

const successData = [
    { success: 'pass', percentage: 75 },
    { success: 'fail', percentage: 50 },
];

const examStatusData = [
    { status: 'Assigned', count: 20 },
    { status: 'Not started', count: 30 },
    { status: 'In progress', count: 30 },
    { status: 'Incomplete', count: 40 },
    { status: 'Completed', count: 50 },
];
const scoreData = [
    { score: 'max score', count: 70 },
    { score: 'min score', count: 30 },
    { score: 'average score', count: 30 },
];

const scoreChartProps = {
    data: scoreData,
    title: 'Score analysis',
    width: '250',
    height:'500',
    valueField: 'count',
    argumentField: 'score',
    scaleName:'zoom',
}
const successChartProps = {
    data: successData,
    title: 'pass/fail analysis',
    valueField: "percentage",
    argumentField: "success",
}
const examstatusChartProps = {
    data: examStatusData,
    title: 'Exam status/ Candidates count',
    width: '380',
    height:'500',
    valueField: "count",
    argumentField: "status"
}

export default function ExamReport() {
    const appContext = useAppContext();
    appContext.setTitle('Exam Report');
    return (
        <div>
            <Grid container spacing={5}>
                <Grid item sm={12} md={6}>
                    <Box  {...boxProps}>
                        Assigned candidates :2
                    </Box>
                </Grid>
                <Grid item sm={12} md={6}>
                    <Box  {...boxProps}>
                        Total Time: 30mins
                    </Box>
                </Grid>
                <Grid item sm={12} md={6}>
                    <Box  {...boxProps}>
                        Total Questions : 5
                    </Box>
                </Grid>
                <Grid item sm={12} md={6}>
                    <Box  {...boxProps}>
                        Candidates more than average score: 1
                    </Box>
                </Grid>
                <Grid item sm={12} md={6}>
                    <Box  {...boxProps}>
                        Candidates less than average score: 1
                    </Box>
                </Grid>
                <Grid item sm={12} md={6}>
                    <Box  {...boxProps}>
                        Average of top 10 candidates :8.00
                    </Box>
                </Grid>
            </Grid>
            <Grid container spacing={2} >
                <Grid item sm={12} md={4}>
                    <Box  {...chartsProps}>
                        <Box><BarChart {...examstatusChartProps} /></Box>
                    </Box>
                </Grid>
                <Grid item sm={12} md={4}>
                    <Box  {...chartsProps}>
                        <BarChart {...scoreChartProps} />
                    </Box>
                </Grid>
                <Grid item sm={12} md={4}>
                    <Box  {...chartsProps}>
                        <PieChart {...successChartProps} />
                    </Box>
                </Grid>
            </Grid>
        </div>

    )
}