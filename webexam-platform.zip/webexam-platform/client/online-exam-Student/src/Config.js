const Config = {
    apiBase: 'http://localhost:8080/'
    // apiBase: 'https://dev.shiken.online/we-api/'
  };
  
  export default Config;
  