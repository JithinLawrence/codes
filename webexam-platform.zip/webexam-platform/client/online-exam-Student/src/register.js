import React from 'react';

import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import Link from '@material-ui/core/Link';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';

import CreateOutlinedIcon from '@material-ui/icons/CreateOutlined';

import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import InputBase from '@material-ui/core/InputBase';
import {
    MuiPickersUtilsProvider,
    KeyboardDatePicker,
} from '@material-ui/pickers';

import { useHistory } from "react-router-dom";
import { useAlert } from 'react-alert';
import { useForm, Controller } from "react-hook-form";

import useAppContext from './AppContext';
import { Input } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(1),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
    root: {
        display: "flex"
    },
    cover: {
        width: 151
    },
    profilePic: {
        borderStyle: "dotted"
    },
    browse: {
        margin: theme.spacing(3)
    }
}));

export default function Register() {
    const classes = useStyles();
    const alert = useAlert();
    const { register, errors, handleSubmit, control } = useForm();

    const history = useHistory();
    const appContext = useAppContext();

    const REGISTER_API = "login/register"
    const IMAGE_UPLOAD_API = "login/imageupload"
    const GRADES_LIST_API = "login/getgrades"
    const ORGANIZATION_LIST_API = 'login/getorganizations'

    const [disabled, setDisabled] = React.useState(false);

    const [gradesList, setGradesList] = React.useState([]);
    const [organiztaionsList, setOrganizationsList] = React.useState([])

    const [password, setPassword] = React.useState("");
    const [profilePic, setProfilePic] = React.useState(null);
    const [profilePicError,setProfilePicError]= React.useState("");

    const [imageUrl, setImageUrl] = React.useState("")
    const [selectedDOB, setSelectedDOB] = React.useState(null);

    const handleDOBChange = (date) => {
        setSelectedDOB(date);
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };



    const handleProfileChange = event => {
        setDisabled(true)
        if(!(event.target.files[0]['type'].match("image/*" ))){
            setProfilePicError("Please upload an image file")
            setDisabled(false);
            return
        }
        const data = new FormData()
        data.append('file', event.target.files[0])
        appContext.getAxios().post(IMAGE_UPLOAD_API, data).then((response) => {
            setProfilePic("")
            setImageUrl(response.data.path)
            setDisabled(false);
        }).catch(error => {
            console.log(error)
            setProfilePicError("Upload failed please try again")
            setDisabled(false);
        });

    };


    const validateConfirmPassword = value => {
        if (value === password) return true;

        return false;
    }


    const getGrades = () => {
        appContext.getAxios().get(GRADES_LIST_API).then((response) => {
            setGradesList(response.data)
            setDisabled(false);
        }).catch(error => {
            console.log(error)
            setDisabled(false);
        });
    }

    const getOrganization = () => {
        appContext.getAxios().get(ORGANIZATION_LIST_API).then((response) => {
            setOrganizationsList(response.data)
            setDisabled(false);
        }).catch(error => {
            console.log(error)
            setDisabled(false);
        });
    }

    const onSubmit = (data, event) => {
        event.preventDefault()
        setDisabled(true);
        appContext.getAxios().post(REGISTER_API, data).then((response) => {
            setDisabled(false);
            history.push('/dashboard');
            window.location.reload();

        }).catch(error => {
            console.log(error)
            setDisabled(false);
            alert.error(error.response.data.message);
        });
    }

    React.useEffect(getGrades, []);
    React.useEffect(getOrganization, []);
    return (
        <Box my={4} >
            <Typography variant="h4" component="h1" gutterBottom align="center">
                OnlineExamPlatform
            </Typography>
            <Container component="main" maxWidth="sm">
                <CssBaseline />
                <div>
                    <div className={classes.paper}>
                        <Avatar className={classes.avatar} >
                            <CreateOutlinedIcon />
                        </Avatar>
                        <Typography component="h1" variant="h5">
                            Sign up
                        </Typography>

                        <form className={classes.form} onSubmit={handleSubmit(onSubmit)}>
                            <Grid container spacing={2}>

                                <Grid item lg={12}>
                                    <TextField
                                        variant="outlined"
                                        fullWidth
                                        label="First name"
                                        name="firstName"
                                        autoComplete="given-name"
                                        autoFocus
                                        required={true}
                                        disabled={disabled}
                                        inputRef={register({ required: true, maxLength: 50 })}
                                        error={errors.firstName}
                                        helperText={errors.firstName && (errors.firstName.type === "required" ? "First name is required" : "firstname too long")}
                                    />
                                </Grid>
                                <Grid item lg={12}>
                                    <TextField
                                        variant="outlined"
                                        fullWidth
                                        id="last-name"
                                        label="Last name"
                                        name="lastName"
                                        autoComplete="family-name"
                                        required={true}
                                        disabled={disabled}
                                        inputRef={register({ required: true, maxLength: 50 })}
                                        error={errors.lastName}
                                        helperText={errors.lastName && (errors.lastName.type === "required" ? "Last name is required" : "firstname too long")}
                                    />
                                </Grid>

                            </Grid>
                            <Grid container spacing={2} >
                                <Grid item xs={12} sm={4} >
                                    <FormControl required variant="outlined" fullWidth margin="normal" >
                                        <InputLabel id="student-registration-organization-label" >Organization </InputLabel>
                                        <Controller
                                            as={Select}
                                            control={control}
                                            name="organizationId"
                                            variant="outlined"
                                            labelId="student-registration-organization-label"
                                            label="Organiztion "
                                            required={true}
                                            disabled={disabled}
                                            error={errors.organizationId}
                                            defaultValue=""
                                        >

                                            {organiztaionsList.map((organization) => (
                                                <MenuItem key={organization.organizationId} value={organization.organizationId}>{organization.organizationName}</MenuItem>
                                            ))}
                                        </Controller>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} sm={4} >
                                    <FormControl variant="outlined" fullWidth margin="normal" required >
                                        <InputLabel id="student-registration-level-label" >Group</InputLabel>
                                        <Controller
                                            as={Select}
                                            control={control}
                                            name="gradeId"
                                            variant="outlined"
                                            labelId="student-registration-level-label"
                                            label="Level"
                                            disabled={disabled}
                                            error={errors.gradeId}
                                            defaultValue=""
                                        >

                                            {gradesList.map((grade) => (
                                                <MenuItem key={grade.gradeId} value={grade.gradeId}>{grade.gradeName}</MenuItem>
                                            ))}
                                        </Controller>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} sm={4} >
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <Grid container>
                                            <KeyboardDatePicker
                                                margin="normal"
                                                label="Date of Birth *"
                                                name="dob"
                                                format="yyyy-MM-dd"
                                                inputRef={register({ required: true })}
                                                maxDate={new Date()}
                                                error={errors.dob}
                                                value={selectedDOB}
                                                disabled={disabled}
                                                onChange={handleDOBChange}
                                                KeyboardButtonProps={{
                                                    'aria-label': 'change date',
                                                }}
                                                helperText={errors.dob && "Dob is required"}

                                            />

                                        </Grid>
                                    </MuiPickersUtilsProvider>
                                </Grid>
                            </Grid>
                            <TextField
                                variant="outlined"
                                margin="normal"
                                fullWidth
                                id="email"
                                label="Email Address *"
                                name="email"
                                autoComplete="email"
                                disabled={disabled}
                                inputRef={register({ required: true, pattern: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ })}
                                error={errors.email}
                                helperText={errors.email && (errors.email.type === "required" ? "Email is required" : "Invalid email")}
                            />
                            <TextField
                                variant="outlined"
                                margin="normal"
                                fullWidth
                                name="password"
                                label="Password *"
                                type="password"
                                disabled={disabled}
                                onChange={handlePasswordChange}
                                inputRef={register({ required: true, pattern: /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/ })}
                                error={errors.password}
                                helperText={errors.password && (errors.password.type === "required" ? "Password is required" : " Password should be 8 letters or more in upper and lower case letters and numbers")}
                            />
                            <TextField
                                variant="outlined"
                                margin="normal"
                                fullWidth
                                name="confirmPassword"
                                label="Confirm Password *"
                                type="password"
                                id="password-confirm"
                                disabled={disabled}
                                inputRef={register({ required: true, validate: validateConfirmPassword })}
                                error={errors.confirmPassword}
                                helperText={errors.confirmPassword && (errors.confirmPassword.type === "required" ? "Please re-type your password" : "Passwords doesnt match")}
                            />
                            <Box display="flex" alignItems="center">
                                <Typography variant="h6" mx={3} >Profile Picture  :</Typography>

                                    <Button variant="contained" component="label" style={{marginLeft:3}} >
                                        Upload
                                        <input
                                            variant="contained"
                                            color="secondary"
                                            accept="image/*"
                                            style={{ display: 'none' }}
                                            className={classes.browse}
                                            single
                                            type="file"
                                            onChange={handleProfileChange}
                                        />
                                    </Button>
                                    <p>&nbsp;</p>
                                    <label >{profilePic}</label>
                                <input name="imageUrl" ref={register({ pattern: "https?://.+" })} style={{ display: "none" }} value={imageUrl} />
                                <br>
                                </br>
                                <input name="role" ref={register()} style={{ display: "none" }} value={3} />
                            </Box>
                            <p style={{"color":"red"}}>{profilePicError !="" && profilePicError}</p>
                            <Link href="/">
                                <Button
                                    disabled={disabled}
                                    type="submit"
                                    fullWidth
                                    variant="contained"
                                    color="primary"
                                    className={classes.submit}
                                >
                                    Sign up
                                </Button>
                            </Link>
                        </form>
                        <Link href="/">Already have an account? Sign in</Link>
                    </div>
                    <Box mt={8}>
                    </Box>
                </div>
            </Container >
        </Box >
    );
}