import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import { Link } from "react-router-dom";
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import lightBlue from '@material-ui/core/colors/lightBlue';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import LaunchIcon from '@material-ui/icons/Launch';
import ExamRegister from './examRegister'
import ExamStart from './examStart';
import PlayCircleFilledWhiteIcon from '@material-ui/icons/PlayCircleFilledWhite';
import DoneOutlineTwoToneIcon from '@material-ui/icons/DoneOutlineTwoTone';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";
import { IconButton } from '@material-ui/core';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    mainContainer: {
        width: "100%"
    },
    mainGridContainer: {
        flexGrow: 1,
    },
    mainGrid: {
        margin: "10px;",
        // height: "35% !important"
    },
    examTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        textAlign: "center",
        paddingTop: "20px",
        fontWeight: "bold"
    },
    examDetailP: {
        marginLeft: "10px",

    },
    bottomDiv: {
        height: "auto",
        textAlign: "center"
    },
    reviewButton: {
        marginTop: "13%",
        marginBottom: "13%",
        backgroundColor: lightBlue[500] + " !important",
    },
    resultButton: {
        marginTop: "13%",
        marginBottom: "13%",
        backgroundColor: theme.palette.secondary.light + " !important",
    }
});




export default function DashBoard() {
    const classes = useStyles();
    const alert = useAlert();
    const appContext = useAppContext();
    const [examRegisterOpen, examRegisterSetOpen] = React.useState(false);
    const [examStartOpen, examStartSetOpen] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [examToday, setExamToday] = React.useState([]);
    const [examId, setExamId] = React.useState([]);
    const [scheduleId, setScheduleId] = React.useState([]);
    const [registerId, setRegisterId] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('exam_id');
    const [sortType, setSortType] = React.useState(true);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(1);
    const [register, setRegister] = React.useState(false);

    const EXAMS_LIST_API = "schedule_assign/get_exam_upcomming"
    const CURRENTTIME_API = "exam_answer/get_current_time"

    const handleCloseExamRegister = hasChange => {
        if(hasChange){
            setRegister(!register)
        }
        examRegisterSetOpen(false);
    };
    const handleClickOpenExamRegister = (scheduleAssignId) => {
        examRegisterSetOpen(true);
        setRegisterId(scheduleAssignId);
    };

    const handleCloseExamStart = hasChange => {
        examStartSetOpen(false);
    };
    const handleClickOpenExamStart = (examId, scheduleId) => {
        setExamId(examId);
        setScheduleId(scheduleId);
        examStartSetOpen(true);
    };

    function displayApplicationStatus(applied, scheduleAssignId) {
        if (applied == 0) {
            return (
                <IconButton> <LaunchIcon onClick={() => handleClickOpenExamRegister(scheduleAssignId)} /> </IconButton>
            );
        } else if (applied == 1) {
            return (
                <DoneOutlineTwoToneIcon />
            );
        }
    }

    function timeConvert(n) {
        var num = n;
        var hours = (num / 60);
        var rhours = Math.floor(hours);
        var minutes = (hours - rhours) * 60;
        var rminutes = Math.round(minutes);
        return rhours + " hour : " + rminutes + " mins.";
    }


    function getExams() {
        appContext.getAxios().get(CURRENTTIME_API).then((response) => {
            let currTime = new Date(response.data)
            appContext.getAxios().get(EXAMS_LIST_API + '?page=' + (page + 1) + '&limit=' + limit + '&search=' + search + '&type=' + sortType + '&sort=' + sort).then((response) => {
                setData(response.data.result);
                console.log(response.data.result)
                var i = 0;
                var list = []
                response.data.result.forEach(exam => {
                    if (i < 4 && new Date(exam.startTime) <= currTime && exam.registerStatus == 1) {
                        console.log(exam)
                        list.push(exam)
                        i++;
                    }
                });
                setExamToday(list);
                setPage(response.data.currentPage - 1)//to reset page in case deleting the last row of last page
                setCount(response.data.pagerInfo.count);
            }, (error) => {
                alert.error(error.response.data.message);
            });
        }, (error) => {
            alert.error(error.response.data.message);
        });

    }


    React.useEffect(() => {
        getExams();
    }, [sort, sortType, page, limit, search,register]);

    return (
        <div>
            <br></br>
            <h2>Todays Exams</h2>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={10}>
                    <Grid container spacing={5}>
                        {examToday.map((item) => (
                            <Grid key={item.scheduleAssignId} item md={3}>
                                <Card>
                                    <Box borderRadius={16}>
                                        <div className={classes.examTitleDiv}>
                                            {item.name}
                                        </div>
                                        <p className={classes.examDetailP} ><b>Start:</b> {item.startTime}</p>
                                        <p className={classes.examDetailP} ><b>Time duration:</b> {timeConvert(item.duration)}</p>

                                        <div className={classes.examDetailP} style={{ 'height': '25vh', 'overflow': 'hidden' }} dangerouslySetInnerHTML={{ __html: item.description }} />
                                        <Divider />
                                        <div className={classes.bottomDiv}>
                                            <Grid container justify="center" spacing={2}>
                                                <Grid item xs={5}>
                                                    <Button variant="contained"
                                                        color="secondary"
                                                        justify="right"
                                                        className={classes.resultButton}
                                                        onClick={() => handleClickOpenExamStart(item.examId, item.scheduleId)}>
                                                        <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
                                                </Grid>
                                            </Grid>
                                        </div>
                                    </Box>
                                </Card>
                            </Grid>
                        ))}
                    </Grid>
                </Grid>
            </Grid>

            <br></br>
            <br></br>



            <br></br>
            <br></br>
            <h2>Upcoming Exams</h2>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Title</TableCell>
                            <TableCell align="center">Duration</TableCell>
                            <TableCell align="center">Schedule</TableCell>
                            <TableCell align="center">Apply</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {data.slice(0, 5).map((row) => (
                            <TableRow key={row.scheduleAssignId}>
                                <TableCell component="th" scope="row" style={{ overflow: "hide", width: "500px" }}>
                                    <b>{row.name}</b>
                                    <br>
                                    </br>
                                    <div dangerouslySetInnerHTML={{__html: row.description}} />
                                </TableCell>
                                <TableCell align="center">{timeConvert(row.duration)}</TableCell>
                                <TableCell align="center">{row.startTime}</TableCell>
                                <TableCell align="center">
                                    {displayApplicationStatus(row.registerStatus, row.scheduleAssignId)}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                <Link style={{ float: "right", fontSize: "16px", color: "black", textDecoration: "none" }} to="/upcoming" >...View All</Link>
            </TableContainer>

            <ExamRegister open={examRegisterOpen} onClose={handleCloseExamRegister} registerId={registerId} />
            <ExamStart open={examStartOpen} onClose={handleCloseExamStart} examId={examId} scheduleId={scheduleId} />
        </div>
    );
}