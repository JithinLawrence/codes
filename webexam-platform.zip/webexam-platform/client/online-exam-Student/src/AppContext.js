import React from 'react';
import axios from "axios";
import Config from "./Config";

const NO_OP = () => { };


const AppContext = React.createContext();
if (process.env.NODE_ENV !== 'production') {
    AppContext.displayName = 'AppContext';
}

const useAppContext = () => React.useContext(AppContext);

const LOGIN_API = "login";
const FORGOT_PASSWORD_API = "login/forgotPassword";
const FORGOT_PASSWORD_RESET_API = "login/forgotPasswordReset";
const SESSION_KEY = "refreshToken";

const accessKey = "OnlineExam ";
const basicContentType = { "Content-Type": "application/json" };
const AXIOS = axios.create({
    baseURL: Config.apiBase,
    headers: {
        "Content-Type": "application/json",
        get: basicContentType,
        post: basicContentType,
        put: basicContentType,
        delete: basicContentType,
        patch: basicContentType,
    },
});

function AppContextProvider({ init, children }) {
    const [title, setTitle] = React.useState('Web Exam');
    const [displayAll, setDisplayAll] = React.useState("true");
    const [auth, setAuth] = React.useState(init);
    const getTitle = () => title;
    const getDisplayAll = () => displayAll;

    React.useEffect(() => { document.title = title ? 'Web Exam / - ' + title : 'Web exam /'; }, [title]);

    React.useEffect(() => {
        if (auth !== null) {
            const expiry = new Date(auth.expiry).getTime() - Date.now();
            const time = (expiry >= 300 ? expiry - 30 : expiry * 0.9) * 1000;
            const timeout = setTimeout(() => {
                refreshAccessToken().then(setAuth);
            }, time);
            return () => {
                clearTimeout(timeout);
            };
        }

        return NO_OP;
    }, [auth]);

    function signIn(email, password) {
        removeAuthorization();
        let data = JSON.stringify({
            password: password,
            email: email,
        });

        return AXIOS.post(LOGIN_API, data).then(
            (response) => {
                AXIOS.defaults.headers.common["AuthToken"] =
                    response.data.accessToken.value;
                setAuthorization(response.data.accessToken.value);
                sessionStorage.setItem(
                    SESSION_KEY,
                    response.data.refreshToken.value
                );
                sessionStorage.setItem("role", response.data.role);
                sessionStorage.setItem("userId", response.data.userId);
                setAuth(response.data.accessToken);
                return { status: true, info: response };
            }, (error) => {
                return { status: false, info: error };
            });
    }

    function forgotPassword(email) {
        let data = JSON.stringify({
            email: email,
        });

        return AXIOS.post(FORGOT_PASSWORD_API, data).then(
            (response) => {
                console.log(response)
                return {status: true, info: response};
            }, (error) => {
                return {status: false, info: error};
            });
    }

    function forgotPasswordReset(newPassword, confirmPassword, token){
        let data = JSON.stringify({
            newPassword : newPassword,
            confirmNewPassword : confirmPassword,
            token : token
        })

        return AXIOS.put(`${FORGOT_PASSWORD_RESET_API}`, data).then((response)=>{
            // onClose();
            return {status:true , info :response};
        },(error)=>{
            return {status:false, info:error};
        });

    }

    function logout() {
        sessionStorage.removeItem(SESSION_KEY);
        removeAuthorization();
        setAuth(null);
    }

    const isExamAttending = () => sessionStorage.getItem("examId") !== null;

    const isLoggedin = () => auth !== null;

    const getAccessToken = () => auth;

    const getAxios = () => AXIOS;

    const context = {
        signIn,
        forgotPassword,
        forgotPasswordReset,
        setTitle,
        getTitle,
        logout,
        isLoggedin,
        getAccessToken,
        getAxios,
        setDisplayAll,
        getDisplayAll,
        isExamAttending
    };

    return <AppContext.Provider value={context}>{children}</AppContext.Provider>;
}
function refreshAccessToken() {
    let refreshToken = sessionStorage.getItem(SESSION_KEY);
    if (refreshToken === null) {
        return Promise.resolve(null);
    }
    return AXIOS.put(LOGIN_API, refreshToken).then(
        (response) => {
            AXIOS.defaults.headers.common["AuthToken"] =
                response.data.accessToken.value;
            setAuthorization(response.data.accessToken.value);

            return response.data.accessToken;
        },
        () => {
            removeAuthorization();
            sessionStorage.removeItem(SESSION_KEY);
            return null;
        }
    );
}

function setAuthorization(accessTokenValue) {
    AXIOS.defaults.headers.common["authorization"] = AXIOS.defaults.headers.get[
        "authorization"
    ] = AXIOS.defaults.headers.post[
    "authorization"
    ] = AXIOS.defaults.headers.put[
    "authorization"
    ] = AXIOS.defaults.headers.delete[
    "authorization"
    ] = AXIOS.defaults.headers.patch["authorization"] =
        accessKey + accessTokenValue;
}

function removeAuthorization() {
    delete AXIOS.defaults.headers.common["authorization"];
    delete AXIOS.defaults.headers.get["authorization"];
    delete AXIOS.defaults.headers.post["authorization"];
    delete AXIOS.defaults.headers.put["authorization"];
    delete AXIOS.defaults.headers.delete["authorization"];
    delete AXIOS.defaults.headers.patch["authorization"];
}

export default useAppContext;
export { refreshAccessToken, AppContextProvider };
