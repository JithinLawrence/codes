import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    grid: {
        justifyContent: "center"
    }
}));

function PasswordChange({ open, onClose }) {
    const classes = useStyles();
    const alert = useAlert();

    const PASSWORD_CHANGE_API = 'users/changePassword';
    const appContext = useAppContext();
    
    const [disabled, setDisabled] = React.useState(false);
    const [currentPassword, setCurrentPassword] = React.useState('');
    const [currentPasswordError, setCurrentPasswordError] = React.useState(null);
    const [newPassword, setNewPassword] = React.useState('');
    const [newPasswordError, setNewPasswordError] = React.useState(null);
    const [confirmNewPassword, setConfirmNewPassword] = React.useState('');
    const [confirmNewPasswordError, setConfirmNewPasswordError] = React.useState(null);

    const handleCurrentPasswordChange = event => {
        const val = event.target.value;
        setCurrentPassword(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Current password is required" : null;
        errorMsg = errorMsg == null ? (val.length < 8 ? "Current password length must be 8 or more characters" : null) : errorMsg;
        setCurrentPasswordError(errorMsg)
    };

    const handleNewPasswordChange = event => {
        const val = event.target.value;
        setNewPassword(val);
        let errorMsg = null;
        errorMsg = val === '' ? "New password is required" : null;
        errorMsg = errorMsg == null ? (val.length > 135 ? "New password length must not exceed 135 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (val.length < 8 ? "New password length must be 8 or more characters" : null) : errorMsg;
        setNewPasswordError(errorMsg)
    };

    const handleConfirmNewPasswordChange = event => {
        const val = event.target.value;
        setConfirmNewPassword(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Confirm password is required" : null;
        errorMsg = errorMsg == null ? (val.length > 135 ? "Confirm password length must not exceed 135 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (val.length < 8 ? "Confirm password length must be 8 or more characters" : null) : errorMsg;
        setConfirmNewPasswordError(errorMsg)
    };

    const handleSubmit = event => {
        event.preventDefault();

        if(currentPasswordError != null || newPasswordError!= null || confirmNewPasswordError != null){
            return;
        }

        setDisabled(true)
        passwordChange(currentPassword, newPassword, confirmNewPassword).then((result) => {
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                resetInputs();
                alert.success("OK");
            }
            setDisabled(false)
        });
    };
    function resetInputs(){
        setCurrentPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
        setCurrentPasswordError(null);
        setNewPasswordError(null);
        setConfirmNewPasswordError(null);
    }

    function passwordChange(currentPassword, newPassword, confirmNewPassword) {
        let data = JSON.stringify({
            oldPassword: currentPassword,
            newPassword: newPassword,
            confirmNewPassword: confirmNewPassword
      })
    
        return appContext.getAxios().put(PASSWORD_CHANGE_API, data).then((response) => {
              onClose();
        return {status: true, info: response};
    }, (error) => {
        return {status: false, info: error};
    });
      }

    return (
        <Dialog maxWidth="lg" open={open} onClose={() => {resetInputs();onClose();}} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Change Password</Typography>
                <IconButton size="small" className={classes.close} onClick={() => {resetInputs();onClose();}}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
                <form className={classes.form} onSubmit={handleSubmit}>
                    <Grid container>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="first-name-label">First Name</InputLabel> */}
                            <TextField

                                label="Current Password"
                                labelId="current-password-label"
                                fullWidth
                                required
                                type="password"
                                id="currentPassword"
                                disabled={disabled} 
                                value={currentPassword} 
                                onChange={handleCurrentPasswordChange} 
                                error={currentPasswordError !== null} 
                                helperText={currentPasswordError}
                                >
                            </TextField>
                        </Grid>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="last-name-label">Last Name</InputLabel> */}
                            <TextField
                                label="New Password"
                                id="newPassword"
                                fullWidth
                                required
                                type="password"
                                labelId="new-password-label"
                                disabled={disabled} 
                                value={newPassword} 
                                onChange={handleNewPasswordChange} 
                                error={newPasswordError !== null} 
                                helperText={newPasswordError}
                                >
                            </TextField>
                        </Grid>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="email-label">Email</InputLabel> */}
                            <TextField
                                fullWidth
                                required
                                label="Confirm new password"
                                id="confirmNewPassword"
                                type="password"
                                labelId="confirm-new-password-label"
                                disabled={disabled} 
                                value={confirmNewPassword} 
                                onChange={handleConfirmNewPasswordChange} 
                                error={confirmNewPasswordError !== null} 
                                helperText={confirmNewPasswordError}
                                >
                            </TextField>
                        </Grid>

                    </Grid>
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type="submit"
                            disabled={disabled}
                        >
                            Submit
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            onClick={() => {resetInputs();onClose();}}
                        >
                            cancel
                        </Button>
                    </Box>
                </form >
            </DialogContent>
        </Dialog >

    )
}

function ProfileChange({ open, onClose }) {
    const classes = useStyles();
    const alert = useAlert();
    
    const USER_API = 'users';
    const appContext = useAppContext();
    
    const [disabled, setDisabled] = React.useState(false);
    const [firstName, setFirstName] = React.useState('');
    const [firstNameError, setFirstNameError] = React.useState(null);
    const [lastName, setLastName] = React.useState('');
    const [lastNameError, setLastNameError] = React.useState(null);
    const [email, setEmail] = React.useState('');
    const [emailError, setEmailError] = React.useState(null);

    React.useEffect(() => {
        if(open){
            appContext.getAxios().get(USER_API).then((response) => {
                setFirstName(response.data.firstName);
                setLastName(response.data.lastName);
                setEmail(response.data.email);
            }, (error) => {
                alert.error(error.response.data.message);
            });
        }
    }, [open]); 

    const handleFirstNameChange = event => {
        const val = event.target.value;
        setFirstName(val);
        let errorMsg = null;
        errorMsg = val === '' ? "First name is required" : null;
        errorMsg = errorMsg == null ? (val.length > 50 ? "First name length must not exceed 50 characters" : null) : errorMsg;
        setFirstNameError(errorMsg)
    };

    const handleLastNameChange = event => {
        const val = event.target.value;
        setLastName(val);
        setLastNameError(val.length > 50 ? 'Last name length must not exceed 50 characters' : null);
    };

    const handleEmailChange = event => {
        const val = event.target.value;
        setEmail(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Email is required" : null;
        errorMsg = errorMsg == null ? (val.length > 255 ? "Email length must not exceed 255 characters" : null) : errorMsg;
        setEmailError(errorMsg)
    };

    const handleSubmit = event => {
        event.preventDefault();

        if(firstNameError != null || lastNameError != null || emailError != null){
            return;
        }

        setDisabled(true)
        editProfile(firstName, lastName, email).then((result) => {
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                resetInputs();
                alert.success("OK");
            }
            setDisabled(false)
        });
    };

    function resetInputs(){
        setFirstName('');
        setLastName('');
        setEmail('');
        setFirstNameError(null);
        setLastNameError(null);
        setEmailError(null);
    }

    function editProfile(firstName, lastName, email) {
        let data = JSON.stringify({
            firstName: firstName,
            lastName: lastName,
            email: email,
            role: sessionStorage.getItem("role")
      })
    
        return appContext.getAxios().put(USER_API, data).then((response) => {
              onClose();
        return {status: true, info: response};
    }, (error) => {
        return {status: false, info: error};
    });
      }

    return (
        <Dialog maxWidth="lg" open={open} onClose={() => {resetInputs();onClose();}} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Edit Profile</Typography>
                <IconButton size="small" className={classes.close} onClick={() => {resetInputs();onClose();}}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
                <form className={classes.form} onSubmit={handleSubmit}>
                    <Grid container>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="first-name-label">First Name</InputLabel> */}
                            <TextField

                                label="First Name"
                                labelId="first-name-label"
                                fullWidth
                                required
                                id="plannerFirstName"
                                disabled={disabled} 
                                value={firstName} 
                                onChange={handleFirstNameChange} 
                                error={firstNameError !== null} 
                                helperText={firstNameError}
                                >
                            </TextField>
                        </Grid>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="last-name-label">Last Name</InputLabel> */}
                            <TextField
                                label="Last Name"
                                id="plannerLastName"
                                fullWidth
                                labelId="last-name-label"
                                disabled={disabled} 
                                value={lastName} 
                                onChange={handleLastNameChange} 
                                error={lastNameError !== null} 
                                helperText={lastNameError}
                                >
                            </TextField>
                        </Grid>
                        <Grid item sm={12} md={12} >
                            {/* <InputLabel id="email-label">Email</InputLabel> */}
                            <TextField
                                type="email"
                                fullWidth
                                required
                                label="Email"
                                id="email"
                                labelId="email-label"
                                disabled={disabled} 
                                value={email} 
                                onChange={handleEmailChange} 
                                error={emailError !== null} 
                                helperText={emailError}
                                >
                            </TextField>
                        </Grid>

                    </Grid>
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type="submit"
                            disabled={disabled}
                        >
                            Submit
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            color="error."
                            onClick={() => {resetInputs();onClose();}}
                        >
                            cancel
                        </Button>
                    </Box>
                </form >
            </DialogContent>
        </Dialog >

    )
}

export default ProfileChange;
export { PasswordChange };
