import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import Button from '@material-ui/core/Button';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import Box from '@material-ui/core/Box';
import { Typography, Divider } from '@material-ui/core';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';


const useStyles = makeStyles((theme) => ({
    chkbxMain: {
    },
    options: {
        margin: theme.spacing(3)
    }
}));

export default function TextInput(props) {
    const classes = useStyles();
    const [value, setValue] = React.useState(props.question.answer);

    React.useEffect(() => {
        const timer = setTimeout(() => {
            props.submitVal(value);
        }, 1000);
    
        return () => clearTimeout(timer);
    }, [value]);

    React.useEffect(() => {
        setValue(props.question.answer);
    }, [props.question]);

    return (
        <>
            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                        <Typography variant="h6">Q{props.index}.{props.question.title}</Typography>
                        <div dangerouslySetInnerHTML={{__html: props.question.description}} />
                        {props.question.imageUrl != "" &&
                            <div><img style={{ "height": "500px", "maxWidth": "500px" }} src={props.question.imageUrl} /></div>
                        }
                        <FormControl className={classes.options} component="fieldset">
                        <TextareaAutosize style={{minWidth:600, marginLeft:10 , minHeight:50}}
                                aria-label="Answer" 
                                rowsMax={3} 
                                value={value}
                                placeholder="Answer" 
                                onChange={e => setValue(e.target.value)}                                 
                        />
                        </FormControl>
                    </div>
                    <br></br>
                    <br></br>
                </div>
            </Box>

        </>
    );
}