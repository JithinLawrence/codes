import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import Button from '@material-ui/core/Button';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import Box from '@material-ui/core/Box';
import { Typography, Divider } from '@material-ui/core';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import { useAlert } from "react-alert";
import useAppContext from '../AppContext';


const useStyles = makeStyles((theme) => ({
    chkbxMain: {
    },
    options: {
        margin: theme.spacing(3)
    }
}));

export default function ImageInput(props) {
    const classes = useStyles();
    const appContext = useAppContext();
    const [url, setUrl] = React.useState(props.question.answer)
    const alert = useAlert();
    const IMAGE_UPLOAD_API = "exam_answer/imageupload"


    const handleChange = event => {
        if(!(event.target.files[0]['type'].match("image/*" ))){
            alert.error("Please upload an image file")
            return
        }
        const data = new FormData()
        data.append('file', event.target.files[0])
        appContext.getAxios().post(IMAGE_UPLOAD_API, data).then((response) => {
            setUrl(response.data.path)
            props.submitVal(response.data.path[0]);
        }).catch(error => {
            console.log(error)
            alert.error("Upload failed please try again")
        });

    };

    React.useEffect(() => {
        setUrl(props.question.answer);
    }, [props.question]);

    return (
        <>
            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                        <Typography variant="h6">Q{props.index}.{props.question.title}</Typography>
                        <div dangerouslySetInnerHTML={{__html: props.question.description}} />
                        {props.question.imageUrl != "" &&
                            <div><img style={{ "height": "500px", "maxWidth": "500px" }} src={props.question.imageUrl} /></div>
                        }
                        <FormControl className={classes.options} component="fieldset">
                        <Button variant="contained" component="label" style={{marginLeft:3}} >
                                        Upload
                                        <input
                                            variant="contained"
                                            color="secondary"
                                            accept="image/*"
                                            style={{ display: 'none' }}
                                            className={classes.browse}
                                            single
                                            type="file"
                                            onChange={handleChange}
                                        />
                                    </Button>
                        </FormControl>
                        {url != "" &&
                        <div ><img style={{ "height": "250px", "maxWidth": "250px", }} src={url} /></div>
                        }
                    </div>
                    <br></br>
                    <br></br>
                </div>
            </Box>

        </>
    );
}