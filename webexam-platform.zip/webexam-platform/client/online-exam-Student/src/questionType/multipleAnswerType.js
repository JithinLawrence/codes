import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import Button from '@material-ui/core/Button';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import Box from '@material-ui/core/Box';
import { Typography, Divider, Checkbox } from '@material-ui/core';


const useStyles = makeStyles((theme) => ({
    chkbxMain: {
    },
    options: {
        margin: theme.spacing(3)
    }
}));

export default function MultipleAnswer(props) {
    const classes = useStyles();
    const [options, setOptions] = React.useState([])
    const [choices, setChoices] = React.useState([]);

    const handleChange = (event) => {
        setChoices(choices.filter((ch) => ch != event.target.id));
        if (event.target.checked) {
            setChoices([...choices, event.target.id]);
            props.submitVal([...choices, event.target.id]);
        } else {
            props.submitVal(choices.filter((ch) => ch != event.target.id));
        }
    };

    const isOptionSelected = (option) => {
        console.log(choices.includes(option.id.toString()))
        if (choices.includes(option.id.toString())) {
            return true;
        } else {
            return false;
        }

    };

    React.useEffect(() => {
        console.log(choices)
        let opts = JSON.parse(props.question.options)
        setOptions(opts.options);
        if (props.question.answer != '') {
            setChoices(props.question.answer.split(','))
        }else{
            setChoices([])
        }
    }, [props.question])

    return (
        <>
            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                        <Typography variant="h6">Q{props.index}.{props.question.title}</Typography>
                        <div dangerouslySetInnerHTML={{ __html: props.question.description }} />
                        {props.question.imageUrl != "" &&
                            <div><img style={{ "height": "500px", "maxWidth": "500px" }} src={props.question.imageUrl} /></div>
                        }
                        <FormControl className={classes.options} component="fieldset">
                            <FormGroup>
                                {options.map((option) => (
                                    <Box display="flex">
                                        <Checkbox id={option.id} checked={isOptionSelected(option)} onChange={handleChange} /><div style={{'alignSelf':'center'}}>{option.value} </div>
                                    </Box>
                                ))}
                            </FormGroup>
                        </FormControl>
                    </div>
                    <br></br>
                    <br></br>
                </div>
            </Box>

        </>
    );
}