import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import Box from '@material-ui/core/Box';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import { grey } from '@material-ui/core/colors';
import CssBaseline from '@material-ui/core/CssBaseline';
import clsx from 'clsx';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import useAppContext from './AppContext';
import AccountCircleRoundedIcon from '@material-ui/icons/AccountCircleRounded';
import Catagory from './catagory'
import { BrowserRouter as Router, Link, Switch, Route, useHistory } from 'react-router-dom';
import PlayCircleFilledWhiteIcon from '@material-ui/icons/PlayCircleFilledWhite';
import Card from '@material-ui/core/Card';
import ExamaDashBoard from './examDashboard';
import Agreement from './agreement';
import { useAlert } from "react-alert";


const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({

    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    drawer: {
        justifyContent: 'center',
        backgroundColor: grey[400],
        borderColor: "secondary",
        flexWrap: 'wrap',
        height: '90vh',
        marginRight: theme.spacing(1)
    },
    catogories: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    questions: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    dialog: {
        padding: theme.spacing(3)
    },
    dialogTitle: {
        backgroundColor: theme.palette.primary.main,
    },
    catogoryChip: {
        margin: theme.spacing(0.5),
        backgroundColor: theme.palette.primary.main,
    },
    purple: {
        color: theme.palette.getContrastText(theme.palette.primary.main),
        backgroundColor: theme.palette.primary.main,
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    caption: {
        margin: theme.spacing(3)
    },
    questionArea: {
        width: `calc(100% - ${drawerWidth}px)`,
        paddingTop: theme.spacing(3)
    },
    nextbtn: {
        margin: theme.spacing(3)
    },
    prevbtn: {
        margin: theme.spacing(3)
    },
    timerDiv: {
        fontSize: 20,

    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    title: {
        flexGrow: 1,
    },
    content: {
        paddingTop: theme.spacing(5)
    },
    catTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        textAlign: "center",
        paddingTop: "20px",
        fontWeight: "bold"
    },
    catDetailP: {
        marginLeft: "10px",

    },

}));


export default function Exam() {
    const appContext = useAppContext();
    const classes = useStyles();
    const [qno, setQno] = React.useState(1);
    const [btntext, setBtntext] = React.useState("next");
    const [firstName, setFirstName] = React.useState('');
    const [lastName, setLastName] = React.useState('');
    const [status, setStatus] = React.useState('');

    const alert = useAlert();
    const history = useHistory();
    const USER_API = 'users';
    const EXAMS_ANSWER_STATUS_API = "exam_answer/status"

    function getExamStatus() {
        let examId = sessionStorage.getItem('examId')
        let scheduleId = sessionStorage.getItem('scheduleId')
        appContext.getAxios().get(EXAMS_ANSWER_STATUS_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
            console.log(response.data)
            setStatus(response.data);

        }, (error) => {
            alert.error(error.response.data.message);
        });

    }

    React.useEffect(() => {
        if (appContext.isLoggedin()) {
            appContext.getAxios().get(USER_API).then((response) => {
                setFirstName(response.data.firstName);
                setLastName(response.data.lastName);
            }, (error) => {
                alert.error(error.response.data.message);
            });
        }
    }, []);

    React.useEffect(() => {
        getExamStatus();
    }, []);


    return (
        <>
            <CssBaseline />
            <AppBar position="absolute" color="secondary" className={classes.appBar}>
                <Toolbar className={classes.toolbar}>

                    <Typography component="h1" variant="h6" color="inherit" noWrap className={classes.title}>
                        {appContext.getTitle()}
                    </Typography>

                    <Divider orientation={"vertical"} />
                    <Button color="inherit" m={5} disabled>
                        <AccountCircleRoundedIcon />
                        <Typography variant="caption"> &nbsp; {firstName} {lastName} </Typography>
                    </Button>
                </Toolbar>

            </AppBar>
            <div className={classes.content}>
                <br></br>
                {status == -1 && <Agreement />}
                {status == 2 && <ExamaDashBoard />}
            </div >
        </>
    )
}