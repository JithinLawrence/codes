import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Avatar from '@material-ui/core/Avatar';
import CssBaseline from '@material-ui/core/CssBaseline';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Container from '@material-ui/core/Container';
import { useAlert } from 'react-alert';
import useAppContext from './AppContext';
import { useHistory, withRouter } from "react-router-dom";
import Link from '@material-ui/core/Link';


const useStyles = makeStyles((theme) => ({
    paper: {
      marginTop: theme.spacing(8),
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
    },
    avatar: {
      margin: theme.spacing(1),
      backgroundColor: theme.palette.secondary.main,
    },
    form: {
      width: '100%', // Fix IE 11 issue.
      marginTop: theme.spacing(1),
    },
    submit: {
      margin: theme.spacing(3, 0, 2),
    },
  }));
  


export default function ForgotPasswordReset() {
    const classes = useStyles();
    const alert = useAlert();
    const appContext = useAppContext();

    const paawordreset_API = 'login/forgotPasswordReset'

    const [disabled, setDisabled] = React.useState(false);
    const [newPassword, setNewPassword] = React.useState('');
    const [newPasswordError, setNewPasswordError] = React.useState(null);
    const [confirmPassword, setConfirmPassword] = React.useState('');
    const [confirmPasswordError, setConfirmPasswordError] = React.useState(null);

    const handleNewPasswordChange = event =>{
        const newPass = event.target.value;
        setNewPassword(newPass);
        let test = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~])[a-zA-Z0-9 \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~]+$").test(newPass);  
        let errorMsg = null;
        errorMsg = newPass === '' ? "New Password is required" : null;
        errorMsg = errorMsg == null ? (newPass.length > 30 ? "Password length must not exceed 30 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (newPass.length < 8 ? "Password length must be 8 or more characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (test == false ? "Password must contain one lowercase letter, uppercase letter, digit and special character." : null) : errorMsg;
        setNewPasswordError(errorMsg);
    };

    const handleConfirmPasswordChange =event =>{
        const confPass = event.target.value;
        setConfirmPassword(confPass);
        let test = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~])[a-zA-Z0-9 \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~]+$").test(confPass);  
        let errorMsg = null;
        errorMsg = confPass === '' ? "Confirm password is required" : null;
        errorMsg = errorMsg == null ? (confPass.length > 30 ? "Password length must not exceed 30 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (confPass.length < 8 ? "Password length must be 8 or more characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (test == false ? "Password must contain one lowercase letter, uppercase letter, digit and special character." : null) : errorMsg;
        setConfirmPasswordError(errorMsg);
    };

    let history = useHistory();
    const handleSubmit = event =>{
        event.preventDefault();
        
        if(newPassword === ''){
            setNewPasswordError('New password is required');
            return;
        }
        if(confirmPassword === ''){
            setConfirmPasswordError('Confirm password is required');
            return;
        }
        if(newPassword !== confirmPassword){
            setConfirmPasswordError('Confirm password should be same as new password!!');
            return;
        }
        
        setDisabled(true);
        appContext.forgotPasswordReset(newPassword, confirmPassword, window.location.pathname.split('/')[window.location.pathname.split('/').length-1]).then((result)=>{
            if(!result.status){
                alert.error(result.info.response.data.message);
            }else{
                reSetInput();
                alert.success("Login using new password");
                history.push('/')
            }
            setDisabled(false);
        });
    }

    function reSetInput(){
       setNewPassword('');
       setConfirmPassword('');
       setNewPasswordError(null);
       setConfirmPasswordError(null); 
    }

    return (


        <Box my={4} >
      <Typography variant="h4" component="h1" gutterBottom align="center">
        OnlineExamPlatform
      </Typography>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <div className={classes.paper}>
          <Avatar className={classes.avatar}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            {"Reset Password"}
        </Typography>
          <form className={classes.form} onSubmit={handleSubmit}>
          <TextField
                            type="Password"
                            fullWidth
                            label="New Password"
                            id="newPassword"
                            onChange = {handleNewPasswordChange}
                            error = {newPasswordError !== null}
                            helperText = {newPasswordError}
                            >
                            </TextField>
                            <TextField
                            type="Password"
                            fullWidth
                            label="Confirm Password"
                            id="confirmPassword"
                            onChange = {handleConfirmPasswordChange}
                            error = {confirmPasswordError !== null}
                            helperText = {confirmPasswordError}
                            >
                            </TextField>
           
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              className={classes.submit}
            >
              Submit
            </Button>
            <div align="center" >
                <Link color="inherit" href="/admin/" variant="body2">
                  {"Back to Login page"}
                </Link>
            </div>
          </form>
        </div>
        <Box mt={8}>
        </Box>
      </Container>
    </Box>



        // <Box my={4} >
        //   <Typography variant="h4" component="h1" gutterBottom align="center">
        //   Forgot Password
        //   </Typography>
        //   <Container component="main" maxWidth="xs">
        //     <CssBaseline />
        //     <div className={classes.paper}>
        //       {/* <Avatar className={classes.avatar}>
        //         <LockOutlinedIcon />
        //       </Avatar> */}
        //       {/* <Typography component="h1" variant="h5">
        //         {"Forgot Password"}
        //     </Typography> */}
        //       <form className={classes.formControl} onSubmit={handleSubmit}>
        //         <div >
        //         <Grid container>                    
        //             <Grid item sm={12} md={6} >
        //             <FormControl className={classes.formControl}>
        //                     <TextField
        //                     type="Password"
        //                     fullWidth
        //                     label="newPassword"
        //                     id="newPassword"
        //                     onChange = {handleNewPasswordChange}
        //                     error = {newPasswordError !== null}
        //                     helperText = {newPasswordError}
        //                     >
        //                     </TextField>
        //                     </FormControl>
        //             </Grid>
        //         </Grid>

        //         <Grid container>                    
        //             <Grid item sm={12} md={6} >
        //             <FormControl className={classes.formControl}>                   
        //                     <TextField
        //                     type="Password"
        //                     fullWidth
        //                     label="confirmPassword"
        //                     id="confirmPassword"
        //                     onChange = {handleConfirmPasswordChange}
        //                     error = {confirmPasswordError !== null}
        //                     helperText = {confirmPasswordError}
        //                     >
        //                     </TextField>
        //                     </FormControl>
        //             </Grid>
        //         </Grid>

        //             <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
        //                 <Button
        //                     variant="contained"
        //                     color="secondary"
        //                     className={classes.submitButton}
        //                     type = "submit"
        //                     disabled = {disabled}
        //                 >
        //                     Submit
        //                 </Button>
        //             </Box>
        //         </div >
        //         </form>
        //     </div>
        //     <Box mt={8}>
        //     </Box>
        //   </Container>
        // </Box>
      );
}