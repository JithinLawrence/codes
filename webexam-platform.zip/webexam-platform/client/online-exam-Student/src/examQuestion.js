import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import useAppContext from './AppContext';
import { BrowserRouter as Router, Link, Switch, Route, useHistory } from 'react-router-dom';
import { useAlert } from "react-alert";
import SingleAnswer from './questionType/singleAnswerType';
import MultipleAnswer from './questionType/multipleAnswerType';
import SingleAnswerImage from './questionType/singleAnswerImageType';
import MultipleAnswerImage from './questionType/multipleAnswerImageType';

import TextInput from './questionType/textInput';
import ImageInput from './questionType/imageInput';
import { Typography, Grid } from '@material-ui/core';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import { Divider } from '@material-ui/core';
import { set } from 'date-fns';


const useStyles = makeStyles((theme) => ({

    nextbtn: {
        margin: theme.spacing(1)
    },
    prevbtn: {
        margin: theme.spacing(1)
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },

}));


export default function ExamQuestion(props) {
    const appContext = useAppContext();
    const classes = useStyles();
    const alert = useAlert();
    const history = useHistory();

    const [question, setQuestion] = React.useState({});
    const [qid, setQid] = React.useState(props.questionId);
    const [index,setIndex] = React.useState(props.qIndex)
    const [submitValue, setSubmitValue] = React.useState(0);
    const [showmarks, setShowmarks] = React.useState(false);
    const [marks, setMarks] = React.useState(0);
    const [total, setTotal] = React.useState(0);
    const [correctCount, setCorrectCount] = React.useState(0);
    const [totalCount, setTotalCount] = React.useState(false);
    const [disabled, setDisabled] = React.useState(false);

    const GET_QUESTION = "exam_answer/get_question";
    const EXAMS_SUBMIT_API = "exam_answer/submit_exam"
    const SUBMIT_SINGLE_ANSWER_API = "exam_answer/single_answer";
    const SUBMIT_MULTIPLE_ANSWER_API = "exam_answer/multiple_answer";
    const SUBMIT_TEXT_ANSWER_API = "exam_answer/text_answer";
    const SUBMIT_IMAGE_ANSWER_API = "exam_answer/image_answer";

    React.useEffect(() => {
        let scheduleId = sessionStorage.getItem('scheduleId');
        appContext.getAxios().get(GET_QUESTION + '/' + qid + '/' + scheduleId).then((response) => {
            console.log(response.data);
            setQuestion(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });

    }, [qid])

    React.useEffect(() => {
        setQid(props.questionId);
        setIndex(props.qIndex)
    }, [props.questionId])


    const handleNext = () => {
        setQid(question.nextQ)
        setIndex(index+1);
    };

    const handlePrev = () => {
        setQid(question.prevQ)
        setIndex(index-1);
    };

    const closeMarksDialog = () => {
        sessionStorage.removeItem('examId');
        sessionStorage.removeItem('scheduleId');
        window.location.reload();
    };

    const handleSubmit = () => {
        setDisabled(true);
        let examId = sessionStorage.getItem('examId');
        let scheduleId = sessionStorage.getItem('scheduleId');
        appContext.getAxios().get(EXAMS_SUBMIT_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
            setMarks(response.data['scoredMark']);
            setTotal(response.data['marks']);
            setCorrectCount(response.data['answeredCorrect']);
            setTotalCount(response.data['questions']);
            setShowmarks(true);
            setDisabled(false);
        }, (error) => {
            alert.error(error.response.data.message);
            sessionStorage.removeItem('examId');
            sessionStorage.removeItem('scheduleId');
            window.location.reload();
            setDisabled(false);

        });
    };

    function changeValue(value) {
        setSubmitValue(value);
        console.log(value);
        if (question.questionTypeId == 1 || question.questionTypeId == 3) {
            var data = {
                'examId': sessionStorage.getItem('examId'),
                'scheduleId': sessionStorage.getItem('scheduleId'),
                'examQuestionId': qid,
                'answer': value
            }
            appContext.getAxios().post(SUBMIT_SINGLE_ANSWER_API, data).then((response) => {
                console.log(response);
                props.setCurrentAnswer(qid);
            }).catch(error => {
                console.log(error)
            });
        }
        else if (question.questionTypeId == 2 || question.questionTypeId == 4) {
            var data = {
                'examId': sessionStorage.getItem('examId'),
                'scheduleId': sessionStorage.getItem('scheduleId'),
                'examQuestionId': qid,
                'answer': value
            }
            appContext.getAxios().post(SUBMIT_MULTIPLE_ANSWER_API, data).then((response) => {
                console.log(value.length);
                console.log(value.length !== 0);


                if (value.length !== 0) {
                    props.setCurrentAnswer(qid);
                } else {
                    props.setNotAnswered(qid)
                }
            }).catch(error => {
                console.log(error)
            });
        }
        else if (question.questionTypeId == 5) {
            var data = {
                'examId': sessionStorage.getItem('examId'),
                'scheduleId': sessionStorage.getItem('scheduleId'),
                'examQuestionId': qid,
                'answer': value
            }
            appContext.getAxios().post(SUBMIT_TEXT_ANSWER_API, data).then((response) => {
                console.log(response);
                if (value !== '') {
                    props.setCurrentAnswer(qid);
                } else {
                    props.setNotAnswered(qid)
                }
            }).catch(error => {
                console.log(error)
            });
        }
        else if (question.questionTypeId == 6) {
            var data = {
                'examId': sessionStorage.getItem('examId'),
                'scheduleId': sessionStorage.getItem('scheduleId'),
                'examQuestionId': qid,
                'answer': value
            }
            appContext.getAxios().post(SUBMIT_IMAGE_ANSWER_API, data).then((response) => {
                console.log(response);
                props.setCurrentAnswer(qid);
            }).catch(error => {
                console.log(error)
            });
        }
    };


    return (
        <>
            {question.questionTypeId == 1 &&
                <SingleAnswer question={question} submitVal={changeValue} index={index}/>
            }
            {question.questionTypeId == 2 &&
                <MultipleAnswer question={question} submitVal={changeValue} index={index} />
            }
            {question.questionTypeId == 3 &&
                <SingleAnswerImage question={question} submitVal={changeValue}  index={index}/>
            }
            {question.questionTypeId == 4 &&
                <MultipleAnswerImage question={question} submitVal={changeValue} index={index}/>
            }
            {question.questionTypeId == 5 &&
                <TextInput question={question} submitVal={changeValue} index={index} />
            }
            {question.questionTypeId == 6 &&
                <ImageInput question={question} submitVal={changeValue} index={index} />
            }
            <Divider />
            <Box display="flex" alignSelf="flex-end" justifyContent="center" width="100%" m={1} p={1} bgcolor="background.paper">
                <Box>
                    <Button variant="contained" disabled={question.prevQ === -1 || disabled} className={classes.prevbtn} onClick={() => handlePrev()}>
                        Previous
                    </Button>
                </Box>
                <Box>
                    <Button variant="contained" className={classes.nextbtn} disabled={question.nextQ === -1 || disabled} color="primary" onClick={() => handleNext()} mx={1} >
                        next
                    </Button>
                </Box>

                <Box>
                    <Button variant="contained" disabled={disabled} className={classes.nextbtn} color="primary" onClick={() => handleSubmit()} mx={1} >
                        Finish Exam
                    </Button>
                </Box>

            </Box>
            <Dialog maxWidth="lg" open={showmarks} onClose={closeMarksDialog} >
                <DialogTitle id="marks-dialog-title" disableTypography>
                    <Typography variant="h6" component="h2" gutterBottom>EXAM OVER</Typography>
                    <IconButton size="small" className={classes.close} onClick={closeMarksDialog}><CloseIcon /></IconButton>
                    <Divider classes={{ root: classes.divider }} />
                </DialogTitle>
                <DialogContent>
                    <Typography >
                        Thank You for attending the exam
                    <br />
                    You mark is &nbsp;<b>{marks}</b>&nbsp; out of &nbsp;<b>{total}</b>
                        <br />
                    You.ve got &nbsp; <b>{correctCount}</b> &nbsp; of &nbsp; <b>{totalCount}</b> &nbsp; correct answers.
                    <br />
                    Congrats
                    </Typography>
                </DialogContent>
            </Dialog>


        </>
    )
}