import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import Link from '@material-ui/core/Link';
import { useHistory } from "react-router-dom";


const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
        marginLeft: "10px"
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
}));
function createData(title, difficulty, marks) {
    return { title, difficulty, marks };
}
const rows = [
    createData('what is Science', 'hard', 20),
    createData('what is Maths', 'easy', 10),
    createData('what is Science', 'medium', 20),
    createData('what is Maths', 'hard', 10),
    createData('what is Science', 'easy', 20),

];


export default function ExamStart({ open, onClose, examId, scheduleId
}) {
    const classes = useStyles();
    const startExam = () => {
        sessionStorage.setItem('examId',examId);
        sessionStorage.setItem('scheduleId',scheduleId);
        window.location.reload()
    }
    return (
        <Dialog maxWidth="lg" open={open} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Register</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
                <div >
                    <Grid container>
                        <Grid item sm={12} md={12} >
                            Please confirm whether do you want to start examination?
                    </Grid>
                    </Grid>

                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            color=".error"
                            onClick={() => onClose()}
                        >
                            Cancel
                        </Button>

                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            color="secondary"
                            onClick={startExam}
                        >
                            Start
                        </Button>
                    </Box>
                </div >
            </DialogContent>
        </Dialog>

    )
}