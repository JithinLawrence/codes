import React, { useEffect, useState } from "react";
import useAppContext from './AppContext';


export default function CountdownTimer() {
    const appContext = useAppContext();

    const [startTimer, setStartTimer] = useState(false);
    const [duration, setDuration] = useState(null);
    const [examStart, setExamStart] = useState(null);
    const [currentTime, setCurrentTime] = useState(null);
    const [timeLeft, setTimeLeft] = useState(9999999);

    const START_TIME_API = "exam_answer/get_start_time"
    const DURATION_API = "exam_answer/get_duration"
    const EXAMS_SUBMIT_API = "exam_answer/submit_exam"
    const CURRENTTIME_API = "exam_answer/get_current_time"

    function getStartTime() {
        let examId = sessionStorage.getItem('examId');
        let scheduleId = sessionStorage.getItem('scheduleId');
        appContext.getAxios().get(START_TIME_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
            setExamStart(response.data);

        }, (error) => {
            console.log(error)
            // alert.error(error.response.data.message);
        });
    }

    function getDuration() {
        let examId = sessionStorage.getItem('examId');
        appContext.getAxios().get(DURATION_API + '/' + (examId)).then((response) => {
            console.log(response.data)
            setDuration(response.data);
            setStartTimer(true)
        }, (error) => {
            console.log(error)
            // alert.error(error.response.data.message);
        });
    }

    function getCurrentDate() {
        appContext.getAxios().get(CURRENTTIME_API).then((response) => {
            setCurrentTime(response.data);
        }, (error) => {
            console.log(error)
            return 0;
        });
    }

    React.useEffect(() => {
        getStartTime();
        getDuration();
    }, []);

    const calculateTimeLeft = (startTimer) => {
        if (startTimer && examStart != null && duration != null) {
            const difference = duration * 60000 - (new Date() - new Date(examStart));
            let timeLeft = {};

            if (difference > 0) {
                timeLeft = {
                    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                    minutes: Math.floor((difference / 1000 / 60) % 60),
                    seconds: Math.floor((difference / 1000) % 60)
                };
            }
            else {
                if (duration != null && examStart != null) {
                    let examId = sessionStorage.getItem('examId');
                    let scheduleId = sessionStorage.getItem('scheduleId');
                    appContext.getAxios().get(EXAMS_SUBMIT_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
                        console.log(response)
                        sessionStorage.removeItem('examId');
                        sessionStorage.removeItem('scheduleId');
                        setTimeout(() => { }, 10000);
                        window.location.reload(true);
                    }, (error) => {
                        sessionStorage.removeItem('examId');
                        sessionStorage.removeItem('scheduleId');
                        alert.error("Something went wrong please try again");
                        window.location.reload(true);
                    });
                    
                }
            }
            return timeLeft;
        }
        return "0"
    };


    useEffect(() => {
        setTimeout(() => {
            setTimeLeft(calculateTimeLeft(startTimer));
        }, 1000);
    });

    const timerComponents = [];

    Object.keys(timeLeft).forEach(interval => {
        if (!timeLeft[interval]) {
            if (interval == "seconds") {
                timeLeft[interval] = "00";
            }
            else {
                return ""
            }
        }
        if (interval == "seconds") {
            timerComponents.push(
                <span>
                    {timeLeft[interval]}
                </span>
            );
        } else {
            timerComponents.push(
                <span>
                    {timeLeft[interval]}{":"}
                </span>
            );
        }
    });

    return (
        <div>
            {timerComponents.length ? timerComponents : <span>Time's up!</span>}
        </div>
    );
}

