import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import { Link } from "react-router-dom";
import ListAltIcon from '@material-ui/icons/ListAlt';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import FormControl from '@material-ui/core/FormControl';
import { TextField } from '@material-ui/core';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";
import TablePagination from '@material-ui/core/TablePagination';
import ExamResult from './examResult';
import IconButton from '@material-ui/core/IconButton';


const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    mainContainer: {
        width: "100%"
    },
    mainGridContainer: {
        flexGrow: 1,
    },
    mainGrid: {
        margin: "10px;",
        // height: "35% !important"
    },
    noDecLink: {
        textDecoration: "none",
    },
    cursorPinter: {
        cursor: 'pointer'
    }
});





export default function ExamHistory() {
    const classes = useStyles();
    const alert = useAlert();
    const appContext = useAppContext();
    const [data, setData] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('exam_id');
    const [sortType, setSortType] = React.useState(true);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [examId, setExamId] = React.useState(null);
    const [scheduleId, setScheduleId] = React.useState(null);

    const EXAMS_LIST_API = "exam_result/get_exam_history"

    function getExams() {
        appContext.getAxios().get(EXAMS_LIST_API + '?page=' + (page + 1) + '&limit=' + limit + '&search=' + search + '&type=' + sortType + '&sort=' + sort).then((response) => {
            console.log(response.data.result)
            setData(response.data.result);
            setPage(response.data.currentPage - 1)//to reset page in case deleting the last row of last page
            setCount(response.data.pagerInfo.count);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeLimit = event => {
        setLimit(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleSearchChange = event => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleSort = val => {
        if (sort == val) {
            setSortType(!sortType)
        } else {
            setSortType(sort == val)
        }
        setSort(val);
    };
    const showResult = (eId, sId) => {
        console.log("sssssssssssss")
        console.log(eId);
        console.log(sId)
        setScheduleId(sId);
        setExamId(eId);
    };


    React.useEffect(() => {
        getExams();
    }, [sort, sortType, page, limit, search]);


    if (scheduleId != null && examId != null) {
        console.log(scheduleId,examId)
        return (<ExamResult eId={examId} sId={scheduleId}></ExamResult>)
    }

    return (
        <div>
            <h1>Exam History</h1>
            <Divider></Divider>
            <Box className={classes.toolbar} display="flex" flexDirection="row-reverse">


                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                            label="Search"
                            id="titleSearch"
                            value={search}
                            onChange={handleSearchChange}
                        ></TextField>
                    </FormControl>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>

                            <TableCell className={classes.cursorPinter} onClick={() => { handleSort('e.name'); }}>Title</TableCell>
                            <TableCell className={classes.cursorPinter} onClick={() => { handleSort('e.duration'); }} align="center">Mark</TableCell>
                            <TableCell className={classes.cursorPinter} onClick={() => { handleSort('s.start_time'); }} align="center">Schedule</TableCell>
                            <TableCell align="center">Result</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {data.map((row) => (
                            <TableRow key={row.examResultId}>
                                <TableCell component="th" scope="row" style={{ overflow: "hide", width: "500px" }}>
                                    <b>{row.name}</b>
                                    <br>
                                    </br>
                                    <div dangerouslySetInnerHTML={{ __html: row.description }} />
                                </TableCell>
                                <TableCell align="center">{row.mark}</TableCell>
                                <TableCell align="center">{row.startTime}</TableCell>
                                <TableCell align="center">
                                    <IconButton><ListAltIcon onClick={() => showResult(row.examId, row.scheduleId)} fontSize="default" /></IconButton>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>

                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[0]}
                component="div"
                count={count}
                rowsPerPage={limit}
                page={page}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeLimit}
            />
        </div>
    );
}