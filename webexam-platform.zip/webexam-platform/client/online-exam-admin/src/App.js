import React from 'react';
import { BrowserRouter as Router, Route, Switch, useRouteMatch, useHistory, Redirect } from 'react-router-dom';
import clsx from 'clsx';
import CssBaseline from '@material-ui/core/CssBaseline';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import Button from '@material-ui/core/Button';
import Tooltip from '@material-ui/core/Tooltip';
import Link from '@material-ui/core/Link';
import { withStyles } from "@material-ui/core";
import { makeStyles, useTheme } from "@material-ui/core/styles";
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Fade from '@material-ui/core/Fade';
import CategoryIcon from '@material-ui/icons/Category';
import GradeIcon from '@material-ui/icons/Grade';


import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

import DashboardSharpIcon from '@material-ui/icons/Dashboard';
import MenuIcon from '@material-ui/icons/Menu';
import CreateOutlinedSharpIcon from '@material-ui/icons/CreateOutlined';
import ScheduleSharpIcon from '@material-ui/icons/ScheduleSharp';
import LibraryBooksRoundedIcon from '@material-ui/icons/LibraryBooksRounded';
import AssignmentTurnedInRoundedIcon from '@material-ui/icons/AssignmentTurnedInRounded';
import SchoolRoundedIcon from '@material-ui/icons/SchoolRounded';
import AccountBoxRoundedIcon from '@material-ui/icons/AccountBoxRounded';
import AccountCircleRoundedIcon from '@material-ui/icons/AccountCircleRounded';

import useAppContext from './AppContext';
import dashboard from './dashboard';
import ForgotPassword from './forgotPassword';
import ForgotPasswordReset from './forgotPasswordReset';
import Register from './register';
import SignIn from './SignIn';
import Questions from './questions';
import ExamCreate from './examCreate';
import ExamSchedule from './examSchedule';
import ExamScheduleCreate from './examScheduleCreate'
import QuestionCreate from './questionCreate';
import QuestionEdit from './questionEdit';
import Exams from './exams';
import ExamReport from './examReport';
import ExamEdit from './examEdit';
import ExamCopy from './examCopy';
import UserList from './examPlanerList';
import CandidatesList from './candidatesList';
import CandidatesExamList from './candidatesExamList';
import ExamCandidateList from './examCandidateList';
import ExamScheduleEdit from './examScheduleEdit';
import QuestionBankList from './questionBankList';
import QuestionBankCreate from './questionBankCreate';
import QuestionBankEdit from './questionBankEdit';
import { PasswordChange } from './profile'
import ProfileChange from './profile'
import { positions, Provider } from "react-alert";
import AlertTemplate from "react-alert-template-basic";
import GradeList from './gradeList';
import GradeAdd from './gradeAdd';
import GradeEdit from './gradeEdit';
import CategoryAdd from './categoryAdd';
import CategoryEdit from './categoryEdit';
import CategoryList from './categoryList';
import QuestionBankAddQuestions from './questionBankAddQuestions';
import ExamResult from './examResult';
import Avatar from '@material-ui/core/Avatar';
import ListIcon from '@material-ui/icons/List';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
    },
    toolbar: {
        paddingRight: 24, // keep right padding when drawer closed
    },
    toolbarIcon: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: '0 8px',
        ...theme.mixins.toolbar,
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
    },
    menuButton: {
        marginRight: 36,
    },
    title: {
        flexGrow: 1,
    },
    drawerPaper: {
        position: 'relative',
        whiteSpace: 'nowrap',
        backgroundColor: "#e9e9e9",
        borderRight: 0,
        paddingTop: theme.spacing(10),
        overflow: "hidden",
        width: drawerWidth,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    drawerPaperClose: {
        overflowX: 'hidden',
        backgroundColor: "#e9e9e9",
        paddingTop: theme.spacing(10),
        overflow: "hidden",
        borderRight: 0,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        width: theme.spacing(7),
        [theme.breakpoints.up('sm')]: {
            width: theme.spacing(7),
        },
    },
    content: {
        flexGrow: 1,
        height: '100vh',
        overflow: 'auto',
        paddingTop: theme.spacing(10),
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(2)
    },

    paper: {
        padding: theme.spacing(2),
        display: 'flex',
        overflow: 'auto',
        flexDirection: 'column',
    },
    profileMenu: {
        marginTop: theme.spacing(4)
    },
    imageBox: {
        // backgroundColor: theme.palette.secondary.light + " !important",
        // fontSize: "20px !important",
        // fontWeight: "bold",
        // width: theme.spacing(10),
        // height: theme.spacing(10),
        // marginLeft: theme.spacing(2),
        // height: "40px !important",
        // width: "40px !important",
    },
    cursorPinter:{
        cursor: 'pointer'
    },


}));

const options = {
    timeout: 5000,
    containerStyle: {
        zIndex: 10000
      },
    position: positions.TOP_RIGHT
  };

function Copyright() {
    return (
        <Typography variant="body2" color="textSecondary" align="center">
            {'Copyright © '}
            <Link color="inherit" href="https://material-ui.com/">
                Your Website
      </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

const StyledListItem = withStyles({
    root: {
        "&$selected": {
            backgroundColor: "white"
        },
        "&:hover": {
            backgroundColor: "white !important"
        }

    },
    selected: {}
})(ListItem);

function MenuLink({ to, icon: Icon, text }) {
    const history = useHistory();
    const classes = useStyles();
    const match = useRouteMatch(to);
    return (
        <Tooltip title={text} placement="right-end">
            <StyledListItem button selected={match && match.isExact} onClick={() => history.push(to)}>
                <ListItemIcon><Icon color="secondary" fontSize="small" /></ListItemIcon>
                <ListItemText primary={text} />
            </StyledListItem>
        </Tooltip>
    );
}

export default function App() {
    const appContext = useAppContext();
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);
    const [profileOpen, setProfileOpen] = React.useState(false);
    const [passwordOpen, setPasswordOpen] = React.useState(false);
    const [anchorEl, setAnchorEl] = React.useState(null);
    const accountsOpen = Boolean(anchorEl);
    const handleDrawerOpen = () => {
        setOpen(!open);
    };
    const handleProfileClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleProfileClose = () => {
        setAnchorEl(null);
    };
    const history = useHistory();
    const handleProfileLogout = () => {//window.location.href = 'http://www.google.com'; Config.apiBase
        setAnchorEl(null);
        appContext.logout();
        history.push('/')
    };
    const handleProfileChange = () => {
        setAnchorEl(null);
        setProfileOpen(true);
    };
    const handlePasswordChange = () => {
        setAnchorEl(null);
        setPasswordOpen(true);
    };
    const handleProfileChangeClose = hasChange => {
        setProfileOpen(false);
    };
    const handlePasswordChangeClose = hasChange => {
        setPasswordOpen(false);
    };

    if (window.location.pathname.endsWith("/register")) {
        return (
            <><Register></Register></>
        )
    } else if (window.location.pathname.endsWith("/forgotpassword")) {
        return (
            <>
            <Provider template={AlertTemplate} {...options}>
            <ForgotPassword></ForgotPassword>
            </Provider>
            </>
        )
    }  else if (window.location.pathname.includes("/forgotPasswordReset")) {
        return (
            <>
            <Provider template={AlertTemplate} {...options}>
            <ForgotPasswordReset></ForgotPasswordReset>
            </Provider>
            </>
        )
    } else if (!appContext.isLoggedin()) {
        return (
            <>
            <Provider template={AlertTemplate} {...options}>
            <SignIn/>
            </Provider>
            </>
        )
    }
    return (
        <>
            <Provider template={AlertTemplate} {...options}>
            <div className={classes.root}>
                <CssBaseline />
                <AppBar position="absolute" color="secondary" className={classes.appBar}>
                    <Toolbar className={classes.toolbar}>
                        <IconButton
                            edge="start"
                            color="inherit"
                            aria-label="open drawer"
                            onClick={handleDrawerOpen}
                            className={clsx(classes.menuButton)}
                        >
                            <MenuIcon />
                        </IconButton>
                        <Typography component="h1" variant="h6" color="inherit" noWrap className={classes.title}>
                            {appContext.getTitle()}
                        </Typography>
                        {/* <Button color="inherit"> */}
                            {/* <Avatar className={classes.imageBox} src={`${localStorage.getItem("imageUrl")}`}> */}
                                <AccountCircleRoundedIcon />
                                {/* <ListIcon /> */}
                            {/* </Avatar> */}
                            <Typography variant="caption"> &nbsp; {`${localStorage.getItem("firstName")} ${localStorage.getItem("lastName")}`} </Typography>
                            <ExpandMoreIcon className={classes.cursorPinter} onClick={handleProfileClick}/>
                        {/* </Button> */}
                        <Menu
                            id="profile-menu"
                            className={classes.profileMenu}
                            elevation={0}
                            anchorEl={anchorEl}
                            keepMounted
                            open={accountsOpen}
                            onClose={handleProfileClose}
                            TransitionComponent={Fade}
                        >
                            <MenuItem onClick={handleProfileChange}>Edit Profile</MenuItem>
                            <MenuItem onClick={handlePasswordChange}>Change Password</MenuItem>
                            <MenuItem onClick={handleProfileLogout}>Logout</MenuItem>
                        </Menu>
                    </Toolbar>
                </AppBar>
                <Drawer
                    variant="permanent"
                    classes={{
                        paper: clsx(classes.drawerPaper, !open && classes.drawerPaperClose),
                    }}
                    open={open}
                >
                    <List>
                        {/* <MenuLink to="/" icon={DashboardSharpIcon} text="Dashboard" /> */}                          
                        {(localStorage.getItem("role")==1 || localStorage.getItem("role")==2 || localStorage.getItem("role")==4) && <MenuLink to="/questionbanklist" icon={LibraryBooksRoundedIcon} text="Question bank" />}
                        {(localStorage.getItem("role")==1 || localStorage.getItem("role")==2 || localStorage.getItem("role")==4) && <MenuLink to="/questions" icon={CreateOutlinedSharpIcon} text="Questions" />}
                        {(localStorage.getItem("role")==1 || localStorage.getItem("role")==2 ) && <MenuLink to="/exams" icon={AssignmentTurnedInRoundedIcon} text="Exams" />}
                        {(localStorage.getItem("role")==1 || localStorage.getItem("role")==2 ) &&<MenuLink to="/examschedule" icon={ScheduleSharpIcon} text="Exam scheduler" />}
                        {(localStorage.getItem("role")==1 || localStorage.getItem("role")==2 ) &&<MenuLink to="/students" icon={SchoolRoundedIcon} text="Candidates" />}
                        {(localStorage.getItem("role")==1 ) && <MenuLink to="/users" icon={AccountBoxRoundedIcon} text="Users" />}
                        {(localStorage.getItem("role")==1 ) &&<MenuLink to="/grades" icon={GradeIcon} text="Group" />}
                        {(localStorage.getItem("role")==1 ) &&<MenuLink to="/categories" icon={CategoryIcon} text="Category" />}                  
                    </List>
                </Drawer>
                <main className={classes.content}>
                    <div className={classes.toolbar} />
                    <Switch>
                        <Route path="/grades" component={GradeList} />
                        <Route path="/gradeadd" component={GradeAdd} />
                        <Route path="/gradeedit" component={GradeEdit} />
                        <Route path="/categories" component={CategoryList} />
                        <Route path="/categoryadd" component={CategoryAdd} />
                        <Route path="/categoryedit" component={CategoryEdit} />
                        <Route path="/exams" component={Exams} />
                        <Route path="/examcandidates" component={ExamCandidateList} />
                        <Route path="/examcreate" component={ExamCreate} />
                        <Route path="/examedit/:examId" component={ExamEdit} />
                        <Route path="/examcopy/:examId" component={ExamCopy} />
                        <Route path="/users" component={UserList} />
                        <Route path="/examreport/:examId" component={ExamReport} />
                        <Route path="/examschedule" component={ExamSchedule} />
                        <Route path="/examschedulecreate" component={ExamScheduleCreate} />
                        <Route path="/examscheduleedit" component={ExamScheduleEdit} />
                        <Route path="/questionedit/:questionId" component={QuestionEdit} />
                        <Route path="/questionbank/:questionBankId" component={Questions} />
                        <Route path="/questions" component={Questions} />
                        <Route path="/questionbankcreate" component={QuestionBankCreate} />
                        <Route path="/questionbankedit/:questionBankId" component={QuestionBankEdit} />
                        <Route path="/questionbankList" component={QuestionBankList} />
                        <Route path="/questioncreate" component={QuestionCreate} />
                        <Route path="/students" component={CandidatesList} />
                        <Route path="/studentsexam/:userId" component={CandidatesExamList} />
                        <Route path="/questionbankaddquestions" component={QuestionBankAddQuestions} />
                        <Route path="/result/:examId/:scheduleId" component={ExamResult} />
                        <Route exact path="/">
                            {appContext.isLoggedin() ? <Redirect to="/questions" /> : <SignIn />}
                        </Route>
                    </Switch>
                </main>
            </div>
            {/* <Copyright /> */}
            <PasswordChange open={passwordOpen} onClose={handlePasswordChangeClose} />
            <ProfileChange open={profileOpen} onClose={handleProfileChangeClose} />
            </Provider>
        </>
    );
}
