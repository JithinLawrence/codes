import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import useAppContext from './AppContext';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import DialogActions from '@material-ui/core/DialogActions';

const useStyles = makeStyles({
    table: {
        minWidth: 150,
        marginTop: theme.spacing(1),
        marginBottom: theme.spacing(1)
    },
    formControl: {
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    addButton: {
        marginLeft: theme.spacing(1)
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    dialog: {
        paddingTop: theme.spacing(8),
    },
    dialogActionsCenter: {
        justifyContent: "center",
        marginTop: theme.spacing(1),

    },
    dialogActionsLeft:{
        justifyContent: "left",
        marginBottom: theme.spacing(1),
        marginLeft:theme.spacing(2),
        paddingTop:0
    }
});

function createData(id, firstName, lastName, email, grade) {
    return { id, firstName, lastName, email, grade };
}

const rows = [
    createData(1, "Student1", "Student1", "student1@noemail.com", 3),
    createData(2, "Student1", "Student1", "student1@noemail.com", 4),
    createData(3, "Student1", "Student1", "student1@noemail.com", 8),
    createData(1, "Student1", "Student1", "student1@noemail.com", 3),
    createData(2, "Student1", "Student1", "student1@noemail.com", 4),
    createData(3, "Student1", "Student1", "student1@noemail.com", 8),
    createData(1, "Student1", "Student1", "student1@noemail.com", 3),
    createData(2, "Student1", "Student1", "student1@noemail.com", 4),
    createData(3, "Student1", "Student1", "student1@noemail.com", 8),
];



export default function ExamAssign({ open, onClose }) {
    const classes = useStyles();
    const [checked, setChecked] = React.useState(false);

    const handleClick = () => {
        setChecked(!checked);
    };
    return (
        <Dialog scroll="paper" className={classes.dialog} fullWidth maxWidth="lg" open={open} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Assign Candidates</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogActions className={classes.dialogActionsLeft}>
                <FormControl className={classes.formControl}>
                    <InputLabel id="select-group-label">Group</InputLabel>
                    <Select
                        labelId="select-group-label"
                        id="select-group"
                        value={""}
                    >
                        <MenuItem value={1}>group 1</MenuItem>
                        <MenuItem value={2}>group 2</MenuItem>
                        <MenuItem value={3}>group 3</MenuItem>
                    </Select>
                </FormControl>
            </DialogActions>
            <DialogContent>

                <TableContainer component={Paper}>
                    <Table className={classes.table} aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell padding="checkbox">
                                    <Checkbox
                                        color="secondary"
                                        inputProps={{ 'aria-label': 'checkbox' }}
                                        checked={checked}
                                        onClick={handleClick}
                                    />
                                </TableCell>
                                <TableCell>Id</TableCell>
                                <TableCell align="center">First Name</TableCell>
                                <TableCell align="center">Last Name</TableCell>
                                <TableCell align="center">Email</TableCell>
                                <TableCell align="right">Grade</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.map((row) => (
                                <TableRow key={row.name}>
                                    <TableCell padding="checkbox">
                                        <Checkbox
                                            color="secondary"
                                            inputProps={{ 'aria-label': 'checkbox' }}
                                            checked={checked}
                                        />
                                    </TableCell>
                                    <TableCell component="th" scope="row">
                                        {row.id}
                                    </TableCell>
                                    <TableCell align="center">{row.firstName}</TableCell>
                                    <TableCell align="center">{row.lastName}</TableCell>
                                    <TableCell align="center">{row.email}</TableCell>
                                    <TableCell align="right">{row.grade}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>


            </DialogContent>
            <DialogActions className={classes.dialogActionsCenter}>
                <Button
                    variant="contained"
                    color="secondary"
                    justify="center"
                >
                    Save
                </Button>
            </DialogActions>
        </Dialog>
    )
}