import React, { useEffect, useState } from "react";
import useAppContext from './../AppContext';


let dt = new Date();
dt.setMinutes(dt.getMinutes() + 30);
export default function CountdownTimer({examId, save}) {
    const appContext = useAppContext();

    const [startTimer, setStartTimer] = useState(false);
    const [duration, setDuration] = useState(null);
    const [examStart, setExamStart] = useState(null);
    const [timeLeft, setTimeLeft] = useState(9999999);

    const START_TIME_API = "preview_exam_answer/get_start_time"
    const DURATION_API = "preview_exam_answer/get_duration"
    const EXAMS_SUBMIT_API ="preview_exam_answer/submit_exam"
    
    function getStartTime() {
        setExamStart(new Date());
        // let examId = localStorage.getItem('examId');
        // let scheduleId = localStorage.getItem('scheduleId');
        // appContext.getAxios().get(START_TIME_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
        //     setExamStart(response.data);

        // }, (error) => {
        //     console.log(error)
        //     // alert.error(error.response.data.message);
        // });
    }

    function getDuration() {
        appContext.getAxios().get(DURATION_API + '/' + (examId)).then((response) => {
            console.log(response.data)
            if(save.duration == ""){
                setDuration(response.data);
            } else {
                setDuration(save.duration);
            }
            setStartTimer(true)
        }, (error) => {
            console.log(error)
            // alert.error(error.response.data.message);
        });
    }
    React.useEffect(() => {
        getStartTime();
        getDuration();
    }, []);

    const calculateTimeLeft = (startTimer) => {
        setTimeout(() => { }, 3000);
        if (startTimer && examStart != null && duration != null) {
            const difference = duration * 60000 - (new Date() - new Date(examStart));
            let timeLeft = {};

            if (difference > 0) {
                timeLeft = {
                    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                    minutes: Math.floor((difference / 1000 / 60) % 60),
                    seconds: Math.floor((difference / 1000) % 60)
                };
            }
            else {
                // let examId = localStorage.getItem('examId');
                // let scheduleId = localStorage.getItem('scheduleId');
                // appContext.getAxios().get(EXAMS_SUBMIT_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
                //     console.log(response)
                //     localStorage.removeItem('examId');
                //     localStorage.removeItem('scheduleId');
                //     window.location.reload();
                // }, (error) => {
                //     alert.error("Something went wrong please try again");

                // });
                window.location.reload();
            }
            return timeLeft;
        }
        return "0"
    };


    useEffect(() => {
        setTimeout(() => {
            setTimeLeft(calculateTimeLeft(startTimer));
        }, 1000);
    });

    const timerComponents = [];

    Object.keys(timeLeft).forEach(interval => {
        if (!timeLeft[interval]) {
            if (interval == "seconds") {
                timeLeft[interval] = "00";
            }
            else {
                return ""
            }
        }
        if (interval == "seconds") {
            timerComponents.push(
                <span>
                    {timeLeft[interval]}
                </span>
            );
        } else {
            timerComponents.push(
                <span>
                    {timeLeft[interval]}{":"}
                </span>
            );
        }
    });

    return (
        <div>
            {timerComponents.length ? timerComponents : <span>Time's up!</span>}
        </div>
    );
}

