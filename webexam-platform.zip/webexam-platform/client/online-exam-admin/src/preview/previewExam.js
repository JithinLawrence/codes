import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import Box from '@material-ui/core/Box';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import { grey } from '@material-ui/core/colors';
import CssBaseline from '@material-ui/core/CssBaseline';
import clsx from 'clsx';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import useAppContext from './../AppContext';
import AccountCircleRoundedIcon from '@material-ui/icons/AccountCircleRounded';
import Catagory from './catagory'
import { BrowserRouter as Router, Link, Switch, Route, useHistory } from 'react-router-dom';
import PlayCircleFilledWhiteIcon from '@material-ui/icons/PlayCircleFilledWhite';
import Card from '@material-ui/core/Card';
import ExamaDashBoard from './previewExamDashboard';
import Agreement from './previewAgreement';
import { useAlert } from "react-alert";
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import Avatar from '@material-ui/core/Avatar';


const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({

    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    drawer: {
        justifyContent: 'center',
        backgroundColor: grey[400],
        borderColor: "secondary",
        flexWrap: 'wrap',
        height: '90vh',
        marginRight: theme.spacing(1)
    },
    catogories: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    questions: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    dialog: {
        padding: theme.spacing(3)
    },
    dialogTitle: {
        backgroundColor: theme.palette.primary.main,
    },
    catogoryChip: {
        margin: theme.spacing(0.5),
        backgroundColor: theme.palette.primary.main,
    },
    purple: {
        color: theme.palette.getContrastText(theme.palette.primary.main),
        backgroundColor: theme.palette.primary.main,
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    caption: {
        margin: theme.spacing(3)
    },
    questionArea: {
        width: `calc(100% - ${drawerWidth}px)`,
        paddingTop: theme.spacing(3)
    },
    nextbtn: {
        margin: theme.spacing(3)
    },
    prevbtn: {
        margin: theme.spacing(3)
    },
    timerDiv: {
        fontSize: 20,

    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    title: {
        flexGrow: 1,
    },
    content: {
        paddingTop: theme.spacing(5)
    },
    catTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        textAlign: "center",
        paddingTop: "20px",
        fontWeight: "bold"
    },
    catDetailP: {
        marginLeft: "10px",

    },

}));


export default function PreviewExam({ open, onClose, row, type, save }) {
    const appContext = useAppContext();
    const classes = useStyles();
    const [qno, setQno] = React.useState(1);
    const [btntext, setBtntext] = React.useState("next");
    const [status, setStatus] = React.useState(-1);
    const [examId, setExamId] = React.useState(0);

    const alert = useAlert();
    const history = useHistory();
    // const EXAMS_ANSWER_STATUS_API = "preview_exam_answer/status"

    // function getExamStatus() {
    //     let examId = localStorage.getItem('examId')
    //     let scheduleId = localStorage.getItem('scheduleId')
    //     appContext.getAxios().get(EXAMS_ANSWER_STATUS_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
    //         console.log(response.data)
    //         setStatus(response.data);

    //     }, (error) => {
    //         alert.error(error.response.data.message);
    //     });

    // }

    const onAgreeHandle = hasChange => {
        console.log(hasChange)
        if(hasChange){
            setStatus(2);
        }
    };

    React.useEffect(() => {
        if(open){
            setStatus(-1);
            setExamId(row.examId);
            console.log(save)
        }
    }, [open]);


    return (
        <div>
            <Dialog fullScreen open={open} 
            onClose={() => {
                onClose(true);
            }} 
            // TransitionComponent={Transition}
            >
            <CssBaseline />
            <AppBar position="absolute" color="secondary" className={classes.appBar}>
                <Toolbar className={classes.toolbar}>
                    <IconButton edge="start" color="inherit" onClick={() => {
                        onClose(true);
                        }} 
                        aria-label="close">
                        <CloseIcon />
                    </IconButton>
                    <Typography component="h1" variant="h6" color="inherit" noWrap className={classes.title}>
                        {appContext.getTitle()}
                    </Typography>

                    <Divider orientation={"vertical"} />
                    <Button color="inherit" m={5} disabled>
                        {/* <Avatar className={classes.imageBox} src={`${localStorage.getItem("imageUrl")}`}> */}
                            <AccountCircleRoundedIcon />
                        {/* </Avatar> */}
                        <Typography variant="caption"> &nbsp; {localStorage.getItem("firstName")} {localStorage.getItem("lastName")} </Typography>
                    </Button>
                </Toolbar>
            </AppBar>
            {/* <DialogContent> */}
                <div className={classes.content}>
                    <br></br>
                    {status == -1 && <Agreement examId={examId} onAgree={onAgreeHandle} save={save}/>}
                    {status == 2 && <ExamaDashBoard examId={examId} type={type} save={save}/>}
                </div >
            {/* </DialogContent> */}
            </Dialog>
        </div>
    )
}