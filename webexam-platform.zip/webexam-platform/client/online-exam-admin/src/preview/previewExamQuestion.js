import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import useAppContext from './../AppContext';
import { BrowserRouter as Router, Link, Switch, Route, useHistory } from 'react-router-dom';
import { useAlert } from "react-alert";
import SingleAnswer from './questionType/singleAnswerType';
import MultipleAnswer from './questionType/multipleAnswerType';
import SingleAnswerImage from './questionType/singleAnswerImageType';
import MultipleAnswerImage from './questionType/multipleAnswerImageType';

import TextInput from './questionType/textInput';
import ImageInput from './questionType/imageInput';

import { Typography, Grid } from '@material-ui/core';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import { Divider } from '@material-ui/core';
import { set } from 'date-fns';


const useStyles = makeStyles((theme) => ({

    nextbtn: {
        margin: theme.spacing(1)
    },
    prevbtn: {
        margin: theme.spacing(1)
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },

}));


export default function ExamQuestion(props) {
    const appContext = useAppContext();
    const classes = useStyles();
    const alert = useAlert();
    const history = useHistory();

    const [question, setQuestion] = React.useState({});
    const [qid, setQid] = React.useState(props.questionId);
    const [submitValue, setSubmitValue] = React.useState(0);
    const [answers, setAnswers] = React.useState({});
    const [showmarks, setShowmarks] = React.useState(false);
    const [marks, setMarks] = React.useState(0);
    const [total, setTotal] = React.useState(0);
    const [correctCount, setCorrectCount] = React.useState(0);
    const [totalCount, setTotalCount] = React.useState(false);

    const GET_QUESTION = "preview_exam_answer/get_exam_question";
    const EXAMS_SUBMIT_API ="preview_exam_answer/submit_exam"
    const SUBMIT_SINGLE_ANSWER_API = "preview_exam_answer/single_answer";
    const SUBMIT_MULTIPLE_ANSWER_API = "preview_exam_answer/multiple_answer";
    const SUBMIT_TEXT_ANSWER_API = "preview_exam_answer/text_answer";
    const SUBMIT_IMAGE_ANSWER_API = "preview_exam_answer/image_answer";

    React.useEffect(() => {
        appContext.getAxios().get(GET_QUESTION + '/' + qid+'?type='+props.type).then((response) => {
            console.log("++++++++++");
            console.log(response.data);
            setQuestion(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });

    }, [qid])

    React.useEffect(() => {
       setQid(props.questionId);

    }, [props.questionId])


    const handleNext = () => {
        setQid(question.nextQ)
    };

    const handlePrev = () => {
        setQid(question.prevQ)
    };

    const closeMarksDialog = () => {
        localStorage.removeItem('examId');
        localStorage.removeItem('scheduleId');
        window.location.reload();
    };

    const handleSubmit = () => {
        // let examId = localStorage.getItem('examId');
        // let scheduleId = localStorage.getItem('scheduleId');
        // appContext.getAxios().get(EXAMS_SUBMIT_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
        //     setMarks(response.data['scoredMark']);
        //     setTotal(response.data['marks']);
        //     setCorrectCount(response.data['answeredCorrect']);
        //     setTotalCount(response.data['questions']);
        //     setShowmarks(true);

        // }, (error) => {
        //     alert.error(error.response.data.message);

        // });
    };

    function changeValue(value) {
        setSubmitValue(value);
        let ans = answers;
        if(question.questionTypeId == 1 || question.questionTypeId == 3){
            console.log("13");
            ans[qid] = value;
            if (value.length > 0) {
                props.setCurrentAnswer(qid);
            } else {
                props.setNotAnswered(qid)
            }
        }
        else if(question.questionTypeId == 2 || question.questionTypeId == 4){
            console.log("24");
            ans[qid] = value;
            if (value.length > 0) {
                props.setCurrentAnswer(qid);
            } else {
                props.setNotAnswered(qid)
            }
        }
        else if(question.questionTypeId == 5){
            ans[qid] = value;
            if (value !== '') {
                props.setCurrentAnswer(qid);
            } else {
                props.setNotAnswered(qid)
            }
        }
        else if(question.questionTypeId == 6){
            ans[qid] = value;
            if (value !== '') {
                props.setCurrentAnswer(qid);
            } else {
                props.setNotAnswered(qid)
            }
        }
        console.log(ans);
        setAnswers(ans)
    };


    return (
        <>
            <div style={{'display':'none'}}>{qid}</div>
            {question.questionTypeId == 1 &&
                <SingleAnswer question={question} submitVal={changeValue} answers={answers}/>
            }
            {question.questionTypeId == 2 &&
                <MultipleAnswer question={question} submitVal={changeValue}  answers={answers}/>
            }
            {question.questionTypeId == 3 &&
                <SingleAnswerImage question={question} submitVal={changeValue}  answers={answers}/>
            }
            {question.questionTypeId == 4 &&
                <MultipleAnswerImage question={question} submitVal={changeValue}  answers={answers}/>
            }
            {question.questionTypeId == 5 &&
                <TextInput question={question} submitVal={changeValue}  answers={answers}/>
            }
            {question.questionTypeId == 6 &&
                <ImageInput question={question} submitVal={changeValue}  answers={answers}/>
            }
            <Divider/>
            <Box display="flex" alignSelf="flex-end" justifyContent="center" width="100%" m={1} p={1} bgcolor="background.paper">
                <Box>
                    <Button variant="contained" disabled={question.prevQ === -1} className={classes.prevbtn} onClick={() => handlePrev()}>
                        Previous
                    </Button>
                </Box>
                <Box>
                    <Button variant="contained" className={classes.nextbtn} disabled={question.nextQ === -1} color="primary" onClick={() =>handleNext()} mx={1} >
                        next
                    </Button>
                </Box>

                {/* <Box>
                    <Button variant="contained" className={classes.nextbtn} 
                    // disabled={question.nextQ === -1} 
                    color="primary" onClick={() =>handleSubmit()} mx={1} >
                        Submit
                    </Button>
                </Box> */}

            </Box>
            <Dialog maxWidth="lg" open={showmarks} onClose={closeMarksDialog} >
                <DialogTitle id="marks-dialog-title" disableTypography>
                    <Typography variant="h6" component="h2" gutterBottom>EXAM OVER</Typography>
                    <IconButton size="small" className={classes.close} onClick={closeMarksDialog}><CloseIcon /></IconButton>
                    <Divider classes={{ root: classes.divider }} />
                </DialogTitle>
                <DialogContent>
                    <Typography >
                        Thank You for attending the exam
                    You mark is {marks} out of {total}
                    You.ve got {correctCount} of {totalCount} correct answers.
                    Congrats
                    </Typography>
                </DialogContent>
            </Dialog>

        </>
    )
}