import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import useAppContext from '../AppContext';
import { BrowserRouter as Router, Link, Switch, Route, useHistory } from 'react-router-dom';
import { useAlert } from "react-alert";
import SingleAnswer from './questionType/singleAnswerType';
import MultipleAnswer from './questionType/multipleAnswerType';
import SingleAnswerImage from './questionType/singleAnswerImageType';
import MultipleAnswerImage from './questionType/multipleAnswerImageType';

import TextInput from './questionType/textInput';
import ImageInput from './questionType/imageInput';

import { Divider } from '@material-ui/core';



import { Typography, Grid } from '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
// import useAppContext from './../AppContext';
import AccountCircleRoundedIcon from '@material-ui/icons/AccountCircleRounded';
import Dialog from '@material-ui/core/Dialog';
import CloseIcon from '@material-ui/icons/Close';
import Avatar from '@material-ui/core/Avatar';
import IconButton from '@material-ui/core/IconButton';

const useStyles = makeStyles((theme) => ({

    nextbtn: {
        margin: theme.spacing(1)
    },
    prevbtn: {
        margin: theme.spacing(1)
    },

}));


export default function PreviewQuestion({isOpen, onClose, row, save}) {
    const appContext = useAppContext();
    const classes = useStyles();
    const alert = useAlert();
    const history = useHistory();

    const [question, setQuestion] = React.useState({});
    const [submitValue, setSubmitValue] = React.useState(0);
    const [answers, setAnswers] = React.useState({});

    const GET_QUESTION = "preview_exam_answer/get_question";
    const EXAMS_SUBMIT_API ="preview_exam_answer/submit_exam"
    const SUBMIT_SINGLE_ANSWER_API = "preview_exam_answer/single_answer";
    const SUBMIT_MULTIPLE_ANSWER_API = "preview_exam_answer/multiple_answer";
    const SUBMIT_TEXT_ANSWER_API = "preview_exam_answer/text_answer";
    const SUBMIT_IMAGE_ANSWER_API = "preview_exam_answer/image_answer";

    React.useEffect(() => {
        console.log(isOpen)
        if(isOpen){
            setQuestion({});
            setAnswers({});
            if(!save.isList && row.questionId == 0){
                setQuestion(save);
                let ans = [];
                setAnswers(ans)
            } else {
                appContext.getAxios().get(GET_QUESTION + '/' + row.questionId).then((response) => {
                    if(save.isList){
                        setQuestion(response.data);
                    } else {
                        setQuestion(save);
                        let ans = [];
                        setAnswers(ans)
                    }
                }, (error) => {
                    alert.error(error.response.data.message);
                });
            }
        }

    }, [isOpen])

    const handleSubmit = () => {
        // let examId = localStorage.getItem('examId');
        // let scheduleId = localStorage.getItem('scheduleId');
        // appContext.getAxios().get(EXAMS_SUBMIT_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
        //     console.log(response)
        //     localStorage.removeItem('examId');
        //     localStorage.removeItem('scheduleId');
        //     window.location.reload();
        // }, (error) => {
        //     alert.error("Something went wrong please try again");
            
        // });
    };

    function changeValue(value) {
        setSubmitValue(value);
        let ans = answers;
        if(question.questionTypeId == 1 || question.questionTypeId == 3){
            console.log("13");
            ans[row.questionId] = value;
        }
        else if(question.questionTypeId == 2 || question.questionTypeId == 4){
            console.log("24");
            ans[row.questionId] = value;
        }
        else if(question.questionTypeId == 5){
            ans[row.questionId] = value;
        }
        else if(question.questionTypeId == 6){
            ans[row.questionId] = value;
        }
        console.log(ans);
        setAnswers(ans)
    };


    return (
        <div>
            <Dialog fullScreen open={isOpen} 
            onClose={() => {
                onClose(true);
            }} 
            // TransitionComponent={Transition}
            >
            <CssBaseline />
            <AppBar position="absolute" color="secondary" className={classes.appBar}>
                <Toolbar className={classes.toolbar}>
                    <IconButton edge="start" color="inherit" onClick={() => {
                        onClose(true);
                        }} 
                        aria-label="close">
                        <CloseIcon />
                    </IconButton>
                    <Typography component="h1" variant="h6" color="inherit" noWrap className={classes.title}>
                        {appContext.getTitle()}
                    </Typography>

                    <Divider orientation={"vertical"} />
                    <Button color="inherit" m={5} disabled>
                        {/* <Avatar className={classes.imageBox} src={`${localStorage.getItem("imageUrl")}`}>
                            <AccountCircleRoundedIcon />
                        </Avatar>
                        <Typography variant="caption"> &nbsp; {localStorage.getItem("firstName")} {localStorage.getItem("lastName")} </Typography> */}
                    </Button>
                </Toolbar>
            </AppBar>
            <div style={{'padding-left': '20px'}}>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            {/* <DialogContent> */}
                <div style={{'display':'none'}}>{row.questionId}</div>
                {question.questionTypeId == 1 &&
                    <SingleAnswer question={question} submitVal={changeValue} answers={answers}/>
                }
                {question.questionTypeId == 2 &&
                    <MultipleAnswer question={question} submitVal={changeValue}  answers={answers}/>
                }
                {question.questionTypeId == 3 &&
                    <SingleAnswerImage question={question} submitVal={changeValue}  answers={answers}/>
                }
                {question.questionTypeId == 4 &&
                    <MultipleAnswerImage question={question} submitVal={changeValue}  answers={answers}/>
                }
                {question.questionTypeId == 5 &&
                    <TextInput question={question} submitVal={changeValue}  answers={answers}/>
                }
                {question.questionTypeId == 6 &&
                    <ImageInput question={question} submitVal={changeValue}  answers={answers}/>
                }
                <Divider/>
            {/* </DialogContent> */}
            </div>
            </Dialog>
        </div>
    )
}