import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import Button from '@material-ui/core/Button';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import Box from '@material-ui/core/Box';
import { Typography, Divider } from '@material-ui/core';


const useStyles = makeStyles((theme) => ({
    chkbxMain: {
    },
    options: {
        margin: theme.spacing(3)
    }
}));

export default function SingleAnswerImage(props) {
    const classes = useStyles();
    const [value, setValue] = React.useState(-1);
    const [options, setOptions] = React.useState([])

    function handleChange(event) {
        console.log(event.target.value)
        setValue(event.target.value);
        props.submitVal(event.target.value);
        // console.log(submitValue)
    };

    React.useEffect(() => {
        let opts = JSON.parse(props.question.options)

        setOptions(opts.options);
    }, [props.question])

    return (
        <>
            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                        <Typography variant="h4">{props.question.title}</Typography>
                        <div dangerouslySetInnerHTML={{__html: props.question.description}} />
                        {props.question.imageUrl != "" &&
                            <div><img style={{ "height": "500px" }} src={props.question.imageUrl} /></div>
                        }
                        <FormControl className={classes.options} component="fieldset">
                            <RadioGroup aria-label={props.question.examQuestionId} onChange={handleChange} value={value} name={props.question.examQuestionId} >
                                {options.map((option) => (
                                  <>
                                  <Box display="flex" my={3}>
                                    <FormControlLabel 
                                    checked={ (props.answers[props.question.examQuestionId] || 0) ==  option.id.toString()} 
                                    value={option.id.toString()} control={<Radio></Radio>} />
                                    <img src ={option.src} style={{ "height": "300px" }}/>
                                  </Box>
                                  </>
                                 ))}
                            </RadioGroup>
                        </FormControl>
                    </div>
                    <br></br>
                    <br></br>
                </div>
            </Box>

        </>
    );
}
