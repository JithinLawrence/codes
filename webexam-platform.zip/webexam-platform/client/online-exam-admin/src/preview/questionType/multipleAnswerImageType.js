import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import Button from '@material-ui/core/Button';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import Box from '@material-ui/core/Box';
import { Typography, Divider, Checkbox } from '@material-ui/core';


const useStyles = makeStyles((theme) => ({
  chkbxMain: {
  },
  options: {
    margin: theme.spacing(3)
  }
}));

export default function MultipleAnswer(props) {
  const classes = useStyles();
  const [value, setValue] = React.useState('-1');
  const [options, setOptions] = React.useState([])

  const handleChange = (event) => {
    const tempAnswer = props.answers[props.question.examQuestionId];
    const newChoices = tempAnswer?.includes(event.target.value)
        ? tempAnswer?.filter(choice => choice !== event.target.value)
        : [...(tempAnswer ?? []), event.target.value];
        props.submitVal(newChoices);
    setValue(event.target.value);

  };

  React.useEffect(() => {
    let opts = JSON.parse(props.question.options)

    setOptions(opts.options);
  }, [props.question])

//   React.useEffect(() => {
//     props.submitVal(choices);
//   }, [choices])

  return (
    <>
      <Box display="flex">
        <div className={classes.chkbxMain}>
          <div>
            <Typography variant="h4">{props.question.title}</Typography>
            <div dangerouslySetInnerHTML={{ __html: props.question.description }} />
            {props.question.imageUrl != "" &&
              <div><img style={{ "height": "500px" }} src={props.question.imageUrl} /></div>
            }
            <FormControl className={classes.options} component="fieldset">
              <FormGroup>
                {options.map((option) => (
                  <Box display="flex" my={3}>
                    <FormControlLabel 
                    checked={ (props.answers[props.question.examQuestionId] || []).includes(option.id.toString()) } 
                    value={option.id.toString()} onChange={handleChange} control={<Checkbox />} />
                    <img src={option.src} style={{ "height": "300px" }} />
                  </Box>
                ))}
              </FormGroup>
            </FormControl>
          </div>
          <br></br>
          <br></br>
        </div>
      </Box>

    </>
  );
}
