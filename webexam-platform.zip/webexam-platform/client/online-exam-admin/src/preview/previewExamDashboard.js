import React from 'react';
import { makeStyles, useTheme } from "@material-ui/core/styles";
import { Typography, Grid } from '@material-ui/core';
import ExamQuestions from './previewExamQuestion';
import Box from '@material-ui/core/Box';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import Avatar from '@material-ui/core/Avatar';
import Chip from '@material-ui/core/Chip';
import { grey } from '@material-ui/core/colors';
import CountdownTimer from './countDownTimer';
import CssBaseline from '@material-ui/core/CssBaseline';
import clsx from 'clsx';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
import useAppContext from './../AppContext';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import Link from '@material-ui/core/Link';
import { BrowserRouter as Router, Link as RouterLink, Switch, Route, useHistory } from 'react-router-dom';
import PlayCircleFilledWhiteIcon from '@material-ui/icons/PlayCircleFilledWhite';
import Card from '@material-ui/core/Card';
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import PropTypes from "prop-types";
import { useAlert } from "react-alert";


const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({

    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    drawer: {
        justifyContent: 'center',
        backgroundColor: grey[400],
        borderColor: "secondary",
        flexWrap: 'wrap',
        height:"93vh"
    },
    catogories: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    questions: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    dialog: {
        padding: theme.spacing(3)
    },
    dialogTitle: {
        backgroundColor: theme.palette.primary.main,
    },
    catogoryChip: {
        margin: theme.spacing(0.5),
        backgroundColor: theme.palette.primary.main,
    },
    purple: {
        color: theme.palette.getContrastText(theme.palette.primary.main),
        backgroundColor: theme.palette.primary.main,
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    green: {
        color: theme.palette.getContrastText(theme.palette.primary.main),
        backgroundColor: 'green',
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    blue: {
        color: theme.palette.getContrastText(theme.palette.primary.main),
        backgroundColor: theme.palette.secondary.main,
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    caption: {
        margin: theme.spacing(3)
    },
    questionArea: {
        [theme.breakpoints.up('sm')]: {
            width: `calc(100% - ${drawerWidth}px)`,
        },
        [theme.breakpoints.down('sm')]: {
            width: `100%`,
        },
        height: '93vh',
        overflow:'scroll',
        paddingTop: theme.spacing(3)
    },
    questionBox: {
        width: `100%`,
        paddingTop: theme.spacing(3)
    },
    nextbtn: {
        margin: theme.spacing(3)
    },
    prevbtn: {
        margin: theme.spacing(3)
    },
    timerDiv: {
        fontSize: 20,

    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    title: {
        flexGrow: 1,
    },
    content: {
        paddingTop: theme.spacing(5),
        height: '93vh',
    },
    catTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        alignItems: "center",
        fontWeight: "bold",
        display: "flex",
    },
    catTitle: {
        marginLeft: "20px",
        alignSelf: "center"
    },
    catDetailP: {
        marginLeft: "10px",

    },
    grid: {
        [theme.breakpoints.up('sm')]: {
            width: `calc(100% - ${drawerWidth}px)`,
            marginLeft: theme.spacing(3)

        },
        [theme.breakpoints.up('down')]: {
            width: `100%`,
            marginLeft: theme.spacing(3)

        },
        paddingTop: theme.spacing(3),

    },
    attendButton: {
        margin: theme.spacing(2)
    },
    smPanel: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper
    }


}));
function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        "aria-controls": `simple-tabpanel-${index}`
    };
}

export default function Exam({examId, type, save}) {
    const classes = useStyles();
    const theme = useTheme();
    const appContext = useAppContext();
    const alert = useAlert();
    const smUp = useMediaQuery(theme.breakpoints.up('sm'));

    const drawerDisp = smUp ? '' : 'none';
    const smrawerDisp = smUp ? 'none' : '';
    const gridSpacing = smUp ? '10' : '3';

    const [value, setValue] = React.useState(-1);
    const [examName, setExamName] = React.useState("");
    const [category, setCatagory] = React.useState({});
    const [questionId, setQuestionId] = React.useState();
    const [answered, setAnswered] = React.useState([]);    
    const [answering, setAnswering] = React.useState(false);
    const [catagoryList, setCatagoryList] = React.useState([]);

    const EXAMS_NAME_API = "preview_exam_answer/get_name"
    const EXAMS_CATEGORY_LIST_API = "preview_exam_answer/get_categories"

    const handleChange = (event, newValue) => {
        console.log(newValue)
        if (newValue == value) {
            setValue(-1)
        } else {
            setValue(newValue);
        }
    };

    const gotoQuestion = (category, question) => {
        console.log(question);
        setQuestionId(question);
        setCatagory(category);
        setAnswering(true);
    };

    function getName() {
        appContext.getAxios().get(EXAMS_NAME_API + '/' + (examId)).then((response) => {
            console.log(response.data)
            if(save.name == ""){
                setExamName(response.data);
            } else {
                setExamName(save.name);
            }
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function getCatagoryList() {
        appContext.getAxios().get(EXAMS_CATEGORY_LIST_API + '/' + (examId)+"?type="+type).then((response) => {
            console.log(response.data)
            setCatagoryList(response.data);

        }, (error) => {
            console.log(error)
            // alert.error(error.response.data.message);
        });
    }

    const handleAnswer = value => {
        setAnswered([...answered,value]);
    };

    const handleNotAnswered = value => {
        setAnswered(answered.filter((answer)=>answer != value));
    };



    React.useEffect(() => {
        getCatagoryList();
        getName();
    }, []);



    return (
        <>
            <Box className={classes.smPanel} flexGrow={1} display={smrawerDisp}>
                <AppBar position="sticky">
                    <Tabs
                        value={value}
                        aria-label="simple tabs example"
                        onChange={handleChange}
                    >
                        {catagoryList.map((cat, index) => (
                            <Tab label={cat.name} {...a11yProps(index)} />
                        ))}
                    </Tabs>
                </AppBar>
                {catagoryList.map((cat, index) => (
                    <TabPanel value={value} index={index}>
                        {cat.qlist.map((question, indesxq) => (
                            // <IconButton onClick={() => gotoQuestion(cat, question)}><Avatar className={classes.purple}>{indesxq + 1}</Avatar></IconButton>
                            <IconButton onClick={() => gotoQuestion(cat, question.questionId)}><Avatar className={classes.purple}>{indesxq + 1}</Avatar></IconButton>
                        ))}
                    </TabPanel>
                ))}
            </Box>
            <Box display="flex">
                <Box
                    color="primary"
                    variant="permanent"
                    width={drawerWidth}
                    className={classes.drawer}
                    display={drawerDisp}
                >
                    <Typography className={classes.caption} variant="h6">Catagory</Typography>
                    <Box className={classes.catogories}>
                        {catagoryList.map((cat, index) => (
                            // <IconButton onClick={() => gotoQuestion(cat, cat.qlist[0])}><Avatar className={classes.purple}>{index + 1}</Avatar></IconButton>
                            <IconButton onClick={() => gotoQuestion(cat, cat.qlist[0].questionId)}><Avatar className={classes.purple}>{index + 1}</Avatar></IconButton>
                        ))}
                    </Box>
                    {answering &&
                        <>
                            <Divider />
                            <Typography className={classes.caption} variant="h6">Question</Typography>

                            <Box className={classes.questions}>
                                {category.qlist.map((question, indesxq) => (
                                    // <IconButton onClick={() => gotoQuestion(category, question)}><Avatar className={classes.purple}>{indesxq + 1}</Avatar></IconButton>
                                    <IconButton onClick={() => gotoQuestion(category, question.questionId)}><Avatar  className={ question.isAnswered ||answered.includes( question.questionId) ? classes.green : classes.purple}>{indesxq + 1}</Avatar></IconButton>
                                ))}

                            </Box>
                        </>
                    }
                </Box>

                <Box className={classes.questionArea} flexWrap="wrap" display="flex">
                    <Box className={classes.questionBox} flexShrink={1} mx={2}>
                        <Box display="flex" alignItems="center">
                            <Box flex={1} justifyContent="right">
                                <Typography variant="h4">{examName}</Typography>
                            </Box>
                            <Box justifyContent="left" className={classes.timerDiv}  >
                                {/* <CountdownTimer start={false} examId={examId} ></CountdownTimer> */}
                                <CountdownTimer examId={examId} save={save}></CountdownTimer>
                            </Box>
                        </Box>
                        <Divider />
                        {answering &&
                            // <ExamQuestions questionId={questionId}/>
                            <ExamQuestions questionId={questionId} setCurrentAnswer={handleAnswer} setNotAnswered={handleNotAnswered} type={type}/>
                        }
                        {!answering &&
                            <div className={classes.question}>
                                <Grid container className={classes.grid} 
                                spacing={gridSpacing} 
                                alignItems="center">

                                    {catagoryList.map((cat, index) => (
                                        <Grid item className={classes.gridItem} md={4} sm={6} xs={12} >
                                            <Card>
                                                <Box borderRadius={16}>
                                                    <Box className={classes.catTitleDiv} display="flex">
                                                        <Box mx={1} >
                                                            <Avatar className={classes.blue} >{index + 1}</Avatar>
                                                        </Box>
                                                        <Box flexGrow={1} >
                                                            <Box display="flex" justifyContent="center" style={{ marginRight: theme.spacing(3) }}>
                                                                {cat.name}
                                                            </Box>
                                                        </Box>
                                                    </Box>
                                                    <p className={classes.catDetailP} >Question Count: {cat.questionCount}</p>
                                                    <p className={classes.catDetailP} >Marks: {cat.totalMarks}</p>
                                                    <Divider />
                                                    <div className={classes.bottomDiv}>
                                                        <Grid container justify="center" spacing={2} >
                                                            <Grid item xs={5.5}>
                                                                <Button variant="contained"
                                                                    color="secondary"
                                                                    justify="right"
                                                                    // onClick={() => gotoQuestion(cat, cat.qlist[0])}
                                                                    onClick={() => gotoQuestion(cat, cat.qlist[0].questionId)}
                                                                    className={classes.attendButton}>
                                                                    <PlayCircleFilledWhiteIcon></PlayCircleFilledWhiteIcon> Attend</Button>
                                                            </Grid>

                                                        </Grid>
                                                    </div>
                                                </Box>
                                            </Card>
                                        </Grid>
                                    ))}
                                </Grid>
                            </div>
                        }
                    </Box>

                </Box>
            </Box>
        </>
    )
}