import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import theme from './../theme';
import FormControl from '@material-ui/core/FormControl';
import { Link } from "react-router-dom";
import { Grid } from '@material-ui/core';
import Checkbox from '@material-ui/core/Checkbox';
import Typography from '@material-ui/core/Typography';
import { useAlert } from "react-alert";

import useAppContext from './../AppContext';
import { getNameOfDeclaration } from 'typescript';


const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    mainPaper: {
        width: "80% !important",
        textAlign: "center",
        marginLeft: "10%",
        marginTop: "5%"
    },
    h1Agreement: {
        textAlign: "center",
        textDecoration: "underline",
    },
    title: {
        textAlign: "center",
        paddingBottom: theme.spacing(3)
    },
    agrBody: {
        padding: "10px",
    },
    agrChkP: {
        fontWeight: "bold",
        fontSize: "16px",

    }
});



export default function Agreement({ examId, onAgree, save }) {
    const classes = useStyles();
    const appContext = useAppContext();
    const alert = useAlert();

    const [agree, setAgree] = React.useState(false);
    const [agreement, setAgreement] = React.useState("");
    const [examName, setExamName] = React.useState("");
    const EXAMS_AGREEMENT_API = "preview_exam_answer/get_agreement"
    const EXAMS_NAME_API = "preview_exam_answer/get_name"
    const EXAMS_START_API = "preview_exam_answer/start_exam"


    const handleClickAgreement = () => {
        setAgree(!agree);
    }

    // const onAgree = () => {
    //     setAgree(!agree);
    // }

    const clickAgree = () => {
        // let scheduleId = localStorage.getItem('scheduleId');
        // appContext.getAxios().get(EXAMS_START_API + '/' + (examId) + '/' + (scheduleId)).then((response) => {
        //     console.log(response)

            // window.location.reload();
            onAgree(agree);
        // }, (error) => {
        //     alert.error("Something went wrong please try again");
        //     localStorage.removeItem('examId');
        //     localStorage.removeItem('scheduleId');
        // });
    };

    function getAgreement() {
        appContext.getAxios().get(EXAMS_AGREEMENT_API + '/' + (examId)).then((response) => {
            console.log(response.data)
            if(save.ckdTC == ""){
                setAgreement(response.data);
            } else {
                setAgreement(save.ckdTC);
            }
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function getName() {
        appContext.getAxios().get(EXAMS_NAME_API + '/' + (examId)).then((response) => {
            console.log(response.data)
            if(save.name == ""){
                setExamName(response.data);
            } else {
                setExamName(save.name);
            }
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    React.useEffect(() => {
        getAgreement();
        getName();
    }, []);

    function SetStart() {
        if (agree) {
            return (
                <Button
                    color="secondary"
                    variant="contained"
                    onClick={clickAgree}
                >
                    Start
                </Button>
            )
        } else {
            return (
                <Button
                    // color=".error"
                    variant="contained"
                >
                    Start
                </Button>
            )
        }


    }
    return (
        <div className={classes.mainPaper}>
            <Grid container justify="center">

                <Grid item 
                // justify="center"
                >
                    <Typography variant="h2" className={classes.title}>{examName}</Typography>
                    <Typography variant="h6" className={classes.h1Agreement}>Terms and Conditions</Typography>
                    <br></br>
                    <div className={classes.agrBody}>
                        <p>{agreement}</p>
                    </div>
                </Grid>

            </Grid>
            <Grid container justify="center">
                <Grid item>
                    <FormControl>
                        <p className={classes.agrChkP}><Checkbox name="" onClick={handleClickAgreement} > </Checkbox> I Agree</p>
                    </FormControl>
                </Grid>
            </Grid>
            <Grid container justify="center">
                <Grid item>
                    <SetStart />
                </Grid>
            </Grid>
            <br></br>
            <br></br>
        </div>
    );
}