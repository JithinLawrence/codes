import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box'
import Grid from '@material-ui/core/Grid';
import Radio from '@material-ui/core/Radio';
import { Typography, TextareaAutosize, Checkbox } from '@material-ui/core';
import { useParams } from 'react-router-dom';
import useAppContext from './AppContext';
import { useAlert } from 'react-alert';
import TextField from '@material-ui/core/TextField';

const useStyles = makeStyles((theme) => ({
    mainDiv:{
        marginLeft : "10%",
        alignItems: "center",
        justifyContent : "center",
        justifyItems :"center",
    },
    chkbxMain: {
        // width:"50%"
    },
    textBoxAuto:{
        // minWidth : '30rem',
        [theme.breakpoints.up('sm')]: {
            minWidth : '60rem',

        },
        [theme.breakpoints.down('sm')]: {
            minWidth : '15rem',

        },
    },
    options: {
        margin: theme.spacing(3)
    },
    correctAnswer: {
        backgroundColor: "lightgreen",
        paddingTop : "4px"
    },
    wrongAnswer: {
        backgroundColor: "#eea29a",
    },
    detailsBox:{
        // border : "1px black solid",
        // padding : "10px",
        // fontSize : "16px",
        // fontWeight : "bold",
        // marginLeft : "10%",
        [theme.breakpoints.up('sm')]: {
            width : "40%",

        },
        
        // textAlign : "center",

    }
}));
const boxProps = {
    display: "flex",
    bgcolor: 'background.paper',
    // style: { height: '3rem' },
    borderLeft: '5px solid',
    borderColor: "secondary.main",
    justifyContent: "flex-start",
    margin: 1,
    padding: 1,
    boxShadow: 3,
    minHeight: "150px !important",
};
const chartsProps = {
    display: "flex",
    bgcolor: 'background.paper',
    justifyContent: "center",
    margin: 3,
    padding: 1,
};

const successData = [
    { success: 'pass', percentage: 75 },
    { success: 'fail', percentage: 50 },
];

const examStatusData = [
    { status: 'Assigned', count: 20 },
    { status: 'Not started', count: 30 },
    { status: 'In progress', count: 30 },
    { status: 'Incomplete', count: 40 },
    { status: 'Completed', count: 50 },
];
const scoreData = [
    { score: 'max score', count: 70 },
    { score: 'min score', count: 30 },
    { score: 'average score', count: 30 },
];

const scoreChartProps = {
    data: scoreData,
    title: 'Score analysis',
    width: '250',
    height: '500',
    valueField: 'count',
    argumentField: 'score',
    scaleName: 'zoom',
}
const successChartProps = {
    data: successData,
    title: 'pass/fail analysis',
    valueField: "percentage",
    argumentField: "success",
}
const examstatusChartProps = {
    data: examStatusData,
    title: 'Exam status/ Candidates count',
    width: '380',
    height: '500',
    valueField: "count",
    argumentField: "status"
}

export default function ExamResult() { 
    const classes = useStyles();
    const appContext = useAppContext();
    const alert = useAlert();
    const [checkedValue, setCheckedValue] = React.useState(10)
    const [value, setValue] = React.useState('female');
    let count=0;
    const trueStatus = 'true';
    const marks = "Marks";
    

    const {examId} = useParams();
    const {scheduleId} = useParams();
    const [resultList, setResultList] = React.useState([]);
    const [qstnResultList, setQstnResultList] = React.useState([]);
    const Exam_Result_API = "exam_result/getExamResult";
    const ExamQuestion_Result_API = "exam_result/getExamQuestionResult";
    const [radioList , setRadioData] = React.useState([]);
   

    const userId = localStorage.getItem("candidateId");

    console.log("userId:"+userId);

    

    React.useEffect(()=>{
        getExamDetails();
    },[]);


    function getExamDetails(){

        appContext.getAxios().get(`${Exam_Result_API}?user=${userId}&examId=${examId}&scheduleId=${scheduleId}`).then((response)=>{
            setResultList(response.data);
        },(error)=>{
            alert.error(error.response.data.message);    
        })
    }

    React.useEffect(()=>{
        getExamResultDetails();
    },[]);

    
    const radioDataFn = async (radioData)=>{
        //  data =radioData;
        const rdData = JSON.parse(radioData.options);
        console.log("Radio called : 1"+rdData);
        setRadioData(rdData.options);
        
    } 

    function getExamResultDetails(){

        appContext.getAxios().get(`${ExamQuestion_Result_API}?user=${userId}&examId=${examId}`).then((response)=>{
            setQstnResultList(response.data);          
        },(error)=>{
            alert.error(error.response.data.message);    
        })
    }

    const handleChange = (event) => {
        setValue(event.target.value);
    };
    return (
        <div className={classes.mainDiv}>
            <h1>Exam Result - {resultList['examName']}</h1>
            <br></br>
            <Grid container >
                <Grid item sm={12}>
                    <Box {...boxProps} className={classes.detailsBox}>
                        Examination Name &nbsp;&nbsp;: &nbsp;&nbsp;{resultList['examName']} <br></br>
                        Examination Date &nbsp; &nbsp;&nbsp;: &nbsp;&nbsp;{resultList['examDate']}<br></br>
                        Total Duration &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;{(resultList['durationHour']) !=0 ? resultList['durationHour']+" h " +resultList['durationMin']+" Min" : ((resultList['durationMin']) !=0 ? resultList['durationMin']+" Min." : '')}<br></br>
                        Total Questions &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;{resultList['questions']}<br></br>
                        Total Marks &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;{resultList['marks']}<br></br>
                        Answered Correct &nbsp; &nbsp;: &nbsp;&nbsp;{resultList['answeredCorrect']}<br></br>
                        Marks Scored &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;{resultList['scoredMark']}
                    </Box>
                </Grid>
            </Grid>

            <br></br>
            <br></br>
            {qstnResultList.map((qstnObj) => (   
                
            <Box display="flex">
                <div className={classes.chkbxMain}>
                    <div>
                    <div style={{width:'60rem', textAlign:'right'}}>Mark : {qstnObj.mark}</div>
            <Typography variant="h4">Q{++count}. {qstnObj.title}</Typography>

                         {qstnObj.typeId === 1  && (
                            (qstnObj.options).map((d) =>(
                                d.isAnswer == true ? (<p className={classes.correctAnswer}>
                                    <Radio value={d.id} disabled checked="true" />{d.value}</p>)
                             :(qstnObj.answer == d.id ? ( <p className={classes.wrongAnswer}>
                                 <Radio key={d.id} disabled checked="true" />{d.value}<br></br></p>)
                                 : <p>
                                 <Radio key={d.id} disabled/>{d.value}<br></br></p>
                             )  
                            )
                         ))}
                        
                        
                        {qstnObj.typeId === 2 && (
                         (qstnObj.options).map((d) =>(
                            d.isAnswer == true ? (<p className={classes.correctAnswer}>
                                <Checkbox value={d.id} disabled checked="true" />{d.value}</p>)
                         :(qstnObj.answer.indexOf(d.id) !== -1  ? ( <p className={classes.wrongAnswer}>
                             <Checkbox key={d.id} disabled checked="true" />{d.value}<br></br></p>)
                             : <p>
                             <Checkbox key={d.id} disabled/>{d.value}<br></br></p>
                         )  
                        )
                     ))}
                        {qstnObj.typeId === 3 && (
                       (qstnObj.options).map((d) =>(
                        d.isAnswer == true ? (<p className={classes.correctAnswer}>
                            <Radio value={d.id} disabled checked="true" /><img style={{height:'100px', width:'100px'}} src={d.value}/></p>)
                     :(qstnObj.answer == d.id ? ( <p className={classes.wrongAnswer}>
                         <Radio key={d.id} disabled checked="true" /><img style={{height:'100px', width:'100px'}} src={d.value}/><br></br></p>)
                         : <p>
                         <Radio key={d.id} disabled/><img style={{height:'100px', width:'100px'}} src={d.value}/><br></br></p>
                     )  
                    )
                 ))}
                        {qstnObj.typeId === 4 && (
                       (qstnObj.options).map((d) =>(
                        d.isAnswer == true ? (<p className={classes.correctAnswer}>
                            <Checkbox value={d.id} disabled checked="true" /><img style={{height:'100px', width:'100px'}} src={d.value}/></p>)
                     :(qstnObj.answer.indexOf(d.id) !== -1 ? ( <p className={classes.wrongAnswer}>
                         <Checkbox key={d.id} disabled checked="true" /><img style={{height:'100px', width:'100px'}} src={d.value}/><br></br></p>)
                         : <p>
                         <Checkbox key={d.id} disabled/><img style={{height:'100px', width:'100px'}} src={d.value}/><br></br></p>
                     )  
                    )
                 ))}
                        {qstnObj.typeId === 5 && 
                        <p> <TextareaAutosize rowsMax={7} className={classes.textBoxAuto} disabled>{qstnObj.answer} 
                         </TextareaAutosize></p>}

                         {qstnObj.typeId === 6 && 
                        <p> <img style={{height:'100px', width:'100px'}} src={qstnObj.answer}/></p>}
                    </div>
                    <br></br>
                    <br></br>
                </div>
            </Box>
            ))}
            <div style={{width:'60rem', textAlign:'right'}}><b>Marks Scored  :</b> <b>{resultList['scoredMark']}</b></div>
            <div style={{width:100, height:'30px'}}></div>     
        </div>

    )
}