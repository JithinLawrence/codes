import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';

import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import SingleAnswer from './sampleQuestions/singleAnswerType';
import MultipleAnswer from './sampleQuestions/multipleAnswerType';
import IconButton from '@material-ui/core/IconButton';
import CssBaseline from '@material-ui/core/CssBaseline';
import Drawer from '@material-ui/core/Drawer';
import Box from '@material-ui/core/Box';
import AppBar from '@material-ui/core/AppBar';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import Avatar from '@material-ui/core/Avatar';
import Chip from '@material-ui/core/Chip';
import Button from '@material-ui/core/Button';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import AccountBoxIcon from '@material-ui/icons/AccountBox';
import { BrowserRouter as Router, Route, Switch, useRouteMatch, useHistory } from 'react-router-dom';
import { deepPurple, grey } from '@material-ui/core/colors';

import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import CreateOutlinedSharpIcon from '@material-ui/icons/CreateOutlined';
import PeopleSharpIcon from '@material-ui/icons/People';
import ScheduleSharpIcon from '@material-ui/icons/ScheduleSharp';
import NoteSharpIcon from '@material-ui/icons/NoteSharp';

const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({

    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    dialog: {
        padding: theme.spacing(3)
    },
    dialogTitle: {
        backgroundColor: theme.palette.primary.main,
    },
    toolbar: {
        justifyContent: 'center',
        backgroundColor: grey[400],
        borderColor: "secondary",
        flexWrap: 'wrap',
    },
    catogories: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    questions: {
        paddingBottom: theme.spacing(3),
        paddingLeft: theme.spacing(1),
    },
    catogoryChip: {
        margin: theme.spacing(0.5),
        backgroundColor: theme.palette.primary.main,
    },
    purple: {
        color: theme.palette.getContrastText(theme.palette.primary.main),
        backgroundColor: theme.palette.primary.main,
        width: theme.spacing(4),
        height: theme.spacing(4),
    },
    caption: {
        margin: theme.spacing(3)
    },
    questionArea: {
        width: `calc(100% - ${drawerWidth}px)`
    },
    nextbtn: {
        margin: theme.spacing(3)
    },
    prevbtn: {
        margin: theme.spacing(3)
    }

}));

function Question({ qno }) {
    if (qno == 1) {
        return (
            <SingleAnswer />
        )
    } else if (qno == 2) {
        return (
            <MultipleAnswer />
        )
    }
}

export default function ExamPreview({ isOpen, onClose }) {
    const classes = useStyles();
    const [qno, setQno] = React.useState(1);
    const [btntext, setBtntext] = React.useState("next");
    const handleNext = () => {
        setQno(qno + 1);
    };
    const handlePrev = () => {
        setQno(qno - 1);
    };
    return (
        <Dialog className={classes.dialog} fullWidth maxWidth="lg" open={isOpen} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" className={classes.dialogTitle} disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Preview</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
            </DialogTitle>
            <DialogContent>
                <div >
                    <Box display="flex">
                        <Box
                            color="primary"
                            variant="permanent"
                            width={drawerWidth}
                            className={classes.toolbar}
                        >
                            <Divider />
                            <Typography className={classes.caption} variant="h6">Catagory</Typography>
                            <Box className={classes.catogories}>
                                <Chip className={classes.catogoryChip} avatar={<Avatar>M</Avatar>} label="Cat1" clickable />
                                <Chip className={classes.catogoryChip} avatar={<Avatar>E</Avatar>} label="Cat2" clickable />
                                <Chip className={classes.catogoryChip} avatar={<Avatar>S</Avatar>} label="Cat3" clickable />
                                <Chip className={classes.catogoryChip} avatar={<Avatar>P</Avatar>} label="Cat4" clickable />
                                <Chip className={classes.catogoryChip} avatar={<Avatar>P</Avatar>} label="Cat5" clickable />
                            </Box>
                            <Divider />
                            <Typography className={classes.caption} variant="h6">Question</Typography>
                            <Box className={classes.questions}>
                                <IconButton><Avatar className={classes.purple}>1</Avatar></IconButton>
                                <IconButton><Avatar className={classes.purple}>2</Avatar></IconButton>
                                <IconButton><Avatar className={classes.purple}>3</Avatar></IconButton>
                                <IconButton><Avatar className={classes.purple}>4</Avatar></IconButton>
                                <IconButton><Avatar className={classes.purple}>5</Avatar></IconButton>
                            </Box>
                        </Box>
                        <Box className={classes.questionArea} mx={2}>
                            <Question qno={qno} />
                        </Box>

                    </Box>
                    <Box display="flex" justifyContent="center" m={1} p={1} bgcolor="background.paper">
                        <Button variant="contained" disabled={qno == 1} className={classes.prevbtn} onClick={handlePrev}>
                            Previous
                        </Button>
                        <Button variant="contained" className={classes.nextbtn} disabled={qno == 2} color="primary" onClick={handleNext} mx={1} >
                            next
                        </Button>
                        <Button variant="contained" className={classes.nextbtn} disabled={qno != 2} color="primary" mx={1} >
                            Submit
                        </Button>
                    </Box>
                </div >
            </DialogContent>
        </Dialog>
    )
}