import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Avatar from '@material-ui/core/Avatar';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import DialogActions from '@material-ui/core/DialogActions';
import Chip from '@material-ui/core/Chip';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 150,
        paddingRight: theme.spacing(2)
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        marginRight: theme.spacing(3),

    },
    submitButton: {
        marginLeft: theme.spacing(3),
    },
    table: {
        minWidth: 50,
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    dialog: {
        paddingTop: theme.spacing(1),
    },
    dialogActionsCenter: {
        justifyContent: "center",
        marginTop: theme.spacing(1),

    },
    dialogActionsLeft: {
        justifyContent: "left",
        marginBottom: theme.spacing(1),
        marginLeft: theme.spacing(2),
        paddingTop: 0
    },
    dialogPaper: {
        minHeight: '85vh',
        maxHeight: '85vh',
    },
    outerChipTotal: {
        color: "rgba(0, 0, 0, 0.87)",
        fontSize: "24px",
        // height: "auto",
        fontWeight: "normal",
        margin: "20px",
        backgroundColor: "white !important",
        boxShadow: "3px 3px 1px 1px #ccc;",
        textAlign: "left",
        height: "40px !important",
        width: "200px !important",

    },
    containTotal:{
        width: "100% !important",
        // width: "100% !important",
        display:'inline-block',
        // display:'block',
        textAlign:'center',
        whiteSpace: 'normal',
        wordWrap: 'break-word',
        // textOverflow: 'ellipsis',
        // overflow: 'hidden',
    },
    numberBoxTotal: {
        backgroundColor: theme.palette.secondary.light + " !important",
        // fontSize: "20px !important",
        fontWeight: "bold",
        width: theme.spacing(10),
        height: theme.spacing(10),
        marginLeft: theme.spacing(2),
        height: "40px !important",
        width: "40px !important",
    },
    headerStyle05: {
        width: '05%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    headerStyle50: {
        width: '50%',
        maxWidth: '1px'
    },
    headerStyle15: {
        width: '15%',
        maxWidth: '1px'
    },
    cellStyle05: {
        width: '05%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle50: {
        width: '50%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle15: {
        width: '15%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
}));

function createData(title, difficulty, marks) {
    return { title, difficulty, marks };
}

export default function ExamCatogoryEdit({ open, onClose, examId
    // , categoryId 
}) {

    const classes = useStyles();
    const alert = useAlert();
    let totalMarks = 0;

    const QUESTIONS_LIST_API = 'exams/listExamQuestions';
    const QUESTIONS_TEMP_UPDATE_API = 'exams/temporaryUpdate';
    const appContext = useAppContext();


    const [total, setTotal] = React.useState(0)
    const [updateTotal,setUpdateTotal] = React.useState(false)
    const [data, setData] = React.useState([]);
    const [deletedData, setDeletedData] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [previousValidOrder, setPreviousValidOrder] = React.useState(0);
    const [previousValidOrderIndex, setPreviousValidOrderIndex] = React.useState(-1);
    
    const handleSearchChange = event => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleChange = (e, i) => {
        // data[i].mark = e.target.value;
        // setUpdateTotal(!updateTotal);


        const val = e.target.value;
        let errorMsg = null;
        console.log(val)
        if (val <= 1000 && (/^\d+$/.test(val) || val === '')) {
            data[i].mark = e.target.value;
            setUpdateTotal(!updateTotal);
            // errorMsg = (val != "" && val < 1) ? "Mark must be greater than 0" : null;
        } else {
            // e.target.value = 0;
            // data[i].mark = 0;
            // setUpdateTotal(!updateTotal);
            // errorMsg = "Mark must be greater than 0";
        }

        if(val > 1000){
            alert.error("Mark must not exceed 1000");
        }  
        // errorMsg = errorMsg == null ? (val > 1000 ? "Mark must not exceed 1000" : null) : errorMsg;
        // errorMsg = errorMsg == null ? (val === '' ? "Mark is required" : null) : errorMsg;
        // setMarkError(errorMsg)
    }
    const handleOrderChange = (e, i) => {
        let val = e.target.value;
        let errorMsg = null;
        
            if (val <= 1000 && (/^\d+$/.test(val) || val === '')) {
                if(val.trim() === "0" || val === 0){} 
                else if(val.trim() === ""){
                    let tempPreviousValidOrder = previousValidOrder;
                    let tempPreviousValidOrderIndex = previousValidOrderIndex;
                    if(previousValidOrder != 0 && previousValidOrderIndex != -1 && previousValidOrderIndex != i){
                        data[previousValidOrderIndex].questionOrder = previousValidOrder;
                        setPreviousValidOrder(0)
                        setPreviousValidOrderIndex(-1)
                    }
                    tempPreviousValidOrder = (data[i].questionOrder !== "" && data[i].questionOrder !== "0" && data[i].questionOrder !== 0) ? data[i].questionOrder : tempPreviousValidOrder;
                    tempPreviousValidOrderIndex = (data[i].questionOrder !== "" && data[i].questionOrder !== "0" && data[i].questionOrder !== 0) ? i : tempPreviousValidOrderIndex;
                    setPreviousValidOrder(tempPreviousValidOrder)
                    setPreviousValidOrderIndex(tempPreviousValidOrderIndex)
                    data[i].questionOrder = val.trim();
                    setData(data);
                    setUpdateTotal(!updateTotal);
                    alert.error("Invalid count");
                } else {
                    if(previousValidOrder != 0 && previousValidOrderIndex != -1 
                        // && previousValidOrderIndex != i
                        ){
                        data[previousValidOrderIndex].questionOrder = previousValidOrder;
                    }
                    setPreviousValidOrder(0)
                    setPreviousValidOrderIndex(-1)
                    const currentOrder = parseInt(data[i].questionOrder);
                    const currentId = parseInt(data[i].examQuestionId);
                    if(data.length < parseInt(val)){
                        val = data.length;
                    }
                    const newOrder = parseInt(val);
                    let tempData = data;
                    if(newOrder > currentOrder){
                        tempData.forEach(function(part, index) {
                            if(parseInt(part.questionOrder) > currentOrder && parseInt(part.questionOrder) <= newOrder ){
                                part.questionOrder = parseInt(part.questionOrder) - 1;
                            }
                        }, tempData);
                    } else if(newOrder < currentOrder){
                        tempData.forEach(function(part, index) {
                            if(parseInt(part.questionOrder) < currentOrder && parseInt(part.questionOrder) >= newOrder ){
                                part.questionOrder = parseInt(part.questionOrder) + 1;
                            }
                        }, tempData);
                    }
                    tempData[i].questionOrder = parseInt(val);
                    tempData = tempData.sort(function(a, b) {
                        return parseInt(a.questionOrder) - parseInt(b.questionOrder);
                    });
        
                    setData(tempData);
                    setUpdateTotal(!updateTotal);
                }
            } else {
                setPreviousValidOrder(0)
                setPreviousValidOrderIndex(-1)
                if(val > 1000){
                    alert.error("Count limit exceeded 1000");
                } else {
                    alert.error("Invalid count");
                }
            }

        // if(val > 1000){
        //     alert.error("Count limit exceed 1000");
        // }
    }
    const handleDelete = (examQuestionId) => {//total
        let tempDeletedData = deletedData;
        tempDeletedData.push(examQuestionId);
        setDeletedData(tempDeletedData);

        let tempData = data;
        const removingQuestionOrder = tempData.filter(i => i.examQuestionId == examQuestionId).map(j=>j.questionOrder)
        tempData = tempData.filter(i => i.examQuestionId !== examQuestionId);

        tempData.forEach(function(part, index) {
            if(part.questionOrder > removingQuestionOrder){
                part.questionOrder = part.questionOrder - 1;
            }
        }, tempData);

        setData(tempData);
        setUpdateTotal(!updateTotal);
    };
    let i = 0;
    let x;
    React.useEffect(() => {
        for (x = 0; x < data.length; x++) {
            totalMarks += parseInt(data[x].mark) || 0;
        }
        if(totalMarks > 10000){
            alert.error("Total mark must not exceed 10000");
        }
        setTotal(totalMarks);
    }, [updateTotal]);


    React.useEffect(() => {
        if(open){
            console.log('open')
            setData([]);
            listExamQuestions(examId, 
                // categoryId, 
                search);
        }
    }, [open, search]); 

    function listExamQuestions(examId, 
        // categoryId, 
        search) {
        appContext.getAxios().get(QUESTIONS_LIST_API+'?examId='+examId+
        // '&categoryId='+categoryId+
        '&search='+encodeURIComponent(search)).then((response) => {
            console.log(response.data);
            setData(response.data);
            const rows = response.data;
            for (x = 0; x < rows.length; x++) {
                totalMarks += parseInt(rows[x].mark);  
                console.log('total: '+totalMarks)              
            }
            setTotal(totalMarks);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }
  
    const handleAdd = e => {//ExamQuestionUpdateInnerForm
        let updateData = [];
        let totMrk = 0;
        for (x = 0; x < data.length; x++) {
            if(isNaN(parseInt(data[x].mark))){
                alert.error("Invalid number entered");
                return;
            }  
            if(isNaN(parseInt(data[x].questionOrder))){
                alert.error("Invalid order entered");
                return;
            }  
            totMrk += parseInt(data[x].mark) || 0; 
            const updateDatum = {
                examQuestionId: data[x].examQuestionId,
                questionId: data[x].questionId,
                categoryOrder: data[x].categoryOrder,
                questionOrder: data[x].questionOrder,
                mark: data[x].mark
            };
            updateData.push(updateDatum);
        }
        if(totMrk > 10000){
            alert.error("Total mark must not exceed 10000");
            return;
        }
        let finalData = {
            deletedData: deletedData,
            examQuestionUpdateInnerForm: updateData
        };
        console.log(finalData);
        appContext.getAxios().put(QUESTIONS_TEMP_UPDATE_API+"/"+examId
        // +"/"+categoryId
        , JSON.stringify(finalData)).then((response) => {   
            onClose(response)
        }, (error) => {     
            console.log(error)
        });
    };


    return (
        <Dialog classes={{ paper: classes.dialogPaper }} className={classes.dialog} fullWidth maxWidth="lg" open={open} onClose={() => onClose({})} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Edit Questions</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose({})}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogActions className={classes.dialogActionsLeft}>
                <Box display="flex" style={{ width: '100%' }}>
                    <Box flexGrow={1}>
                        <Chip
                            className={classes.outerChipTotal}
                            color='secondary'
                            avatar={<Avatar className={classes.numberBoxTotal} ><label className={classes.containTotal}>{total}</label></Avatar>}
                            label="Total Marks"
                        />

                    </Box>

                    <Box alignSelf="flex-end">
                        <FormControl className={classes.formControl} >
                            <TextField
                                label="Search"
                                id="titleSearch"
                                value={search} 
                                onChange={handleSearchChange} 
                            ></TextField>
                        </FormControl>
                    </Box>
                </Box>
            </DialogActions>
            <DialogContent>
                <TableContainer component={Paper} >
                    <Table className={classes.table} aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell className={classes.headerStyle05} align="left">Order</TableCell>
                                <TableCell className={classes.headerStyle50} align="left">Title</TableCell>
                                <TableCell className={classes.headerStyle15} align="left">Category</TableCell>
                                <TableCell className={classes.headerStyle10} align="left">Difficulty</TableCell>
                                <TableCell className={classes.headerStyle10} align="left">Marks</TableCell>
                                <TableCell className={classes.headerStyle10} align="center">Delete</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data.map(function (row, index) {
                                return (
                                    <TableRow key={row.examQuestionId}>
                                        <TableCell className={classes.headerStyle05} align="left"component="th" scope="row">
                                            {/* {row.questionOrder} */}
                                            <TextField 
                                            style={{ maxWidth: "100px" }} 
                                            onChange={e => handleOrderChange(e, index)} 
                                            required
                                            value={row.questionOrder}
                                            inputProps={{ min: "1", step: "1" }} 
                                            // type="number" 
                                            // defaultValue={row.mark}
                                             />
                                        </TableCell>
                                        <TableCell className={classes.headerStyle50} align="left">{row.title}</TableCell>
                                        <TableCell className={classes.headerStyle15} align="left">{row.category}</TableCell>
                                        <TableCell className={classes.headerStyle10} align="left">{row.questionLevel}</TableCell>
                                        <TableCell className={classes.headerStyle10} align="left">
                                            <TextField 
                                            style={{ maxWidth: "100px" }} 
                                            onChange={e => handleChange(e, index)} 
                                            required
                                            value={row.mark}
                                            inputProps={{ min: "0", step: "1" }} 
                                            // type="number" 
                                            // defaultValue={row.mark}
                                             />
                                        </TableCell>
                                        <TableCell className={classes.headerStyle10} align="center">
                                        <Button disableRipple onClick={()=>handleDelete(row.examQuestionId)}>
                                            <DeleteSharpIcon style={{ color: red[500] }} fontSize="small"/>
                                        </Button>
                                        </TableCell>
                                    </TableRow>
                                )
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
            </DialogContent>
            <DialogActions className={classes.dialogActionsCenter}>
                <Button
                    variant="contained"
                    className={classes.cancelButton}
                    onClick={() => onClose({})}
                >
                    cancel
                        </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.submitButton}
                    onClick={(e) => handleAdd(e) }
                >
                    Update
                        </Button>
            </DialogActions>
        </Dialog>
    )
}