import React from 'react';
import theme from './theme';
import Avatar from '@material-ui/core/Avatar';
import Box from '@material-ui/core/Box'
import Chip from '@material-ui/core/Chip';
import FormControl from '@material-ui/core/FormControl';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import pink from '@material-ui/core/colors/pink';
import lightGreen from '@material-ui/core/colors/lightGreen';
import lightBlue from '@material-ui/core/colors/lightBlue';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { TextField } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { useParams } from 'react-router-dom';
import { useAlert } from 'react-alert';
import useAppContext from './AppContext'
import TablePagination from '@material-ui/core/TablePagination'
import { Link } from "react-router-dom";

import SearchIcon from '@material-ui/icons/Search';
import ListAltIcon from '@material-ui/icons/ListAlt';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },


    mainGrid:{
        margin: "50px;",
        // height: "35% !important"
    },
    examTitleDiv: {
        backgroundColor: theme.palette.secondary.main,
        height: "60px",
        color: "white",
        textAlign: "center",
        paddingTop: "20px",
        fontWeight: "bold"
    },
    examDetailP: {
        marginLeft: "10px",

    },
    bottomDiv: {
        height: "80px",
        textAlign: "center"
    },
    numberBoxTotal:{
        backgroundColor: "#b24c00 !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",
    },
    numberBox1: {
        backgroundColor: theme.palette.secondary.main + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    numberBox2: {
        backgroundColor: lightGreen['A700'] + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    numberBox3: {
        backgroundColor: pink[500] + " !important",
        fontSize: "20px !important",
        fontWeight: "bold",
        height: "40px !important",
        width: "40px !important",

    },
    outerChip: {
        color: "rgba(0, 0, 0, 0.87)",
        fontSize: "16px",
        height: "auto",
        fontWeight: "normal",
        margin:"20px",
        backgroundColor : "white !important",
        boxShadow :"3px 3px 1px 1px #ccc;",
        textAlign:"left",
        width:"150px",
        // paddingRight:"65px",


    },
    outerChipTotal: {
        color: "rgba(0, 0, 0, 0.87)",
        fontSize: "16px",
        height: "auto",
        fontWeight: "normal",
        margin:"20px",
        backgroundColor : "white !important",
        boxShadow :"3px 3px 1px 1px #ccc;",
        textAlign:"left",
        width:"150px",
        paddingRight:"65px",

    },
    reviewButton: {
        marginTop: "10%",
        backgroundColor: lightBlue[500] + " !important",
    },
    resultButton: {
        marginTop: "10%",
        backgroundColor: theme.palette.secondary.light + " !important",
    }
});


export default function CandidatesExamList() {
    const classes = useStyles();
    const { userId } = useParams(); 
    const appContext = useAppContext();
    const alert = useAlert();
    const Candidate_Exam_List_API = 'exams/listCandidateExams';
    const Status_count_API = 'exams/listStatusCounts';

    localStorage.setItem("candidateId", userId);

    const [open, setOpen] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [sort, setSort] = React.useState('scheduleAssignId');
    const [sortType, setSortType] = React.useState(true);
    const [search, setSearch] = React.useState('');
    const [groupData, setGroupData] = React.useState([]);
    const [gId, setGroupId] = React.useState(0);
    const [statusCount, setStatusCount] = React.useState([]);

    const [forceChange, setForceChange] = React.useState(false);
    const [candidatesList, setCandidatesList] = React.useState([]);
    const [rowData, setRowData] = React.useState([]);
    const [editOpen, setEditOpen] = React.useState(false);
    const [deleteOpen, setDeleteOpen] = React.useState(false);

    const handleSort = val =>{
        if(sort === val){
            setSortType(!sortType);
        }else{
            setSortType(sort === val);
        }
        setSort(val);
    }
    const handleSearchChange = event =>{
        const val = event.target.value;
        setSearch(val);
    }
    const handleSearchKeyUp = event =>{
      getCandidatesList();
    }  
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
      };
    
    const handleChangeLimit = event => {
        setLimit(parseInt(event.target.value, 10));
        setPage(0);
      };


    React.useEffect(()=>{
        getCandidatesList();
    },[sort, sortType, page, limit, forceChange, userId]);

    function getCandidatesList(){
        let apiUrl = `${Candidate_Exam_List_API}?limit=${limit}&search=`+encodeURIComponent(search)+`&page=${page + 1}&sort=${sort}&type=${sortType}&user=${userId}`

        appContext.getAxios().get(apiUrl).then((response)=>{
            setCandidatesList(response.data.result);
            setPage(response.data.currentPage-1);
            setCount(response.data.pagerInfo.count);

        },(error)=>{
            alert.error(error.response.data.message);    
        })
    }

    React.useEffect(()=>{
        getStatusCounts();
    },[]);

    function getStatusCounts(){
        let apiUrl = `${Status_count_API}?user=${userId}`

        appContext.getAxios().get(apiUrl).then((response)=>{
            setStatusCount(response.data);         
        },(error)=>{
            alert.error(error.response.data.message);    
        })
    }

    return (
        <div> 
            <h2>Exam List</h2>        
                <Grid container>
                 <Grid item md={3} sm={6}>
                 <Chip
                     className={classes.outerChipTotal}
                     color='secondary'
                     avatar={<Avatar color='secondary' className={classes.numberBoxTotal} >{statusCount[0]}</Avatar>}
                     label="All"
                 />
             </Grid>
             <Grid item md={3} sm={6}>
                 <Chip
                     className={classes.outerChip}
                     color='secondary'
                     avatar={<Avatar color='secondary' className={classes.numberBox1} >{statusCount[1]}</Avatar>}
                     label="Completed"
                 />
             </Grid>
             <Grid item md={3} sm={6}>
                 <Chip
                     className={classes.outerChip}
                     color='secondary'
                     avatar={<Avatar color='secondary' className={classes.numberBox2} >{statusCount[2]}</Avatar>}
                     label="Yet to start"
                 />
             </Grid>
             <Grid item md={3} sm={6}>
                 <Chip
                     className={classes.outerChip}
                     color='secondary'
                     avatar={<Avatar color='secondary' className={classes.numberBox3} >{statusCount[3]}</Avatar>}
                     label="Expired"startDate
                 />
             </Grid>
             </Grid>             
            
            {/* <Grid container>
                {rows.map((item) => (

                    <Grid item className={classes.mainGrid} md={4} sm={6}>

                        <Card>
                            <Box borderRadius={16}>
                                <div className={classes.examTitleDiv}>
                                    {item.examName}
                                </div>
                <p className={classes.examDetailP} >Start: {item.startDate.toDateString()} {item.startDate.getHours()}:{item.startDate.getMinutes()}</p>
                <p className={classes.examDetailP} >Expired: {item.expiredDate.toDateString()} {item.expiredDate.getHours()}:{item.expiredDate.getMinutes()}</p>
                <p className={classes.examDetailP} >No of Question: {item.totalQuestions}</p>
                <p className={classes.examDetailP} >Time duration: {item.duration}</p>
                                <Divider />
                                <div className={classes.bottomDiv}>
                                    <Grid container>
                                    <Grid item md={6} sm={6}>
                                    <Button variant="contained"
                                        color="secondary"
                                        justify="right"
                                        className={classes.resultButton} >
                                        <ListAltIcon></ListAltIcon> Result</Button>
                                    </Grid>
                                    <Grid item md={6} sm={6}>
                                    <Button variant="contained"
                                        color="secondary"
                                        justify="right"
                                        className={classes.reviewButton}>
                                        <SearchIcon></SearchIcon> Review</Button>
                                        </Grid>
                                    </Grid>
                                </div>
                            </Box>
                        </Card>

                    </Grid>


                ))}


            </Grid> */}

            
            <Box className={classes.toolbar} display="flex" flexDirection="row-reverse">

    
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        onChange = {handleSearchChange}
                        onKeyUp = {handleSearchKeyUp}
                        ></TextField>
                    </FormControl>
                    {/* <FormControl className={classes.formControl}>
                        <InputLabel id="select-grade-label">Group</InputLabel>
                        <Select
                            labelId="select-grade-label"
                            id="select-grade"
                            value={""}
                        >
                            <MenuItem value={1}>1</MenuItem>
                            <MenuItem value={2}>2</MenuItem>
                            <MenuItem value={3}>3</MenuItem>
                        </Select>
                    </FormControl> */}
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell  onClick = {()=>{handleSort('scheduleAssignId');}}>Title</TableCell>
                            <TableCell align="center">Duration</TableCell>
                            <TableCell align="center">Schedule</TableCell>
                            <TableCell align="center">Total Questions</TableCell>
                            <TableCell align="center">Result</TableCell>
                            {/* <TableCell align="center">Review</TableCell> */}
                            {/* <TableCell align="center">Apply</TableCell> */}
                        </TableRow>
                    </TableHead>
                    {candidatesList.length > 0 ? 
                    <TableBody>
                        {candidatesList.map((exam) => (
                            <TableRow key={exam.examId}>
                                <TableCell component="th" scope="row">
                                    {exam.name}
                                </TableCell>
                                <TableCell align="center">{exam.duration}</TableCell>
                                {/* <TableCell align="center">{exam.startDate} {exam.startDate.getHours()}:{exam.startDate.getMinutes()}</TableCell> */}
                                <TableCell align="center">{exam.startDate}</TableCell>
                                {/* <TableCell align="center">
                                    {displayApplicationStatus(row.applied)}
                                </TableCell> */}
                                <TableCell align="center">{exam.questionCount}</TableCell>
                                <TableCell align="center">{exam.resultCount > 0 ? <Link to={`/result/${exam.examId}/${exam.scheduleId}`}><ListAltIcon></ListAltIcon></Link>:''}</TableCell>
                                {/* <TableCell align="center"><SearchIcon></SearchIcon></TableCell> */}
                            </TableRow>
                        ))}
                    </TableBody>:''}
                </Table>
                {(candidatesList.length ==0 && search != "") ? 
                <div style={{'textAlign':"center"}}>Search result not found</div>
                :(candidatesList.length ==0) ? 
                <div style={{'textAlign':"center"}}>No result found</div>
                :''}
            </TableContainer>
            <TablePagination
            rowsPerPageOptions={[0]}
            component="div"
            count={count}
            rowsPerPage={limit}
            page={page}
            onChangePage={handleChangePage}
            onChangeRowsPerPage={handleChangeLimit}
            />
        </div>
    );
}