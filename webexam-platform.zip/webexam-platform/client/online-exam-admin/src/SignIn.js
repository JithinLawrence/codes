import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";

const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(8),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}));
export default function SignIn() {
    const alert = useAlert();
    const classes = useStyles();
    const [disabled, setDisabled] = React.useState(false);
    const [password, setPassword] = React.useState('');
    const [passwordError, setPasswordError] = React.useState(null);
    const [email, setEmail] = React.useState('');
    const [emailError, setEmailError] = React.useState(null);

    const appContext = useAppContext();

    const handlePasswordChange = event => {
        const pwd = event.target.value;
        setPassword(pwd);
        setPasswordError(pwd === '' ? 'Password is required' : null);
    };

    const handleEmailChange = event => {
        const eml = event.target.value;
        setEmail(eml);
        setEmailError(eml === '' ? 'Email is required' : null);
    };

    const handleSubmit = event => {
        event.preventDefault();

        if (password === '') {
            setPasswordError('Password is required');
            return;
        }

        if (email === '') {
            setEmailError('Email is required');
            return;
        }

        setDisabled(true)
        appContext.signIn(email, password).then((result) => {
            if (!result.status) {
                if(result.info.response){
                    alert.error(result.info.response.data.message);
                } else {
                    alert.error("Network Error");
                }
                setDisabled(false)// to prevent disabling this button if error occurs
            }
            if(disabled){// to prevent no-op error, this condition is checked
                setDisabled(false)
            }
        });
    };

    return (
        <Box my={4} >
            <Typography variant="h4" component="h1" gutterBottom align="center">
                OnlineExamPlatform
      </Typography>
            <Container component="main" maxWidth="xs">
                <CssBaseline />
                <div className={classes.paper}>
                    <Avatar className={classes.avatar}>
                        <LockOutlinedIcon />
                    </Avatar>
                    <Typography component="h1" variant="h5">
                        Sign in
        </Typography>
                    <form className={classes.form} onSubmit={handleSubmit}>
                        <TextField
                            variant="outlined"
                            margin="normal"
                            required
                            fullWidth
                            id="email"
                            label="Email Address"
                            name="email"
                            autoComplete="email"
                            autoFocus
                            type="email"
                            disabled={disabled} 
                            value={email} 
                            onChange={handleEmailChange} 
                            error={emailError !== null} 
                            helperText={emailError} 
                        />
                        <TextField
                            variant="outlined"
                            margin="normal"
                            required
                            fullWidth
                            name="password"
                            label="Password"
                            type="password"
                            id="password"
                            autoComplete="current-password"
                            disabled={disabled} 
                            value={password} 
                            onChange={handlePasswordChange} 
                            error={passwordError !== null} 
                            helperText={passwordError}
                        />
                        <Button
                            fullWidth
                            variant="contained"
                            color="primary"
                            className={classes.submit}
                            type="submit"
                            disabled={disabled}
                        >
                            Sign In
                        </Button>
                        <Grid container>
                            <Grid item xs>
                                <Link href="/admin/forgotpassword" variant="body2">
                                    {"Forgot password?"}
                                </Link>
                            </Grid>
                            
                        </Grid>
                    </form>
                </div>
                <Box mt={8}>
                </Box>
            </Container>
        </Box>
    );
}