const Config = {
    apiBase: 'http://localhost:8080/admin/',
    // apiBase: 'https://dev.shiken.online/we-api/admin/',
    // 1024*1024*10 = 10Mb
    imageMaxFileSize: 10485760
  };
  
  export default Config;
  