import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import useAppContext from './AppContext';
import { useAlert } from 'react-alert';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    formControl: {
        width:250,
        height:70,
        marginLeft: "10px"
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
}));

export default function UserAdd({ open, onClose }) {
    const classes = useStyles();

    const appContext=useAppContext();
    const alert = useAlert();
    const ExamPlanner_Add_API = 'users'

    const [disabled, setDisabled] = React.useState(false);
    const [firstName, setFirstName] = React.useState('');
    const [firstNameError, setFirstNameError] = React.useState(null);
    const [lastName, setLastName] = React.useState('');
    const [lastNameError, setLastNameError] = React.useState(null);
    const [email, setEmail] = React.useState('');
    const [emailError, setEmailError] = React.useState(null);
    const [password, setPassword] = React.useState('');
    const [passwordError, setPasswordError] = React.useState(null);
    const [confirmPassword, setconfirmPassword] = React.useState('');
    const [confirmPasswordError, setConfirmPasswordError] = React.useState(null);
    const [role, setRole] = React.useState('');
    const [roleError, setRoleError] = React.useState(null);

    const handleFirstNameChange = event => {
        const firstName = event.target.value;
        setFirstName(firstName);
        let errorMsg = null;
        errorMsg = firstName === '' ? "First Name is required" : null;
        errorMsg = errorMsg == null ? (firstName.length > 50 ? "First name length must not exceed 50 characters" : null) : errorMsg;
        setFirstNameError(errorMsg);
    };

    const handleLastNameChange = event =>{
        const lastName = event.target.value;
        setLastName(lastName);
        let errorMsg = null;
        errorMsg = errorMsg == null ? (lastName.length > 50 ? "Last name length must not exceed 50 characters" : null) : errorMsg;
        setLastNameError(errorMsg)
        //setLastNameError(lastName === '' ? 'LastName is required' : null);
    };

    const handleEmailChange = event => {
        const email = event.target.value;
        let emailChk = new RegExp(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,15}/g).test(email);
        setEmail(email);
        let errorMsg = null;
        errorMsg = email === '' ? "Email is required" : null;
        errorMsg = errorMsg == null ? (email.length > 225 ? "Email length must not exceed 225 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (emailChk == false ? "Please enter a valid email." : null) : errorMsg;
        setEmailError(errorMsg);
    };

    const handlePasswordChange = event =>{
        const password = event.target.value;
        setPassword(password);
        let test = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~])[a-zA-Z0-9 \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~]+$").test(password);  
        let errorMsg = null;
        errorMsg = password === '' ? "Password is required" : null;
        errorMsg = errorMsg == null ? (password.length > 30 ? "Password length must not exceed 30 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (password.length < 8 ? "Password length must be 8 or more characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (test == false ? "Password must contain one lowercase letter, uppercase letter, digit and special character." : null) : errorMsg;
        setPasswordError(errorMsg);
        };

    const handleRoleChange = event => {
        const role = event.target.value;
        setRole(role);
        let errorMsg = null;
        errorMsg = role === '' ? "Role is required" : null;
        setRoleError(errorMsg);
    };

    const handleConfirmPasswordChange = event =>{
        const confPassword = event.target.value;
        setconfirmPassword(confPassword);
        let test = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~])[a-zA-Z0-9 \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~]+$").test(confPassword);  
        let errorMsg = null;
        errorMsg = confPassword === '' ? "Confirm password is required" : null;
        errorMsg = errorMsg == null ? (confPassword.length > 30 ? "Confirm password length must not exceed 30 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (confPassword.length < 8 ? "Confirm password length must be 8 or more characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (test == false ? "Password must contain one lowercase letter, uppercase letter, digit and special character." : null) : errorMsg;
        setConfirmPasswordError(errorMsg);
        };

    
    const handleSubmit = event =>{
        event.preventDefault();

        if(firstNameError != null || emailError != null || passwordError != null || roleError != null || confirmPasswordError != null){
            return;
        }

        if(confirmPassword !== password){
            setConfirmPasswordError("Confirm password not same as the actual password");
            return;
        }

        setDisabled(true);
        setExamPlannerAdd(firstName,lastName,email,password,role,confirmPassword).then((result)=>{
            if(!result.status){             
                alert.error(result.info.response.data.message);
            }else{
                reSetInput();
                alert.success("User created successfully.");
            }
            setDisabled(false);
        });    
    };

   function reSetInput(){
       setFirstName('');
       setLastName('');
       setEmail('');
       setPassword('');
       setRole('');
       setconfirmPassword('');
       setFirstNameError(null);
       setLastNameError(null);
       setEmailError(null);
       setPasswordError(null);
       setRoleError(null);
       setConfirmPasswordError(null);
    }

    function setExamPlannerAdd(firstName,lastName,email,password,role,confirmPassword){
        let data = JSON.stringify({
            firstName : firstName,
            lastName : lastName,
            email : email,
            password : password,            
            role : role,
            confirmPassword : confirmPassword
        })

        return appContext.getAxios().post(ExamPlanner_Add_API,data).then((response)=>{
            onClose(true);
            return {status:true, info : response}
        },(error)=>{
            return {status:false, info : error}
        });
    }

    return(
        <Dialog  minWidth="sm" open={open} onClose={() => {reSetInput();onClose(false);}} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Add User</Typography>
                <IconButton size="small" className={classes.close} onClick={() => {reSetInput();onClose(false);}}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
            <form className={classes.form} onSubmit={handleSubmit}>
                <div >
                <Grid container>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                     
                        <TextField                        
                        label="First Name"  
                        required                      
                        id="plannerFirstName"
                        value={firstName}
                        onChange={handleFirstNameChange}
                        error={firstNameError !== null}
                        helperText = {firstNameError}
                        >                       
                        </TextField>
                    </FormControl>
                    </Grid>    
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                    
                        <TextField
                        label="Last Name"                        
                        id="plannerLastName"                        
                        value={lastName}
                        onChange={handleLastNameChange}
                        error={lastNameError !== null}
                        helperText={lastNameError}
                        >
                        </TextField>
                        </FormControl>
                    </Grid>    
                </Grid>
                <br></br>
                <Grid container>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                       
                            <TextField
                            type="email"
                            fullWidth
                            required
                            label="Email"
                            id="email"                            
                            value={email}
                            onChange={handleEmailChange}
                            error={emailError !== null}
                            helperText={emailError}
                            >
                            </TextField>
                            </FormControl>
                    </Grid>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                        
                            <TextField
                            type="Password"
                            fullWidth
                            required
                            label="Password"
                            id="password"                            
                            value={password}
                            onChange={handlePasswordChange}
                            error={passwordError !== null}
                            helperText={passwordError}
                            >
                            </TextField>
                            </FormControl>
                    </Grid>
                </Grid>
                <br></br>
                <Grid container>

                <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                       
                            <TextField
                            type="Password"
                            fullWidth
                            required
                            label="ConfirmPassword"
                            id="confirmPassword"                            
                            value={confirmPassword}
                            onChange={handleConfirmPasswordChange}
                            error={confirmPasswordError !==null}
                            helperText = {confirmPasswordError}
                            >
                            </TextField>
                            </FormControl>
                    </Grid>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl} required>
                    <InputLabel id="select-role-label">Role</InputLabel>
                        <Select
                            labelId="select-role-label"
                            id="select-role"
                            required
                            value={role}
                            onChange={handleRoleChange}
                            error={roleError !== null}                            
                        >
                            <MenuItem value=""><em>Select</em></MenuItem>
                            <MenuItem value={1}>Admin</MenuItem>
                            <MenuItem value={2}>Exam Planner</MenuItem>
                            <MenuItem value={4}>Support</MenuItem>
                        </Select>
                    </FormControl>
                    </Grid>
                </Grid>
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>                      
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            color="default"
                            onClick={() => {reSetInput();onClose();}}
                        >
                            cancel
                        </Button>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type="submit"
                            disabled={disabled}
                        >
                            Create User
                        </Button>
                    </Box>
                </div >
                </form>
            </DialogContent>
        </Dialog>
    
    )
}
