import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid, IconButton } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import ExamCatogoryEdit from './examCatogoryEdit'
import ExamAddQuestions from './examAddQuestions';
import PageviewRoundedIcon from '@material-ui/icons/PageviewRounded';
import CKEditor from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import useAppContext from './AppContext';
import { Link, useParams } from 'react-router-dom';
import { useAlert } from "react-alert";
import { useHistory } from "react-router-dom";
import Checkbox from '@material-ui/core/Checkbox';
import ListIcon from '@material-ui/icons/List';
import PreviewExam from './preview/previewExam';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
    },
    addButton: {
        marginTop: theme.spacing(3),
    },
    previewButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    headerStyle15: {
        width: '15%',
        maxWidth: '1px'
    },
    headerStyle50: {
        width: '50%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    cellStyle15: {
        width: '15%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle50: {
        width: '50%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    }
}));

const rows = [
    createData(1, 'Maths', 10, 'q1'),
    createData(2, 'Science', 20, 'q2'),
    createData(3, 'Maths', 10, 'q3'),
    createData(4, 'Science', 20, 'q4'),
    createData(5, 'Maths', 10, 'q5'),
    createData(6, 'Science', 20, 'q6'),

];

function createData(categoryId, category, marks, questions) {
    return { categoryId, category, marks, questions };
}

export default function ExamEdit() {
    const classes = useStyles();
    const alert = useAlert();

    const EXAM_API = 'exams';
    const appContext = useAppContext();

    const { examId } = useParams();
    const [open, setOpen] = React.useState(false);
    const [showMark, setShowMark] = React.useState(1);
    const [catOpen, setCatOpen] = React.useState(false);
    const [catOpenedId, setCatOpenedId] = React.useState(false);
    const [ckd, setCkd] = React.useState('');
    const [ckdTC, setCkdTC] = React.useState('');
    const [ckdError, setCkdError] = React.useState(null);

    const [disabled, setDisabled] = React.useState(false);
    const [name, setName] = React.useState('');
    const [currentName, setCurrentName] = React.useState('');
    const [nameError, setNameError] = React.useState(null);
    const [duration, setDuration] = React.useState('');
    const [durationError, setDurationError] = React.useState(null);
    const [examType, setExamType] = React.useState('');//examType scheduleType
    const [examTypeError, setExamTypeError] = React.useState(null);
    const [scheduleType, setScheduleType] = React.useState('');
    const [scheduleTypeError, setScheduleTypeError] = React.useState(null);
    const [passMark, setPassMark] = React.useState('');
    const [passMarkError, setPassMarkError] = React.useState(null);
    const [totalMark, setTotalMark] = React.useState(0);
    const [totalMarkError, setTotalMarkError] = React.useState(null);
    // const [examId, setExamId] = React.useState(0);
    const [categories, setCategories] = React.useState([]);
    const [isOpen, setIsOpen] = React.useState(false);
    const [previewRow, setPreviewRow] = React.useState([]);

    const handlePreviewClose = hasChange => {
        setIsOpen(false);
    };
    const handlePreview = (row) => {
        if(categories.length > 0){
            setPreviewRow(row)
            setIsOpen(true);
        }
    };  

    
    const handleNameChange = event => {
        const val = event.target.value;
        setName(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Exam name is required" : null;
        errorMsg = errorMsg == null ? (val.length > 100 ? "Name must not exceed 100 characters" : null) : errorMsg;
        setNameError(errorMsg)
    };

    const handleDurationChange = event => {
        const val = event.target.value;
        let errorMsg = null;
        if (/^\d+$/.test(val) || val === '') {
            setDuration(val);
            errorMsg = (val != "" && val < 1) ? "Duration must be greater than 0" : null;
        } else {
            // event.target.value = 0;
            // setDuration(0);
            // errorMsg = "Duration must be greater than 0";
        }
        errorMsg = errorMsg == null ? (val > 1000  ? "Duration cannot exceed 1000" : null) : errorMsg;
        errorMsg = errorMsg == null ? (val === '' ? "Duration is required" : null) : errorMsg;
        setDurationError(errorMsg)
    };

    const handleExamTypeChange = event => {
        const val = event.target.value;
        setExamType(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Exam type is required" : null;
        setExamTypeError(errorMsg)
    };

    const handleScheduleTypeChange = event => {
        const val = event.target.value;
        setScheduleType(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Schedule type is required" : null;
        setScheduleTypeError(errorMsg)
    };

    // const handleDescriptionChange = event => {
    //     const val = event.target.value;
    //     setDescription(val);
    //     let errorMsg = null;
    //     errorMsg = val === '' ? "Description is required" : null;
    //     // errorMsg = errorMsg == null ? (val.length > 100 ? "Exam name length must not exceed 100 characters" : null) : errorMsg;
    //     setDescriptionError(errorMsg)
    // };

    const ermsg = "Pass mark must be less than total mark";
    const handlePassMarkChange = event => {
        const val = event.target.value;
        let errorMsg = null;
        if (/^\d+$/.test(val) || val === '') {
            setPassMark(val);
            errorMsg = (val != "" && val < 1 && parseInt(totalMark) != 0) ? "Pass mark must be greater than 0" : null;
            errorMsg = errorMsg == null ? (parseInt(val) > parseInt(totalMark) ? ermsg : null) : errorMsg;
        } else {
            // event.target.value = 0;
            // setPassMark(0);
            // errorMsg = "Pass mark must be greater than 0";
        }
        errorMsg = errorMsg == null ? (val === '' ? "Pass mark is required" : null) : errorMsg;
        setPassMarkError(errorMsg)
    };

    const handleTotalMarkChange = event => {
        const val = event.target.value;
        let errorMsg = null;
        if (/^\d+$/.test(val) || val === '') {
            setTotalMark(val);
            errorMsg = (val != "" && val < 1) ? "Total mark must be greater than 0" : null;
            let errorMsgPassMark = (passMarkError == null || passMarkError == ermsg) ? ((parseInt(passMark) > parseInt(val)) ? ermsg : null) : passMarkError;
            setPassMarkError(errorMsgPassMark)
        } else {
            event.target.value = 0;
            setTotalMark(0);
            errorMsg = "Total mark must be greater than 0";
        }
        errorMsg = errorMsg == null ? (val === '' ? "Total mark is required" : null) : errorMsg;
        setTotalMarkError(errorMsg)
    };

    const handleCatClose = examCategoryReceived => {
        console.log(examCategoryReceived)
        if(Object.keys(examCategoryReceived).length != 0){
            // setExamId(examCategoryReceived.data.examId)
            setCategories(examCategoryReceived.data.tableData)
            const temp = examCategoryReceived.data.tableData;
            let total = 0;
            temp.map((row) => {
                total += row.marks;
            });
            if(examCategoryReceived.data.tableData.length == 0){
                setPassMark(0)
            } else {
                if(total < passMark){
                    setPassMarkError("Pass mark must be less than total mark")
                }
            }
            setTotalMark(total);
        }
        setCatOpen(false);
    };
    const handleClose = examQuestionReceived => {
        if(Object.keys(examQuestionReceived).length != 0){
            // setExamId(examQuestionReceived.data.examId)
            setCategories(examQuestionReceived.data.tableData)
            const temp = examQuestionReceived.data.tableData;
            let total = 0;
            temp.map((row) => {
                total += row.marks;
            });
            if(examQuestionReceived.data.tableData.length == 0){
                setPassMark(0)
            } else {
                if(total < passMark){
                    setPassMarkError("Pass mark must be less than total mark")
                }
            }
            setTotalMark(total);
        }
        setOpen(false);
    };
    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleCatClick = (
        // categoryId
        ) => {
        // setCatOpenedId(categoryId)
        setCatOpen(true);
    };
    const handleDelete = (categoryId) => {
        appContext.getAxios().delete(EXAM_API+"/"+examId+"/"+categoryId).then((response) => {
            if(Object.keys(response).length != 0){
                setCategories(response.data.tableData)
                const temp = response.data.tableData;
                let total = 0;
                temp.map((row) => {
                    total += row.marks;
                });
                if(response.data.tableData.length == 0){
                    setPassMark(0)
                } else {
                    if(total < passMark){
                        setPassMarkError("Pass mark must be less than total mark")
                    }
                }
                setTotalMark(total);
            }

            let tempData = categories;
            tempData = tempData.filter(i => i.categoryId !== categoryId);
            setCategories(tempData);
            // if {
                // alert.success("OK");
            // }
            // return {status: true, info: response};
        }, (error) => {
            console.log(error)
                    // if (!result.status) {
                        // alert.error(error.response.data.message);
                    // } 
            // return {status: false, info: error};
        });
    };

    function handleShowMark(e) {
        setShowMark(e.target.checked ? 1 : 0)
    };

    let history = useHistory();

    const handleSubmit = event => {
        event.preventDefault();
        if(totalMark > 0 && passMark == 0){
            const errorMsg = "Pass mark must be greater than 0";
            setPassMarkError(errorMsg)
            return;
        }

        if(nameError != null || durationError != null || examTypeError != null || scheduleTypeError != null || passMarkError != null || totalMarkError != null){
            return;
        }

        setDisabled(true)//description, passMark, totalMark
        createExam(name, duration, examType, scheduleType, ckd, ckdTC, passMark, totalMark, showMark).then((result) => {
            setDisabled(false)
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                resetInputs();
                alert.success("Exam updated successfully");
                history.push('/exams')
            }
        });
    };

    function resetInputs(){
        setName('');
        setDuration('');
        setExamType('');
        setScheduleType('');
        setCkd('');
        setCkdTC('');
        setPassMark('');
        setTotalMark('');
        setNameError(null);
        setDurationError(null);
        setExamTypeError(null);
        setScheduleTypeError(null);
        setCkdError(null);
        setPassMarkError(null);
        setTotalMarkError(null);
    }

    React.useEffect(() => {
        console.log('examId change')
        console.log(examId)
        appContext.getAxios().put(EXAM_API+"/initEdit/"+examId).then((response) => {
            if(Object.keys(response).length != 0){
                console.log(response)
                setCategories(response.data.tableData)
                setName(response.data.name)
                setCkd(response.data.description)
                setCkdTC(response.data.termsAndConditions)
                setCurrentName(response.data.name)
                setDuration(response.data.duration)
                setExamType(response.data.examType)
                setScheduleType(response.data.scheduleType)
                setPassMark(response.data.passMark)
                setShowMark(response.data.showMark)
                //setName setDuration setExamType setScheduleType setPassMark
                const temp = response.data.tableData;
                let total = 0;
                temp.map((row) => {
                    total += row.marks;
                });
                setTotalMark(total);
            }
            // alert.success("OK");
        }, (error) => {
            alert.error(error.response.data.message);
            history.push('/exams')
        });
    }, [examId]);

    function createExam(name, duration, examType, scheduleType, ckd, ckdTC, passMark, totalMark, showMark) {
        // categories.map((row) => {
        //     console.log(row);
        // });
        let data = JSON.stringify({
            name: name,
            duration: duration,
            type: examType,
            scheduleType: scheduleType,
            description: ckd,
            termsAndConditions: ckdTC,
            passMark: passMark,
            totalMark: totalMark,
            showMark: showMark
            
        })
        return appContext.getAxios().put(EXAM_API+"/"+examId, data).then((response) => {            
            return {status: true, info: response};
        }, (error) => {
            return {status: false, info: error};
        });
    }

    return (
        <form className={classes.form} onSubmit={handleSubmit}>
            <h1>Edit exam</h1>
            <Grid container>
                <Grid item sm={12} md={3}>
                    <FormControl className={classes.formControl}>
                        <TextField 
                        required 
                        id="name" 
                        className={classes.inputField}
                        label="Exam Name" 
                        disabled={disabled} 
                        value={name} 
                        onChange={handleNameChange} 
                        error={nameError !== null} 
                        helperText={nameError}
                        />
                    </FormControl>
                </Grid>
                <Grid item sm={12} md={3}>
                    <FormControl className={classes.formControl}>
                        <TextField 
                        required 
                        id="duration" 
                        className={classes.inputField} 
                        label="Duration of exam (in minutes)" 
                        disabled={disabled} 
                        value={duration} 
                        // type="number"
                        // keyboardType="numeric"
                        onChange={handleDurationChange} 
                        error={durationError !== null} 
                        helperText={durationError}
                        />
                    </FormControl>
                </Grid>
                <Grid item sm={12} md={3}>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-exam-type-label">Exam type *</InputLabel>
                        <Select
                            labelId="select-exam-type-label"
                            id="select-exam-type"
                            required
                            disabled={disabled} 
                            value={examType} 
                            onChange={handleExamTypeChange} 
                            error={examTypeError !== null} 
                            // helperText={examTypeError}
                        >
                            <MenuItem value={1}>Public</MenuItem>
                            <MenuItem value={2}>Private</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item sm={12} md={3}>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-exam-schedule-label">Exam schedule type *</InputLabel>
                        <Select
                            labelId="select-exam-schedule-label"
                            id="select-exam-schedule"
                            required
                            disabled={disabled} 
                            value={scheduleType} 
                            onChange={handleScheduleTypeChange} 
                            error={scheduleTypeError !== null} 
                            // helperText={scheduleTypeError}
                        >
                            <MenuItem value={1}>Flexi</MenuItem>
                            <MenuItem value={2}>Fixed</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
            </Grid>
            <div >
                <br></br>
                <Typography>Description :</Typography>
                <CKEditor
                    editor={ClassicEditor}
                    data={ckd}
                    className={classes.ckeditor}
                    onInit={editor => {
                        // You can store the "editor" and use when it is needed.  
                        console.log('Editor is ready to use!', editor);
                    }}
                    onChange={(event, editor) => {
                        const data = editor.getData();
                        setCkd(data);
                        console.log({ event, editor, data });
                    }}
                    onBlur={(event, editor) => {
                        console.log('Blur.', editor);
                    }}
                    onFocus={(event, editor) => {
                        console.log('Focus.', editor);
                    }}
                />
            </div>
            <div >
                <br></br>
                <Typography>Terms and Conditions :</Typography>
                <CKEditor
                    editor={ClassicEditor}
                    data={ckdTC}
                    className={classes.ckeditor}
                    onInit={editor => {
                        // You can store the "editor" and use when it is needed.  
                        console.log('Editor is ready to use!', editor);
                    }}
                    onChange={(event, editor) => {
                        const data = editor.getData();
                        setCkdTC(data);
                        console.log({ event, editor, data });
                    }}
                    onBlur={(event, editor) => {
                        console.log('Blur.', editor);
                    }}
                    onFocus={(event, editor) => {
                        console.log('Focus.', editor);
                    }}
                />
            </div>
            <Grid container>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.addButton}
                    onClick={handleClickOpen}
                >
                    Add Question
                    </Button>
                &nbsp;&nbsp;
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.addButton}
                    disabled={disabled || categories.length == 0} 
                    onClick={handleCatClick}
                >
                    View Question
                </Button>
            </Grid>
            {/* <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell className={classes.headerStyle10} align="center">Questions</TableCell>
                            <TableCell className={classes.headerStyle50} align="left">Category</TableCell>
                            <TableCell className={classes.headerStyle15} align="left">Marks</TableCell>
                            <TableCell align="left" style={{ whiteSpace : "nowrap" }}>Question Count</TableCell>
                            <TableCell className={classes.headerStyle10} align="center">Delete</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {categories.map((row) => (
                            <TableRow key={row.categoryId}>
                                <TableCell className={classes.cellStyle10} align="center" component="th" scope="row">
                                    <Button disableRipple onClick={()=>handleCatClick(row.categoryId)}>
                                        <ListIcon fontSize="small"/>
                                    </Button>
                                </TableCell>
                                <TableCell className={classes.cellStyle50} align="left" component="th" scope="row">{row.category}</TableCell>
                                <TableCell className={classes.cellStyle15} align="left">{row.marks}</TableCell>
                                <TableCell className={classes.cellStyle15} align="left">{row.questions}</TableCell>                                
                                <TableCell className={classes.cellStyle10} align="center">
                                    <Button disableRipple onClick={()=>handleDelete(row.categoryId)}>
                                        <DeleteSharpIcon style={{ color: red[500] }} fontSize="small"/>
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer> */}
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                <Typography variant="h6"> Passing marks for exam / Total mark </Typography>
            </Box>
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                <TextField 
                required 
                id="passmark" 
                label="Pass Mark" 
                disabled={disabled || categories.length == 0} 
                value={ categories.length == 0 ? 0 : passMark} 
                // type="number"
                onChange={handlePassMarkChange} 
                error={passMarkError !== null} 
                helperText={passMarkError}
                />
                <Box justifyContent="center" m={2} pb={1}>
                    <Typography variant="h4"> / </Typography>
                </Box>
                <Box justifyContent="center" mt={2} mb={2} pt={1} pb={1}>
                    <Typography variant="h5"> {totalMark} </Typography>
                </Box>
                {/* <TextField 
                required 
                id="totalmark" 
                label="Total Mark" 
                disabled={true} 
                value={totalMark} 
                onChange={handleTotalMarkChange} 
                error={totalMarkError !== null} 
                helperText={totalMarkError}
                /> */}
            </Box>
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                <Typography variant="h6"> 
                Show mark right after exam 
                <Checkbox 
                    checked={showMark == 1} 
                    onChange={(e) => handleShowMark(e)}/>
                </Typography>
            </Box>
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                <Link style={{ textDecoration: 'none', color: "black" }} to="/exams" className={classes.btnprimary} >
                    <Button
                        variant="contained"
                        className={classes.cancelButton}
                    >
                        Cancel
                    </Button>
                </Link>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.submitButton}
                    type="submit"
                    disabled={disabled || categories.length == 0}
                >
                    Update
                </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.previewButton}
                    disabled={categories.length == 0}
                    onClick={() => handlePreview(examId)} 
                >
                    <PageviewRoundedIcon />
                    Preview
                </Button>

            </Box>
            < PreviewExam open={isOpen} onClose={handlePreviewClose} row={{'examId':  examId}} type={"edit"} save={{name: name, duration: duration, ckd: ckd, ckdTC: ckdTC}}/>
            <ExamAddQuestions open={open} onClose={handleClose} examId={examId}/>
            <ExamCatogoryEdit open={catOpen} onClose={handleCatClose} examId={examId}/>
        </form >

    )
}