import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import EditSharpIcon from '@material-ui/icons/EditSharp';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import { Link } from "react-router-dom";
import useAppContext from './AppContext';
import { TextField } from '@material-ui/core';
import CategoryAdd from './categoryAdd';
import CategoryEdit from './categoryEdit';
import DeleteConfirm from './deleteConfirm';
import ListIcon from '@material-ui/icons/List';
import { useAlert } from "react-alert";
import TablePagination from '@material-ui/core/TablePagination';
import SwapVertSharpIcon from '@material-ui/icons/SwapVertSharp';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    cursorPinter:{
        cursor: 'pointer'
    },
    headerStyle5: {
        width: '5%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    headerStyle15: {
        width: '15%',
        maxWidth: '1px'
    },
    headerStyle40: {
        width: '40%',
        maxWidth: '1px'
    },
    headerStyle30: {
        width: '30%',
        maxWidth: '1px'
    },
    cellStyle5: {
        width: '5%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle15: {
        width: '15%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle40: {
        width: '40%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle30: {
        width: '30%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    }
});

export default function GradeList() {
    const classes = useStyles();
    const alert = useAlert();

    const Category_List_API = 'common/listCategories';
    const appContext = useAppContext();

    const [createOpen, setCreateOpen] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('category_id');
    const [sortType, setSortType] = React.useState(true);
    let count1=0;
    const [forceChange, setForceChange] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [editOpen, setEditOpen] = React.useState(false);
    const [deleteOpen, setDeleteOpen] = React.useState(false);
    const [rowData, setRowData] = React.useState([]);
    const [status, setDataStatus] = React.useState(false);
    
    const handleSearchChange = event => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleCloseCreate = hasChange => {
        if(hasChange){
            setSort('category_id');
            setSortType(true);
            setPage(0);
            setForceChange(!forceChange)//after saving count not incremented properly. so changing this value reloads the method listQuestionBank
        }
        setCreateOpen(false);
    };
    const handleClickOpenCreate = () => {
        setCreateOpen(true);
    };

    const handleCloseEdit = hasChange => {
        if(hasChange){
            listGrades()
        }
        setEditOpen(false);
    };

    const handleDelete = hasChange => {
        if(hasChange){
            listGrades()
        }
        setDeleteOpen(false);
    };
    const handleClickOpenEdit = (editingRow) => {
        setRowData(editingRow)
        setEditOpen(true);
    };    
    const handleClickOpeDelete = (deletingRow) => {
        setRowData(deletingRow)
        setDeleteOpen(true);
    };  

    const handleSort = val => {
        if(sort == val){
            setSortType(!sortType)
        } else {
            setSortType(sort == val)
        }
        setSort(val);
    };

    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
  
    const handleChangeLimit = event => {
      setLimit(parseInt(event.target.value, 10));
      setPage(0);
    };

    React.useEffect(() => {
        listGrades();
      }, [sort, sortType, page, limit, forceChange, search]); 

    function listGrades() {
        appContext.getAxios().get(Category_List_API+'?page='+(page+1)+'&limit='+limit+'&search='+encodeURIComponent(search)+'&type='+sortType+'&sort='+sort).then((response) => {
            setData(response.data.result);
            setPage(response.data.currentPage-1)//to reset page in case deleting the last row of last page           
            setCount(response.data.pagerInfo.count);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }
    return (
        <div>
            <h1>Category List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

                <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                        <Button
                            variant="contained"
                            color="secondary"
                            justify="right"
                            onClick={handleClickOpenCreate}
                        >
                            Add Category
                        </Button>
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                            label="Search"
                            id="search"
                            value={search} 
                            onChange={handleSearchChange} 
                        ></TextField>
                    </FormControl>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell className={classes.headerStyle5} align="left">No</TableCell>
                            <TableCell className={classes.headerStyle30} align="left">
                                Name&nbsp;
                                <SwapVertSharpIcon fontSize="small" style={{'marginBottom':'-5px'}} className={classes.cursorPinter} onClick={() => {handleSort('name');}}/>
                            </TableCell>
                            <TableCell className={classes.headerStyle40} align="left">Description</TableCell>
                            <TableCell className={classes.headerStyle15} align="left" style={{ whiteSpace : "nowrap" }}>Created at</TableCell>                         
                            <TableCell className={classes.headerStyle10} align="center">Action</TableCell>
                        </TableRow>
                    </TableHead>
                    {data.length > 0 ?
                    <TableBody>
                        { data.map((row, index) => (
                            <TableRow key={row.categoryId}>
                                <TableCell className={classes.cellStyle5} align="left" component="th" scope="row">
                                    {(page * limit) + index + 1}
                                </TableCell>
                                <TableCell className={classes.cellStyle30} align="left">{row.name}</TableCell>
                                <TableCell className={classes.cellStyle40} align="left" >{row.description}</TableCell>
                                <TableCell align="left" style={{ 'white-space' : 'nowrap' }}>{row.createDate}</TableCell>
                                <TableCell className={classes.cellStyle10} align="center" style={{ 'white-space' : 'nowrap' }}>
                                 <EditSharpIcon className={classes.cursorPinter}  fontSize="small" onClick={() => handleClickOpenEdit(row)} /> &nbsp;&nbsp;&nbsp;
                                 <DeleteSharpIcon className={classes.cursorPinter}  style={{ color: red[500] }} fontSize="small"  onClick={() => handleClickOpeDelete(row)} />
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>:''}
                </Table>
                {(data.length ==0 && search != "") ? 
                <div style={{'textAlign':"center"}}>Search result not found</div>
                :(data.length ==0) ? 
                <div style={{'textAlign':"center"}}>No result found</div>
                :''}
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[0]}
                component="div"
                count={count}
                rowsPerPage={limit}
                page={page}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeLimit}
            />
            <CategoryAdd  open={createOpen} onClose={handleCloseCreate}  />
            <CategoryEdit  open={editOpen} onClose={handleCloseEdit} row={rowData} />
            <DeleteConfirm open={deleteOpen} onClose={handleDelete} apiLink={'common/category'} deleteId={rowData.categoryId} deleteText={'Are you sure you want to delete this category?'} deleteMsg={'Category deleted successfully.'}/>
        </div>
    );
}