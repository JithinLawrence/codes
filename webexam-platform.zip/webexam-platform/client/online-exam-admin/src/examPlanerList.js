import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import { Link } from "react-router-dom"; 
import useAppContext from './AppContext';
import UserAdd from './examPlannerAdd';
import UserEdit from './examPlannerEdit';
import UserPasswordChange from './userPasswordChange';
import DeleteConfirm from './deleteConfirm';
import FormControl from '@material-ui/core/FormControl';
import { TextField } from '@material-ui/core';
import EditSharpIcon from '@material-ui/icons/EditSharp';
import zIndex from '@material-ui/core/styles/zIndex';
import TablePagination from '@material-ui/core/TablePagination'
import { useAlert } from 'react-alert';
import SwapVertSharpIcon from '@material-ui/icons/SwapVertSharp';


const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration : "none"
    },
    cursorPinter:{
        cursor: 'pointer'
    },
    headerStyle5: {
        width: '5%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    headerStyle15: {
        width: '15%',
        maxWidth: '1px'
    },
    headerStyle20: {
        width: '20%',
        maxWidth: '1px'
    },
    headerStyle30: {
        width: '30%',
        maxWidth: '1px'
    },
    cellStyle5: {
        width: '5%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle15: {
        width: '15%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle20: {
        width: '20%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle30: {
        width: '30%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    }
});

export default function UserList(){
    const classes = useStyles();
    const alert = useAlert();
    let count1=0;

    const ExamPlanner_List_API = 'users/list';

    const ExamPlanner_Delete_API = 'users';

    const appContext = useAppContext();

    //Data for fetch examplanner list
    const [examPlannerList, setExamPlannerList] = React.useState([]);

    //dialog box controls
    const [open, setOpen] = React.useState(false);
    const [editableObj, setEditableObj] = React.useState('');
    const [deleteOpen, setDeleteOpen] = React.useState(false);

    //form data
    const [firstName, setFirstName] = React.useState('');
    const [lastName, setLastName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [type, setType] = React.useState('');
    const [isEdit, setIsEdit] = React.useState(false);
    const [examPlanner, setExamPlanner] = React.useState([]);

    //Fetching exam planner list  
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [count, setCount] = React.useState(0);
    const [searchKey, setSearchKey] = React.useState('');
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('user_id');
    const [sortType, setSortType] = React.useState(true);

    const [forceChange, setForceChange] = React.useState(false);

    const [openUserAdd, setOpenUserAdd] = React.useState(false);

    const handleSearchChange = event => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleSearchKeyUp = event => {
        getExamPlannerList();
    };

    const handleSort = val => {
        if(sort == val){
            setSortType(!sortType)
        } else {
            setSortType(sort == val)
        }
        setSort(val);
    };

    const handleCloseUserAdd = hasChange => {
        if(hasChange){
            setSort('user_id');
            setSortType(true);
            setPage(0);
            setForceChange(!forceChange)
        }
        setOpenUserAdd(false);
    };

    const handleClickOpenUserAdd = () => {
        setOpenUserAdd(true);
    };

    const [openUserEdit, setOpenUserEdit] = React.useState(false);

    const handleCloseUserEdit = hasChange => {

        if(hasChange){
            getExamPlannerList()
        }
        setOpenUserEdit(false);
    };

    const handleCloseUserEditPassword = hasChange => {
        setOpenUserEdit(false);
        setOpenUserPasswordChange(true);
    };

    const handleClickOpenUserEdit = () => {
        setOpenUserEdit(true);
    };


    const [openUserPasswordChange, setOpenUserPasswordChange] = React.useState(false);

    const handleCloseUserPasswordChange = hasChange => {
        setOpenUserPasswordChange(false);
    };
    const handleClickOpenUserPasswordChange = () => {
        setOpenUserEdit(false);
        setOpenUserPasswordChange(true);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
      };
    
      const handleChangeLimit = event => {
        setLimit(parseInt(event.target.value, 10));
        setPage(0);
      };

      const handleDelete = hasChange => {
        if(hasChange){
            getExamPlannerList();
        }
        setDeleteOpen(false);
    };

    const handleClickOpeDelete = (examPlanner) => {
        setExamPlanner(examPlanner);
        setDeleteOpen(true);
    };  

    const editExamPlanner = (examPlanner) =>{                    
                setExamPlanner(examPlanner);
                setOpenUserEdit(true);             
    };  
    
    React.useEffect(()=>{
        getExamPlannerList();
    }, [sort, sortType, page, limit, forceChange]);  

    function getExamPlannerList(){
    
     let apiUrl = `${ExamPlanner_List_API}?limit=${(limit)}&page=${page + 1}&search=`+encodeURIComponent(search)+`&type=${sortType}&sort=${sort}`;
       
        appContext.getAxios().get(apiUrl).then((response) => {            
          setExamPlannerList(response.data['result']);
          setPage(response.data.currentPage-1)
          setCount(response.data.pagerInfo.count);
        },(error)=>{
            alert.error(error.response.data.message);
        });
      };   
     
    return (
        <div>
            <h1>User List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

               <Box flexGrow={1} margin={2.5}  alignContent="flex-start">
               {(1 == localStorage.getItem("role")) &&<Button
                        variant="contained"
                        color="secondary"
                        className={classes.addButton}
                        onClick={handleClickOpenUserAdd}
                    >
                      Add User
                    </Button>}
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        value={search} 
                        onChange={handleSearchChange} 
                        onKeyUp={handleSearchKeyUp}
                        ></TextField>
                    </FormControl>
                </Box>                
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell className={classes.headerStyle5} align="left">No</TableCell>
                            <TableCell className={classes.headerStyle20} align="left">
                                First Name&nbsp;
                                <SwapVertSharpIcon fontSize="small" style={{'marginBottom':'-5px'}} className={classes.cursorPinter} onClick={() => {handleSort('first_name');}}/>
                            </TableCell>
                            <TableCell className={classes.headerStyle20} align="left">Last Name</TableCell>
                            <TableCell className={classes.headerStyle30} align="left">Email</TableCell>
                            <TableCell className={classes.headerStyle15} align="left">Role</TableCell>
                            <TableCell className={classes.headerStyle5} align="center">Edit</TableCell>
                            <TableCell className={classes.headerStyle5} align="center">Delete</TableCell>
                        </TableRow>
                    </TableHead>
                    {examPlannerList.length > 0 ?
                    <TableBody>
                        {examPlannerList.map((examPlanner, index) => (
                            <TableRow key={examPlanner.userId}>
                                <TableCell className={classes.cellStyle5} align="left" component="th" scope="row">
                                    {(page * limit) + index + 1}
                                </TableCell>
                                <TableCell className={classes.cellStyle20} align="left">{examPlanner.firstName}</TableCell>
                                <TableCell className={classes.cellStyle20} align="left">{examPlanner.lastName}</TableCell>
                                <TableCell className={classes.cellStyle30} align="left">{examPlanner.email}</TableCell>
                                <TableCell className={classes.cellStyle15} align="left">{(examPlanner.role)==1?"Admin":((examPlanner.role)==2?"Exam Planner":"Support")}</TableCell>
                                <TableCell className={classes.cellStyle5} align="center"> <EditSharpIcon className={classes.cursorPinter} fontSize="small" onClick={()=> editExamPlanner(examPlanner)} /></TableCell>
                                <TableCell className={classes.cellStyle5} align="center"> <DeleteSharpIcon className={classes.cursorPinter} style={{ color: red[500] }} fontSize="small"  onClick={() => handleClickOpeDelete(examPlanner)}/></TableCell>
                            </TableRow>
                        ))}

                    </TableBody>:''}
                </Table>
                {(examPlannerList.length ==0 && search != "") ? 
                <div style={{'textAlign':"center"}}>Search result not found</div>
                :(examPlannerList.length ==0) ? 
                <div style={{'textAlign':"center"}}>No result found</div>
                :''}
            </TableContainer>
            <TablePagination
            rowsPerPageOptions={[0]}
            component="div"
            count={count}
            rowsPerPage={limit}
            page={page}
            onChangePage={handleChangePage}
            onChangeRowsPerPage={handleChangeLimit}
            />
            <UserAdd open={openUserAdd} onClose={handleCloseUserAdd}  />
            <UserEdit open={openUserEdit} onClose={handleCloseUserEdit}   onPasswordChangeBegin={handleCloseUserEditPassword} planner={examPlanner}  />
            <UserPasswordChange open={openUserPasswordChange} onClose={handleCloseUserPasswordChange} planner={examPlanner}/>
            <DeleteConfirm open={deleteOpen} onClose={handleDelete} apiLink={'users'} deleteId={examPlanner.userId} deleteText={'Are you sure you want to delete this user?'} deleteMsg={'User deleted successfully.'}/>
        </div>
    )
}

