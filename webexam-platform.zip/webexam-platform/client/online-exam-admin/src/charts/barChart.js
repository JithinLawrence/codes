import * as React from 'react';
import Paper from '@material-ui/core/Paper';
import {
    Chart,
    BarSeries,
    Title,
    ArgumentAxis,
    ValueAxis,
} from '@devexpress/dx-react-chart-material-ui';

import { Animation } from '@devexpress/dx-react-chart';



export default function BarChart(props) {

    return (
        <Paper>
            {props.title}
            <Chart
                data={props.data}
                width={props.width}
                height={props.height}
            >
                <ArgumentAxis />
                <ValueAxis max={7} />
                <BarSeries 
                    valueField={props.valueField} argumentField={props.argumentField} 
                
                />
                <Title text={props.Title} />
                <Animation />
            </Chart>
        </Paper>
    );
}

