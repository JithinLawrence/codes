import * as React from "react";
import Paper from "@material-ui/core/Paper";
import {
    Chart,
    PieSeries,
    Title,
    Legend
} from "@devexpress/dx-react-chart-material-ui";

import { Animation } from "@devexpress/dx-react-chart";
import { withStyles } from "@material-ui/core/styles";


const legendStyles = {
    root: {
        display: "flex",
        margin: "auto",
        flexDirection: "row"
    }
};
const legendLabelStyles = theme => ({
    label: {
        paddingTop: theme.spacing(1)
    }
});
const legendItemStyles = {
    item: {
        flexDirection: "column"
    }
};

const LegendRootBase = ({ classes, ...restProps }) => (
    <Legend.Root {...restProps} className={classes.root} />
);
const LegendLabelBase = ({ classes, ...restProps }) => (
    <Legend.Label {...restProps} className={classes.label} />
);
const LegendItemBase = ({ classes, ...restProps }) => (
    <Legend.Item {...restProps} className={classes.item} />
);

const LegendRoot = withStyles(legendStyles, { name: "LegendRoot" })(
    LegendRootBase
);
const LegendLabel = withStyles(legendLabelStyles, { name: "LegendLabel" })(
    LegendLabelBase
);
const LegendItem = withStyles(legendItemStyles, { name: "LegendItem" })(
    LegendItemBase
);


export default function PieChart(props) {

    return (        
        <Paper>           
            {props.title}
            <Chart data={props.data}>
                <PieSeries valueField={props.valueField} argumentField={props.argumentField} />
                <Title text="" />
                <Animation />
                <Legend
                    position="bottom"
                    rootComponent={LegendRoot}
                    itemComponent={LegendItem}
                    labelComponent={LegendLabel}
                />
            </Chart>
        </Paper>
    );
}

