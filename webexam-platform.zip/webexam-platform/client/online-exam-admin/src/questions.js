import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import EditSharpIcon from '@material-ui/icons/EditSharp';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red, blue } from '@material-ui/core/colors';
import { Link, useParams } from "react-router-dom";
import useAppContext from './AppContext';
import { TextField } from '@material-ui/core';
import SingleAnswer from './sampleQuestions/singleAnswerType';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import PageviewRoundedIcon from '@material-ui/icons/PageviewRounded';
import { useAlert } from "react-alert";
import TablePagination from '@material-ui/core/TablePagination';
import ShareSharpIcon from '@material-ui/icons/ShareSharp';
import QuestionShare from './questionShare';
import DeleteConfirm from './deleteConfirm';
import SwapVertSharpIcon from '@material-ui/icons/SwapVertSharp';
import PreviewQuestion from './preview/previewQuestion';


const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    dialog: {
        padding: theme.spacing(1),
    },
    dialogTitle: {
        backgroundColor: theme.palette.grey[300],
    }, 
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    cursorPinter:{
        cursor: 'pointer'
    },
    headerStyle5: {
        width: '5%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    headerStyle40: {
        width: '40%',
        maxWidth: '1px'
    },
    headerStyle50: {
        width: '50%',
        maxWidth: '1px'
    },
    cellStyle5: {
        width: '5%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle40: {
        width: '40%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle40: {
        width: '40%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    }
});

function createData(title, catogory, grade, difficulty, marks) {
    return { title, catogory, grade, difficulty, marks };
}

const rows = [
    createData('What is Frozen yoghurt', 'Maths', 1, 'Hard', 24),
    createData('What is Ice cream sandwich', 'Science', 2, 'Easy', 37),
    createData('What is Eclair', 'English', 1, 'Medium', 24),
    createData('What is Cupcake', 'Maths', 4, 'Easy', 67),
    createData('What is Gingerbread', 'Science', 2, 'Hard', 49),
];

export default function Questions() {
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);

    const {questionBankId} = useParams();

    const handleClose = hasChange => {
        setOpen(false);
    };
    const handlePreview = (row) => {
        setPreviewRow(row)
        setOpen(true);
    };  
    const alert = useAlert();

    const QUESTION_BANK_LIST_API = 'question/list';
    const CATEGORY_LIST_API = 'common/category';
    const GROUP_LIST_API = 'common/group';
    const LEVEL_LIST_API = 'common/level';
    const appContext = useAppContext();

    const [createOpen, setCreateOpen] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [categoryData, setCategoryData] = React.useState([]);
    const [groupData, setGroupData] = React.useState([]);
    const [levelData, setLevelData] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('question_id');
    const [sortType, setSortType] = React.useState(true);
    const [forceChange, setForceChange] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [categoryId, setCategoryId] = React.useState(0);
    const [groupId, setGroupId] = React.useState(0);
    const [levelId, setLevelId] = React.useState(0);
    const [editOpen, setEditOpen] = React.useState(false);
    const [deleteOpen, setDeleteOpen] = React.useState(false);
    const [rowData, setRowData] = React.useState([]);
    const [shareOpen, setShareOpen] = React.useState(false);
    const [previewRow, setPreviewRow] = React.useState([]);
    
    const handleSearchChange = event => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleClickOpenShare = (editingRow) => {
        setRowData(editingRow)
        setShareOpen(true);
    };   

    const handleShare = hasChange => {
        if(hasChange){
            listQuestion()
        }
        setShareOpen(false);
    };

    const handleCloseCreate = hasChange => {
        if(hasChange){
            setSort('question_id');
            setSortType(true);
            setPage(0);
            // setLimit(5);
            // setSortPage(1);
            setForceChange(!forceChange)//after saving count not incremented properly. so changing this value reloads the method listQuestionBank
            // listQuestionBank()
        }
        setCreateOpen(false);
    };
    const handleClickOpenCreate = () => {
        setCreateOpen(true);
    };

    const handleCloseEdit = hasChange => {
        if(hasChange){
            listQuestion()
        }
        setEditOpen(false);
    };

    const handleDelete = hasChange => {
        if(hasChange){
            listQuestion()
        }
        setDeleteOpen(false);
    };
    const handleClickOpenEdit = (editingRow) => {
        setRowData(editingRow)
        setEditOpen(true);
    };    
    const handleClickOpenDelete = (deletingRow) => {
        setRowData(deletingRow)
        setDeleteOpen(true);
    };  

    const handleSort = val => {
        if(sort == val){
            setSortType(!sortType)
        } else {
            setSortType(sort == val)
        }
        setSort(val);
    };

    const handleGroupChange = (event) => {
        setGroupId(event.target.value);
    };

    const handleCategoryChange = (event) => {
        setCategoryId(event.target.value);
    };

    const handleLevelChange = (event) => {
        setLevelId(event.target.value);
    };

    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
  
    const handleChangeLimit = event => {
      setLimit(parseInt(event.target.value, 10));
      setPage(0);
    };

    React.useEffect(() => {
        listQuestion();
      }, [sort, sortType, page, limit, forceChange, search, categoryId, groupId, levelId]); 

    React.useEffect(() => { listCategory(); }, []); 
    React.useEffect(() => { listGroup(); }, []); 
    React.useEffect(() => { listLevel(); }, []); 

    function listQuestion() {
        let qId=0;
        let apiUrl = `${QUESTION_BANK_LIST_API}?categoryId=${categoryId}&groupId=${groupId}&levelId=${levelId}&page=${page+1}&limit=${limit}&search=${encodeURIComponent(search)}&type=${sortType}&sort=${sort}`;
        if(questionBankId){
            apiUrl += `&questionBankId=${questionBankId}`; 
        }else{
            apiUrl += `&questionBankId=${qId}`; 
        }
        appContext.getAxios().get(apiUrl).then((response) => {
            console.log(response.data.result);
            setData(response.data.result);
            setPage(response.data.currentPage-1)
            setCount(response.data.pagerInfo.count);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function listCategory() {
        appContext.getAxios().get(CATEGORY_LIST_API).then((response) => {
            setCategoryData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function listGroup() {
        appContext.getAxios().get(GROUP_LIST_API).then((response) => {
            setGroupData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function listLevel() {
        appContext.getAxios().get(LEVEL_LIST_API).then((response) => {
            setLevelData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    return (
        <div>
            <h1>Question List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

                <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                    <Link style={{ textDecoration: 'none', color: "black" }} to="/questioncreate" className={classes.btnprimary} >
                        <Button
                            variant="contained"
                            color="secondary"
                            justify="right"
                        >
                            Add Question
                        </Button>
                    </Link>
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                            label="Search"
                            id="titleSearch"
                            value={search} 
                            onChange={handleSearchChange} 
                        ></TextField>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-grade-label">Group</InputLabel>
                        <Select
                            labelId="select-grade-label"
                            id="select-grade"
                            value={groupId} 
                            onChange={handleGroupChange}
                        >
                        <MenuItem value="0">All</MenuItem>
                        {groupData.map((row) => (
                            <MenuItem key={row.gradeId} value={row.gradeId}>{row.name}</MenuItem>
                        ))}
                        </Select>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-catagory-label">Category</InputLabel>
                        <Select
                            labelId="select-catagory-label"
                            id="select-catagory"
                            value={categoryId} 
                            onChange={handleCategoryChange}
                        >
                        <MenuItem value="0">All</MenuItem>
                        {categoryData.map((row) => (
                            <MenuItem key={row.categoryId} value={row.categoryId}>{row.name}</MenuItem>
                        ))}
                        </Select>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-difficulty-label">Difficulty</InputLabel>
                        <Select
                            labelId="select-difficulty-label"
                            id="select-difficulty"
                            value={levelId} 
                            onChange={handleLevelChange}
                        >
                        <MenuItem value="0">All</MenuItem>
                        {levelData.map((row) => (
                            <MenuItem key={row.questionLevelId} value={row.questionLevelId}>{row.name}</MenuItem>
                        ))}
                        </Select>
                    </FormControl>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell className={classes.headerStyle5} align="left">No</TableCell>
                            <TableCell align="left" className={(1 == localStorage.getItem("role")) ? classes.headerStyle40 : classes.headerStyle50}>
                                Title&nbsp;
                                <SwapVertSharpIcon fontSize="small" style={{'marginBottom':'-5px'}} className={classes.cursorPinter} onClick={() => {handleSort('title');}}/>
                            </TableCell>
                            <TableCell className={classes.headerStyle10} align="left">Category</TableCell>
                            <TableCell className={classes.headerStyle10} align="left">Difficulty</TableCell>
                            <TableCell align="left" className={classes.headerStyle5} onClick={() => {handleSort('mark');}}>Marks</TableCell>
                            {(1 == localStorage.getItem("role")) && <TableCell align="left" style={{ whiteSpace : "nowrap" }}>Created By</TableCell>}
                            <TableCell className={classes.headerStyle10} align="center">Preview</TableCell>
                            <TableCell className={classes.headerStyle10} align="center">Action</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {data.map((row, index) => (
                            <TableRow key={row.questionId}>
                                <TableCell className={classes.cellStyle5} align="left">{(page * limit) + index + 1}</TableCell>
                                <TableCell align="left" className={(1 == localStorage.getItem("role")) ? classes.cellStyle40 : classes.cellStyle50} component="th" scope="row">
                                    {row.title}
                                </TableCell>
                                <TableCell className={classes.cellStyle10} align="left">{row.category}</TableCell>
                                <TableCell className={classes.cellStyle10} align="left">{row.level}</TableCell>
                                <TableCell className={classes.cellStyle5} align="left">{row.mark}</TableCell>
                                {(1 == localStorage.getItem("role")) && <TableCell className={classes.cellStyle10} align="left">{row.createdUser}</TableCell>}
                                <TableCell className={classes.cellStyle10} align="center">
                                    <PageviewRoundedIcon className={classes.cursorPinter} onClick={() => handlePreview(row)} fontSize="small" />
                                </TableCell>
                                <TableCell className={classes.cellStyle10} align="center" style={{ whiteSpace : "nowrap" }}>
                                    {(row.createdBy == localStorage.getItem("userId") || 1 == localStorage.getItem("role")) && <Link style={{ textDecoration: 'none', color: "black" }} to={"/questionedit/"+row.questionId}>
                                        <EditSharpIcon fontSize="small" /></Link>}&nbsp;&nbsp;&nbsp;
                                    {(row.createdBy == localStorage.getItem("userId") || 1 == localStorage.getItem("role")) && 
                                    <DeleteSharpIcon className={classes.cursorPinter}  style={{ color: red[500] }} fontSize="small"  onClick={() => handleClickOpenDelete(row)} />}&nbsp;&nbsp;&nbsp;
                                    {(localStorage.getItem("role") ==4 && row.createdBy == localStorage.getItem("userId")) && 
                                    <ShareSharpIcon className={classes.cursorPinter} style={{ color: blue[600] }} fontSize="small" onClick={() => handleClickOpenShare(row)}/>}
                                </TableCell>

                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {(data.length ==0 && search != "") ? 
                <div style={{'textAlign':"center"}}>Search result not found</div>
                :(data.length ==0) ? 
                <div style={{'textAlign':"center"}}>No result found</div>
                :''}
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[0]}
                component="div"
                count={count}
                rowsPerPage={limit}
                page={page}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeLimit}
            />
            {/* < QuestionPreview isOpen={open} onClose={handleClose} /> */}
            < PreviewQuestion isOpen={open} onClose={handleClose} row={previewRow} save={{isList: true, title: "", ckd: "", img: "", answer: "", options: []}}/>
            <QuestionShare open={shareOpen} onClose={handleShare} questionId={rowData.questionId} title={rowData.title} editText={'Would you like to share your questionnaire to another user?'}/>
            <DeleteConfirm open={deleteOpen} onClose={handleDelete} apiLink={'question'} deleteId={rowData.questionId} deleteText={'Are you sure you want to delete this question ?'} deleteMsg={'Question deleted successfully.'}/>
        </div>
    );
}

function QuestionPreview({ isOpen, onClose }) {
    const classes = useStyles();
    const [qno, setQno] = React.useState(1);
    const [btntext, setBtntext] = React.useState("next");
    const handleNext = () => {
        setQno(qno + 1);
    };
    const handlePrev = () => {
        setQno(qno - 1);
    };
    return (
        <Dialog className={classes.dialog} fullWidth maxWidth="sm" open={isOpen} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" className={classes.dialogTitle} disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Preview</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
            </DialogTitle>
            <DialogContent>
                <SingleAnswer />
            </DialogContent>
        </Dialog>
    )
}