import React, { useState, useEffect } from 'react';
import { Container } from '@material-ui/core';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import CKEditor from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import SingleAnswer from './questionType/singleAnswerType';
import SingleAnswerImage from './questionType/singleAnswerImageType';
import MultipleAnswer from './questionType/multipleAnswerType';
import MultipleAnswerImage from './questionType/multipleAnswerImageType';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";
import Input from '@material-ui/core/Input';
import InputBase from '@material-ui/core/InputBase';
import { useHistory } from "react-router-dom";
import ModalImage from "react-modal-image";
import { CircularProgress } from '@material-ui/core';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import { Link, useParams } from 'react-router-dom';
import Config from "./Config";
import PageviewRoundedIcon from '@material-ui/icons/PageviewRounded';
import PreviewQuestion from './preview/previewQuestion';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';

// NOTE: Use the editor from source (not a build)!

const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(1),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        marginTop: "10px",

    },
    cancel: {
        marginTop: "10px",
        // backgroundColor: theme.palette.error.main

    },
    imageMargin: {
        marginTop: "2px",
        // backgroundColor: theme.palette.error.main

    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
    imageUpload: {
        padding: '5px',
        color: 'white',
        backgroundColor: theme.palette.primary.main,
        // width:'100% !important'
    },
    GridButton: {
        textAlign: "center",
        marginRight: "20px",
    },
    GridButtonLeft: {
        textAlign: "left",
        marginRight: "20px",
    },
    browse: {
        margin: theme.spacing(3)
    },
    cancelButton: {
        margin: theme.spacing(3),
    },
    previewButton: {
        margin: theme.spacing(3),
    },
    cursorPinter:{
        cursor: 'pointer'
    },

}));

function getStyles(name, personName, theme) {
    return {
    fontWeight:
        personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
    };
}


function QuestionTypeSelected({questionType, handleAnswer}) {
    if (questionType == 1) {
        return (
            <SingleAnswer answerActive={questionType} toAnswer={[]} fromAnswer={handleAnswer} updated={false}></SingleAnswer>
        );
    } else if (questionType == 2) {
        return (
            <MultipleAnswer answerActive={questionType} toAnswer={[]} fromAnswer={handleAnswer} updated={false}></MultipleAnswer>
        );
    } else if (questionType == 3) {
        return (
            <SingleAnswerImage answerActive={questionType} toAnswer={[]} fromAnswer={handleAnswer} updated={false}></SingleAnswerImage>
        );
    } else if (questionType == 4) {
        return (
            <MultipleAnswerImage answerActive={questionType} toAnswer={[]} fromAnswer={handleAnswer} updated={false}></MultipleAnswerImage>
        );
    } else {
        return ("");
    }
}
function CircularProgressWithLabel(props) {
    return (
      <Box position="relative" display="inline-flex">
        <CircularProgress variant="static" {...props} />
        <Box
          top={0}
          left={0}
          bottom={0}
          right={0}
          position="absolute"
          display="flex"
          alignItems="center"
          justifyContent="center"
        >
          <Typography variant="caption" component="div" color="textSecondary">{`${Math.round(
            props.value,
          )}%`}</Typography>
        </Box>
      </Box>
    );
  }
  
  CircularProgressWithLabel.propTypes = {
    /**
     * The value of the progress indicator for the determinate and static variants.
     * Value between 0 and 100.
     */
    value: PropTypes.number.isRequired,
  };

export default function QuestionCreate() {
    const classes = useStyles();
    const alert = useAlert();
    const theme = useTheme();
    const appContext = useAppContext();
    
    const QUESTION_API = 'question';
    const LIST_QUESTION_BANK_API = 'question_bank/list_question_bank';
    const CATEGORY_LIST_API = 'common/category';
    const GROUP_LIST_API = 'common/group';
    const LEVEL_LIST_API = 'common/level';
    const TYPE_LIST_API = 'common/type';
    const IMAGE_UPLOAD_API = "question/imageupload"
    // const [uploadImageOpen, setUploadImageOpen] = React.useState(false);
    
    const [disabled, setDisabled] = React.useState(false);
    const [img, setImg] = React.useState("");
    // const [url, setUrl] = React.useState("");
    const [ckd, setCkd] = useState("");
    const [ckdError, setCkdError] = React.useState(null);
    const [questionType, setQuestionType] = useState('');
    const [activeQuestionType, setactiveQuestionType] = useState(0);
    const [categoryId, setCategoryId] = React.useState('');
    const [levelId, setLevelId] = React.useState('');
    const [groupId, setGroupId] = React.useState([]);
    const [groupName, setGroupName] = React.useState([]);
    const [questionBankId, setQuestionBankId] = React.useState([]);
    const [questionBankName, setQuestionBankName] = React.useState([]);
    const [imageUrl, setImageUrl] = React.useState("")
    const [imagePath, setImagePath] = React.useState("")
    const [categoryIdError, setCategoryIdError] = React.useState(null);
    const [title, setTitle] = React.useState('');
    const [mark, setMark] = React.useState(0);
    const [correctAnswer, setCorrectAnswer] = React.useState('');
    const [markError, setMarkError] = React.useState(null);
    const [groupIdError, setGroupIdError] = React.useState(null);
    const [questionTypeError, setQuestionTypeError] = React.useState(null);
    const [levelIdError, setLevelIdError] = React.useState(null);
    // const [questionBankIdError, setQuestionBankIdError] = React.useState(null);
    const [titleError, setTitleError] = React.useState(null);
    const [categoryData, setCategoryData] = React.useState([]);
    const [levelData, setLevelData] = React.useState([]);
    const [questionTypeData, setQuestionTypeData] = React.useState([]);
    const [questionBankData, setQuestionBankData] = React.useState([]);
    const [groupData, setGroupData] = React.useState([]);
    const [options, setOptions] = React.useState([]);
    const [showAnswerBox, setShowAnswerBox] = React.useState("none");
    const [progress, setProgress] = React.useState(100);
    const [open, setOpen] = React.useState(false);
    const [previewRow, setPreviewRow] = React.useState([]);
    
    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
      PaperProps: {
        style: {
          maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
          width: 250,
        },
      },
    };
    
    const handleAnswer = (ops) => {
        console.log(ops)
        setOptions(ops);
    }

    const handleClose = hasChange => {
        setOpen(false);
    };
    const handlePreview = (row) => {
        setPreviewRow(row)
        setOpen(true);
    }; 



    // const handleCloseCreate = hasChange => {
    //     if(hasChange){
    //         // setSort('question_bank_id');
    //         // setSortType(true);
    //         // setPage(0);
    //         // // setLimit(5);
    //         // // setSortPage(1);
    //         // setForceChange(!forceChange)//after saving count not incremented properly. so changing this value reloads the method listQuestionBank
    //         // // listQuestionBank()
    //     }
    //     setUploadImageOpen(false);
    // };
    // const handleClickUploadImage = () => {
    //     setUploadImageOpen(true);
    // };

    const handleCategoryChange = (event) => {
        const val = event.target.value;
        console.log('---1');
        console.log(categoryId);
        setCategoryId(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Category is required" : null;
        setCategoryIdError(errorMsg)
    };

    const selectQuestionType = (event) => {
        // setQuestionType(event.target.value);
        console.log('---2');
        console.log(event);
        const val = event.target.value;
        if(val==5){
            setShowAnswerBox("");
        } else{
            setShowAnswerBox("none");
        }
        setQuestionType(val);
        setactiveQuestionType(val)
        let errorMsg = null;
        errorMsg = val === '' ? "Question type is required" : null;
        setQuestionTypeError(errorMsg)
    }

    const handleLevelChange = event => {
        const val = event.target.value;
        setLevelId(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Level is required" : null;
        setLevelIdError(errorMsg)
    };

    const handleGroupChange = (event) => {
        setGroupName(event.target.value);
    };

    const handleGroupChoose = (g_id) => {
        const newIds = groupId?.includes(g_id)
          ? groupId?.filter(id => id !== g_id)
          : [...(groupId ?? []), g_id];
          setGroupId(newIds);
          let errorMsg = null;
          errorMsg = groupId === [] ? "Group is required" : null;
          console.log(errorMsg)
          setGroupIdError(errorMsg)
    };

    const handleQuestionBankChange = (event) => {
        setQuestionBankName(event.target.value);
    };

    const handleQuestionBankChoose = (q_id) => {
        const newIds = questionBankId?.includes(q_id)
          ? questionBankId?.filter(id => id !== q_id)
          : [...(questionBankId ?? []), q_id];
          setQuestionBankId(newIds);
        //   let errorMsg = null;
        //   errorMsg = questionBankId === [] ? "Question bank is required" : null;
        //   console.log(errorMsg)
        //   setQuestionBankIdError(errorMsg)
    };

    const handleQuestionImageChange = event => {
        setImg(imageUrl)
        if(event.target.files.length>0){
            setProgress(0)
            setDisabled(true)
            setProgress(1)
            var formData = new FormData();
            let isInvalid = false;
            for (let i = 0 ; i < event.target.files.length ; i++) {
                const fileName = event.target.files[i].name || "";
                const fileSize = event.target.files[i].size || 0;
                if (
                    (fileName.endsWith(".png")) || 
                    (fileName.endsWith(".PNG")) || 
                    (fileName.endsWith(".jpeg")) || 
                    (fileName.endsWith(".JPEG")) || 
                    (fileName.endsWith(".jpg")) || 
                    (fileName.endsWith(".JPG")) || 
                    (fileName.endsWith(".gif")) ||
                    (fileName.endsWith(".GIF"))
                    ) {
                        if (fileSize > Config.imageMaxFileSize) {
                            alert.error("File size exceeded. Upload image smaller than 10 Mb");
                            isInvalid = true;
                        }
                        formData.append("file", event.target.files[i]);
                } else {
                    alert.error("Invalid file");
                    isInvalid = true;
                }
            }
            if(isInvalid){
                setProgress(100)
                setDisabled(false);
                event.target.value = "";
                return;
            }
            setProgress(10)
            appContext.getAxios().post(IMAGE_UPLOAD_API, formData).then((response) => {
                setProgress(99)
                setImageUrl(response.data.path[0])
                setImg(response.data.path[0])
                setDisabled(false);
                setProgress(100)
            }).catch(error => {
                if(error.response){
                    alert.error(error.response.data.message);
                } else {
                    alert.error("Upload error");
                }
                setDisabled(false);
                setProgress(100)
            });
        }
    };

    const handleTitleChange = event => {
        const val = event.target.value;
        setTitle(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Question title is required" : null;
        errorMsg = errorMsg == null ? (val.length > 4000 ? "Question title length must not exceed 4000 characters" : null) : errorMsg;
        setTitleError(errorMsg)
    };
    const handleMarkChange = event => {
        const val = event.target.value;
        let errorMsg = null;
        console.log(val)
        if (/^\d+$/.test(val) || val === '') {
            console.log("here1")
            setMark(val);
            errorMsg = (val != "" && val < 1) ? "Mark must be greater than 0" : null;
        } else {
            event.target.value = 0;
            setMark(0);
            errorMsg = "Mark must be greater than 0";
        }
        errorMsg = errorMsg == null ? (val > 1000 ? "Mark must not exceed 1000" : null) : errorMsg;
        errorMsg = errorMsg == null ? (val === '' ? "Mark is required" : null) : errorMsg;
        setMarkError(errorMsg)
    };

    const handleCorrectAnswerChange = event => {
        const val = event.target.value;
        setCorrectAnswer(val);
    };
    const handleImageDelete = event => {
        setImg("")
        setImageUrl("")
    };
    let history = useHistory();
    const handleSubmit = event => {
        event.preventDefault();
        const trueOptions = options.filter(function(o) { return o.isAnswer == true; });

        if(categoryIdError != null || groupIdError != null || questionTypeError != null || 
            levelIdError != null || titleError != null || markError != null){
            return;
        }
        if(questionType != 5 && questionType != 6){
            if(options.length <= 1){
                alert.error("Atleast 2 options needed");
                return;
            } else if(trueOptions.length <= 0){
                alert.error("Select atleast 1 correct option");
                return;
            } else if(trueOptions.length > 1){
                console.log(trueOptions)
                console.log(options)
                if(questionType == 1 || questionType == 3){
                    alert.error("More than 1 option not allowed");
                    return;
                } else if (trueOptions.length == options.length && (questionType == 2 || questionType == 4)){
                    alert.error("All options cannot be selected as answers");
                    return;
                }
            } else if(questionType != 3 && questionType != 4){
                const blankOptions = options.filter(function(o) { return o.value.trim() == ""; });
                if(blankOptions.length > 0){
                    alert.error("Blank option not allowed");
                    return;
                }
            } else if(questionType == 3 || questionType == 4){
                const blankSrc = options.filter(function(o) { return o.src.trim() == ""; });
                if(blankSrc.length > 0){
                    alert.error("Upload image for all options");
                    return;
                }
            }
        }

        setDisabled(true)//description, passMark, totalMark
        createQuestion(categoryId, groupId, questionType, levelId, questionBankId, imageUrl, title, ckd, mark, correctAnswer, options).then((result) => {
            setDisabled(false)
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                // resetInputs();
                alert.success("Question created successfully");
                history.push('/questions')
            }
        });
    };

    function createQuestion(categoryId, groupId, questionType, levelId, questionBankId, imageUrl, title, ckd, mark, correctAnswer, options) {
        // categories.map((row) => {
        //     console.log(row);
        // });
        const questionTypeName = questionTypeData.filter(function(o) { return o.questionTypeId == questionType; });
        const optionDetails = {
            questionTypeId: questionType,
            questionTypeName: questionTypeName[0].name,
            options: (questionType == 5 || questionType == 6) ? [] : options
        };
        console.log(optionDetails);
        let data = JSON.stringify({
            categoryId: categoryId,
            groupIds: groupId,
            questionTypeId: questionType,
            questionLevelId: levelId,
            questionBankIds: questionBankId,
            imageUrl: imageUrl,
            title: title,
            description: ckd,
            mark: mark,
            answer: correctAnswer,
            price: 0,
            publishMarket: 0,
            options: JSON.stringify(optionDetails)
            
        });
        return appContext.getAxios().post(QUESTION_API, data).then((response) => {            
            return {status: true, info: response};
        }, (error) => {
            return {status: false, info: error};
        });
    }

    useEffect(() => {
        document
            .querySelector("input[type='number']")
            .addEventListener("keypress", evt => {
                if (evt.which === 8) {
                    return;
                }
                if (evt.which < 48 || evt.which > 57) {
                    evt.preventDefault();
                }
            });
    }, []);
    React.useEffect(() => { console.log('listCategory'); listCategory(); }, []); 
    React.useEffect(() => { listGroup(); }, []); 
    React.useEffect(() => { listLevel(); }, []); 
    React.useEffect(() => { listQuestionType(); }, []); 
    React.useEffect(() => { listQuestionBank(); }, []); 

    function listCategory() {
        appContext.getAxios().get(CATEGORY_LIST_API).then((response) => {
            setCategoryData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function listGroup() {
        appContext.getAxios().get(GROUP_LIST_API).then((response) => {
            setGroupData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function listLevel() {
        appContext.getAxios().get(LEVEL_LIST_API).then((response) => {
            setLevelData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function listQuestionType() {
        appContext.getAxios().get(TYPE_LIST_API).then((response) => {
            setQuestionTypeData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function listQuestionBank() {
        appContext.getAxios().get(LIST_QUESTION_BANK_API).then((response) => {
            setQuestionBankData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    return (
        <div>
            <h1>Create Question</h1>
            <div className={classes.paper}>
                <form className={classes.form} onSubmit={handleSubmit}>
                    <Grid container className={classes.root} spacing={2} >
                        <Grid item xs={6} >
                            <label>Catgeory *</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-category-select-label" >Category</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-category-select-label"
                                    id="question-category-select"
                                    label="Category"
                                    required
                                    disabled={disabled} 
                                    value={categoryId} 
                                    onChange={handleCategoryChange} 
                                    error={categoryIdError !== null} 
                                    // helperText={examTypeError}
                                >
                                    {categoryData.map((row) => (
                                        <MenuItem 
                                            key={row.categoryId}
                                            value={row.categoryId}>
                                            {row.name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={6}>
                            <label>Group *</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-group-label" >Group</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-group-label"
                                    id="question-group"
                                    label="Group"
                                    multiple
                                    required
                                    value={groupName} 
                                    onChange={handleGroupChange}
                                    // input={<Input />}
                                    MenuProps={MenuProps}
                                    error={groupIdError !== null} 
                                >
                                {groupData.map((row) => (
                                    <MenuItem 
                                        key={row.gradeId}  
                                        onClick={(e)=>handleGroupChoose(row.gradeId)} 
                                        value={row.name}
                                        style={getStyles(row.name, groupName, theme)}
                                        >
                                        {row.name}
                                    </MenuItem>
                                ))}
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                    <Grid container className={classes.root} spacing={2}>
                        <Grid item xs={6} >
                            <label>Question Type *</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-type-select-label" >Question Type</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-type-select-label"
                                    id="question-type-select"
                                    label="Question Type"
                                    required
                                    disabled={disabled} 
                                    value={questionType} 
                                    onChange={selectQuestionType} 
                                    error={questionTypeError !== null}
                                >
                                    {questionTypeData.map((row) => (
                                        <MenuItem 
                                            key={row.questionTypeId}
                                            value={row.questionTypeId}>
                                            {row.name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={6}>
                            <label>Difficulty Level *</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-creation-level-label" >Difficulty Level</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-difficulty-level-label"
                                    id="question-difficulty-level"
                                    label="DifficultyLevel"
                                    required
                                    disabled={disabled} 
                                    value={levelId} 
                                    onChange={handleLevelChange} 
                                    error={levelIdError !== null}
                                >
                                    {levelData.map((row) => (
                                        <MenuItem 
                                            key={row.questionLevelId}
                                            value={row.questionLevelId}>
                                            {row.name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>

                    <br></br>
                    <Grid container className={classes.root} spacing={2}>
                        <Grid item xs={6} >
                            <label>Question Bank</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                                <InputLabel id="question-creation-QB-label" >Question Bank</InputLabel>
                                <Select
                                    variant="outlined"
                                    labelId="question-creation-QB-label"
                                    id="question-creation-QB"
                                    label="Question Bank"
                                    multiple
                                    value={questionBankName} 
                                    onChange={handleQuestionBankChange}
                                    // input={<Input />}
                                    MenuProps={MenuProps}
                                    // error={questionBankIdError !== null} 
                                >
                                {questionBankData.map((row) => (
                                    <MenuItem 
                                        key={row.questionBankId}  
                                        onClick={(e)=>handleQuestionBankChoose(row.questionBankId)} 
                                        value={row.name}
                                        style={getStyles(row.name, questionBankName, theme)}
                                        >
                                        {row.name}
                                    </MenuItem>
                                ))}
                                </Select>
                            </FormControl>

                        </Grid>
                        </Grid>
                    <br></br>
                    <label>Question Title *</label>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="questionTitle"
                        // label="Question Title"
                        placeholder="Question Title"
                        name="title"
                        autoComplete="title"
                        disabled={disabled} 
                        value={title} 
                        onChange={handleTitleChange} 
                        error={titleError !== null} 
                        helperText={titleError}
                    />
                    <br></br>
                    <br></br>
                    <div>
                        <label>Description</label>
                        <br></br>
                        <br></br>
                        <CKEditor
                            editor={ClassicEditor}
                            data=""
                            onInit={editor => {
                                // You can store the "editor" and use when it is needed.  
                                console.log('Editor is ready to use!', editor);
                            }}
                            onChange={(event, editor) => {
                                const data = editor.getData();
                                setCkd(data);
                                console.log({ event, editor, data });
                            }}
                            onBlur={(event, editor) => {
                                console.log('Blur.', editor);
                            }}
                            onFocus={(event, editor) => {
                                console.log('Focus.', editor);
                            }}
                        />
                    </div>
                    <br></br>
                    <Grid item xs={6} >
                        <label>Description Image</label>
                            <FormControl variant="outlined" fullWidth margin="normal" >
                            {/* <Grid item className={classes.GridButtonLeft}>
                                <Button
                                    variant="contained"
                                    color="secondary"
                                    onClick={handleClickUploadImage}
                                    className={classes.submit}
                                >
                                    Upload Images
                                </Button>
                                &nbsp;&nbsp;
                                <label></label>
                            </Grid> */}
                            <input
                                accept="image/*"
                                className={classes.imageUpload}
                                // style={{ backgroundColor: 'rgb(85, 108, 214)', padding: "10px", color: 'white' }}
                                id="rais-button-file"
                                // multiple
                                // value={imagePath}
                                // required={questionType == 6 && imageUrl == ""}
                                type="file"
                                onChange={handleQuestionImageChange}
                            />
                            <Grid container spacing={2} style={{display: (progress<100) ? 'block' : 'none' }}>
                                <Grid item xs={2} style={{display: (progress<100) ? 'block' : 'none' }}>
                                    {/* <CircularProgressWithLabel value={progress} size={30}/> */}
                                    <CircularProgress color="secondary" size={30}/>
                                </Grid>
                            </Grid>
                            <Grid container className={classes.imageMargin} spacing={2}>
                                <Grid item xs={2} style={{display: (img!="") ? 'block' : 'none' }}>
                                    <label>View image</label>
                                </Grid>
                                <Grid item xs={1} style={{display: (img!="") ? 'block' : 'none' }}>
                                    <ModalImage
                                    small={img}
                                    large={img}
                                    hideDownload={true}
                                    // hideZoom={true}
                                    />
                                </Grid>
                                <Grid item xs={1} style={{display: (img!="") ? 'block' : 'none' }}>
                                    <DeleteSharpIcon className={classes.cursorPinter}  style={{ color: red[500] }} fontSize="small"  onClick={() => handleImageDelete()} />
                                </Grid>
                            </Grid>
                            </FormControl>
                        </Grid>
                    <br></br>
                    <br></br>
                    <label>Marks *</label>
                    <br></br>
                    <TextField
                        id="question-marks"
                        type="number"
                        disabled={disabled} 
                        value={mark} 
                        required
                        onChange={handleMarkChange} 
                        error={markError !== null} 
                        helperText={markError}
                        InputLabelProps={{
                            shrink: true
                        }}
                    />
                    <br></br>
                    <br></br>
                    <br></br>

                    <div className="questionTypeSelected">
                        <Grid>
                            <QuestionTypeSelected questionType={questionType} handleAnswer={handleAnswer}></QuestionTypeSelected>
                        </Grid>
                    </div>

                    <Box display={showAnswerBox} >
                        <label>Correct Answer *</label>
                        <br></br>
                        <TextField
                            variant="outlined"
                            margin="normal"
                            id="correctAnswer"
                            label="Correct Answer"
                            name="answer"
                            disabled={disabled}
                            required={questionType == 5}
                            value={correctAnswer} 
                            onChange={handleCorrectAnswerChange} 
                            fullWidth
                            multiline={true}
                            rows={5}
                        />
                    </Box>
                    {/* <Grid item xs={6} display={showQuestionImageBox} >
                        <FormControl variant="outlined" fullWidth margin="normal" >
                        <Grid item className={classes.GridButtonLeft}>
                            <Button
                                variant="contained"
                                color="secondary"
                                onClick={handleClickUploadImage}
                                className={classes.submit}
                            >
                                Upload Images
                            </Button>
                            &nbsp;&nbsp;
                            <label></label>
                        </Grid>
                        </FormControl>
                    </Grid> */}
                    <br></br>
                    <br></br>
                    <Grid container
                        spacing={0}
                        alignItems="center"
                        justify="center"

                         >
                        <Grid item className={classes.GridButton}>
                            <Link style={{ textDecoration: 'none', color: "black" }} to="/questions" className={classes.btnprimary} >
                                <Button
                                    variant="contained"
                                    className={classes.cancelButton}
                                >
                                    Cancel
                                </Button>
                            </Link>
                        </Grid>
                        <Grid item className={classes.GridButton}>
                            <Button

                                variant="contained"
                                color="secondary"
                                type="submit"
                                disabled={disabled}
                            >
                                Create Question
                    </Button>
                        </Grid>
                        <Grid item className={classes.GridButton}>
                            <Button
                                variant="contained"
                                color="secondary"
                                className={classes.previewButton}
                                disabled={questionType == 0}
                                onClick={() => handlePreview(0)} 
                            >
                                <PageviewRoundedIcon />
                                Preview
                            </Button>
                        </Grid>
                    </Grid>
                </form>
            </div>
            <Box mt={8}>
            </Box>
            < PreviewQuestion isOpen={open} onClose={handleClose} row={{questionId: previewRow}} save={{isList: false, title: title, description: ckd, imageUrl: img, options: JSON.stringify({questionTypeId: questionType, options: options}), questionTypeId: questionType, examQuestionId: 0}}/>
            {/* <UploadImage  open={uploadImageOpen} onClose={handleCloseCreate}  /> */}
        </div>
    );
}