import React from "react";
import axios from "axios";
import Config from "./Config";
import LocalStorageService from "./LocalStorageService";
import { BrowserRouter as Router, Route, Switch, useRouteMatch, useHistory, Redirect } from 'react-router-dom';
import LanguageJson from './assets/lang.json';


const NO_OP = () => { };


const AppContext = React.createContext();
if (process.env.NODE_ENV !== 'production') {
  AppContext.displayName = 'AppContext';
}

const useAppContext = () => React.useContext(AppContext);

const LOGIN_API = "login";
const FORGOT_PASSWORD_API = "login/forgotPassword";
const FORGOT_PASSWORD_RESET_API = "login/forgotPasswordReset";
const SESSION_KEY = "refreshToken";

const accessKey = "OnlineExam ";
const basicContentType = { "Content-Type": "application/json" };
const AXIOS = axios.create({
    baseURL: Config.apiBase,
    headers: {
        "Content-Type": "application/json",
        get: basicContentType,
        post: basicContentType,
        put: basicContentType,
        delete: basicContentType,
        patch: basicContentType,
    },
});

// LocalstorageService
const localStorageService = LocalStorageService.getService();

// // Add a request interceptor
// AXIOS.interceptors.request.use(
//    config => {
//        const token = localStorageService.getAccessToken();
//        if (token) {
//            console.log("sssssssssss1")
//         //    config.headers['Authorization'] = 'Bearer ' + token;
//        }
//        // config.headers['Content-Type'] = 'application/json';
//        return config;
//    },
//    error => {
//     console.log("sssssssssss2")
//        Promise.reject(error)
//    });

AXIOS.interceptors.response.use((response) => {
   return response
}, function (error) {
    console.log(error.response.status)
   const originalRequest = error.config;

   if (error.response.status === 403) {
    console.log("-----2")
    localStorage.removeItem(SESSION_KEY);
        removeAuthorization();
        // setAuth(null);
        window.location.reload();
       return Promise.reject(error);
   }

//    if (error.response.status === 403 && !originalRequest._retry) {
//     console.log("sssssssssss7")

//        originalRequest._retry = true;
//        const refreshToken = localStorageService.getRefreshToken();
//        return axios.post('/auth/token',
//            {
//                "refresh_token": refreshToken
//            })
//            .then(res => {
//                if (res.status === 201) {
//                    localStorageService.setToken(res.data);
//                    axios.defaults.headers.common['Authorization'] = localStorageService.getAccessToken();
//                    return axios(originalRequest);
//                }
//            })
//    }
   return Promise.reject(error);
});

function AppContextProvider({ init, children }) {
  const [title, setTitle] = React.useState(LanguageJson.WEB_EXAM);
  React.useEffect(() => { document.title = title ? LanguageJson.WEB_EXAM+' / - ' + title : LanguageJson.WEB_EXAM+' /'; }, [title]);
  const getTitle = () => title;

  const [auth, setAuth] = React.useState(init);
    React.useEffect(() => {
        if (auth !== null) {
            const expiry = new Date(auth.expiry).getTime() - Date.now();
            const time = (expiry >= 300 ? expiry - 30 : expiry * 0.9) * 1000;
            const timeout = setTimeout(() => {
                refreshAccessToken().then(setAuth);
            }, time);
            return () => {
                clearTimeout(timeout);
            };
        }

        return NO_OP;
    }, [auth]);

    function signIn(email, password) {
        // removeAuthorization();
        let data = JSON.stringify({
            password: password,
            email: email,
        });

        return AXIOS.post(LOGIN_API, data).then(
            (response) => {
                AXIOS.defaults.headers.common["AuthToken"] =
                    response.data.accessToken.value;
                setAuthorization(response.data.accessToken.value);
                localStorage.setItem(
                    SESSION_KEY,
                    response.data.refreshToken.value
                );
                console.log(response.data);
                localStorage.setItem("role", response.data.role);
                localStorage.setItem("userId", response.data.userId);
                localStorage.setItem("firstName", response.data.firstName);
                localStorage.setItem("lastName", response.data.lastName);
                localStorage.setItem("imageUrl", response.data.imageUrl);
                setAuth(response.data.accessToken);
                return {status: true, info: response};
            }, (error) => {
                return {status: false, info: error};
            });
    }

    function forgotPassword(email) {
        let data = JSON.stringify({
            email: email,
        });

        return AXIOS.post(FORGOT_PASSWORD_API, data).then(
            (response) => {
                console.log(response)
                return {status: true, info: response};
            }, (error) => {
                return {status: false, info: error};
            });
    }

    function forgotPasswordReset(newPassword, confirmPassword, token){
        let data = JSON.stringify({
            newPassword : newPassword,
            confirmNewPassword : confirmPassword,
            token : token
        })

        return AXIOS.put(`${FORGOT_PASSWORD_RESET_API}`, data).then((response)=>{
            // onClose();
            return {status:true , info :response};
        },(error)=>{
            return {status:false, info:error};
        });

    }


    function logout() {
        console.log("-----4")
        localStorage.removeItem(SESSION_KEY);
        removeAuthorization();
        setAuth(null);
    }

    const isLoggedin = () => auth !== null;

    const getAccessToken = () => auth;

    const getAxios = () => AXIOS;

    const context = {
        signIn,
        forgotPassword,
        forgotPasswordReset,
        setTitle,
        getTitle,
        logout,
        isLoggedin,
        getAccessToken,
        getAxios,
    };

  return <AppContext.Provider value={context}>{children}</AppContext.Provider>;
}



function refreshAccessToken() {
    console.log("-----1")
    let refreshToken = localStorage.getItem(SESSION_KEY);
    console.log(refreshToken)
    if (refreshToken === null) {
        return Promise.resolve(null);
    }
    return AXIOS.put(LOGIN_API, refreshToken).then(
        (response) => {
            AXIOS.defaults.headers.common["AuthToken"] =
                response.data.accessToken.value;
            setAuthorization(response.data.accessToken.value);

            return response.data.accessToken;
        },
        () => {
            removeAuthorization();
            console.log("-----5")
            localStorage.removeItem(SESSION_KEY);
            return null;
        }
    );
}

function setAuthorization(accessTokenValue) {
    AXIOS.defaults.headers.common["authorization"] = AXIOS.defaults.headers.get[
        "authorization"
    ] = AXIOS.defaults.headers.post[
        "authorization"
    ] = AXIOS.defaults.headers.put[
        "authorization"
    ] = AXIOS.defaults.headers.delete[
        "authorization"
    ] = AXIOS.defaults.headers.patch["authorization"] =
        accessKey + accessTokenValue;
}

function removeAuthorization() {
    delete AXIOS.defaults.headers.common["authorization"];
    delete AXIOS.defaults.headers.get["authorization"];
    delete AXIOS.defaults.headers.post["authorization"];
    delete AXIOS.defaults.headers.put["authorization"];
    delete AXIOS.defaults.headers.delete["authorization"];
    delete AXIOS.defaults.headers.patch["authorization"];
}

export default useAppContext;
export { refreshAccessToken, AppContextProvider };
