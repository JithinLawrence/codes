import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import CloseIcon from "@material-ui/icons/Close";
import {
    Typography,
    Grid,
    useTheme,
    DialogTitle,
    Dialog,
    IconButton,
    Divider,
    DialogContent,
    Input,
} from "@material-ui/core";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import Button from "@material-ui/core/Button";
import Box from "@material-ui/core/Box";
import "date-fns";
import DateFnsUtils from "@date-io/date-fns";
import {
    MuiPickersUtilsProvider,
    KeyboardTimePicker,
    KeyboardDatePicker,
} from "@material-ui/pickers";
import useAppContext from "./AppContext";
import ExamAssign from "./examAssign";
import { useAlert } from "react-alert";
import { convertCompilerOptionsFromJson } from "typescript";
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import DialogActions from '@material-ui/core/DialogActions';

const useStyles = makeStyles((theme) => ({
    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
    },
    cancelButton: {
        margin: theme.spacing(3),
    },
    submitButton: {
        margin: theme.spacing(3),
    },
    datePicker: {
        marginLeft: theme.spacing(3),
    },
    datePickerContainer: {
        marginTop: theme.spacing(3),
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    cursorPinter:{
        cursor: 'pointer'
    },
}));

function getStyles(name, personName, theme) {
    return {
        fontWeight:
            personName.indexOf(name) === -1
                ? theme.typography.fontWeightRegular
                : theme.typography.fontWeightMedium,
    };
}

export default function ExamScheduleEdit({ open, onClose, row }) {
    const classes = useStyles();
    const alert = useAlert();
    const theme = useTheme();

    const handleClick = () => {
        console.log("assgin is loading....");
    };

    const EXAM_SCHEDULE_API = "exam_schedule";
    const EXAM_LIST_API = "exams";
    const appContext = useAppContext();
    const DELETE_ASSIGNED_CANDIDATE_API = 'exam_schedule/deleteCandidate';
    const LIST_ASSIGNED_CANDIDATES = 'candidates/listAssignedCandidates';

    const [disabled, setDisabled] = React.useState(false);
    const [examData, setExamData] = React.useState([]);

    const [exam, setExam] = React.useState("");
    const [file, setFile] = React.useState("");
    const [fileUrl, setFileUrl] = React.useState("");
    const [progress, setProgress] = React.useState(100);

    const [examError, setExamError] = React.useState(null);

    const [scheduleId, setScheduleId] = React.useState("");
    const [examId, setExamId] = React.useState("");
    const [examIdError, setExamIdError] = React.useState(null);
    const [startDate, setStartDate] = React.useState();
    const [startTime, setStartTime] = React.useState("");
    const [startTimeError, setStartTimeError] = React.useState(null);
    const [endDate, setEndDate] = React.useState();
    const [endTime, setEndTime] = React.useState("");
    const [endTimeError, setEndTimeError] = React.useState(null);
    const [assignedList, setAssignedList] = React.useState([]);

    const [csvUploaded, setCsvUploaded] = React.useState(false);

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 250,
            },
        },
    };

    React.useEffect(() => {
        if (open) {
            loadExam();
            loadInputs(row);
            setCsvUploaded(false);
            loadAssignedCandidates();
        }
    }, [open]);

    const handleStartDateChange = (date) => {
        setStartDate(date);
        handleStartTimeChange(date);
    };

    const handleStartTimeChange = (date) => {
        setStartTime(date);
        let errorMsg = null;
        errorMsg =
            errorMsg == null
                ? date.length < 6
                    ? "Please check the start time"
                    : null
                : errorMsg;
        setStartTimeError(errorMsg);
    };

    const handleEndDateChange = (eTime) => {
        setEndDate(eTime);
        handleEndTimeChange(eTime);
    };

    const handleEndTimeChange = (eTime) => {
        setEndTime(eTime);
        let errorMsg = null;
        errorMsg =
            errorMsg == null
                ? eTime.length < 6
                    ? "Please check the end time"
                    : null
                : errorMsg;
        setEndTimeError(errorMsg);
    };

    const handleUpdate = (event) => {
        event.preventDefault();

        if (
            examError != null ||
            startTimeError != null ||
            endTimeError != null
        ) {
            //setting error
            console.log("something is missing!");
            console.log("examError " + examError);
            console.log("startTimeError " + startTimeError);
            console.log("endTimeError " + endTimeError);

            return;
        }

        setDisabled(true);
        updateExamSchedule(scheduleId, examId, startTime, endTime).then(
            (result) => {
                if (!result.status) {
                    console.log("result->" + result.status);
                    //  alert.error(result.info.response.data.message);
                    console.log("error");
                } else {
                    resetInputs();
                    alert.success("Schedule Updated Successfully.");
                }
                setDisabled(false);
            }
        );
    };

    const handleExamChoose = (e_id) => {
        console.log("changing the exam is not allowed " + e_id);
    };

    const handleExamChange = (event) => {
        //    setExam(event.target.value);

        console.log("Exam can't be changed");
    };

    function loadInputs(row) {
        setScheduleId(row.scheduleId);
        var varStartTime = new Date(row.startTime);
        var varEndTime = new Date(row.endTime);
        setStartTime(varStartTime);
        setStartDate(varStartTime);
        setEndTime(varEndTime);
        setEndDate(varEndTime);
        setExamId(row.examId);
    }

    function loadExam() {
        appContext
            .getAxios()
            .get(
                EXAM_LIST_API +
                    "/list" +
                    "?page=" +
                    "&limit=" +
                    "&search=" +
                    "&sort=name"
            )
            .then(
                (response) => {
                    setExamData(response.data.result);
                },
                (error) => {
                    console.log("error!");
                    //alert.error(error.response.data.message);
                }
            );
    }

    function loadAssignedCandidates() {
        appContext
            .getAxios().get(LIST_ASSIGNED_CANDIDATES +"?scheduleId="+row.scheduleId).then((response) => {
                    setAssignedList(response.data);
                },
                (error) => {
                    console.log("error!");
                    //alert.error(error.response.data.message);
                }
            );
    }

    function resetInputs() {
        setExam("");
        setExamError(null);
        setEndTime("");
        setEndDate("");
        setStartDate("");
        setStartTime("");
        setStartTimeError(null);
        setEndTimeError(null);
        setCsvUploaded(false);
    }

    function updateExamSchedule(scheduleId, examId, startTime, endTime, type) {
        let data = JSON.stringify({
            scheduleId: scheduleId,
            examId: examId,
            startTime: startTime,
            endTime: endTime,
            type: type,
        });

        return appContext
            .getAxios()
            .put(EXAM_SCHEDULE_API + "/" + scheduleId, data)
            .then(
                (response) => {
                    onClose(true);
                    return { status: true, info: response };
                },
                (error) => {
                    return { status: false, info: error };
                }
            );
    }

    const handleDelete = (userId) => {
        appContext.getAxios().delete(DELETE_ASSIGNED_CANDIDATE_API+"/"+row.scheduleId+"/"+userId).then((response) => {
            loadAssignedCandidates();
        }, (error) => {
            console.log(error)
        });
    };


    return (
        <Dialog
            maxWidth="lg"
            open={open}
            onClose={() => {
                resetInputs();
                onClose(false);
            }}
            aria-labelledby="add-schedule-dialog-title"
        >
            <DialogTitle id="edit-schedule-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>
                    Edit Exam Schedule
                </Typography>
                <IconButton
                    size="small"
                    className={classes.close}
                    onClick={() => {
                        resetInputs();
                        onClose(false);
                    }}
                >
                    <CloseIcon />
                </IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>

            
                    <Grid container style={{'margin-left':'2%'}}>
                        <Grid item sm={12} md={6}>
                            <FormControl className={classes.formControl}>
                                <InputLabel id="select-exam-label">
                                    Exam
                                </InputLabel>

                                <Select style={{'margin-left':'2%'}}
                                    labelId="select-exam-label"
                                    id="select-exam"
                                    label="Exam"
                                    required
                                    value={examId}
                                    onChange={handleExamChange}
                                    disabled={disabled}
                                    error={examError !== null}
                                >
                                    {examData.map((row) => (
                                        <MenuItem
                                            key={row.examId}
                                            value={row.examId}
                                            onClick={(e) =>
                                                handleExamChoose(row.examId)
                                            }
                                        >
                                            {row.name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            <br></br>
                            <br></br>
                        </Grid>
                        <br></br>
                    </Grid>

                    <Grid container>
                        <Grid item sm={12} md={12} py={5}>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <Grid
                                    className={classes.datePickerContainer}
                                    container
                                >
                                    <KeyboardDatePicker
                                        margin="normal"
                                        className={classes.datePicker}
                                        id="start-date-picker-dialog"
                                        label="Exam schedule start date "
                                        value={startDate}
                                        format="yyyy-MM-dd"
                                        onChange={handleStartDateChange}
                                        KeyboardButtonProps={{
                                            "aria-label": "change date",
                                        }}
                                    />
                                    <KeyboardTimePicker
                                        margin="normal"
                                        className={classes.datePicker}
                                        id="start-time-picker"
                                        label="Exam schedule start time "
                                        value={startTime}
                                        onChange={handleStartTimeChange}
                                        KeyboardButtonProps={{
                                            "aria-label": "change time",
                                        }}
                                    />
                                </Grid>
                            </MuiPickersUtilsProvider>
                        </Grid>

                        <Grid item sm={12} md={12}>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <Grid
                                    container
                                    className={classes.datePickerContainer}
                                >
                                    <KeyboardDatePicker
                                        margin="normal"
                                        className={classes.datePicker}
                                        id="end-date-picker-dialog"
                                        label="Exam schedule end date"
                                        format="yyyy-MM-dd"
                                        value={endDate}
                                        onChange={handleEndDateChange}
                                        KeyboardButtonProps={{
                                            "aria-label": "change date",
                                        }}
                                    />
                                    <KeyboardTimePicker
                                        className={classes.datePicker}
                                        margin="normal"
                                        id="end-time-picker"
                                        label="Exam schedule expire time"
                                        value={endTime}
                                        onChange={handleEndTimeChange}
                                        KeyboardButtonProps={{
                                            "aria-label": "change time",
                                        }}
                                    />
                                </Grid>
                            </MuiPickersUtilsProvider>
                            <br></br>
                            <br></br>
                        </Grid>
                   </Grid>
                <DialogContent >
                  <form className={classes.form}>
                  <Divider classes={{ root: classes.divider }} />
                    {assignedList.length > 0 ?
                   
                    <TableContainer component={Paper} style={{'height':'15%'}}>
                        <Table className={classes.table} aria-label="simple table">
                            <TableHead>
                                <TableRow>                                   
                                    <TableCell align="center">First Name</TableCell>
                                    <TableCell align="center">Last Name</TableCell>
                                    <TableCell align="center">Email</TableCell>
                                    <TableCell align="left">Group</TableCell>
                                    <TableCell align="left">Action</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {assignedList.map((row) => (
                                    <TableRow key={row.userId}>                                      
                                        <TableCell align="center">
                                            {row.firstName}
                                        </TableCell>
                                        <TableCell align="center">
                                            {row.lastName}
                                        </TableCell>
                                        <TableCell align="center">
                                            {row.email}
                                        </TableCell>
                                        <TableCell align="left">
                                            {row.grade}
                                        </TableCell>
                                        <TableCell align="left">
                                            <DeleteSharpIcon className={classes.cursorPinter} style={{ color: red[500] }} fontSize="small" onClick={()=>handleDelete(row.userId)}/>
                                            </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                      </TableContainer>:''}
                      <Divider classes={{ root: classes.divider }} />
                    </form>
                </DialogContent>
                <DialogActions>
                    <Box
                        display="flex"
                        flex={1}
                        justifyContent="center"
                        m={1}
                        p={1}
                    >

                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type="submit"
                            disabled={disabled}
                            onClick={handleUpdate}
                        >
                            Update Schedule
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            onClick={() => {
                                resetInputs();
                                onClose(false);
                            }}
                        >
                            cancel
                        </Button>
                    </Box>
                </DialogActions>
               
            
        </Dialog>
    );
}
