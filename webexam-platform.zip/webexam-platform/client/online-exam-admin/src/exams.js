import React from 'react';
import { BrowserRouter as Router, Route, Switch, useRouteMatch, useHistory, Redirect } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import EditSharpIcon from '@material-ui/icons/EditSharp';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import PageviewRoundedIcon from '@material-ui/icons/PageviewRounded';
import EqualizerRoundedIcon from '@material-ui/icons/EqualizerRounded';
import { Link } from "react-router-dom";
import useAppContext from './AppContext';
import PreviewExam from './preview/previewExam';
import { IconButton } from '@material-ui/core';
import { TextField } from '@material-ui/core';
import DeleteConfirm from './deleteConfirm';
import { useAlert } from "react-alert";
import TablePagination from '@material-ui/core/TablePagination';
import SwapVertSharpIcon from '@material-ui/icons/SwapVertSharp';
import LanguageJson from './assets/lang.json';
import FileCopyIcon from '@material-ui/icons/FileCopy';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    cursorPinter:{
        cursor: 'pointer'
    },
    headerStyle5: {
        width: '5%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    headerStyle30: {
        width: '30%',
        maxWidth: '1px'
    },
    headerStyle15: {
        width: '15%',
        maxWidth: '1px'
    },
    cellStyle5: {
        width: '5%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle30: {
        width: '30%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle15: {
        width: '15%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    }
});

export default function Exams() {
    const classes = useStyles();
    const alert = useAlert();

    const EXAMS_LIST_API = 'exams/list';
    const EXAMS_VERIFY_EDIT_API = 'exams/verifyEdit';
    const EXAMS_INIT_COPY_API = 'exams/initCopy';
    const appContext = useAppContext();

    const [isOpen, setIsOpen] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('exam_id');
    const [sortType, setSortType] = React.useState(true);
    // const [forceChange, setForceChange] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [deleteOpen, setDeleteOpen] = React.useState(false);
    const [rowData, setRowData] = React.useState([]);
    const [previewRow, setPreviewRow] = React.useState([]);

    const handleClose = hasChange => {
        setIsOpen(false);
    };
    const handlePreview = (row) => {
        setPreviewRow(row)
        setIsOpen(true);
    };  
    const history = useHistory();
    const handleEdit = (row) => {
        appContext.getAxios().get(EXAMS_VERIFY_EDIT_API+"/"+row.examId).then((response) => {
            console.log(response.data.result)
            history.push("/examedit/"+row.examId)
        }, (error) => {
            alert.error(error.response.data.message);
        });
    };  

    const handleCopy = (row) => {
        appContext.getAxios().post(EXAMS_INIT_COPY_API+"/"+row.examId).then((response) => {
            console.log(response.data)
            history.push("/examcopy/"+response.data)
        }, (error) => {
            alert.error(error.response.data.message);
        });
    };  

    const handleSearchChange = event => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleDelete = hasChange => {
        if(hasChange){
            listExams()
        }
        setDeleteOpen(false);
    };
    
    const handleClickOpeDelete = (deletingRow) => {
        setRowData(deletingRow)
        setDeleteOpen(true);
    };  

    const handleSort = val => {
        if(sort == val){
            setSortType(!sortType)
        } else {
            setSortType(sort == val)
        }
        setSort(val);
    };

    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
  
    const handleChangeLimit = event => {
      setLimit(parseInt(event.target.value, 10));
      setPage(0);
    };

    React.useEffect(() => {
        listExams();
      }, [sort, sortType, page, limit, search]); 

    function listExams() {
        appContext.getAxios().get(EXAMS_LIST_API+'?page='+(page+1)+'&limit='+limit+'&search='+encodeURIComponent(search)+'&type='+sortType+'&sort='+sort).then((response) => {
            console.log(response.data.result)
            setData(response.data.result);
            setPage(response.data.currentPage-1)//to reset page in case deleting the last row of last page
            setCount(response.data.pagerInfo.count);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    return (
        <div>
            <h1>{LanguageJson.EXAM_LIST}</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

                <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                    <Link style={{ textDecoration: 'none', color: "black" }} to="/examcreate" className={classes.btnprimary} >
                        <Button
                            variant="contained"
                            color="secondary"
                            justify="right"
                        >
                            {LanguageJson.EXAM_CREATE_EXAM}
                    </Button>
                    </Link>
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        value={search} 
                        onChange={handleSearchChange} 
                        ></TextField>
                    </FormControl>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell className={classes.headerStyle5} align="left">{LanguageJson.COMMON_SL_NO}</TableCell>
                            <TableCell align="left" className={classes.headerStyle30} >
                            {LanguageJson.EXAM_TITLE}&nbsp;
                                <SwapVertSharpIcon fontSize="small" style={{'marginBottom':'-5px'}} className={classes.cursorPinter} onClick={() => {handleSort('name');}}/>
                            </TableCell>
                            <TableCell align="left" style={{ whiteSpace : "nowrap" }}>{LanguageJson.EXAM_QUESTION_COUNT}</TableCell>
                            <TableCell className={classes.headerStyle10} align="left">{LanguageJson.EXAM_DURATION}</TableCell>
                            <TableCell className={classes.headerStyle10} align="center">{LanguageJson.EXAM_PREVIEW}</TableCell>
                            <TableCell className={classes.headerStyle10} align="center">{LanguageJson.EXAM_REPORT}</TableCell>
                            <TableCell className={classes.headerStyle10} align="center">{LanguageJson.EXAM_COPY}</TableCell>
                            {/* <TableCell align="right">Schedule</TableCell> */}
                            <TableCell className={classes.headerStyle10} align="center">{LanguageJson.COMMON_ACTIONS}</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {data.map((row, index) => (
                            <TableRow key={row.examId}>
                                <TableCell className={classes.cellStyle5} align="left">{(page * limit) + index + 1}</TableCell>
                                <TableCell align="left" className={classes.cellStyle30} component="th" scope="row">
                                    {row.name}
                                </TableCell>
                                <TableCell className={classes.cellStyle15} align="left">{row.questionCount}</TableCell>
                                <TableCell className={classes.cellStyle10} align="left">{row.duration}</TableCell>
                                {/* <TableCell align="right">{row.schedule}</TableCell> */}
                                <TableCell className={classes.cellStyle10} align="center" >
                                    {row.questionCount>0 ? 
                                    <PageviewRoundedIcon className={classes.cursorPinter} onClick={() => handlePreview(row)} fontSize="small" /> : 
                                    <PageviewRoundedIcon color="disabled" fontSize="small" />
                                    }
                                    
                                </TableCell>
                                <TableCell className={classes.cellStyle10} align="center">
                                    <Link style={{ textDecoration: 'none', color: "black" }} to={`/examreport/${row.examId}`}>
                                        <EqualizerRoundedIcon fontSize="small" />
                                    </Link>
                                </TableCell>
                                <TableCell className={classes.cellStyle10} align="center" style={{ whiteSpace : "nowrap" }}>
                                    {/* <Link style={{ textDecoration: 'none', color: "black" }} to={"/examcopy/"+row.examId}> */}
                                        {/* <FileCopyIcon fontSize="small"/> */}
                                        <FileCopyIcon fontSize="small" className={classes.cursorPinter} onClick={() => handleCopy(row)}/>
                                    {/* </Link> */}
                                </TableCell>
                                <TableCell className={classes.cellStyle10} align="center" style={{ whiteSpace : "nowrap" }}>
                                    {/* <Link style={{ textDecoration: 'none', color: "black" }} to={"/examedit/"+row.examId}> */}
                                        <EditSharpIcon fontSize="small" className={classes.cursorPinter} onClick={() => handleEdit(row)}/>
                                    {/* </Link>&nbsp;&nbsp;&nbsp; */}
                                    &nbsp;&nbsp;&nbsp;
                                    {(row.createdBy == localStorage.getItem("userId") || 1 == localStorage.getItem("role")) && <DeleteSharpIcon className={classes.cursorPinter}  style={{ color: red[500] }} fontSize="small"  onClick={() => handleClickOpeDelete(row)} />}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {(data.length ==0 && search != "") ? 
                <div style={{'textAlign':"center"}}>Search result not found</div>
                :(data.length ==0) ? 
                <div style={{'textAlign':"center"}}>No result found</div>
                :''}
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[0]}
                component="div"
                count={count}
                rowsPerPage={limit}
                page={page}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeLimit}
            />
            < PreviewExam open={isOpen} onClose={handleClose} row={previewRow} type={"list"} save={{name: "", duration: "", ckd: "", ckdTC: ""}}/>
            <DeleteConfirm open={deleteOpen} onClose={handleDelete} apiLink={'exams'} deleteId={rowData.examId} deleteText={'Are you sure you want to delete this Exam ?'} deleteMsg={'Exam deleted successfully.'}/>
        </div>
    );
}