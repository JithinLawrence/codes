import React from 'react'
import { makeStyles, useTheme } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";
import Autocomplete from '@material-ui/lab/Autocomplete';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 300,
        maxWidth : 500,
        marginLeft: "10px",
        borderBottomLeftRadius: "25px",
        borderBottomRightRadius: "25px",
        borderTopLeftRadius: "25px",
        borderTopRightRadius: "25px"
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    close: {
        position: 'absolute',
        right: theme.spacing(0),
        top: theme.spacing(0),
        color: theme.palette.grey[500]
    },
    h3:{
        color : theme.palette.grey[600]
    },
    chips: {
        display: 'flex',
        flexWrap: 'wrap',
      },
      chip: {
        margin: 0,
      },
      root: {
        width: 500,
        '& > * + *': {
          marginTop: theme.spacing(3),
        },
      }
}));

function getStyles(name, personName, theme) {
    return {
    fontWeight:
        personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
    };
}

export default function QuestionBankShare({ open, onClose, questionBankId, title, editText }) {
    const classes = useStyles();
    const alert = useAlert();
    const theme = useTheme();

    const appContext = useAppContext();

    const [disabled, setDisabled] = React.useState(false);
    const [userData, setUserData] = React.useState([]);
    const [userName, setUserName] = React.useState([]);
    const [userId, setUserId] = React.useState([]);
    const [userIdError, setUserIdError] = React.useState(null);

    let userIds = [];

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;

    const MenuProps = {
        PaperProps: {
          style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
          },
        },
      };

    const User_List_API = 'users/listUsers';
    const QuestionBank_Share_API = 'question_bank/questionBankShare'

    React.useEffect(() => {
        listUsers();
    }, []); 

    const handleUserChange = (event, value) => {        
       let result = value.map(a => a.userId);
        console.log(result);
        setUserId(result);        
    };

    const handleSubmit = event => {
        event.preventDefault();
        console.log("Users selected : "+ userId);

        if( userIdError != null ){
            return;
        }

        setDisabled(true);
        shareQuestionBank(questionBankId).then((result) => {
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                alert.success("Question bank shared successfully.");
            }
            setDisabled(false);
        });
    };

    function shareQuestionBank() { 
        let data = JSON.stringify({           
            questionBankId: questionBankId, 
            userIds: userId           
        })   
        return appContext.getAxios().post(QuestionBank_Share_API, data).then((response) => {
              onClose(true);
        return {status: true, info: response};
        }, (error) => {
            return {status: false, info: error};
        });
    }

    function listUsers() {
        appContext.getAxios().get(User_List_API).then((response) => {
            //console.log("role"+sessionStorage.getItem("role"));
            //console.log("User"+response.data);
            setUserData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    return (
        <Dialog  maxWidth="lg" open={open} onClose={() =>  {onClose(false);}} aria-labelledby="add-questions-dialog-title">
            <DialogContent>
                <form className={classes.formControl} onSubmit={handleSubmit}>
                <Typography variant="h6" component="h2"  align="center">Exam QuestionBank {questionBankId}</Typography> 
                <h2 variant="h6" className={classes.h3} component="h2">{editText}</h2>

                <Grid item sm={12} md={3}>
                    <FormControl className={classes.root} required>                      
                        <Autocomplete
                            multiple
                            id="tags-outlined"
                            options={userData}
                            getOptionLabel={(userData) => userData.firstName + " "+ userData.lastName}
                            onChange={(event, value) =>handleUserChange(event, value)}                           
                            filterSelectedOptions
                            renderInput={(params) => (
                            <TextField
                                {...params}
                                variant="outlined"                            
                                label="Users"
                                placeholder="User"
                            />
                            )}
                        />
                    </FormControl>
                </Grid>
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            onClick={() =>  {onClose(false);}}
                        >
                            cancel
                        </Button>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type="submit"
                            disabled={disabled}
                        >
                            Share
                        </Button>
                        
                    </Box>
                </form >
            </DialogContent>
        </Dialog>
    
    )
}
