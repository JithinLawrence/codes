import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import theme from './theme';
import Divider from '@material-ui/core/Divider';
import Box from '@material-ui/core/Box'
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import EditSharpIcon from '@material-ui/icons/EditSharp';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import ShareSharpIcon from '@material-ui/icons/ShareSharp';
import { red, blue } from '@material-ui/core/colors';
import { Link } from "react-router-dom";
import useAppContext from './AppContext';
import { TextField } from '@material-ui/core';
import QuestionBankCreate from './questionBankCreate';
import QuestionBankEdit from './questionBankEdit';
import QuestionBankShare from './questionBankShare';
import DeleteConfirm from './deleteConfirm';
import ListIcon from '@material-ui/icons/List';
import { useAlert } from "react-alert";
// import IconButton from '@material-ui/core/IconButton';
// import ArrowBackIos from '@material-ui/icons/ArrowBackIos';
// import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import TablePagination from '@material-ui/core/TablePagination';
import SwapVertSharpIcon from '@material-ui/icons/SwapVertSharp';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration: "none"
    },
    cursorPinter:{
        cursor: 'pointer'
    },
    headerStyle5: {
        width: '5%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    headerStyle15: {
        width: '15%',
        maxWidth: '1px'
    },
    headerStyle20: {
        width: '20%',
        maxWidth: '1px'
    },
    headerStyle50: {
        width: '50%',
        maxWidth: '1px'
    },
    cellStyle5: {
        width: '5%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle15: {
        width: '15%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle20: {
        width: '20%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle50: {
        width: '50%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    }
});

export default function QuestionBankList() {
    const classes = useStyles();
    const alert = useAlert();

    const QUESTION_BANK_LIST_API = 'question_bank/list';
    const appContext = useAppContext();

    const [createOpen, setCreateOpen] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('question_bank_id');
    const [sortType, setSortType] = React.useState(true);
    // const [sortPage, setSortPage] = React.useState(1);
    // const [currectPage, setCurrectPage] = React.useState(1);
    // const [totalPage, setTotalPage] = React.useState(1);
    // const [prevDisabled, setPrevDisabled] = React.useState(false);
    // const [nextDisabled, setNextDisabled] = React.useState(false);
    const [forceChange, setForceChange] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [editOpen, setEditOpen] = React.useState(false);
    const [deleteOpen, setDeleteOpen] = React.useState(false);
    const [rowData, setRowData] = React.useState([]);
    const [shareOpen, setShareOpen] = React.useState(false);
    
    const handleSearchChange = event => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleClickOpenShare = (editingRow) => {
        setRowData(editingRow)
        setShareOpen(true);
    };

    const handleCloseCreate = hasChange => {
        if(hasChange){
            setSort('question_bank_id');
            setSortType(true);
            setPage(0);
            // setLimit(5);
            // setSortPage(1);
            setForceChange(!forceChange)//after saving count not incremented properly. so changing this value reloads the method listQuestionBank
            // listQuestionBank()
        }
        setCreateOpen(false);
    };
    const handleClickOpenCreate = () => {
        setCreateOpen(true);
    };

    const handleCloseEdit = hasChange => {
        if(hasChange){
            listQuestionBank()
        }
        setEditOpen(false);
    };

    const handleShare = hasChange => {
        if(hasChange){
            listQuestionBank()
        }
        setShareOpen(false);
    };

    const handleDelete = hasChange => {
        if(hasChange){
            listQuestionBank()
        }
        setDeleteOpen(false);
    };
    const handleClickOpenEdit = (editingRow) => {
        setRowData(editingRow)
        setEditOpen(true);
    };    
    const handleClickOpeDelete = (deletingRow) => {
        setRowData(deletingRow)
        setDeleteOpen(true);
    };  

    const handleSort = val => {
        if(sort == val){
            setSortType(!sortType)
        } else {
            setSortType(sort == val)
        }
        setSort(val);
    };

    // const handlePrev = event => {
    //     setSortPage(sortPage-1)
    // };

    // const handleNext = event => {
    //     setSortPage(sortPage+1)        
    // };

    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
  
    const handleChangeLimit = event => {
      setLimit(parseInt(event.target.value, 10));
      setPage(0);
    };

    React.useEffect(() => {
        listQuestionBank();
      }, [sort, sortType, page, limit, forceChange, search]);

    function listQuestionBank() {
        appContext.getAxios().get(QUESTION_BANK_LIST_API+'?page='+(page+1)+'&limit='+limit+'&search='+encodeURIComponent(search)+'&type='+sortType+'&sort='+sort).then((response) => {
            setData(response.data.result);
            setPage(response.data.currentPage-1)//to reset page in case deleting the last row of last page
            setCount(response.data.pagerInfo.count);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }
    return (
        <div>
            <h1>Question Bank List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>

                <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                <Link style={{ textDecoration: 'none', color: "black" }} to="/questionbankcreate" className={classes.btnprimary} >
                        <Button
                            variant="contained"
                            color="secondary"
                            justify="right"
                        >
                            Add Question Bank
                        </Button>
                        </Link>
                </Box>
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                            label="Search"
                            id="search"
                            value={search} 
                            onChange={handleSearchChange} 
                        ></TextField>
                    </FormControl>
                </Box>
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell className={classes.headerStyle5} align="left">No</TableCell>
                            <TableCell className={classes.headerStyle50} align="left">
                                Title&nbsp;
                                <SwapVertSharpIcon fontSize="small" style={{'marginBottom':'-5px'}} className={classes.cursorPinter} onClick={() => {handleSort('title');}}/>
                            </TableCell>
                            <TableCell className={classes.headerStyle15} align="center">Questions</TableCell>
                            <TableCell className={classes.headerStyle20} align="left">&nbsp;Created at</TableCell>
                            {/* <TableCell align="right">Marks</TableCell> */}
                            <TableCell className={classes.headerStyle10} align="center">Action</TableCell>
                        </TableRow>
                    </TableHead>
                    {data.length > 0 ?
                    <TableBody>
                        {data.map((row, index) => (
                            <TableRow key={row.questionBankId}>
                                <TableCell className={classes.cellStyle5} align="left">{(page * limit) + index + 1}</TableCell>
                                <TableCell component="th" scope="row" className={classes.cellStyle50} align="left">
                                    {row.title}
                                </TableCell> 
                               <TableCell className={classes.cellStyle15} align="center"> <Link style={{ textDecoration: 'none', color: "black" }} color="inherit" color="inherit" to={"/questionbank/"+row.questionBankId}> <ListIcon /></Link></TableCell>
                                <TableCell className={classes.cellStyle20} align="left" style={{ whiteSpace : "nowrap" }}>{row.createDate}</TableCell>
                                <TableCell className={classes.cellStyle10} align="center" style={{ whiteSpace : "nowrap" }}>
                                {(row.createdBy == localStorage.getItem("userId") || 1 == localStorage.getItem("role")) && <Link style={{ textDecoration: 'none', color: "black" }} to={"/questionbankedit/"+row.questionBankId}>
                                &nbsp;<EditSharpIcon fontSize="small" /></Link>}&nbsp;&nbsp;&nbsp;
                                    {(row.createdBy == localStorage.getItem("userId") || 1 == localStorage.getItem("role")) && <DeleteSharpIcon className={classes.cursorPinter}  style={{ color: red[500] }} fontSize="small"  onClick={() => handleClickOpeDelete(row)} />}
                                    {(row.createdBy == localStorage.getItem("userId") || 1 == localStorage.getItem("role")) && <ShareSharpIcon className={classes.cursorPinter} style={{ color: blue[600] }} fontSize="small" onClick={() => handleClickOpenShare(row)}/>}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>:''}
                </Table>
                {(data.length ==0 && search != "") ? 
                <div style={{'textAlign':"center"}}>Search result not found</div>
                :(data.length ==0) ? 
                <div style={{'textAlign':"center"}}>No result found</div>
                :''}
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[0]}
                component="div"
                count={count}
                rowsPerPage={limit}
                page={page}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeLimit}
            />
            {/* <QuestionBankCreate  opens={createOpen} onClose={handleCloseCreate}  /> */}
            {/* <QuestionBankEdit  open={editOpen} onClose={handleCloseEdit} row={rowData} /> */}
            <QuestionBankShare open={shareOpen} onClose={handleShare} questionBankId={rowData.questionBankId} title={rowData.title} editText={'Would you like to share your question bank to another user?'}/>
            <DeleteConfirm open={deleteOpen} onClose={handleDelete} apiLink={'question_bank'} deleteId={rowData.questionBankId} deleteText={'Are you sure you want to delete this question bank?'} deleteMsg={'QuestionBank deleted successfully.'}/>
        </div>
    );
}