import React from 'react';
import Box from '@material-ui/core/Box'
import Grid from '@material-ui/core/Grid';
import PieChart from './charts/pieChart';
import BarChart from './charts/barChart';
import useAppContext from './AppContext';
import CanvasJSReact from './charts/canvasjs.react';
import { useParams } from 'react-router-dom';
import { useAlert } from 'react-alert';

const boxProps = {
    display: "flex",
    bgcolor: 'background.paper',
    style: { height: '3rem' },
    borderLeft: '5px solid',
    borderColor: "secondary.main",
    justifyContent: "flex-start",
    margin: 1,
    padding: 1,
    boxShadow: 3
};
const chartsProps = {
    display: "flex",
    bgcolor: 'background.paper',
    justifyContent: "center",
    margin: 3,
    padding: 1,
};

export default function ExamReport() {

const [examReport, setExamReport] = React.useState([]);

const successData = [
        { label: 'pass', y: examReport['Pass'] },
        { label: 'fail', y: examReport['Fail'] },
];

const examStatusData = [
    { label: 'Applied', y: examReport['Assigned']},
    { label: 'Attended', y: examReport['Attended'] },
    { label: 'Incomplete', y: examReport['Incomplete'] },
    { label: 'Completed', y: examReport['Completed'] },
];
const scoreData = [
    { label: 'max score', y: examReport['Max'] },
    { label: 'min score', y: examReport['Min'] },
    { label: 'average score', y: examReport['Avg'] },
];

const scoreChartProps = {
    data: scoreData,
    title: 'Score analysis',
    width: '250',
    height: '500',
    valueField: 'y',
    argumentField: 'label',
    scaleName: 'zoom',
}
const successChartProps = {
    data: successData,
    title: 'pass/fail analysis',
    valueField: "y",
    argumentField: "label",
}
const examstatusChartProps = {
    data: examStatusData,
    title: 'Exam status/ Candidates count',
    width: '380',
    height: '500',
    valueField: "y",
    argumentField: "label"
}

    var CanvasJS = CanvasJSReact.CanvasJS;
    var CanvasJSChart = CanvasJSReact.CanvasJSChart;

    const {examId} = useParams();
    const ExamReport_Get_API = "exams/getExamReport";
    const appContext = useAppContext();
    const alert = useAlert();

    const optionsStatus = {
        animationEnabled: true,
        theme: "light2",
        title: {
            text: "Exam status/ Candidates count",
            margin: 30,
            fontWeight: "normal",
            fontSize: 20
        },
        axisX: {
            title: "Status",
        },
        axisY: {
            title: "Count",
            reversed: false,

        },
        data: [{
            type: "column",
            dataPoints: examStatusData
        }]
    }
    const optionsScore = {
        animationEnabled: true,
        theme: "light2",
        title: {
            text: 'Score analysis',
            fontWeight: "normal",
            fontSize: 20,
            margin: 30,
        },
        axisX: {
            title: "Status",
        },
        axisY: {
            title: "Count",
            reversed: false,

        },
        data: [{
            type: "column",
            dataPoints: scoreData
        }]
    }
    const optionsSuccess = {
        theme: "light2",
        animationEnabled: true,
        exportEnabled: false,
        title:{
            fontWeight: "normal",
            margin: 30,
            text: 'pass/fail analysis',
            fontSize: 20,
        },
        creditText:"",
        data: [{
            type: "pie",
            showInLegend: true,
            legendText: "{label}",
            toolTipContent: "{label}: <strong>{y}%</strong>",
            indexLabel: "{y}%",
            indexLabelPlacement: "inside",
            dataPoints: successData
        }]
    }

    React.useEffect(()=>{
        getStatusCounts();
    },[]);

    function getStatusCounts(){
        let apiUrl = `${ExamReport_Get_API}?examId=${examId}`

        appContext.getAxios().get(apiUrl).then((response)=>{
            setExamReport(response.data);         
        },(error)=>{
            alert.error(error.response.data.message);    
        })
    }


    return (
        <div>
            <h1>Exam Report</h1>
            <Grid container spacing={4}>
                <Grid item  xs={12} sm={12} md={6}>
                    <Box  {...boxProps}>
                        Assigned candidates : {examReport['Assigned']}
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={6}>
                    <Box  {...boxProps}>
                        Attended candidates : {examReport['Attended']}
                    </Box>
                </Grid>
                <Grid item  xs={12} sm={12} md={6}>
                    <Box  {...boxProps}>
                        Total Time: {(examReport['Hour']) !=0 ? examReport['Hour']+" h " +examReport['Minute']+" Min" : ((examReport['Minute']) !=0 ? examReport['Minute']+"Min." : '')}
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={6}>
                    <Box  {...boxProps}>
                        Total Questions : {examReport['Question']}
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={6}>
                    <Box  {...boxProps}>
                        Candidates more than average score: {examReport['MoreAvg']}
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={6}>
                    <Box  {...boxProps}>
                        Candidates less than average score: {examReport['LessAvg']}
                    </Box>
                </Grid>
            </Grid>
            <Grid container spacing={2} >
                <Grid item xs={12}  sm={12} md={4}>
                    <Box  {...chartsProps}>
                        {/* <Box><BarChart {...examstatusChartProps} /></Box> */}
                        <CanvasJSChart options={optionsStatus} />
                    </Box>
                </Grid>
                <Grid item xs={12}  sm={12} md={4}>
                    <Box  {...chartsProps}>
                        {/* <BarChart {...scoreChartProps} /> */}
                        <CanvasJSChart options={optionsScore} />
                    </Box>
                </Grid>
                <Grid item xs={12} sm={12} md={4}>
                    <Box  {...chartsProps}>
                        {/* <PieChart {...successChartProps} /> */}
                        <CanvasJSChart options={optionsSuccess} />
                    </Box>
                </Grid>
            </Grid>
        </div>

    )
}