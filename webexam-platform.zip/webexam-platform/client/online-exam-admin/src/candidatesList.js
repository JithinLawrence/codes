import React from 'react';
import { Link } from "react-router-dom"; 

import Box from '@material-ui/core/Box';
import Divider from '@material-ui/core/Divider';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/Paper';
import Select from '@material-ui/core/Select';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { TextField } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import useAppContext from './AppContext'
import TablePagination from '@material-ui/core/TablePagination'
import EditSharpIcon from '@material-ui/icons/EditSharp';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import DoneIcon from '@material-ui/icons/Done';
import { red } from '@material-ui/core/colors';

import ListIcon from '@material-ui/icons/List';

import theme from './theme';
import ExamPlannerAdd from './examPlannerAdd';
import { useAlert } from 'react-alert';
import DeleteConfirm from './deleteConfirm';
import CandidateApproval from './candidateApproval';
import SwapVertSharpIcon from '@material-ui/icons/SwapVertSharp';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
    },
    sortControl: {
        align: "left"
    },
    btnprimary: {
        color: "white",
        textDecoration : "none"
    },
    cursorPinter:{
        cursor: 'pointer'
    },
    headerStyle5: {
        width: '5%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    headerStyle15: {
        width: '15%',
        maxWidth: '1px'
    },
    headerStyle20: {
        width: '20%',
        maxWidth: '1px'
    },
    headerStyle30: {
        width: '30%',
        maxWidth: '1px'
    },
    cellStyle5: {
        width: '5%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle15: {
        width: '15%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle20: {
        width: '20%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle30: {
        width: '30%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    }
});

export default function CandidatesList(){
    const classes = useStyles();
    const appContext = useAppContext();
    const alert = useAlert();    
    let count1=0;
    const Candidate_List_API = 'candidates/list';
    const GROUP_LIST_API = 'common/group';;
    const btnStatus='Pending';

    const [open, setOpen] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [sort, setSort] = React.useState('user_id');
    const [sortType, setSortType] = React.useState(true);
    const [search, setSearch] = React.useState('');
    const [groupData, setGroupData] = React.useState([]);
    const [gId, setGroupId] = React.useState(0);

    const [forceChange, setForceChange] = React.useState(false);
    const [candidatesList, setCandidatesList] = React.useState([]);
    const [rowData, setRowData] = React.useState([]);
    const [editOpen, setEditOpen] = React.useState(false);
    const [deleteOpen, setDeleteOpen] = React.useState(false);

    const handleClose = hasChange => {
        setOpen(false);
    };
    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
      };
    
    const handleChangeLimit = event => {
        setLimit(parseInt(event.target.value, 10));
        setPage(0);
      };

    const handleSearchChange = event =>{
          const val = event.target.value;
          setSearch(val);
      }
    const handleSearchKeyUp = event =>{
        getCandidatesList();
    }  


    const handleGroupChange = (event) => {
        setGroupId(event.target.value);
    };

    const handleSort = val =>{
        if(sort === val){
            setSortType(!sortType);
        }else{
            setSortType(sort === val);
        }
        setSort(val);
    }

    const handleDelete = hasChange => {
        if(hasChange){
            getCandidatesList()
        }
        setDeleteOpen(false);
    };

    const handleEdit = hasChange => {
        if(hasChange){
            getCandidatesList()
        }
        setEditOpen(false);
    };

    const handleClickOpenEdit = (editingRow) => {
        setRowData(editingRow)
        setEditOpen(true);
    };    

    const handleClickOpeDelete = (deletingRow) => {
        setRowData(deletingRow)
        setDeleteOpen(true);
    };  

    React.useEffect(()=>{
        getCandidatesList();
    },[sort, sortType, page, limit, forceChange, gId]);

    React.useEffect(() => { listGroup(); }, []); 

    function getCandidatesList(){
        let apiUrl = `${Candidate_List_API}?limit=${limit}&search=`+encodeURIComponent(search)+`&page=${page + 1}&sort=${sort}&type=${sortType}&grade=${gId}`

        appContext.getAxios().get(apiUrl).then((response)=>{
            setCandidatesList(response.data.result);
            setPage(response.data.currentPage-1);
            setCount(response.data.pagerInfo.count);

        },(error)=>{
            alert.error(error.response.data.message);    
        })
    }

    function listGroup() {
        appContext.getAxios().get(GROUP_LIST_API).then((response) => {
            setGroupData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }


    return (
        <div>
            <h1>Candidates List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar} display="flex" flexDirection="row-reverse">    
                <Box >
                    <FormControl className={classes.formControl}>
                        <TextField
                        label="Search"
                        id="titleSearch"
                        onChange = {handleSearchChange}
                        onKeyUp = {handleSearchKeyUp}
                        ></TextField>
                    </FormControl>
                    <FormControl className={classes.formControl}>
                        <InputLabel id="select-grade-label">Group</InputLabel>
                        <Select
                            labelId="select-grade-label"
                            id="select-grade"
                            onChange={handleGroupChange}
                        >
                            <MenuItem value="0">All</MenuItem>
                        {groupData.map((row) => (
                            <MenuItem key={row.gradeId} value={row.gradeId}>{row.name}</MenuItem>
                        ))}
                        </Select>
                    </FormControl>
                </Box>
            </Box>
            <Box className={classes.toolbar}>                
            </Box>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell className={classes.headerStyle5} align="left">No</TableCell>
                            <TableCell className={classes.headerStyle20} align="left">
                                First Name&nbsp;
                                <SwapVertSharpIcon fontSize="small" style={{'marginBottom':'-5px'}} className={classes.cursorPinter} onClick={() => {handleSort('first_name');}}/>
                            </TableCell>
                            <TableCell className={classes.headerStyle20} align="left">Last Name</TableCell>
                            <TableCell className={classes.headerStyle20} align="centlefter">Email</TableCell>
                            <TableCell className={classes.headerStyle10} align="left">Group</TableCell>
                            <TableCell className={classes.headerStyle10} align="left">Status</TableCell>
                            <TableCell className={classes.headerStyle10} align="center" style={{ whiteSpace : "nowrap" }}>Exam List</TableCell>
                            <TableCell className={classes.headerStyle5} align="center">Action</TableCell>
                        </TableRow>
                    </TableHead>
                    {candidatesList.length > 0 ?
                    <TableBody>
                        {candidatesList.map((candidate, index) => (
                            <TableRow key={candidate.userId}>
                                <TableCell className={classes.cellStyle5} align="left" component="th" scope="row">
                                    {(page * limit) + index + 1}
                                </TableCell>
                                <TableCell className={classes.cellStyle20} align="left">{candidate.firstName}</TableCell>
                                <TableCell className={classes.cellStyle20} align="left">{candidate.lastName}</TableCell>
                                <TableCell className={classes.cellStyle20} align="left">{candidate.email}</TableCell>
                                <TableCell className={classes.cellStyle10} align="left">{candidate.grade}</TableCell>
                                <TableCell className={classes.cellStyle10} align="left">{candidate.status}</TableCell>
                                <TableCell className={classes.cellStyle10} align="center"> 
                                    <Link to={`/studentsexam/${candidate.userId}`} style={{ textDecoration: 'none', color: "black" }}><ListIcon fontSize="default" /></Link></TableCell>
                                <TableCell className={classes.cellStyle5} align="center" style={{ whiteSpace : "nowrap" }}>{candidate.status === btnStatus && 
                                 <DoneIcon className={classes.cursorPinter}  fontSize="small" onClick={() => handleClickOpenEdit(candidate)} />} &nbsp;&nbsp;&nbsp;
                                 <DeleteSharpIcon className={classes.cursorPinter}  style={{ color: red[500] }} fontSize="small"  onClick={() => handleClickOpeDelete(candidate)} />
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>:''}
                </Table>
                {(candidatesList.length ==0 && search != "") ? 
                <div style={{'textAlign':"center"}}>Search result not found</div>
                :(candidatesList.length ==0) ? 
                <div style={{'textAlign':"center"}}>No result found</div>
                :''}
            </TableContainer>
            <TablePagination
            rowsPerPageOptions={[0]}
            component="div"
            count={count}
            rowsPerPage={limit}
            page={page}
            onChangePage={handleChangePage}
            onChangeRowsPerPage={handleChangeLimit}
            />
            <ExamPlannerAdd open={open} onClose={handleClose} />
            <CandidateApproval open={editOpen} onClose={handleEdit} apiLink={'candidates'} userId={rowData.userId} editText={'Do you want to approve candidate '+`${rowData.firstName}` +'?'}/>
            <DeleteConfirm open={deleteOpen} onClose={handleDelete} apiLink={'users'} deleteId={rowData.userId} deleteText={'Are you sure you want to delete this candidate?'} deleteMsg={'Candidate deleted successfully.'}/>
        </div>
    )
}