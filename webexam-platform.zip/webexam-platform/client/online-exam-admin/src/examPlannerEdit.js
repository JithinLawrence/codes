import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import { useAlert } from 'react-alert';
import useAppContext from './AppContext';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        width: 250,
        height:70,
        marginLeft: "10px"
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(1),

    },
    submitButton: {
        margin: theme.spacing(1),
    },
    passwordChange: {
        margin: theme.spacing(1),
        minWidth: "90px !important"
        // color : theme.palette.secondary.main,
        
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
}));

export default function UserEdit({ open, onClose, onPasswordChangeBegin, planner }) {
    const classes = useStyles();
    const alert = useAlert();
    const appContext = useAppContext();

    const ExamPlanner_Edit_API = 'users'

    const [firstName, setFirstName] = React.useState('');
    const [firstNameError, setFirstNameError] = React.useState(null);
    const [lastName, setLastName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [emailError, setEmailError] = React.useState(null);
    const [role, setRole] = React.useState('');
    const [roleError, setRoleError] = React.useState(null);
    const [disabled, setDisabled] = React.useState(false);
    const [lastNameError, setLastNameError] = React.useState(null);
   
    
    React.useEffect(() => {
            setFirstName(planner.firstName);
            setLastName(planner.lastName);
            setEmail(planner.email);
            setRole(planner.role);
        },
        [open]
      );
    const handleFirstNameChange = event => {
        const first = event.target.value;
        setFirstName(first);
        let errorMsg = null;
        errorMsg = firstName === '' ? "FirstName is required" : null;
        errorMsg = errorMsg == null ? (first.length > 50 ? "First name length must not exceed 50 characters" : null) : errorMsg;
        setFirstNameError(errorMsg);
    };

    const handleLastNameChange = event =>{
        const last = event.target.value;
        setLastName(last);
        let errorMsg = null;
        errorMsg = errorMsg == null ? (last.length > 50 ? "Last name length must not exceed 50 characters" : null) : errorMsg;
        setLastNameError(errorMsg)
        //setLastNameError(lastName === '' ? 'LastName is required' : null);
    };

    const handleEmailChange = event => {
        const email = event.target.value;
        let emailChk = new RegExp(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,15}/g).test(email);
        setEmail(email);
        let errorMsg = null;
        errorMsg = email === '' ? "Email is required" : null;
        errorMsg = errorMsg == null ? (email.length > 225 ? "Email length must not exceed 225 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (emailChk == false ? "Please enter a valid email." : null) : errorMsg;
        setEmailError(errorMsg);
    };

    const handleRoleChange = event => {
        const role = event.target.value;
        setRole(role);
        let errorMsg = null;
        errorMsg = role === '' ? "Role is required" : null;
        setRoleError(errorMsg);
    };

    const handleSubmit = event =>{
        event.preventDefault();
        
        if(firstNameError != null || emailError != null || roleError != null ){
            return;
        }
       
        setDisabled(true);
        setExamPlannerEdit(firstName,lastName,email,role).then((result)=>{
            if(!result.status){                
                alert.error(result.info.response.data.message);
            }else{
                reSetInput();
                alert.success("User updated successfully.");
            }
            setDisabled(false);
        });    
    };

    function reSetInput(){
        setFirstName('');
        setLastName('');
        setEmail('');       
        setRole('');        
        setFirstNameError(null);   
        setLastNameError(null);     
        setEmailError(null);        
        setRoleError(null);
       
     }
 
     function setExamPlannerEdit(firstName,lastName,email,role){       
         let data = JSON.stringify({
             firstName : firstName,
             lastName : lastName,
             email : email,                     
             role : role             
         }) 
        
       return appContext.getAxios().put(`${ExamPlanner_Edit_API}/${planner.userId}`,data).then((response)=>{             
             onClose(true);
             return {status:true, info : response}
         },(error)=>{
             return {status:false, info : error}
 
         });
     }

    return(
        <Dialog  minwidth="sm" open={open} onClose={() => {reSetInput();onClose(false);}} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Edit User</Typography>
                <IconButton size="small" className={classes.close} onClick={() => {reSetInput();onClose(false);}}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
            <form className={classes.form} onSubmit={handleSubmit}>
                <div >
                <Grid container>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                        
                        <TextField                        
                        label="First Name"                       
                        id="plannerFirstName"  
                        value={firstName}                                                                                           
                        onChange={handleFirstNameChange}
                        error={firstNameError !==null}
                        helperText = {firstNameError}
                        >
                        </TextField>
                    </FormControl>
                    </Grid>    
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                   
                        <TextField
                        label="Last Name"
                        id="plannerLastName"          
                        value = {lastName}
                        onChange={handleLastNameChange}
                        error={lastNameError !== null}
                        helperText={lastNameError}
                        >
                        </TextField>
                        </FormControl>
                    </Grid>    
                </Grid>
                <br></br>
                <Grid container>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                     
                            <TextField
                            type="email"
                            fullWidth
                            label="Email"
                            id="email"                  
                            value = {email}
                            onChange={handleEmailChange} 
                            error={emailError !==null}
                            helperText = {emailError}
                            >
                            </TextField>
                            </FormControl>
                    </Grid>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl} required>
                    <InputLabel id="select-role-label">Role</InputLabel>
                        <Select                            
                            id="select-role"
                            value = {role}
                            onChange={handleRoleChange}
                            error = {roleError !== null}                            
                             >
                            <MenuItem value="">
                                        <em>Select</em>
                            </MenuItem>
                            <MenuItem value={1}>Admin</MenuItem>
                            <MenuItem value={2}>Exam Planner</MenuItem>
                            <MenuItem value={4}>Support</MenuItem>
                        </Select>
                    </FormControl>

                    </Grid>
                </Grid>
                <br></br>
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>                        
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            color="default"
                            onClick={() => {reSetInput();onClose(false);}}
                        >
                            cancel
                        </Button>
                        <Button
                            variant="contained"                            
                            color="secondary"
                            className={classes.submitButton}  
                            type="submit"
                            disabled={disabled}                          
                        >
                            Submit
                        </Button>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.passwordChange}
                            onClick={() => onPasswordChangeBegin()}
                        >
                            Change Password
                        </Button>
                    </Box>
                </div >
                </form>
            </DialogContent>
        </Dialog>
    
    )
}