import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";


const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
        marginLeft: "10px"
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
}));

export default function DeleteConfirm({ open, onClose, apiLink, deleteId, deleteText, deleteMsg }) {
    const classes = useStyles();
    const alert = useAlert();

    const appContext = useAppContext();

    const [disabled, setDisabled] = React.useState(false);

    React.useEffect(() => {
    }, [open]); 

    const handleSubmit = event => {
        event.preventDefault();

        setDisabled(true)
        deleteSubmit(deleteId).then((result) => {
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                alert.success(deleteMsg);
            }
            setDisabled(false)
        });
    };

    function deleteSubmit(deleteId) {    
        return appContext.getAxios().delete(apiLink+"/"+deleteId).then((response) => {
              onClose(true);
        return {status: true, info: response};
        }, (error) => {
            return {status: false, info: error};
        });
    }

    return (
        <Dialog  maxWidth="lg" open={open} onClose={() =>  {onClose(false);}} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Delete</Typography>
                <IconButton size="small" className={classes.close} onClick={() =>  {onClose(false);}}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
                <h2 style={{'font-weight':'normal'}}>{deleteText}</h2>
            </DialogTitle>
            <DialogContent>
                <form className={classes.formControl} onSubmit={handleSubmit}>
                    
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type="submit"
                            disabled={disabled}
                        >
                            delete
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            onClick={() =>  {onClose(false);}}
                        >
                            cancel
                        </Button>
                    </Box>
                </form >
            </DialogContent>
        </Dialog>
    
    )
}
