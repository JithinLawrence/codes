import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import CreateOutlinedIcon from '@material-ui/icons/CreateOutlined';
import Paper from '@material-ui/core/Paper';
import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {
    MuiPickersUtilsProvider,
    KeyboardTimePicker,
    KeyboardDatePicker,
} from '@material-ui/pickers';


const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(1),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },

    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
    root: {
        display: "flex"
    },
    details: {
        display: "flex",
        flexDirection: "column"
    },
    content: {
        flex: "1 0 auto"
    },
    cover: {
        width: 151
    },
    profilePic: {
        borderStyle: "dotted"
    }

}));

export default function Register() {
    const classes = useStyles();
    const [selectedDOB, setSelectedDOB] = React.useState(null);
    const handleDOBChange = (date) => {
        setSelectedDOB(date);
    };

    return (
        <Box my={4} >
            <Typography variant="h4" component="h1" gutterBottom align="center">
                OnlineExamPlatform
            </Typography>
            <Container component="main" maxWidth="xs">
                <CssBaseline />
                <Paper>
                    <div className={classes.paper}>
                        <Avatar className={classes.avatar} >
                            <CreateOutlinedIcon />
                        </Avatar>
                        <Typography component="h1" variant="h5">
                            Sign up
                        </Typography>

                        <form className={classes.form} noValidate>
                            <Grid container spacing={2}>
                                <Grid item lg={6} >
                                    <Box p={1} my={4} mx={4} bgcolor="grey.300" className={classes.profilePic} > <Button > upload Profile picture</Button></Box>
                                </Grid>
                                <Grid item lg={6}>
                                    <div className={classes.details}>
                                        <Box className={classes.content}>
                                            <TextField
                                                variant="outlined"
                                                margin="normal"
                                                required

                                                id="first-name"
                                                label="First name"
                                                name="first-name"
                                                autoComplete="given-name"
                                                autoFocus
                                            />
                                            <TextField
                                                variant="outlined"
                                                margin="normal"
                                                required

                                                id="last-name"
                                                label="Last name"
                                                name="last-name"
                                                autoComplete="family-name"
                                            />
                                        </Box>

                                    </div>
                                </Grid>
                            </Grid>
                            <Grid container className={classes.root} spacing={2} >

                                <Grid item xs={12} sm={6} >
                                    <FormControl variant="outlined" fullWidth margin="normal" >
                                        <InputLabel id="student-registration-level-label" >level</InputLabel>
                                        <Select
                                            variant="outlined"
                                            labelId="student-registration-level-label"
                                            id="student-registration-level"
                                            label="Level"
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value="1">1</MenuItem>
                                            <MenuItem value="2">2</MenuItem>
                                            <MenuItem value="3">3</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} sm={6} >
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <Grid container>
                                            <KeyboardDatePicker
                                                margin="normal"
                                                id="start-date-picker-dialog"
                                                label="Date of Birth"
                                                format="MM/dd/yyyy"
                                                value={selectedDOB}
                                                onChange={handleDOBChange}
                                                KeyboardButtonProps={{
                                                    'aria-label': 'change date',
                                                }}
                                            />

                                        </Grid>
                                    </MuiPickersUtilsProvider>
                                </Grid>
                            </Grid>
                            <TextField
                                variant="outlined"
                                margin="normal"
                                required
                                fullWidth
                                id="email"
                                label="Email Address"
                                name="email"
                                autoComplete="email"
                            />
                            <TextField
                                variant="outlined"
                                margin="normal"
                                required
                                fullWidth
                                name="password"
                                label="Password"
                                type="password"
                                id="password"
                            />
                            <TextField
                                variant="outlined"
                                margin="normal"
                                required
                                fullWidth
                                name="password-confirm"
                                label="Confirm Password"
                                type="password"
                                id="password-confirm"
                            />
                            <Button
                                type="submit"
                                fullWidth
                                variant="contained"
                                color="primary"
                                className={classes.submit}
                            >
                                Sign up
                        </Button>
                        </form>
                    </div>
                    <Box mt={8}>
                    </Box>
                </Paper>
            </Container>
        </Box>
    );
}