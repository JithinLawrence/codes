import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import theme from "./theme";
import CloseIcon from "@material-ui/icons/Close";
import Divider from "@material-ui/core/Divider";
import Box from "@material-ui/core/Box";
import useAppContext from "./AppContext";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import Checkbox from "@material-ui/core/Checkbox";
import Button from "@material-ui/core/Button";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import ExamAssign from "./examAssign";
import { useAlert } from "react-alert";
import DialogActions from '@material-ui/core/DialogActions';


const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5),
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%"
    },
    sortControl: {
        align: "left",
    },
    btnprimary: {
        color: "white",
        textDecoration: "none",
    },
    addButton: {
        marginLeft: theme.spacing(1),
    },
    close: {
        position: "absolute",
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500],
    },
    dialog: {
        padding: theme.spacing(5),
    },
    imageUpload: {
        padding: '5px',
        color: 'white',
        backgroundColor: theme.palette.primary.main,
        // width:'100% !important'
    },
});

function resetInputs() {}

export default function ExamCandidateList({ open, onClose, row }) {
    const classes = useStyles();
    const GROUP_LIST_API = "common/listGrades";
    const CANDIDATES_LIST_API = "candidates";
    const ASSIGN_CANDIDATES_API = "exam_schedule/assignCandidate";
    const EXAM_SCHEDULE_API = "exam_schedule";
    
    const appContext = useAppContext();
    const [groupData, setGroupData] = React.useState([]);
    const [gradeId, setGradeId] = React.useState(0);
    const [group, setGroup] = React.useState("");
    const [candidates, setCandidates] = React.useState([]);
    const [usrIds, setUsrIds] = React.useState([]);
    const [disabled, setDisabled] = React.useState(false);
    const [examId, setExamId] = React.useState("");
    const [users, setUsers] = React.useState([]);
    const alert = useAlert();
    const [data, setData] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('user_id');
    const [sortType, setSortType] = React.useState(true);
    const [forceChange, setForceChange] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(2);
    const [page, setPage] = React.useState(0);

    const [csvUploaded, setCsvUploaded] = React.useState(false);
    const [file, setFile] = React.useState("");
    const [fileUrl, setFileUrl] = React.useState("");
    const [progress, setProgress] = React.useState(100);

    React.useEffect(() => {
        if (open) {
            setUsers([]);
            setData([]);
            loadGroup();
            loadCandidates();
            setCsvUploaded(false);
        }else if(!open){
            setUsers([]);//otherwise the data wont get cleared
            setData([]);//otherwise the data wont get cleared
        }
    }, [open, sort, sortType, page, limit, forceChange, search,gradeId]);

    const handleGroupChoose = (g_id, name) => {
        setGradeId(g_id);
        setGroup(name);
    };
    const handleGroupChange = (event) => {
        const val = event.target.value;
        setGradeId(val);
    };

    const handleAssign = e => {
        // e.preventDefault();
        const userIds = JSON.stringify({userId: users});  
         setDisabled(true);         
        appContext.getAxios().post(ASSIGN_CANDIDATES_API + "/"+row.scheduleId+"/"+row.examId, userIds).then((response) => {                
            setDisabled(false); 
            alert.success("Candidates assigned successfully.");
            onClose(response)
        }, (error) => {            
            alert.error(error.response.data.message);   
            setDisabled(false); 
            onClose()
        });   
       
    };

    function loadGroup() {
        appContext
            .getAxios()
            .get(
                GROUP_LIST_API +
                    "?search=" +
                    "&page=" +
                    "&limit=" +
                    "&sort=status" +
                    "&type=true"
            )
            .then(
                (response) => {
                    setGroupData(response.data.result);
                },
                (error) => {
                    console.log("error!");
                    alert.error(error.response.data.message);
                }
            );
    }

    function loadCandidates() {
        appContext
            .getAxios()
            .get(CANDIDATES_LIST_API + "/listCandidateToAssign" +"?search="+search +"&page="+(page+1) +"&limit="+limit+"&sort="+sort +"&type="+sortType+"&grade="+gradeId+"&scheduleId="+row.scheduleId)
            .then(
                (response) => {
                    const temp = response.data.result;
                    let tempQuestions = users;
                    temp.map((row) => {
                        if(row.checkedStatus){
                            tempQuestions.push(row.userId);
                        }
                    });
                    setUsers(tempQuestions)
                    setData(response.data.result);
                    setPage(response.data.currentPage-1)//to reset page in case deleting the last row of last page
                    setCount(response.data.pagerInfo.count);
                    // setCandidates(response.data.result);
                },
                (error) => {
                    console.log("error!");
                    //alert.error(error.response.data.message);
                }
            );
   }

    function handleSelect(e, userId) {
        const newQuestionIds = users?.includes(userId)
          ? users?.filter(id => id !== userId)
          : [...(users ?? []), userId];
        setUsers(newQuestionIds);
        return newQuestionIds;
      }

      const handleUploadCsv = (event) => {
        setFile(fileUrl);
        if (event.target.files.length > 0) {
            setProgress(0);
            setDisabled(true);
            setProgress(1);
            var formData = new FormData();
            let isInvalid = false;
            for (let i = 0; i < event.target.files.length; i++) {
                const fileName = event.target.files[i].name || "";
                if (fileName.endsWith(".csv")){
                    formData.append("file", event.target.files[i]);
                }else{
                    alert.error("Invalid file selected. Supports only .csv files");
                    isInvalid = true;
                }
            }
            if(isInvalid){
                setProgress(100)
                setDisabled(false);
                event.target.value = "";
                return;
            }
            setProgress(10);
            appContext
                .getAxios()
                .post(EXAM_SCHEDULE_API +"/uploadCandidateList" +"?scheduleId=" +row.scheduleId +"&examId=" +row.examId,formData).then((response) => {
                    setProgress(99);
                    setFileUrl(response.data.path);
                    setFile(response.data.path);
                    setDisabled(false);
                    setCsvUploaded(true);
                    // setFile(response.data.path);
                    setProgress(100);
                    alert.success("Candidates assigned successfully.");
                })
                .catch((error) => {
                    if(error.response){
                        alert.error(error.response.data.message);
                    } else {
                        alert.error("Upload error");
                    }
                    setDisabled(false);
                    setProgress(100)
                });
        }
    };

    return (
        <Dialog className={classes.dialog} fullWidth maxWidth="lg" open={open} onClose={() => onClose({})} aria-labelledby="add-questions-dialog-title">
        <DialogTitle id="add-videos-dialog-title" disableTypography>
            <Typography variant="h6" component="h2" gutterBottom>Assign Candidates</Typography>
            <IconButton size="small" className={classes.close} onClick={() => onClose({})}><CloseIcon /></IconButton>
            <Divider classes={{ root: classes.divider }} />
            <p margin={2.5} marginTop={4}>Assign candidate by csv upload?</p>      
        </DialogTitle>
        <DialogActions>        
        <Box className={classes.toolbar}>
            <Box flexGrow={1} margin={1.5} marginTop={-1} alignContent="flex-start">
                    <input
                         accept="csv/*"
                         className={classes.imageUpload}                        
                         id="rais-button-file"                                             
                         type="file"
                         onChange={handleUploadCsv}
                     />
            </Box>
            <Box >
                <FormControl className={classes.formControl}>
                    <InputLabel id="select-grade-label">Group</InputLabel>
                    <Select
                        labelId="select-group-label"
                        id="select-group"
                        value={gradeId}
                        onChange={handleGroupChange}
                       >
                            <MenuItem value="0">All</MenuItem>
                            {groupData.map((row) => (
                                <MenuItem key={row.gradeId} value={row.gradeId}>{row.name}</MenuItem>
                            ))}
                    </Select>
                </FormControl>
            </Box>
        </Box>

            </DialogActions>

            <DialogContent>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Select</TableCell>
                            <TableCell align="center">First Name</TableCell>
                            <TableCell align="center">Last Name</TableCell>
                            <TableCell align="center">Email</TableCell>
                            <TableCell align="left">Group</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {data.map((row) => (
                            <TableRow key={row.userId}>
                                 <TableCell padding="checkbox">
                                        <Checkbox 
                                        checked={users.includes(row.userId)} 
                                        onChange={(e) => handleSelect(e, row.userId)}/>
                                    </TableCell>
                                <TableCell align="center">
                                    {row.firstName}
                                </TableCell>
                                <TableCell align="center">
                                    {row.lastName}
                                </TableCell>
                                <TableCell align="center">
                                    {row.email}
                                </TableCell>
                                <TableCell align="left">
                                    {row.grade}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
             </DialogContent>
             <DialogActions className={classes.dialogActionsCenter}>
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                <Button
                    variant="contained"
                    color="secondary"
                    justify="right"
                     disabled={disabled}
                    className={classes.submitButton}
                    onClick={(e) => handleAssign(e)}
                >
                    Assign Candidate
                </Button>
                &nbsp;&nbsp;&nbsp;
                <Button
                    variant="contained"
                    className={classes.cancelButton}
                    onClick={() => onClose({})}
                >
                    Cancel
                </Button>
            </Box>
            </DialogActions>
        </Dialog>
    );
}
