import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import useAppContext from './../AppContext';
import ModalImage from "react-modal-image";
import Grid from '@material-ui/core/Grid';
import { CircularProgress } from '@material-ui/core';
import { useAlert } from "react-alert";
import Config from "./../Config";


const useStyles = makeStyles((theme) => ({
  chkbxMain: {
  },
  formControl: {
    margin: theme.spacing(3),
  },
  imageUpload: {
      padding: '10px',
      color: 'white',
      backgroundColor: theme.palette.primary.main,
  }
}));

export default function MultipleAnswerImage({ answerActive, toAnswer, fromAnswer, updated }) {
  const classes = useStyles();
  const alert = useAlert();
  const [optionCount, setOptionCount] = React.useState(0)
  const [checkedValue, setCheckedValue] = React.useState([])
  const [optionsArray, setOptionsArray] = React.useState([]);
  const appContext = useAppContext();
  const IMAGE_UPLOAD_API = "question/imageupload"
  const [disabled, setDisabled] = React.useState(false);

    const handleDeleteOption = id => {
        setOptionCount(optionCount-1);
    const list = [...optionsArray];
    list.splice(id, 1);
    setOptionsArray(list);    
    };

 const handleChange = e =>{
    const checkedValueTemp = checkedValue?.includes(e.target.value)
    ? checkedValue?.filter(val => val !== e.target.value)
    : [...(checkedValue ?? []), e.target.value];
    setCheckedValue(checkedValueTemp);
   
   optionsArray.forEach(function(part, index) {
       if(part.id == e.target.value){
        setOptionCount(optionCount-1)
        part.isAnswer = !part.isAnswer;
       }
   }, optionsArray);
   setOptionsArray(optionsArray);
 }
 const handleInputChange = (e, index) => {

    // if(e.target.files.length>0){
    //     const { name, value } = e.target;
    //     const list = [...optionsArray];
    //     list[index]["value"] = value;
    //     console.log(e.target.src)
    //  //    list[index]["src"] = "https://webexam-content-upload.s3-ap-northeast-1.amazonaws.com/content/question/1595949529156_f1f394.jpg";
     
     
    //     var formData = new FormData();
    //     for (let i = 0 ; i < e.target.files.length ; i++) {
    //         formData.append("file", e.target.files[i]);
    //     }
    //     //console.log(formData.getAll('file'));
    //     //var options = { content: formData };
    //     appContext.getAxios().post(IMAGE_UPLOAD_API, formData).then((response) => {
    //         console.log(response);
    //         list[index]["src"] = response.data.path[0];
    //     }).catch(error => {
    //         alert.error("Upload error");
    //         // alert.error(error.response.data.message);
    //         console.log(error)
    //     });
    //     setOptionsArray(list);
    // }

    if(e.target.files.length>0){
        setDisabled(true);
        // const { name, value } = e.target;
        var formData = new FormData();
        let isInvalid = false;
        for (let i = 0 ; i < e.target.files.length ; i++) {
            const fileName = e.target.files[i].name || "";
            const fileSize = e.target.files[i].size || 0;
            if (
                (fileName.endsWith(".png")) || 
                (fileName.endsWith(".PNG")) || 
                (fileName.endsWith(".jpeg")) || 
                (fileName.endsWith(".JPEG")) || 
                (fileName.endsWith(".jpg")) || 
                (fileName.endsWith(".JPG")) || 
                (fileName.endsWith(".gif")) ||
                (fileName.endsWith(".GIF"))
                ) {
                    if (fileSize > Config.imageMaxFileSize) {
                        alert.error("File size exceeded. Upload image smaller than 10 Mb");
                        isInvalid = true;
                    }
                    formData.append("file", e.target.files[i]);
            } else {
                alert.error("Invalid file");
                isInvalid = true;
            }
        }
        if(isInvalid){
            // setProgress(100)
            setDisabled(false);
            e.target.value = "";
            return;
        }
        appContext.getAxios().post(IMAGE_UPLOAD_API, formData).then((response) => {
            console.log(response);            
            optionsArray.forEach(function(part, index_2) {
                if(index == index_2){
                    console.log(part)
                    part.src = response.data.path[0];
                    // part.value = value;
                    console.log(part)
                }
            }, optionsArray);
            setOptionsArray(optionsArray);
            setDisabled(false);
        }).catch(error => {
            alert.error("Upload error");
            console.log(error)
            setDisabled(false);
        });
    }
 };

 const addCheckbox = () => {
   const nextId = Math.max.apply(Math, optionsArray.length == 0 ? [0] : optionsArray.map(function(o) { return o.id; }))+1;
   setOptionsArray([...optionsArray, {isAnswer: false, id: nextId, value: "", src: "" }]);
   setOptionCount(optionCount+1);
 };

 React.useEffect(() => {
   console.log('loading single answer type')
     if(answerActive == 4){
       console.log('in single answer type')
       let temp = [
           {isAnswer: false, id:1, src: ""}, 
           {isAnswer: false, id:2, src: ""},
           {isAnswer: false, id:3, src: ""}, 
           {isAnswer: false, id:4, src: ""}
       ];
       console.log(toAnswer)
       temp = toAnswer.length == 0 ? temp : toAnswer;
       if(toAnswer.length != 0){
            setCheckedValue(toAnswer.filter(ans=>ans.isAnswer).map(ans=> ans.id))
       }
       setOptionsArray(temp);
     } else {
       console.log('this should not be printed')
     }

 }, [answerActive, updated]);

 React.useEffect(() => {
    if(answerActive == 4){
        fromAnswer(optionsArray);
    }
 }, [optionsArray]);

  return (
    <div className={classes.chkbxMain}>
        <div>
         <TableContainer component={Paper}>
         <Table className={classes.table} aria-label="simple table">
            <TableHead>
              <TableRow>
              <TableCell>Option</TableCell>
              <TableCell>Correct Answer</TableCell>
              <TableCell>Option Image</TableCell>
              <TableCell>Preview Image</TableCell>
              <TableCell>Delete</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {optionsArray.map(function(item,index){
              return(
                <TableRow key={index} >
                <TableCell style={{'width': '15%'}}>option {index +1}</TableCell>
                <TableCell style={{'width': '15%'}}><Checkbox 
                required={checkedValue.length <= 0} 
                name={item.id + "checkOption"} 
                value={item.id}  
                checked = {item.isAnswer} 
                onChange={handleChange}> </Checkbox></TableCell>
                <TableCell style={{'width': '35%'}}><input
                        accept="image/*"
                        required={item.src == ""}
                        className={classes.imageUpload}
                        // style={{ backgroundColor: 'rgb(85, 108, 214)', padding: "10px", color: 'white' }}
                        id={index + "optionValue"}
                        onChange={e => handleInputChange(e, index)}
                        type="file"
                        src={item.src}
                        // name={index+"optionValue"}
                    /></TableCell>
                <TableCell style={{'width': '25%'}}>
                    <Grid container 
                    // className={classes.imageMargin} 
                    // spacing={2}
                    >
                        <Grid item xs={1} style={{display: (item.src!="") ? 'block' : 'none' }}>
                            <ModalImage
                            small={item.src}
                            large={item.src}
                            hideDownload={true}
                            // hideZoom={true}
                            />
                        </Grid>
                        {/* <Grid item xs={1} style={{display: (item.src!="") ? 'none' : 'block' }}>
                                <CircularProgress color="secondary" size={30}/>
                            </Grid> */}
                    </Grid>
                </TableCell>
                <TableCell style={{'width': '10%'}}>
                    <Button onClick={() => handleDeleteOption(index)} >
                        <DeleteSharpIcon disabled={disabled} style={{ color: red[500] }} fontSize="default" />
                    </Button>
                </TableCell>
                </TableRow>
              )
            })}        
            </TableBody>   
         </Table>
         </TableContainer>
         </div>
      <div>
        <br></br>
        <br></br>
      <Button variant="contained" color="primary" onClick={addCheckbox} >
          Add option
      </Button>
      </div>
      <br></br>
    <br></br>
    </div>
  );
}
