import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import { useAlert } from "react-alert";

const useStyles = makeStyles((theme) => ({
  chkbxMain: {
  },
  formControl: {
    margin: theme.spacing(3),
  }
}));

export default function MultipleAnswer({ answerActive, toAnswer, fromAnswer, updated }) {
  const classes = useStyles();
  const alert = useAlert();
  const [optionCount, setOptionCount] = React.useState(0)
  const [checkedValue, setCheckedValue] = React.useState([])
  const [optionsArray, setOptionsArray] = React.useState([]);

  const handleDeleteOption = id => {
    setOptionCount(optionCount-1);
   const list = [...optionsArray];
   list.splice(id, 1);
   setOptionsArray(list);    
 };

 const handleChange = e =>{
    const checkedValueTemp = checkedValue?.includes(e.target.value)
    ? checkedValue?.filter(val => val !== e.target.value)
    : [...(checkedValue ?? []), e.target.value];
    setCheckedValue(checkedValueTemp);
   
   optionsArray.forEach(function(part, index) {
       if(part.id == e.target.value){
        setOptionCount(optionCount-1)
        part.isAnswer = !part.isAnswer;
       }
   }, optionsArray);
   setOptionsArray(optionsArray);
 }
 const handleInputChange = (e, index) => {
   const { name, value } = e.target;
   const list = [...optionsArray];
   list[index]["value"] = value;
   setOptionsArray(list);
 };

 const addCheckbox = () => {
   const nextId = Math.max.apply(Math, optionsArray.length == 0 ? [0] : optionsArray.map(function(o) { return o.id; }))+1;
   setOptionsArray([...optionsArray, {isAnswer: false, id: nextId, value: "" }]);
   setOptionCount(optionCount+1);
 };

 React.useEffect(() => {
   console.log('loading single answer type')
     if(answerActive == 2){
       console.log('in single answer type')
       let temp = [
           {isAnswer: false, id:1, value:""}, 
           {isAnswer: false, id:2, value:""},
           {isAnswer: false, id:3, value:""}, 
           {isAnswer: false, id:4, value:""}
       ];
       console.log(toAnswer)
       temp = toAnswer.length == 0 ? temp : toAnswer;
       if(toAnswer.length != 0){
            setCheckedValue(toAnswer.filter(ans=>ans.isAnswer).map(ans=> ans.id))
       }
       setOptionsArray(temp);
     } else {
       console.log('this should not be printed')
     }

 }, [answerActive, updated]);

 React.useEffect(() => {
    if(answerActive == 2){
        fromAnswer(optionsArray);
    }
 }, [optionsArray]);

  return (
    <div className={classes.chkbxMain}>
        <div>
         <TableContainer component={Paper}>
         <Table className={classes.table} aria-label="simple table">
            <TableHead>
              <TableRow>
              <TableCell>Option</TableCell>
              <TableCell>Correct Answer</TableCell>
              <TableCell>Option text</TableCell>
              <TableCell>Delete</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {optionsArray.map(function(item,index){
              return(
                <TableRow key={index} >
                <TableCell>option {index +1}</TableCell>
                <TableCell><Checkbox 
                required={checkedValue.length <= 0} 
                name={item.id + "checkOption"} 
                value={item.id}  
                checked = {item.isAnswer} 
                onChange={handleChange}
                 > </Checkbox></TableCell>
                <TableCell><TextField 
                variant="outlined"
                margin="normal"
                required
                value={item.value}
                label="option text"
                name={index+"optionValue"}
                type="text"
                id={index + "optionValue"}
                onChange={e => handleInputChange(e, index)}
                ></TextField></TableCell>
                <TableCell><Button onClick={() => handleDeleteOption(index)} ><DeleteSharpIcon style={{ color: red[500] }} fontSize="default" /></Button></TableCell>
                </TableRow>
              )
            })}        
            </TableBody>   
         </Table>
         </TableContainer>
         </div>
      <div>
        <br></br>
        <br></br>
      <Button variant="contained" color="primary" onClick={addCheckbox} >
          Add option
      </Button>
      </div>
      <br></br>
    <br></br>
    </div>
  );
}
