import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Radio from '@material-ui/core/Radio';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import { useAlert } from "react-alert";


const useStyles = makeStyles((theme) => ({
  chkbxMain: {
  },
  formControl: {
    margin: theme.spacing(3),
  }
}));

export default function SingleAnswer({ answerActive, toAnswer, fromAnswer, updated }) {
  const classes = useStyles();
  const alert = useAlert();
  const [checkedValue, setCheckedValue] = React.useState(0)
  const [requiredRadio, setRequiredRadio] = React.useState(true)
  const [optionsArray, setOptionsArray] = React.useState([]);

   const handleDeleteOption = id => {
    const list = [...optionsArray];
    console.log(optionsArray)
    console.log(list)
    list.splice(id, 1);
    setOptionsArray(list);    
  };

  const handleChange = e =>{
    // handleSingleAnswerChange(e)
    setCheckedValue(e.target.value);
    console.log(e.target.value)
    
    optionsArray.forEach(function(part, index) {
        part.isAnswer = part.id == e.target.value;
    }, optionsArray);
    setRequiredRadio(false);
    setOptionsArray(optionsArray);
  }
  const handleInputChange = (e, index) => {
    const { name, value } = e.target;
    const list = [...optionsArray];
    list[index]["value"] = value;
    setOptionsArray(list);
  };

    // const handleSingleAnswerChange = (test) => {
    //     console.log(test)
    //     console.log(toAnswer)
    //     fromAnswer('from');
    // };

  const addCheckbox = () => {
    const nextId = Math.max.apply(Math, optionsArray.length == 0 ? [0] : optionsArray.map(function(o) { return o.id; }))+1;
    setOptionsArray([...optionsArray, {isAnswer: false, id: nextId, value: "" }]);
  };

  React.useEffect(() => {
    console.log('loading single answer type')
      if(answerActive == 1){
        console.log('in single answer type')
        let temp = [
            {isAnswer: false, id:1, value:""}, 
            {isAnswer: false, id:2, value:""},
            {isAnswer: false, id:3, value:""}, 
            {isAnswer: false, id:4, value:""}
        ];
        console.log(toAnswer)
        temp = toAnswer.length == 0 ? temp : toAnswer;
        if(toAnswer.length != 0){
             setCheckedValue(toAnswer.filter(ans=>ans.isAnswer).map(ans=> ans.id)[0])
             setRequiredRadio(!toAnswer.filter(ans=>ans.isAnswer).length == 1);
        }
        setOptionsArray(temp);
      } else {
        console.log('this should not be printed')
      }

  }, [answerActive, updated]);

  React.useEffect(() => {
     if(answerActive == 1){
         fromAnswer(optionsArray);
     }
  }, [optionsArray]);

  return (
    <div className={classes.chkbxMain}>
        <div>
         <TableContainer component={Paper}>
         <Table className={classes.table} aria-label="simple table">
            <TableHead>
              <TableRow>
              <TableCell>Option</TableCell>
              <TableCell>Correct Answer</TableCell>
              <TableCell>Option text</TableCell>
              <TableCell>Delete</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {optionsArray.map(function(item,index){
              return(
                <TableRow key={index} >
                <TableCell>option {index +1}</TableCell>
                <TableCell><Radio required={requiredRadio} name={item.id + "radioOption"} value={item.id}  checked = {checkedValue == item.id} 
                onChange={handleChange}
                 > </Radio></TableCell>
                <TableCell><TextField 
                variant="outlined"
                margin="normal"
                required
                label="option text"
                value={item.value}
                name={index+"optionValue"}
                type="text"
                id={index + "optionValue"}
                onChange={e => handleInputChange(e, index)}
                ></TextField></TableCell>
                <TableCell><Button onClick={() => handleDeleteOption(index)} >
                    <DeleteSharpIcon style={{ color: red[500] }} fontSize="default" />
                    </Button></TableCell>
                </TableRow>
              )
            })}        
            </TableBody>   
         </Table>
         </TableContainer>
         </div>
      <div>
          <br></br>
          <br></br>
      <Button variant="contained" color="primary" onClick={addCheckbox} >
          Add option
      </Button>
      </div>
    <br></br>
    <br></br>
    </div>
    
  );
}
