import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
    Typography,
    Grid,
    DialogContent,
    Dialog,
    IconButton,
    Divider,
} from "@material-ui/core";
import DialogTitle from "@material-ui/core/DialogTitle";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import Button from "@material-ui/core/Button";
import Box from "@material-ui/core/Box";
import CloseIcon from "@material-ui/icons/Close";
import "date-fns";
import DateFnsUtils from "@date-io/date-fns";
import {
    MuiPickersUtilsProvider,
    KeyboardTimePicker,
    KeyboardDatePicker,
} from "@material-ui/pickers";
import useAppContext from "./AppContext";
import ExamAssign from "./examAssign";
import { useAlert } from "react-alert";
import { set } from "date-fns";

const useStyles = makeStyles((theme) => ({
    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
    },
    cancelButton: {
        margin: theme.spacing(3),
    },
    submitButton: {
        margin: theme.spacing(3),
    },
    datePicker: {
        marginLeft: theme.spacing(3),
    },
    datePickerContainer: {
        marginTop: theme.spacing(3),
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
}));

export default function ExamSchedule({ open, onClose }) {
    const classes = useStyles();
    const alert = useAlert();

    const EXAM_SCHEDULE_API = "exam_schedule";
    const EXAM_LIST_API = "exams/listExams";
    const appContext = useAppContext();

    const [disabled, setDisabled] = React.useState(false);
    const [exam, setExam] = React.useState('');
    const [examError, setExamError] = React.useState(null);
    const [examData, setExamData] = React.useState([]);
    const [examId, setExamId] = React.useState("");
    const [examIdError, setExamIdError] = React.useState(null);

    const [startDate, setStartDate] = React.useState();
    const [startTime, setStartTime] = React.useState();
    const [startTimeError, setStartTimeError] = React.useState(null);

    const [endDate, setEndDate] = React.useState();
    const [endTime, setEndTime] = React.useState();
    const [endTimeError, setEndTimeError] = React.useState(null);
    const [type, setExamType] = React.useState('');
    const [scheduleType, setScheduleType] = React.useState('');

    React.useEffect(() => {
        if (open) {
            loadExam();
            // setEndDate(new Date("2020-08-08T08:08:08"));
            // setStartDate(new Date("2020-08-08T08:08:08"));
            // setEndTime(new Date("2020-08-08T08:08:08"));
            // setStartTime(new Date("2020-08-08T08:08:08"));
        }
    }, [open]);

    function loadExam() {
        appContext.getAxios().get(EXAM_LIST_API).then((response) => {
                    setExamData(response.data);
                },
                (error) => {
                    console.log("error!");
                    alert.error(error.response.data.message);
                }
            );
    }

    const handleExamChange = (event) => {
        const val = event.target.value;
        console.log("selected exam :"+ val );
        setExam(val);
        // examData.map((row) => (
        //     (row.examId === val? setScheduleType(row.scheduleType):'')
        // ))}
        let errorMsg = null;
        errorMsg = val === '' ? "Exam is required" : null;
        setExamError(errorMsg);
    };

    const handleStartDateChange = (startDate) => {
        setStartDate(startDate);
        handleStartTimeChange(startDate);
    };

    const handleStartTimeChange = (startTime) => {
        console.log("start time : "+startTime);
        setStartTime(startTime);
        let errorMsg = null;
        errorMsg =
            errorMsg == null
                ? startTime.length < 6
                    ? "Please check the start time"
                    : null
                : errorMsg;
        setStartTimeError(errorMsg);
    };

    const handleEndDateChange = (endDate) => {
        handleEndTimeChange(endDate);
        setEndDate(endDate);
    };

    const handleEndTimeChange = (endTime) => {
        setEndTime(endTime);
        let errorMsg = null;
        errorMsg =
            errorMsg == null
                ? endTime.length < 6
                    ? "Please check the start time"
                    : null
                : errorMsg;
        setEndTimeError(errorMsg);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        if (
            examError != null ||
            startTimeError != null ||
            endTimeError != null
        ) {
            return;
        }
        setDisabled(true);
        createExamSchedule(exam, startTime, endTime).then((result) => {
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                resetInputs();
                alert.success("Exam scheduled successfully.");
            }
            setDisabled(false);
        });
    };

    const handleExamChoose = (e_id) => {
        const newIds = examId?.includes(e_id)
            ? examId?.filter((id) => id !== e_id)
            : [...(examId ?? []), e_id];
        setExamId(newIds);
        let errorMsg = null;
        errorMsg = examId === [] ? "Exam is required" : null;
        setExamIdError(errorMsg);
    };

    function resetInputs() {
        setExam("");
        setExamError(null);
        setEndTime("");
        setStartTime("");
        setStartTimeError(null);
        setEndTimeError(null);
    }

    function createExamSchedule(examId, startTime, endTime) {
        console.log(" #start Time #" + startTime);
        let data = JSON.stringify({
            examId: examId,
            startTime: startTime,
            endTime: endTime            
        });
        //bug will be here
        console.log(" #data #" + data);

        return appContext
            .getAxios()
            .post(EXAM_SCHEDULE_API, data)
            .then(
                (response) => {
                    onClose(true);
                    return { status: true, info: response };
                },
                (error) => {
                    return { status: false, info: error };
                }
            );
    }

    return (
        <Dialog maxWidth="lg"  open={open}  onClose={() => { resetInputs(); onClose(false);}} aria-labelledby="add-schedule-dialog-title">
            <DialogTitle id="add-schedule-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>
                    Schedule Exam
                </Typography>
                <IconButton size="small" className={classes.close} onClick={() =>  {resetInputs();onClose(false);}}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
                <form className={classes.form} onSubmit={handleSubmit}>
                    <Grid container spacing={4}>
                        <Grid item sm={12} md={6}>
                        <label>Exam *</label>
                            <FormControl  variant="outlined" fullWidth margin="normal">
                                <InputLabel id="select-exam-label">Exam</InputLabel>

                                <Select
                                    variant="outlined"
                                    labelId="question-type-select-label"
                                    id="question-type-select"
                                    label="Exam"
                                    required
                                    disabled={disabled} 
                                    value={exam} 
                                    onChange={handleExamChange} 
                                    error={examError !== null}
                                >
                                    {examData.map((row) => (
                                        <MenuItem 
                                            key={row.examId}
                                            value={row.examId}>
                                            {row.name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <br></br>
                    </Grid>

                    <Grid container>
                        <Grid item sm={12} md={12} py={5}>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <Grid
                                    className={classes.datePickerContainer}
                                    container
                                >
                                    <KeyboardDatePicker
                                        margin="normal"
                                        className={classes.datePicker}
                                        id="start-date-picker-dialog"
                                        label="Exam schedule start date "
                                        value={startDate}
                                        format="yyyy-MM-dd"
                                        onChange={handleStartDateChange}
                                        KeyboardButtonProps={{
                                            "aria-label": "change date",
                                        }}
                                    />
                                    <KeyboardTimePicker                                      
                                        margin="normal"
                                        className={classes.datePicker}
                                        id="start-time-picker"
                                        label="Exam schedule start time "
                                        value={startTime}
                                        onChange={handleStartTimeChange}
                                        KeyboardButtonProps={{
                                            "aria-label": "change time",
                                        }}
                                    />
                                </Grid>
                            </MuiPickersUtilsProvider>
                        </Grid>

                        <Grid item sm={12} md={12}>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <Grid
                                    container
                                    className={classes.datePickerContainer}
                                >
                                    <KeyboardDatePicker
                                        margin="normal"
                                        className={classes.datePicker}
                                        id="end-date-picker-dialog"
                                        label="Exam schedule end date"
                                        format="yyyy-MM-dd"
                                        value={endDate}
                                        onChange={handleEndDateChange}
                                        KeyboardButtonProps={{
                                            "aria-label": "change date",
                                        }}
                                    />
                                    <KeyboardTimePicker
                                        className={classes.datePicker}
                                        margin="normal"
                                        id="end-time-picker"
                                        label="Exam schedule expire time"
                                        value={endTime}
                                        onChange={handleEndTimeChange}
                                        KeyboardButtonProps={{
                                            "aria-label": "change time",
                                        }}
                                    />
                                </Grid>
                            </MuiPickersUtilsProvider>
                        </Grid>
                    </Grid>

                    <Box
                        display="flex"
                        flex={1}
                        justifyContent="center"
                        m={1}
                        p={1}
                    >
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type="submit"
                            disabled={disabled}
                        >
                            Create Schedule
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            onClick={() => {resetInputs();onClose(false);}} >
                            cancel
                        </Button>
                    </Box>
                </form>
            </DialogContent>
        </Dialog>
    );
}
