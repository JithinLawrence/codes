import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import theme from "./theme";
import Divider from "@material-ui/core/Divider";
import Box from "@material-ui/core/Box";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import EditSharpIcon from "@material-ui/icons/EditSharp";
import DeleteSharpIcon from "@material-ui/icons/DeleteSharp";
import { red } from "@material-ui/core/colors";
import GroupAddRoundedIcon from "@material-ui/icons/GroupAddRounded";
import { Link } from "react-router-dom";
import useAppContext from "./AppContext";
import { TextField } from "@material-ui/core";
import TablePagination from "@material-ui/core/TablePagination";
import ExamSchedule from "./examScheduleCreate";
import ExamScheduleEdit from "./examScheduleEdit";
import DeleteConfirm from "./deleteConfirm";
import ExamCandidateList from "./examCandidateList";
import SwapVertSharpIcon from '@material-ui/icons/SwapVertSharp';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5),
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    toolbar: {
        display: "flex",
        width: "100%",
    },
    sortControl: {
        align: "left",
    },
    btnprimary: {
        color: "white",
        textDecoration: "none",
    },
    cursorPinter:{
        cursor: 'pointer'
    },
    headerStyle5: {
        width: '5%',
        maxWidth: '1px'
    },
    headerStyle10: {
        width: '10%',
        maxWidth: '1px'
    },
    headerStyle50: {
        width: '50%',
        maxWidth: '1px'
    },
    headerStyle15: {
        width: '15%',
        maxWidth: '1px'
    },
    cellStyle5: {
        width: '5%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle10: {
        width: '10%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle50: {
        width: '50%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    },
    cellStyle15: {
        width: '15%',
        maxWidth: '1px',
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    }
});

function createData(title, scheduleStart, scheduleEnd) {
    return { title, scheduleStart, scheduleEnd };
}

const rows = [
    createData("Exam 1", "1/02/2020 9:00", " 5/02/2020 19:00"),
    createData("Exam 2", "3/02/2020 9:00", "5/02/2020 19:00"),
    createData("Exam 3", "1/05/2020 9:00", "5/02/2020 19:00"),
    createData("Exam 4", "15/02/2020 9:00", "25/02/2020 19:00"),
    createData("Exam 5", "1/07/2020 9:00", "5/08/2020 19:00"),
];

export default function SchudeleExamList() {
    const classes = useStyles();
    const appContext = useAppContext();
    const EXAM_SCHEDULE_LIST_API = "exam_schedule";

    const [createOpen, setCreateOpen] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [search, setSearch] = React.useState("");
    const [sort, setSort] = React.useState("schedule_id");
    const [sortType, setSortType] = React.useState(true);

    const [forceChange, setForceChange] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [editOpen, setEditOpen] = React.useState(false);
    const [assignOpen, setAssignOpen] = React.useState(false);
    const [deleteOpen, setDeleteOpen] = React.useState(false);
    const [rowData, setRowData] = React.useState([]);

    const handleSearchChange = (event) => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleCloseCreate = (hasChange) => {
        if (hasChange) {
            setSort("schedule_id");
            setSortType(true);
            setPage(0);
            setForceChange(!forceChange); //after saving count not incremented properly. so changing this value reloads the method listSchedule
        }
        setCreateOpen(false);
    };
    const handleClickOpenCreate = () => {
        setCreateOpen(true);
    };

    const handleCloseEdit = (hasChange) => {
        if (hasChange) {
            listSchedules();
        }
        setEditOpen(false);
    };
    const handleCloseAssign = (hasChange) => {
        if (hasChange) {
            listSchedules();
        }
        setAssignOpen(false);
    };

    const handleDelete = (hasChange) => {
        if (hasChange) {
            listSchedules();
        }
        setDeleteOpen(false);
    };
    const handleClickOpenEdit = (editingRow) => {
        setRowData(editingRow);
        setEditOpen(true);
    };
    const handleClickOpeDelete = (deletingRow) => {
        setRowData(deletingRow);
        setDeleteOpen(true);
    };

    const handleClickOpenAssign = (editingRow) => {
        setRowData(editingRow);
        setAssignOpen(true);
    };

    const handleSort = (val) => {
        if (sort == val) {
            setSortType(!sortType);
        } else {
            setSortType(sort == val);
        }
        setSort(val);
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeLimit = (event) => {
        setLimit(parseInt(event.target.value, 10));
        setPage(0);
    };

    React.useEffect(() => {
        listSchedules();
    }, [sort, sortType, page, limit, forceChange, search]);

    function listSchedules() {
        appContext.getAxios().get(EXAM_SCHEDULE_LIST_API +"/list" +"?page=" +(page + 1) +"&limit=" +limit 
        +"&search=" +encodeURIComponent(search) +"&type=" +sortType +"&sort=" +sort).then((response) => {
                    console.log("##" + response.data.result);
                    setData(response.data.result);
                    setPage(response.data.currentPage - 1); //to reset page in case deleting the last row of last page
                    setCount(response.data.pagerInfo.count);
                },
                (error) => {
                    //alert.error(error.response.data.message);
                }
            );
    }

    return (
        <div>
            <h1>Exam Schedule List</h1>
            <Divider classes={{ root: classes.divider }} />
            <Box className={classes.toolbar}>
                <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                    <Button
                        variant="contained"
                        color="secondary"
                        justify="right"
                        onClick={handleClickOpenCreate}
                    >
                        Create Schedule
                    </Button>
                </Box>
                <Box>
                    <FormControl className={classes.formControl}>
                        <TextField
                            label="Search"
                            id="search"
                            value={search}
                            onChange={handleSearchChange}
                        ></TextField>
                    </FormControl>
                </Box>
            </Box>

            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell className={classes.headerStyle5} align="left">No</TableCell>
                            <TableCell className={classes.headerStyle50} align="left" >
                                Exam&nbsp;
                                <SwapVertSharpIcon fontSize="small" style={{'marginBottom':'-5px'}} className={classes.cursorPinter} onClick={() => {handleSort('schedule_id');}}/>
                            </TableCell>
                            <TableCell className={classes.headerStyle15} align="left">Schedule Start</TableCell>
                            <TableCell className={classes.headerStyle15} align="left">Schedule End</TableCell>
                            <TableCell className={classes.headerStyle15} align="center">Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    {data.length > 0 ?
                    <TableBody>
                        {data.map((row, index) => (
                            <TableRow key={row.scheduleId}>
                                <TableCell align="left" className={classes.cellStyle5} component="th" scope="row">
                                    {(page * limit) + index + 1}
                                </TableCell>
                                <TableCell align="left" className={classes.cellStyle50} component="th" scope="row">
                                    {row.examName}
                                </TableCell>
                                <TableCell align="left" style={{ whiteSpace : "nowrap" }}>
                                    {row.startTime}
                                </TableCell>
                                <TableCell align="left" style={{ whiteSpace : "nowrap" }}>
                                    {row.endTime}
                                </TableCell>
                                <TableCell className={classes.cellStyle15} align="center" style={{ whiteSpace : "nowrap" }}>
                                    {( row.createdBy ==
                                        localStorage.getItem("userId") ||
                                        1 == localStorage.getItem("role") ) && (
                                        <GroupAddRoundedIcon
                                          color= {row.examType ===1 ?'disabled':''}
                                            className={row.examType ===2 ?classes.cursorPinter:''}
                                            fontSize="small"
                                            onClick={row.examType ===2 ?() =>
                                                handleClickOpenAssign(row)
                                            :''}
                                        />
                                    )}
                                    &nbsp;&nbsp;&nbsp;
                                    {(row.createdBy ==
                                        localStorage.getItem("userId") ||
                                        1 ==
                                            localStorage.getItem("role")) && (
                                        <EditSharpIcon
                                            className={classes.cursorPinter}
                                            fontSize="small"
                                            onClick={() =>
                                                handleClickOpenEdit(row)
                                            }
                                        />
                                    )}
                                    &nbsp;&nbsp;&nbsp;
                                    {(row.createdBy ==
                                        localStorage.getItem("userId") ||
                                        1 ==
                                            localStorage.getItem("role")) && (
                                        <DeleteSharpIcon
                                            className={classes.cursorPinter}
                                            style={{ color: red[500] }}
                                            fontSize="small"
                                            onClick={() =>
                                                handleClickOpeDelete(row)
                                            }
                                        />
                                    )}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody> :''}
                </Table>
                {(data.length ==0 && search != "") ? 
                <div style={{'textAlign':"center"}}>Search result not found</div>
                :(data.length ==0) ? 
                <div style={{'textAlign':"center"}}>No result found</div>
                :''}
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[0]}
                component="div"
                count={count}
                rowsPerPage={limit}
                page={page}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeLimit}
            />
            <ExamSchedule open={createOpen} onClose={handleCloseCreate} />
            <ExamScheduleEdit
                open={editOpen}
                onClose={handleCloseEdit}
                row={rowData}
            />

            <ExamCandidateList
                open={assignOpen}
                onClose={handleCloseAssign}
                row={rowData}
            />
            <DeleteConfirm 
            open={deleteOpen} 
            onClose={handleDelete} 
            apiLink={'exam_schedule'} 
            deleteId={rowData.scheduleId} 
            deleteText={'Are you sure you want to delete this Schedule ?'} 
            deleteMsg={'Schedule deleted successfully.'}/>
        </div>
    );
}
