import React from 'react';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import { Typography, Grid, IconButton } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import DeleteSharpIcon from '@material-ui/icons/DeleteSharp';
import { red } from '@material-ui/core/colors';
import ExamCatogoryEdit from './examCatogoryEdit'
import ExamAddQuestions from './examAddQuestions';
import PageviewRoundedIcon from '@material-ui/icons/PageviewRounded';
import useAppContext from './AppContext';
import { Link, useParams } from 'react-router-dom';
import { useAlert } from "react-alert";
import { useHistory } from "react-router-dom";
import QuestionBankAddQuestions from './questionBankAddQuestions';
import Input from '@material-ui/core/Input';
import Divider from '@material-ui/core/Divider';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Chip from '@material-ui/core/Chip';

const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 250,
    },
    addButton: {
        marginTop: theme.spacing(3),
    },
    previewButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    textFields: {
        whiteSpace: "normal",
        width:400
    },
    TextareaAutosizeError: {
        color: '#ff1744',
        margin: 0,
        fontSize: '0.75rem',
        marginTop: '3px',
        textAlign: 'left',
        fontFamily: ['"Roboto"', '"Helvetica"', '"Arial"', 'sans-serif'],
        fontWeight: 400,
        lineHeight: 1.66,
        letterSpacing: '0.03333em'
    }
}));

function getStyles(name, personName, theme) {
    return {
    fontWeight:
        personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
    };
}

export default function QuestionBankEdit() {
    const classes = useStyles();
    const alert = useAlert();
    const theme = useTheme();

    const EXAM_API = 'question_bank';
    const Question_List_API = 'question_bank/list_questions'
    const CATEGORY_LIST_API = 'common/category';
    const GROUP_LIST_API = 'common/group';
    const appContext = useAppContext();

    let catga = [];
    let grpa = [];
    let categoryArray;
    let groupArray;
    let errorMsg1 = null, errorMsg2 =null;

    const { questionBankId } = useParams();
    const [open, setOpen] = React.useState(false);
    const [catOpen, setCatOpen] = React.useState(false);
    const [catOpenedId, setCatOpenedId] = React.useState(false);

    const [disabled, setDisabled] = React.useState(false);
    const [name, setName] = React.useState('');
    const [currentName, setCurrentName] = React.useState('');
    const [nameError, setNameError] = React.useState(null);
    const [categoryData, setCategoryData] = React.useState([]);
    const [categoryId, setCategoryId] = React.useState([]);
    const [categoryIdError, setCategoryIdError] = React.useState(null);
    const [categoryName, setCategoryName] = React.useState([]);
    const [groupId, setGroupId] = React.useState([]);
    const [groupIdError, setGroupIdError] = React.useState(null);
    const [groupName, setGroupName] = React.useState([]);
    const [groupData, setGroupData] = React.useState([]);
    const [description, setDescription] = React.useState('');
    const [categories, setCategories] = React.useState([]);
    const [value, setValue] = React.useState([]);
    const [groupValue, setGroupValue] = React.useState([]);
    const [descriptionError, setDescriptionError] = React.useState(null);
    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
      PaperProps: {
        style: {
          maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
          width: 250,
        },
      },
    };

    const handleNameChange = event => {
        const val = event.target.value;
        setName(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Exam name is required" : null;
        errorMsg = errorMsg == null ? (val.length > 100 ? "Exam name length must not exceed 100 characters" : null) : errorMsg;
        setNameError(errorMsg)
    };

    const handleDescriptionChange = event => {
        const val = event.target.value;
        setDescription(val);
        let errorMsg = null;
        errorMsg = errorMsg == null ? (val.length > 2000 ? "Description length must not exceed 2000 characters" : null) : errorMsg;
        setDescriptionError(errorMsg)
    };

    const handleGroupsChange = (event,value) => { 
        console.log("Group value" +value);       
        let results = value.map(b => b.gradeId);
         console.log("Group " +results);
         setGroupId(results); 
         setGroupValue(value);
         let errorMsg = null;
         errorMsg = groupId === [] ? "Group is required" : null;
         console.log(errorMsg)
         setGroupIdError(errorMsg)       
     };

    const handleCategoryChange = (event, value) => {    
        let result = value.map(a => a.categoryId);
         setCategoryId(result);
         setValue(value); 
         let errorMsg = null;
         errorMsg = categoryId === [] ? "Category is required" : null;
         console.log(errorMsg)
         setCategoryIdError(errorMsg)       
     };

    const handleClose = examQuestionReceived => {
        if(Object.keys(examQuestionReceived).length != 0){           
            listQuestions(examQuestionReceived.data.questionBankId) 
        }
        setOpen(false);
    };
    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleCatClick = (categoryId) => {
        setCatOpenedId(categoryId)
        setCatOpen(true);
    };
    const handleDelete = (questionId) => {
        appContext.getAxios().delete(EXAM_API+"/"+questionBankId+"/"+questionId).then((response) => {
            listQuestions(questionBankId);
        }, (error) => {
            console.log(error)
        });
    };


    let history = useHistory();

    const handleSubmit = event => {
        event.preventDefault();


        if(categoryId.length ==0){            
            errorMsg2 = null;
            errorMsg2 = categoryId.length == 0 ? "Category is required" : null;
            setCategoryIdError(errorMsg2)
        }

        if(groupId.length ==0){
            errorMsg1 = null;
            errorMsg1 = groupId.length ==0 ? "Group is required" : null;
            setGroupIdError(errorMsg1) 
        }

        if(nameError != null || errorMsg1 != null || errorMsg2 != null ){
            return;
        }

        setDisabled(true)//description, passMark, totalMark
        createExam(name, description).then((result) => {
            setDisabled(false)
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                resetInputs();
                alert.success("QuestionBank updated successfully.");
                history.push('/questionbankList')
            }
        });
    };

    function resetInputs(){
        setName('');
        setNameError(null);
    }

    React.useEffect(() => {
        listQuestions(questionBankId);   
        listCategory(); 
        listGroup();    
        appContext.getAxios().put(EXAM_API+"/initEdit/"+questionBankId).then((response) => {
            if(Object.keys(response).length != 0){                
                getCategory(response.data.categoryIds, catga);
                getGroups(response.data.gradeIds, grpa);             
                setName(response.data.title)
                setCurrentName(response.data.name)
                setDescription(response.data.description)               
            }
        }, (error) => {
            alert.error(error.response.data.message);
            history.push('/questionbankList')
        });
    }, [questionBankId]);

    function listQuestions(questionBankId){
        appContext.getAxios().get(Question_List_API+'?questionBankId='+questionBankId).then((response) => {
            setCategories(response.data);          
        }, (error) => {
            alert.error(error.response.data.message);
        }); 
    }

    function listCategory() {
        appContext.getAxios().get(CATEGORY_LIST_API).then((response) => {
            catga = response.data;
            setCategoryData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function listGroup() {
      return  appContext.getAxios().get(GROUP_LIST_API).then((response) => {
          grpa = response.data;
            setGroupData(response.data);
        }, (error) => {
            alert.error(error.response.data.message);
        });
    }

    function getCategory(catg, catga){
         categoryArray = catga.filter(function (el) {
            return catg.includes(el.categoryId);
          });
        const categoryIds = categoryArray.map(a => a.categoryId);
        const categoryNames = categoryArray.map(a => a.name);
        setCategoryId(categoryIds);
        setCategoryName(categoryNames);
        setValue(categoryArray);
    }

    function getGroups(grps, grpa){
         groupArray = grpa.filter(function (el) {
            return grps.includes(el.gradeId);
          });
        const gradeIds = groupArray.map(a => a.gradeId);
        const gradeNames = groupArray.map(a => a.name);
        setGroupId(gradeIds);
        setGroupName(gradeNames);
        setGroupValue(groupArray);
    }

    function createExam(name, description) {
        let data = JSON.stringify({
            title: name,
            description: description,
            categories: categoryId,
            groups: groupId  
            
        })
        return appContext.getAxios().put(EXAM_API+"/"+questionBankId, data).then((response) => {            
            return {status: true, info: response};
        }, (error) => {
            return {status: false, info: error};
        });
    }

    return (
        <div>
            <h1>Edit Question Bank</h1>
            <Divider classes={{ root: classes.divider }} />
         <form className={classes.form} onSubmit={handleSubmit}>
            <h1>{currentName}</h1>
            <Grid container>
                <Grid item sm={12} md={3}>
                    <FormControl className={classes.formControl}>
                        <TextField 
                        required 
                        id="name" 
                        className={classes.inputField}
                        label="QuestionBank Title" 
                        disabled={disabled} 
                        value={name} 
                        onChange={handleNameChange} 
                        error={nameError !== null} 
                        helperText={nameError}
                        />
                    </FormControl>
                </Grid>
              
                <Grid item sm={12} md="auto">
                            <FormControl className={classes.form} required>
                                <Autocomplete 
                                required  
                                multiple
                                limitTags={2}
                                id="tags-outlined"
                                value={groupValue}                                
                                options={groupData}
                                getOptionLabel={(groupData) => groupData.name}                                      
                                onChange={(event, value) =>handleGroupsChange(event,value)}                      
                                filterSelectedOptions
                                renderInput={(params) => (
                                <TextField 
                                 error={groupIdError !== null }
                                 helperText={groupIdError}
                                className={classes.textFields}
                                    {...params}
                                    variant="outlined"                              
                                    label="Group *"                                    
                                />   
                            )}
                        />
                            </FormControl>
                            </Grid>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <Grid item sm={12} md="auto">
                            <FormControl className={classes.form}>
                                <Autocomplete                                
                                multiple
                                limitTags={2}
                                id="tags-outlined"
                                value={value}
                                options={categoryData}
                                getOptionLabel={(categoryData) => categoryData.name}
                                onChange={(event, newValue) =>handleCategoryChange(event, newValue)}                     
                                filterSelectedOptions
                                renderInput={(params) => (
                                <TextField                                
                                error={categoryIdError !== null }
                                helperText={categoryIdError} 
                                className={classes.textFields}
                                    {...params}
                                    variant="outlined"                              
                                    label="Category *"                                    
                                />
                            )}
                        />
                            </FormControl>
                            </Grid>
            </Grid>
           
                    <Box>
                        <br></br>
                        <TextField
                            variant="outlined"
                            margin="normal"
                            id="description"
                            label="Description"
                            name="answer"
                            disabled={disabled}
                            value={description} 
                            onChange={handleDescriptionChange} 
                            fullWidth
                            multiline={true}
                            rows={2}
                            error={descriptionError !== null }
                            helperText={descriptionError}
                        />
                    </Box>
            <Grid container>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.addButton}
                    onClick={handleClickOpen}
                >
                    Add Question
                    </Button>
            </Grid>
            <TableContainer component={Paper}>
                <Table className={classes.table} aria-label="simple table">
                    <TableHead>
                    <TableRow>
                            <TableCell><b>Title</b></TableCell>
                            <TableCell align="right"><b>Category</b></TableCell>
                            <TableCell align="right"><b>Group</b></TableCell>
                            <TableCell align="right"><b>Level</b></TableCell>
                            <TableCell align="right"><b>Mark</b></TableCell>
                            <TableCell align="right"><b>Action</b></TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {categories.map((row) => (
                            <TableRow key={row.questionId}>
                                <TableCell>{row.title}</TableCell>
                                <TableCell align="right">{row.category}</TableCell>
                                <TableCell align="right">{row.group}</TableCell>
                                <TableCell align="right">{row.level}</TableCell>
                                <TableCell align="right">{row.mark}</TableCell>
                                <TableCell align="right"><DeleteSharpIcon style={{ color: red[500] }} fontSize="small" onClick={()=>handleDelete(row.questionId)}/></TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            
            <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                <Link style={{ textDecoration: 'none', color: "black" }} to="/questionbankList" className={classes.btnprimary} >
                    <Button
                        variant="contained"
                        className={classes.cancelButton}
                    >
                        Cancel
                    </Button>
                </Link>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.submitButton}
                    type="submit"
                    disabled={disabled}
                >
                    Update
                </Button>

            </Box>
            <QuestionBankAddQuestions open={open} onClose={handleClose} questionBankId={questionBankId}/>
            {/* <ExamCatogoryEdit open={catOpen} onClose={handleCatClose} questionBankId={questionBankId} categoryId={catOpenedId}/> */}
        </form >
    </div>
    );
}