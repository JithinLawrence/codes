import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import { useAlert } from 'react-alert';
import useAppContext from './AppContext';


const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        width: 350,
        height:100,
        marginLeft: "10px"
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
}));

export default function UserPasswordChange({ open, onClose, planner }) {
    const classes = useStyles();
    const alert = useAlert();
    const appcontext = useAppContext();

    const Examplanner_paawordchange_API = 'users/changeUserPassword'

    const [disabled, setDisabled] = React.useState(false);
    const [oldPassword, setOldPassword] = React.useState('');
    const [oldPasswordError, setOldPasswordError] = React.useState(null);
    const [newPassword, setNewPassword] = React.useState('');
    const [newPasswordError, setNewPasswordError] = React.useState(null);
    const [confirmPassword, setConfirmPassword] = React.useState('');
    const [confirmPasswordError, setConfirmPasswordError] = React.useState(null);

    // const handleOldPasswordChange = event =>{
    //     const oldPass = event.target.value;
    //     setOldPassword(oldPass);
    //     setOldPasswordError(oldPass === '' ? 'Current Password is required' : null);
    // };

    const handleNewPasswordChange = event =>{
        const newPass = event.target.value;
        setNewPassword(newPass);
        let test = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~])[a-zA-Z0-9 \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~]+$").test(newPass);  
        let errorMsg = null;
        errorMsg = newPass === '' ? "New Password is required" : null;
        errorMsg = errorMsg == null ? (newPass.length > 30 ? "Password length must not exceed 30 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (newPass.length < 8 ? "Password length must be 8 or more characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (test == false ? "Password must contain one lowercase letter, uppercase letter, digit and special character." : null) : errorMsg;
        setNewPasswordError(errorMsg);
    };

    const handleConfirmPasswordChange =event =>{
        const confPass = event.target.value;
        setConfirmPassword(confPass);
        let test = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~])[a-zA-Z0-9 \\!\"#\\$%&'\\(\\)\\*\\+,\\-\\.\\/\\:;\\<\\=\\>\\?@\\[\\\\\\]\\^_`\\{\\|\\}~]+$").test(confPass);  
        let errorMsg = null;
        errorMsg = confPass === '' ? "Confirm password is required" : null;
        errorMsg = errorMsg == null ? (confPass.length > 30 ? "Password length must not exceed 30 characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (confPass.length < 8 ? "Password length must be 8 or more characters" : null) : errorMsg;
        errorMsg = errorMsg == null ? (test == false ? "Password must contain one lowercase letter, uppercase letter, digit and special character." : null) : errorMsg;
        setConfirmPasswordError(errorMsg);
    };

    const handleSubmit = event =>{
        event.preventDefault();

        if(newPasswordError != null || confirmPasswordError != null){          
            return;
        }

        if(newPassword !== confirmPassword){
            setConfirmPasswordError('Confirm password should be same as new password');
            return;
        }

        setDisabled(true);
        UserPasswordChange(newPassword,confirmPassword).then((result)=>{
            if(!result.status){
                console.log(result);
                console.log(result.response);
                alert.error(result.info.response.data.message);
            }else{
                reSetInput();
                alert.success("Password changed successfully");
            }
            setDisabled(false);
        });
    }

    function reSetInput(){
    //    setOldPassword('');
       setNewPassword('');
       setConfirmPassword('');
    //    setOldPasswordError(null);
       setNewPasswordError(null);
       setConfirmPasswordError(null); 
    }

    function UserPasswordChange(newPassword, confirmPassword){
        let data = JSON.stringify({
            // oldPassword : oldPassword,
            newPassword : newPassword,
            confirmNewPassword : confirmPassword
        })

        return appcontext.getAxios().put(`${Examplanner_paawordchange_API}/${planner.userId}`, data).then((response)=>{
            onClose();
            return {status:true , info :response};
        },(error)=>{
            return {status:false, info:error};
        });

    }

    return(
        <Dialog  minWidth="sm" open={open} onClose={() => onClose()} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Change User Password</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose()}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
            <form className={classes.form} onSubmit={handleSubmit}>
                <div >
                {/* <Grid container>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                        
                            <TextField
                            type="Password"
                            fullWidth
                            label="Old Password"
                            id="oldPassword"
                            onChange = {handleOldPasswordChange}
                            error = {oldPasswordError !== null}
                            helperText = {oldPasswordError}
                            >
                            </TextField>
                            </FormControl>
                    </Grid>                  
                </Grid>  */}

                <Grid container>                    
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl} required>                    
                            <TextField
                            required
                            type="Password"
                            fullWidth
                            value={newPassword}
                            label="New Password"
                            id="newPassword"
                            onChange = {handleNewPasswordChange}
                            error = {newPasswordError !== null}
                            helperText = {newPasswordError}
                            >
                            </TextField>
                            </FormControl>
                    </Grid>
                </Grid>

                <Grid container>                    
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl}>                   
                            <TextField
                            required
                            type="Password"
                            fullWidth
                            value={confirmPassword}
                            label="Confirm Password"
                            id="confirmPassword"
                            onChange = {handleConfirmPasswordChange}
                            error = {confirmPasswordError !== null}
                            helperText = {confirmPasswordError}
                            >
                            </TextField>
                            </FormControl>
                    </Grid>
                </Grid>

                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type = "submit"
                            disabled = {disabled}
                        >
                            Submit
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            color="default"
                            onClick={() => onClose()}
                        >
                            cancel
                        </Button>
                    </Box>
                </div >
                </form>
            </DialogContent>
        </Dialog>
    
    )
}
