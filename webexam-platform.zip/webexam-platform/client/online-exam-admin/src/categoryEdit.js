import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";


const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        width: 250,
        height:70,
        marginLeft: "10px"
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        margin: theme.spacing(3),

    },
    submitButton: {
        margin: theme.spacing(3),
    },
    table: {
        minWidth: 650,
        marginTop: theme.spacing(5)
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    TextareaAutosizeError: {
        color: '#ff1744',
        margin: 0,
        fontSize: '0.75rem',
        marginTop: '3px',
        textAlign: 'left',
        fontFamily: ['"Roboto"', '"Helvetica"', '"Arial"', 'sans-serif'],
        fontWeight: 400,
        lineHeight: 1.66,
        letterSpacing: '0.03333em'
    }
}));


export default function GradeEdit({ open, onClose, row }) {
    const classes = useStyles();
    const alert = useAlert();

    const Category_Edit_API = 'common/category';
    const appContext = useAppContext();

    const [disabled, setDisabled] = React.useState(false);
    const [name, setName] = React.useState('');
    const [nameError, setNameError] = React.useState(null);
    const [description, setDescription] = React.useState('');
    const [descriptionError, setDescriptionError] = React.useState(null);

    React.useEffect(() => {
        if(open){
            setName(row.name)
            setDescription(row.description)
        }
    }, [open]); 

    const handleNameChange = event => {
        const val = event.target.value;
        setName(val);
        let errorMsg = null;
        errorMsg = val === '' ? "Category name is required" : null;
        errorMsg = errorMsg == null ? (val.length > 100 ? "Category name length must not exceed 100 characters" : null) : errorMsg;
        setNameError(errorMsg)
    };

    const handleDescriptionChange = event => {
        const val = event.target.value;
        setDescription(val);
        let errorMsg = null;
        errorMsg = errorMsg == null ? (val.length > 255 ? "Description length must not exceed 255 characters" : null) : errorMsg;
        setDescriptionError(errorMsg)
    };

    const handleSubmit = event => {
        event.preventDefault();

        if(nameError != null || descriptionError != null){
            return;
        }

        setDisabled(true)
        updateGrade(name, description).then((result) => {
            if (!result.status) {
                alert.error(result.info.response.data.message);
            } else {
                resetInputs();
                alert.success("Category updated successfully.");
            }
            setDisabled(false)
        });
    };

    function resetInputs(){
        setName('');
        setDescription('');
        setNameError(null);
        setDescriptionError(null);
    }

    function updateGrade(title, description) {
        let data = JSON.stringify({
            name: name,
            description: description
      })
    
        return appContext.getAxios().put(Category_Edit_API+"/"+row.categoryId, data).then((response) => {
        onClose(true);
        return {status: true, info: response};
    }, (error) => {
        return {status: false, info: error};
    });
      }

    return(
        <Dialog  minWidth="sm" open={open} onClose={() =>  {resetInputs();onClose(false);}} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Edit Category</Typography>
                <IconButton size="small" className={classes.close} onClick={() =>  {resetInputs();onClose(false);}}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogContent>
                <form className={classes.form} onSubmit={handleSubmit}>
                <Grid container>
                    <Grid item sm={12} md={6} >
                    <FormControl className={classes.formControl} style={{minWidth:320, marginLeft:10 , minHeight:50}}>                   
                        <TextField
                        required
                        label="Name"
                        id="name"
                        disabled={disabled} 
                        value={name} 
                        onChange={handleNameChange} 
                        error={nameError !== null} 
                        helperText={nameError}
                        >
                        </TextField>
                    </FormControl>
                    </Grid>                      
                </Grid>
                <br></br>
                    <TextareaAutosize style={{minWidth:320, marginLeft:10 , minHeight:50}}
                                aria-label="Description" 
                                rowsMax={3} 
                                placeholder="Description" 
                                disabled={disabled} 
                                value={description} 
                                onChange={handleDescriptionChange}                                 
                    />
                    <p className={descriptionError !== null ? classes.TextareaAutosizeError : ""} id="Description-helper-text">{descriptionError}</p>
                  
                    <Box display="flex" flex={1} justifyContent="center" m={1} p={1}>
                        <Button
                            variant="contained"
                            color="secondary"
                            className={classes.submitButton}
                            type="submit"
                            disabled={disabled}
                        >
                            Update Category
                        </Button>
                        <Button
                            variant="contained"
                            className={classes.cancelButton}
                            onClick={() =>  {resetInputs();onClose(false);}}
                        >
                            cancel
                        </Button>
                    </Box>
                </form >
            </DialogContent>
        </Dialog>
    
    )
}