import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Grid } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import CloseIcon from '@material-ui/icons/Close';
import IconButton from '@material-ui/core/IconButton';
import Divider from '@material-ui/core/Divider';
import DialogActions from '@material-ui/core/DialogActions';
import useAppContext from './AppContext';
import { useAlert } from "react-alert";
import QuestionBankCreatePage from './questionBankCreate';


const useStyles = makeStyles((theme) => ({

    inputField: {
        color: theme.palette.text.secondary,
    },
    formControl: {
        minWidth: 150,
    },
    formControlTop: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    addButton: {
        margin: theme.spacing(3),
    },
    cancelButton: {
        marginRight: theme.spacing(3),

    },
    submitButton: {
        marginLeft: theme.spacing(3),
    },
    table: {
        minWidth: 50,
    },
    close: {
        position: 'absolute',
        right: theme.spacing(2),
        top: theme.spacing(2),
        color: theme.palette.grey[500]
    },
    dialog: {
        paddingTop: theme.spacing(8),
    },
    dialogActionsCenter: {
        justifyContent: "center",
        marginTop: theme.spacing(1),

    },
    dialogActionsLeft: {
        justifyContent: "left",
        marginBottom: theme.spacing(1),
        marginLeft: theme.spacing(2),
        paddingTop: 0
    },
    dialogActionsRight: {
        justifyContent: "right",
        marginBottom: theme.spacing(1),
        marginLeft: theme.spacing(2),
        paddingTop: 0
    },
    toolbar: {
        display: "flex-end"
    }
}));

export default function QuestionBankAddQuestions({ open, onClose, questionBankId }) {
    const classes = useStyles();
    const alert = useAlert();

    const QUESTIONS_LIST_API = 'question_bank/listQuestionsForQB';
    const QUESTIONS_TEMP_SAVE_API = 'question_bank/temporarySave';
    const CATEGORY_LIST_API = 'common/category';
    const GROUP_LIST_API = 'common/group';
    const LEVEL_LIST_API = 'common/level';
    const appContext = useAppContext();

    const [data, setData] = React.useState([]);
    const [categoryData, setCategoryData] = React.useState([]);
    const [groupData, setGroupData] = React.useState([]);
    const [levelData, setLevelyData] = React.useState([]);
    const [search, setSearch] = React.useState('');
    const [sort, setSort] = React.useState('question_id');
    const [sortType, setSortType] = React.useState(true);
    const [forceChange, setForceChange] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [limit, setLimit] = React.useState(5);
    const [page, setPage] = React.useState(0);
    const [cId, setCategoryId] = React.useState(0);
    const [gId, setGroupId] = React.useState(0);
    const [lId, setLevelId] = React.useState(0);
    const [questions, setQuestions] = React.useState([]);
    
    const handleSearchChange = event => {
        const val = event.target.value;
        setSearch(val);
    };

    const handleGroupChange = (event) => {
        setGroupId(event.target.value);
    };

    const handleCategoryChange = (event) => {
        setCategoryId(event.target.value);
    };

    const handleLevelChange = (event) => {
        setLevelId(event.target.value);
    };

    const handleSort = val => {
        if(sort == val){
            setSortType(!sortType)
        } else {
            setSortType(sort == val)
        }
        setSort(val);
    };

    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
  
    const handleChangeLimit = event => {
      setLimit(parseInt(event.target.value, 10));
      setPage(0);
    };

    function handleSelect(e, questionId) {
        const newQuestionIds = questions?.includes(questionId)
          ? questions?.filter(id => id !== questionId)
          : [...(questions ?? []), questionId];
        setQuestions(newQuestionIds);
        return newQuestionIds;
      }
  
    const handleAdd = e => {
        const questionIds = JSON.stringify({questionId: questions});           
        appContext.getAxios().post(QUESTIONS_TEMP_SAVE_API+"/"+questionBankId, questionIds).then((response) => {   
            onClose(response)
        }, (error) => {
            alert.error(error.response.data.message);
        });    
    };

    React.useEffect(() => {
        if(open){
            setQuestions([]);
            setData([]);
            listQuestions(questionBankId);
            listCategory();
            listGroup();
            listLevel();
        } else if(!open){
            setQuestions([]);//otherwise the data wont get cleared
            setData([]);//otherwise the data wont get cleared
        }
      }, [open, sort, sortType, page, limit, forceChange, search, cId, gId, lId]); 

      function listQuestions(questionBankId) {
          appContext.getAxios().get(QUESTIONS_LIST_API+'?questionBankId='+questionBankId+'&cId='+cId+'&gId='+gId+'&lId='+lId+'&page='+(page+1)+'&limit='+limit+'&search='+search+'&type='+sortType+'&sort='+sort).then((response) => {
              const temp = response.data.result;
              let tempQuestions = questions;
              temp.map((row) => {
                  if(row.checkedStatus){
                      tempQuestions.push(row.questionId);
                  }
              });
              setQuestions(tempQuestions)
              setData(response.data.result);
              setPage(response.data.currentPage-1)//to reset page in case deleting the last row of last page
              setCount(response.data.pagerInfo.count);
          }, (error) => {
              alert.error(error.response.data.message);
          });
      }

      function listCategory() {
          appContext.getAxios().get(CATEGORY_LIST_API).then((response) => {
              setCategoryData(response.data);
          }, (error) => {
              alert.error(error.response.data.message);
          });
      }
  
      function listGroup() {
          appContext.getAxios().get(GROUP_LIST_API).then((response) => {
              setGroupData(response.data);
          }, (error) => {
              alert.error(error.response.data.message);
          });
      }

  
      function listLevel() {
          appContext.getAxios().get(LEVEL_LIST_API).then((response) => {
              setLevelyData(response.data);
          }, (error) => {
              alert.error(error.response.data.message);
          });
      }

    return (
        <Dialog className={classes.dialog} fullWidth maxWidth="lg" open={open} onClose={() => onClose({})} aria-labelledby="add-questions-dialog-title">
            <DialogTitle id="add-videos-dialog-title" disableTypography>
                <Typography variant="h6" component="h2" gutterBottom>Add Questions</Typography>
                <IconButton size="small" className={classes.close} onClick={() => onClose({})}><CloseIcon /></IconButton>
                <Divider classes={{ root: classes.divider }} />
            </DialogTitle>
            <DialogActions>
                <Box className={classes.toolbar}>
                    {/* <Box flexGrow={1} margin={2.5} alignContent="flex-start">
                        <Link style={{ textDecoration: 'none', color: "black" }} to="/questioncreate" className={classes.btnprimary} >
                            <Button
                                variant="contained"
                                color="secondary"
                                justify="right"
                            >
                                Add Question
                            </Button>
                        </Link>
                    </Box> */}
                    <Box >
                        <FormControl className={classes.formControlTop}>
                            <TextField
                                label="Search"
                                id="titleSearch"
                                value={search} 
                                onChange={handleSearchChange} 
                            ></TextField>
                        </FormControl>
                        <FormControl className={classes.formControlTop}>
                            <InputLabel id="select-grade-label">Group</InputLabel>
                            <Select
                                labelId="select-grade-label"
                                id="select-grade"
                                value={gId} 
                                onChange={handleGroupChange}
                            >
                            <MenuItem value="0">All</MenuItem>
                            {groupData.map((row) => (
                                <MenuItem key={row.gradeId} value={row.gradeId}>{row.name}</MenuItem>
                            ))}
                            </Select>
                        </FormControl>
                        <FormControl className={classes.formControlTop}>
                            <InputLabel id="select-catagory-label">Category</InputLabel>
                            <Select
                                labelId="select-catagory-label"
                                id="select-catagory"
                                value={cId} 
                                onChange={handleCategoryChange}
                            >
                            <MenuItem value="0">All</MenuItem>
                            {categoryData.map((row) => (
                                <MenuItem key={row.categoryId} value={row.categoryId}>{row.name}</MenuItem>
                            ))}
                            </Select>
                        </FormControl>
                        <FormControl className={classes.formControlTop}>
                            <InputLabel id="select-difficulty-label">Difficulty</InputLabel>
                            <Select
                                labelId="select-difficulty-label"
                                id="select-difficulty"
                                value={lId} 
                                onChange={handleLevelChange}
                            >
                            <MenuItem value="0">All</MenuItem>
                            {levelData.map((row) => (
                                <MenuItem key={row.questionLevelId} value={row.questionLevelId}>{row.name}</MenuItem>
                            ))}
                            </Select>
                        </FormControl>
                    </Box>
                </Box>
            </DialogActions>
            <DialogContent>
                <TableContainer component={Paper} >
                    <Table className={classes.table} aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell>Select</TableCell>
                                <TableCell >Title</TableCell>
                                <TableCell >Question Bank</TableCell>
                                <TableCell >Category</TableCell>
                                <TableCell >Difficulty</TableCell>
                                <TableCell align="right">Marks</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data.map((row) => (
                                <TableRow key={row.questionId}>
                                    <TableCell padding="checkbox">
                                        <Checkbox 
                                        checked={questions.includes(row.questionId)} 
                                        onChange={(e) => handleSelect(e, row.questionId)}/>
                                    </TableCell>
                                    <TableCell component="th" scope="row">{row.title}</TableCell>
                                    <TableCell component="th" scope="row">{row.questionBank}</TableCell>
                                    <TableCell component="th" scope="row">{row.category}</TableCell>
                                    <TableCell component="th" scope="row">{row.questionLevel}</TableCell>
                                    <TableCell align="right">{row.mark}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </DialogContent>
            <DialogActions className={classes.dialogActionsCenter}>
                <Button
                    variant="contained"
                    className={classes.cancelButton}
                    onClick={() => onClose({})}
                >
                    cancel
                        </Button>
         
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.submitButton}
                    onClick={(e) => handleAdd(e) }
                >
                    Add
                </Button>
           
            </DialogActions>
        </Dialog>
    )
}